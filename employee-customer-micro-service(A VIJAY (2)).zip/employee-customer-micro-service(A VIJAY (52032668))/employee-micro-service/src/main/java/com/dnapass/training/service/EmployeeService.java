package com.dnapass.training.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dnapass.training.entity.EmployeeEntity;
import com.dnapass.training.entity.OfficeEntity;
import com.dnapass.training.exception.ApplicationException;
import com.dnapass.training.repo.EmployeeRepo;
import com.dnapass.training.repo.OfficeRepo;

@Service
public class EmployeeService {

	@Autowired
	private EmployeeRepo empRepo;

	@Autowired
	private OfficeRepo offRepo;

	public EmployeeEntity addEmployee(EmployeeEntity employee) throws ApplicationException {

		List<EmployeeEntity> employeesList = empRepo.findAll();

		Optional<EmployeeEntity> existEmployee = employeesList.stream().filter(emp -> emp.equals(employee)).findFirst();
		if (existEmployee.isPresent()) {
			throw new ApplicationException("Employee Already exists");
		}
		EmployeeEntity newEmpl = empRepo.save(employee);

		return newEmpl;
	}

	public EmployeeEntity findEmployeeById(Long id) {

		Optional<EmployeeEntity> employee = empRepo.findById(id);

		return employee.get();

	}

	public List<EmployeeEntity> findEmployees() {

		List<EmployeeEntity> employessList = empRepo.findAll();

		return employessList;
	}

	public EmployeeEntity addEmployeeOffice(OfficeEntity office, Long id) {
		Optional<EmployeeEntity> employee = empRepo.findById(id);
		employee.get().setOffices(office);
		return empRepo.save(employee.get());
	}

	/// No needed///////////////////////////////
	public OfficeEntity addEmployeeOffice(EmployeeEntity emp, String officeId) {
		Optional<OfficeEntity> office = offRepo.findAll().stream().filter(off -> off.getOfficeCode().equals(officeId))
				.findFirst();
		if (office.isPresent()) {
			EmployeeEntity employee = empRepo.save(emp);
			employee.setOffices(office.get());

		}
		return office.get();
	}

}
