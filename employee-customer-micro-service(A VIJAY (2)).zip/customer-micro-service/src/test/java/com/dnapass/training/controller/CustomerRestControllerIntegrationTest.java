package com.dnapass.training.controller;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.io.IOException;
import java.util.List;

import org.junit.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.dnapass.training.entities.CustomerEntity;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@RunWith(SpringRunner.class)
@SpringBootTest
@AutoConfigureMockMvc
@Rollback(false)
@TestInstance(Lifecycle.PER_CLASS)
public class CustomerRestControllerIntegrationTest {
	@Autowired
	private MockMvc mvc;

	@Test
	public void contextLoads() throws Exception {

		assertThat(mvc).isNotNull();
	}

	@Test
	public void getCustomerList() throws Exception {
		String uri = "/customersList";
		MvcResult mvcResult = mvc.perform(MockMvcRequestBuilders.get(uri).accept(MediaType.APPLICATION_JSON_VALUE))
				.andReturn();

		int status = mvcResult.getResponse().getStatus();
		assertEquals(200, status);
		String content = mvcResult.getResponse().getContentAsString();
		System.out.println("content :: " + content);

	}

	@Test
	public void getOfficeList() throws Exception {
		String uri = "/paymentsList";
		MvcResult mvcResult = mvc.perform(MockMvcRequestBuilders.get(uri).accept(MediaType.APPLICATION_JSON_VALUE))
				.andReturn();

		int status = mvcResult.getResponse().getStatus();
		assertEquals(200, status);
		String content = mvcResult.getResponse().getContentAsString();
		System.out.println("content :: " + content);

	}

	@Test
	public void saveCustomer() throws Exception {
		String uri = "/customers";
		CustomerEntity customerEntity = new CustomerEntity(null, "++", "Vijay", "Peter", "03 9520 4555",
				"636 St Kilda Road", "Level 3", "Melbourne", "Victoria", "3004", "Australia", "117300.00", 4l);
		String inputJson = mapToJson(customerEntity);
		MvcResult mvcResult = mvc.perform(
				MockMvcRequestBuilders.post(uri).contentType(MediaType.APPLICATION_JSON_VALUE).content(inputJson))
				.andReturn();
		System.out.println("mvcResult>>>>>>>>>>>>>>>>>>>>>>>>>" + mvcResult.getResponse().getStatus());
		int status = mvcResult.getResponse().getStatus();
		System.out.println(">>>>>>>>>>>>>>>>>>>>>>>>>" + status);
		assertEquals(201, status);
		String content = mvcResult.getResponse().getContentAsString();
		System.out.println("content ::>>>>>>>>>>>>>>>>>>>>>>>> " + content);
		CustomerEntity emp = mapFromJson(content, CustomerEntity.class);
		assertNotNull(emp);

		System.out.println("customer created :: >>>>>>>>>>>>>>>>>>>>> " + emp);

	}

	@Test
	public void getCustomerById() throws Exception {
		String uri = "/customers/1";
		MvcResult mvcResult = mvc.perform(MockMvcRequestBuilders.get(uri).accept(MediaType.APPLICATION_JSON_VALUE))
				.andReturn();

		int status = mvcResult.getResponse().getStatus();
		System.out.println(status);
		assertEquals(200, status);
		String content = mvcResult.getResponse().getContentAsString();
		System.out.println("content :: >>>>>>>>>>>>getCustomer>>>>>>>>>>>>>>" + content);

	}

	@Test
	public void getPayment() throws Exception {
		String uri = "/customers/HQ336336/1";
		MvcResult mvcResult = mvc.perform(MockMvcRequestBuilders.get(uri).accept(MediaType.APPLICATION_JSON_VALUE))
				.andReturn();

		int status = mvcResult.getResponse().getStatus();
		System.out.println(status);
		assertEquals(200, status);
		String content = mvcResult.getResponse().getContentAsString();
		System.out.println("content :: >>>>>>>>>>>>GET Office>>>>>>>>>>>>>>" + content);

	}

	private CustomerEntity mapFromJson2(String content, TypeReference<CustomerEntity> typeReference)
			throws JsonMappingException, JsonProcessingException {
		ObjectMapper objectMapper = new ObjectMapper();
		objectMapper.setSerializationInclusion(Include.NON_NULL);
		return objectMapper.readValue(content, typeReference);
	}

	protected String mapToJson(Object obj) throws JsonProcessingException {
		ObjectMapper objectMapper = new ObjectMapper();
		objectMapper.setSerializationInclusion(Include.NON_NULL);
		return objectMapper.writeValueAsString(obj);
	}

	protected <T> T mapFromJson(String Json, Class<T> clazz)
			throws JsonParseException, JsonMappingException, IOException {
		ObjectMapper objectMapper = new ObjectMapper();
		objectMapper.setSerializationInclusion(Include.NON_NULL);
		return objectMapper.readValue(Json, clazz);
	}

	private List<CustomerEntity> mapFromJson(String content, TypeReference<List<CustomerEntity>> typeReference)
			throws JsonMappingException, JsonProcessingException {

		ObjectMapper objectMapper = new ObjectMapper();
		objectMapper.setSerializationInclusion(Include.NON_NULL);
		return objectMapper.readValue(content, typeReference);
	}
}
