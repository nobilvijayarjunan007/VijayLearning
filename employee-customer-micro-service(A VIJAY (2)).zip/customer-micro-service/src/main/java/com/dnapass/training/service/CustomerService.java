package com.dnapass.training.service;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dnapass.training.entities.CustomerEntity;
import com.dnapass.training.entities.PaymentEntity;
import com.dnapass.training.exception.ApplicationException;
import com.dnapass.training.repo.CustomerRepo;

@Service
public class CustomerService {

	@Autowired
	private CustomerRepo custRepo;

	public CustomerEntity addCustomer(CustomerEntity cust) throws ApplicationException {
		List<CustomerEntity> customersList = custRepo.findAll();
		Optional<CustomerEntity> existCustomer = customersList.stream().filter(c -> c.equals(cust)).findFirst();
		if (existCustomer.isPresent()) {
			throw new ApplicationException("Customer Already exists");
		}
		CustomerEntity newCust = custRepo.save(cust);

		return newCust;
	}

	public CustomerEntity findCustomerById(Long id) {

		Optional<CustomerEntity> cust = custRepo.findById(id);

		return cust.get();

	}

	public List<CustomerEntity> findCustomer() {

		List<CustomerEntity> employessList = custRepo.findAll();

		return employessList;
	}

	public CustomerEntity addCustomerPayment(PaymentEntity payment, Long custId) {
		Optional<CustomerEntity> customer = custRepo.findById(custId);
		customer.get().setPayments(Arrays.asList(payment));
		return custRepo.save(customer.get());
	}

}
