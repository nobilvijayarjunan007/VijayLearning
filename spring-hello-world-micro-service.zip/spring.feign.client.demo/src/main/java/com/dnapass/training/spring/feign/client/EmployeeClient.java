package com.dnapass.training.spring.feign.client;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@FeignClient(value = "employees", url = "${feign.url}", fallback = EmployeeClientFallback.class)
public interface EmployeeClient {
	@RequestMapping(method = RequestMethod.GET, value = "/api/employees")
	List<Employee> getEmployees();

	@RequestMapping(method = RequestMethod.PUT, value = "/api/employees/{id}", consumes = "application/json")
	Employee update(@PathVariable("id") Long id, Employee employee);

	@RequestMapping(method = RequestMethod.POST, value = "/api/employees", consumes = "application/json")
	Employee create(Employee employee);

	@RequestMapping(method = RequestMethod.DELETE, value = "/api/employees/{id}", consumes = "application/json")
	void delete(@PathVariable("id") Long id);

}