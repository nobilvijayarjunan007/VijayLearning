package com.dnapass.training.spring.feign.client;

import feign.Response;
import feign.codec.ErrorDecoder;

public class CustomErrorDecoder implements ErrorDecoder {

	public Exception decode(String methodcKey, Response response) {

		switch (response.status()) {
		case 400:
			return new BadRequestException();
		case 404:
			return new NotFoundException();
		default:
			return new Exception("Generic error");
		}
	}
}
