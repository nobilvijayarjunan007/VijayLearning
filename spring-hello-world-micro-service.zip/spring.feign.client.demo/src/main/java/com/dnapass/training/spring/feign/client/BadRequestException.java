package com.dnapass.training.spring.feign.client;

public class BadRequestException extends Exception {

}
