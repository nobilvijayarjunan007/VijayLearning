package com.dnapass.training.spring.feign.client;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component
class EmployeeClientExample implements CommandLineRunner {
	@Autowired
	private EmployeeClient employeeClient;
	
	@Override
	public void run(String... strings)throws Exception {
		System.out.println("===========find all==============");
		this.employeeClient.getEmployees().stream().forEach(System.out::println);
		Employee create = this.employeeClient.create(new Employee(102, "employee created", "dept1", "location1"));
		System.out.println(create);
		this.employeeClient.getEmployees().stream().forEach(System.out::println);
		System.out.println("==========update=========");
		Employee update = this.employeeClient.update(1l, new Employee(1, "employee1 updated", "dept1", "location1"));
		System.out.println(update);
		System.out.println(" =========find all=========");
		this.employeeClient.getEmployees().stream().forEach(System.out::println);
		System.out.println(" ========delete========");
		this.employeeClient.delete(1l);
		System.out.println(" =============find all==============");
		this.employeeClient.getEmployees().stream().forEach(System.out::println);
	}

	
}


