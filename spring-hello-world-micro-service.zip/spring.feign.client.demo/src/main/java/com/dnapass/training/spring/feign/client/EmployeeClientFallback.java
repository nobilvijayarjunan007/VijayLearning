package com.dnapass.training.spring.feign.client;

import java.util.List;

import org.springframework.stereotype.Component;

@Component
public class EmployeeClientFallback implements EmployeeClient {

	public List<Employee> getEmployees() {
		return null;
	}

	public Employee update(Long id, Employee employee) {
		return null;
	}

	public Employee create(Employee employee) {
		return null;
	}

	public void delete(Long id) {

	}
}