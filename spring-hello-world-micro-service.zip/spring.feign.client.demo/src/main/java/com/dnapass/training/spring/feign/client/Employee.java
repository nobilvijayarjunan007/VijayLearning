package com.dnapass.training.spring.feign.client;

import java.util.Date;

public class Employee {

	private Integer empId;
	private String empName;
	private String empDept;
	private String empLocation;
	private Date hireDate;

	public Employee(Integer empId, String empName, String empDept, String empLocation) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.empDept = empDept;
		this.empLocation = empLocation;
	}

	public Employee() {

	}

	public Integer getEmpId() {
		return empId;
	}

	public void setEmpId(Integer empId) {
		this.empId = empId;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public String getEmpDept() {
		return empDept;
	}

	public void setEmpDept(String empDept) {
		this.empDept = empDept;
	}

	public String getEmpLocation() {
		return empLocation;
	}

	public void setEmpLocation(String empLocation) {
		this.empLocation = empLocation;
	}

	public Date getHireDate() {
		return hireDate;
	}

	public void setHireDate(Date hireDate) {
		this.hireDate = hireDate;
	}

	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empName=" + empName + ", empDept=" + empDept + ", empLocation="
				+ empLocation + "]";
	}

}
