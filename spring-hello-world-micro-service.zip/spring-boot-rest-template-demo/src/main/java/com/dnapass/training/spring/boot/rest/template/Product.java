package com.dnapass.training.spring.boot.rest.template;

public class Product {

	
	
}
