package com.dnapass.training.spring.boot.rest.template;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

public class EmployeeConsumerService {
	private static final String RESOURCE_PATH = "http://localhost:8080/api/employees";

	@Autowired
	private RestTemplate restTemplate;

	@Autowired
	public EmployeeConsumerService(RestTemplateBuilder restTemplateBuilder) {

		restTemplate = restTemplateBuilder.errorHandler(new RestTemplateResponseErrorHandler()).build();
	}

	public String getPlainJson() {

		ResponseEntity<String> response = restTemplate.getForEntity(RESOURCE_PATH, String.class);
		return response.getBody();
	}

	public List<Employee> getPojo() {

		List<Employee> response = restTemplate.getForObject(RESOURCE_PATH, List.class);
		return response;
	}

	public Employee postEmployee() {
		HttpEntity<Employee> request = new HttpEntity<>(new Employee(101, "employee1post", "dept1", "location1"));
		Employee employee = restTemplate.postForObject(RESOURCE_PATH, request, Employee.class);

		return employee;

	}

	public ResponseEntity<Employee> postEmployeeExchange() {

		HttpEntity<Employee> request = new HttpEntity<>(
				new Employee(101, "employee1postexchange", "dept1", "location1"));

		ResponseEntity<Employee> employee = restTemplate.exchange(RESOURCE_PATH, HttpMethod.POST, request,
				Employee.class);

		return employee;

	}

	public ResponseEntity<Employee> putEmployeeExchange() {
		String uri = RESOURCE_PATH + "/1";

		HttpEntity<Employee> request = new HttpEntity<>(new Employee(101, "employee1 updated", "dept1", "location1"));

		ResponseEntity<Employee> employee = restTemplate.exchange(uri, HttpMethod.PUT, request, Employee.class);

		return employee;

	}

	public void deleteEmployee() {

		String uri = RESOURCE_PATH + "/1";
		restTemplate.delete(uri);

	}
}
