package com.dnapass.training.spring.boot.rest.template;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import antlr.collections.List;

@RestController
public class EmployeeRestClient {

	private static final String RESOURCE_PATH = "http://localhost:8080/api/employees";

	@Autowired
	private RestTemplate restTemplate;

	// http://localhost:8081/getJson
	@GetMapping("/getJson")
	public String getPlainJson() {
		ResponseEntity<String> response = restTemplate.getForEntity(RESOURCE_PATH, String.class);
		return response.getBody();

	}

	@GetMapping("/getPojo")
	public List getPojo() {
		List response = restTemplate.getForObject(RESOURCE_PATH, List.class);
		return response;
	}

	@GetMapping("/postEmployee")
	public Employee postEmployee() {
		HttpEntity<Employee> request = new HttpEntity<>(new Employee(101, "emp1Post", "dept1", "location1"));
		Employee employee = restTemplate.postForObject(RESOURCE_PATH, request, Employee.class);

		return employee;

	}

	@GetMapping("/postEmployeeExchange")
	public ResponseEntity<Employee> postEmployeeExchange() {
		HttpEntity<Employee> request = new HttpEntity<>(new Employee(101, "emp1PostExchange", "dept1", "location1"));
		ResponseEntity<Employee> employee = restTemplate.exchange(RESOURCE_PATH, HttpMethod.POST, request,
				Employee.class);

		return employee;

	}

	@GetMapping("/putEmployeeExchange")
	public ResponseEntity<Employee> putEmployeeExchange() {
		String uri = RESOURCE_PATH + "/1";
		System.out.println("Put Employee Exchange started");
		HttpEntity<Employee> request = new HttpEntity<>(new Employee(101, "emp1 Updated", "dept1", "location1"));
		ResponseEntity<Employee> employee = restTemplate.exchange(uri, HttpMethod.PUT, request, Employee.class);

		return employee;

	}

	@GetMapping("/deleteEmployee")
	public void deleteEmployee() {
		String uri = RESOURCE_PATH + "/1";
		restTemplate.delete(uri);
	}

}
