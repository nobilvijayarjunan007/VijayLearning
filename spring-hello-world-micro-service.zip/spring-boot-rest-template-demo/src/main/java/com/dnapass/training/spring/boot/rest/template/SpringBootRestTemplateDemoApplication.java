package com.dnapass.training.spring.boot.rest.template;

import java.time.Duration;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.ClientHttpRequestFactory;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import antlr.collections.List;

@SpringBootApplication
@RestController

public class SpringBootRestTemplateDemoApplication {
	//private static final String RESOURCE_PATH = "http://localhost:8080/api/employees";

	public static void main(String[] args) {
		SpringApplication.run(SpringBootRestTemplateDemoApplication.class, args);
	}

	//@Bean
	// @LoadBalanced
	public RestTemplate restTemplateBean1() {
		return new RestTemplate(getClientHttpRequestFactory());
		// return new RestTemplate();
	}

	public ClientHttpRequestFactory getClientHttpRequestFactory() {
		int timeout = 5000;
		HttpComponentsClientHttpRequestFactory clientHttpRequestFactory = new HttpComponentsClientHttpRequestFactory();
		clientHttpRequestFactory.setConnectTimeout(timeout);

		return clientHttpRequestFactory;
	}

	@Bean
	public RestTemplate restTemplate(RestTemplateBuilder builder) {
		return builder.setConnectTimeout(Duration.ofMillis(3000)).setReadTimeout(Duration.ofMillis(3000)).build();
	}

//	@Autowired
//
//	private RestTemplate restTemplate;
//
//	// http://localhost:8081/getJson
//	@GetMapping("/getJson")
//	public String getPlainJson() {
//		ResponseEntity<String> response = restTemplate.getForEntity(RESOURCE_PATH, String.class);
//		return response.getBody();
//
//	}
//
//	@GetMapping("/getJson")
//	public List getPojo() {
//		List response = restTemplate.getForObject(RESOURCE_PATH, List.class);
//		return response;
//	}
//
//	@GetMapping("postEmployee")
//	public Employee postEmployee() {
//		HttpEntity<Employee> request = new HttpEntity<>(new Employee(101, "emp1Post", "dept1", "location1"));
//		Employee employee = restTemplate.postForObject(RESOURCE_PATH, request, Employee.class);
//
//		return employee;
//
//	}
//
//	@GetMapping("postEmployeeExchange")
//	public ResponseEntity<Employee> postEmployeeExchange() {
//		HttpEntity<Employee> request = new HttpEntity<>(new Employee(101, "emp1PostExchange", "dept1", "location1"));
//		ResponseEntity<Employee> employee = restTemplate.exchange(RESOURCE_PATH, HttpMethod.POST, request,
//				Employee.class);
//
//		return employee;
//
//	}
//
//	@GetMapping("putEmployeeExchange")
//	public ResponseEntity<Employee> putEmployeeExchange() {
//		HttpEntity<Employee> request = new HttpEntity<>(new Employee(101, "emp1 Updated", "dept1", "location1"));
//		ResponseEntity<Employee> employee = restTemplate.exchange(RESOURCE_PATH, HttpMethod.PUT, request,
//				Employee.class);
//
//		return employee;
//
//	}
//
//	@GetMapping("deleteEmployee")
//	public void deleteEmployee() {
//		String uri = RESOURCE_PATH + "/1";
//		restTemplate.delete(uri);
//	}

}
