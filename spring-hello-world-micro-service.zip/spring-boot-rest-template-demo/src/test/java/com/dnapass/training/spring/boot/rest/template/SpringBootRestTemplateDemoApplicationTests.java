package com.dnapass.training.spring.boot.rest.template;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootRestTemplateDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
