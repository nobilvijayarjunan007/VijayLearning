package com.dnapass.training.spring.boot.helloworld;

import java.util.stream.IntStream;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.cloud.client.ServiceInstance;
import org.springframework.cloud.client.loadbalancer.LoadBalancerClient;
import org.springframework.stereotype.Component;

@Component
public class SpringLoadBalancerExample implements CommandLineRunner {

	@Autowired
	private LoadBalancerClient loadBalancer;

	public void run(String... strings) throws Exception {

		IntStream.range(1, 100).forEach(i -> {
			ServiceInstance instance = loadBalancer.choose("hello-micro-service");
			System.out.println("=============================" + i);
			System.out.println("RibbonLoadBalancerExample :" + ToStringBuilder.reflectionToString(instance));

		});

//		ServiceInstance serviceInstance = loadBalancer.choose("employee-producer");
//		
//		System.out.println(serviceInstance.getUri());
//		String baseUrl = serviceInstance.getUri().toString();
//		baseUrl = baseUrl + "/employee";
//
//		RestTemplate restTemplate = new RestTemplate();
//		ResponseEntity<String> response = null;
//		try {
//			response = restTemplate.exchange(baseUrl, HttpMethod.GET, null, String.class);
//
//		} catch (Exception ex) {
//			System.out.println(ex);
//		}
//
//		System.out.println(response.getBody());

	}

}
