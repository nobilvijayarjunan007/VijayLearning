package com.dnapass.training.spring.boot.helloworld;

import java.util.stream.IntStream;

import javax.swing.Spring;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.cloud.netflix.ribbon.RibbonClient;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.context.annotation.Bean;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@SpringBootApplication
@EnableEurekaClient
@RestController
@EnableFeignClients
@RibbonClient(name = "gateway-service", configuration = RibbonConfiguration.class)
public class SpringHelloWorldMicroServiceApplication {

	// @Autowired
	private RestTemplate helloRestClient;

	@Autowired
	private WorldClient worldFeignClient;

	public static void main(String[] args) {
		SpringApplication.run(SpringHelloWorldMicroServiceApplication.class, args);
	}

	@GetMapping("/helloworld")
	public String getHelloWorld() {
		StringBuilder stringBuilder = new StringBuilder();

		IntStream.range(1, 100).forEach(i -> {
			ResponseEntity<Spring> response = helloRestClient.getForEntity("http://gateway-service/hello3",
					Spring.class);

			ResponseEntity<String> world = worldFeignClient.getWorldEntity();

			stringBuilder.append(response.getBody() + " " + world.getBody() + "\n<br>");

		});

		return stringBuilder.toString();

	}

	@LoadBalanced
	@Bean
	public RestTemplate restTemplate(RestTemplateBuilder builder) {
		// addition config need
		
		return  builder.build();
	}

}
