package com.dnapass.training.spring.boot.helloworld;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@FeignClient(name = "${feign.name}")
public interface WorldClient {
	@RequestMapping(method = RequestMethod.GET, value = "/world")
	String getWorld();

	@RequestMapping(method = RequestMethod.GET, value = "/world")
	ResponseEntity<String> getWorldEntity();

}
