package com.dnapass.training.spring.boot.helloworld;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringHelloWorldMicroServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
