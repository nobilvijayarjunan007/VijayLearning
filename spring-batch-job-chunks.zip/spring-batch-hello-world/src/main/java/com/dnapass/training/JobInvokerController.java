package com.dnapass.training;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class JobInvokerController {

	@Autowired(required = true)
	JobLauncher jobLauncher;

	@Autowired(required = true)
	Job helloWorldBatchJob;

	@Autowired(required = true)
	Job personTaskletBatchJob;

	@RequestMapping("/invokeJobs")
	public String handle() throws Exception {

		JobParameters jobParameters = new JobParametersBuilder().addLong("time", System.currentTimeMillis())
				.toJobParameters();

		JobExecution execution = jobLauncher.run(helloWorldBatchJob, jobParameters);
		return execution.toString();
		// return null;
	}

	//

	@RequestMapping("/invokePersonTasklet")
	public String invokePersonTaskLet() throws Exception {

		JobParameters jobParameters = new JobParametersBuilder().addLong("time", System.currentTimeMillis())
				.toJobParameters();

		JobExecution execution = jobLauncher.run(personTaskletBatchJob, jobParameters);
		return execution.toString();
		// return null;
	}
}
