package com.dnapass.training.spring.batch.jobtasklet;

import java.util.List;

import org.jboss.logging.Logger;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.batch.repeat.RepeatStatus;

public class PersonLinesWriter implements Tasklet, StepExecutionListener {
	private final Logger logger = Logger.getLogger(PersonLinesWriter.class.getName());

	private List<PersonLine> lines;

	private FileUtils fu;

	@Override
	public void beforeStep(StepExecution stepExecution) {
		ExecutionContext executionContext = stepExecution.getJobExecution().getExecutionContext();
		this.lines = (List<PersonLine>) executionContext.get("lines");
		fu = new FileUtils("person-out.csv");
		logger.info("Lines Writer initialised");
	}

	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
		//if (lines != null)
			for (PersonLine line : lines) {
				fu.writeLine(line);
				logger.info("Wrote line" + line.toString());
			}
		return RepeatStatus.FINISHED;
	}

	@Override
	public ExitStatus afterStep(StepExecution stepExecution) {
		fu.closeWriter();
		logger.info("Lines Writer ended.");
		return ExitStatus.COMPLETED;
	}

}
