package com.dnapass.training.spring.batch.jobtasklet;

import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.temporal.ChronoUnit;
import java.util.List;

import org.jboss.logging.Logger;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.batch.repeat.RepeatStatus;

public class PersonLinesProcessor implements Tasklet, StepExecutionListener {
	private final Logger logger = Logger.getLogger(PersonLinesProcessor.class.getName());

	private List<PersonLine> lines;

	@Override
	public void beforeStep(StepExecution stepExecution) {
		ExecutionContext executionContext = stepExecution.getJobExecution().getExecutionContext();
		this.lines = (List<PersonLine>) executionContext.get("lines");
		logger.info("Lines Processor initialised");
	}

	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
		// if (lines != null)
		for (PersonLine line : lines) {
			// if (line != null) {
			LocalDate localDate = Instant.ofEpochMilli(line.getDob().getTime()).atZone(ZoneId.systemDefault())
					.toLocalDate();

			long age = ChronoUnit.YEARS.between(localDate, LocalDate.now());
			logger.info("Calculated age " + age + "for line" + line.toString());
			line.setAge(age);
		}
		return RepeatStatus.FINISHED;

	}

	@Override
	public ExitStatus afterStep(StepExecution stepExecution) {
		logger.info("Lines Processor ended");

		return ExitStatus.COMPLETED;
	}

}
