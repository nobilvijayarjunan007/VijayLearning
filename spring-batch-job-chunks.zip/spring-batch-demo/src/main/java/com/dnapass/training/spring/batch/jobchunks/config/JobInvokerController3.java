package com.dnapass.training.spring.batch.jobchunks.config;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class JobInvokerController3 {

	@Autowired(required = true)
	JobLauncher jobLauncher;

	@Autowired(required = true)
	Job chunksJob;

	@RequestMapping("/invokeChunkJob")
	public String invokePersonTaskLet() throws Exception {

		JobParameters jobParameters = new JobParametersBuilder().addLong("time", System.currentTimeMillis())
				.toJobParameters();

		JobExecution execution = jobLauncher.run(chunksJob, jobParameters);
		return execution.toString();

	}
}
