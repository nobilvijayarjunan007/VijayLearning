package com.dnapass.training.spring.batch.transactionjob.config;

import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.transform.FieldSet;

public class TransactionFieldSetMapper implements FieldSetMapper<Transaction> {

	@Override
	public Transaction mapFieldSet(FieldSet fieldSet) throws org.springframework.validation.BindException {

		Transaction transaction = new Transaction();
		System.out.println(fieldSet);
		transaction.setId(fieldSet.readInt(0));
		System.out.println(fieldSet.readString(1));
		transaction.setType(ProductType.valueOf(fieldSet.readString(1)));
		transaction.setAmount(fieldSet.readDouble(2));
		transaction.setCity(fieldSet.readString(3));
		transaction.setCurrency(fieldSet.readString(4));

		return transaction;
	}

}
