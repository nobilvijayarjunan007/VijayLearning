package com.dnapass.training.spring.batch.transactionjob.config;

public enum ProductType {

	FRUIT,GROCERY,FUEL,ELECTRIC
}
