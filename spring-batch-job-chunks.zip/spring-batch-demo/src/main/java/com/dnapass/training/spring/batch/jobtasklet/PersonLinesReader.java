package com.dnapass.training.spring.batch.jobtasklet;

import java.util.ArrayList;
import java.util.List;

import org.jboss.logging.Logger;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;

public class PersonLinesReader implements Tasklet, StepExecutionListener {

	private final Logger logger = Logger.getLogger(PersonLinesReader.class.getName());

	private List<PersonLine> lines;
	private FileUtils fu;

	@Override
	public void beforeStep(StepExecution stepExecution) {
		lines = new ArrayList<>();
		fu = new FileUtils("person-input.csv");
		logger.info("Lines Reader initialised.");

	}

	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
		PersonLine line = fu.readLine();
		while (line != null) {
			lines.add(line);
			logger.info("Read line: " + line.toString());
			line = fu.readLine();
		}

		return RepeatStatus.FINISHED;
	}

	@Override
	public ExitStatus afterStep(StepExecution stepExecution) {
		fu.closeReader();
		stepExecution.getJobExecution().getExecutionContext().put("lines", this.lines);
		logger.info("Lines Reader ended.");
		return ExitStatus.COMPLETED;
	}

}
