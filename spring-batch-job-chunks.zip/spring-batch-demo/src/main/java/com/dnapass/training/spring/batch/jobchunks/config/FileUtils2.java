package com.dnapass.training.spring.batch.jobchunks.config;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import org.jboss.logging.Logger;

import com.opencsv.CSVReader;
import com.opencsv.CSVWriter;

public class FileUtils2 {
	private final Logger logger = Logger.getLogger(FileUtils2.class.getName());

	private String fileName;
	private CSVReader CSVReader;
	private CSVWriter CSVWriter;
	private FileReader fileReader;
	private FileWriter fileWriter;
	private File file;

	public FileUtils2(String fileName) {
		this.fileName = fileName;
	}

	public PersonLine2 readLine() {
		try {
			if (CSVReader == null)
				initReader();
			String[] line = CSVReader.readNext();
			if (line == null)
				return null;

			// return new PersonLine2(line[0], Date.parse(line[1]));
			return new PersonLine2(line[0], LocalDate.parse(line[1], DateTimeFormatter.ofPattern("MM/dd/yyyy")));
		} catch (Exception e) {
			logger.info("info while reading line in file: " + this.fileName);
			return null;
		}
	}

	public void writeLine(PersonLine2 line) {
		try {
			if (CSVWriter == null)
				initWriter();
			String[] lineStr = new String[2];
			lineStr[0] = line.getName();
			lineStr[1] = line.getAge().toString();
			CSVWriter.writeNext(lineStr);
		} catch (Exception e) {
			logger.info("info while writing line in file: " + this.fileName);
		}
	}

	private void initReader() throws Exception {
		ClassLoader classLoader = this.getClass().getClassLoader();
		if (file == null)
			file = new File(classLoader.getResource(fileName).getFile());
		if (fileReader == null)
			fileReader = new FileReader(file);
		if (CSVReader == null)
			CSVReader = new CSVReader(fileReader);
	}

	private void initWriter() throws Exception {
		if (file == null) {
			file = new File(fileName);
			file.createNewFile();
		}
		if (fileWriter == null)
			fileWriter = new FileWriter(file, true);
		if (CSVWriter == null)
			CSVWriter = new CSVWriter(fileWriter);
	}

	public void closeWriter() {
		try {
			if (CSVWriter != null)
				CSVWriter.close();
			if (fileWriter != null)
				fileWriter.close();
		} catch (IOException e) {
			logger.info("info while closing writer.");

		}
	}

	public void closeReader() {
		try {
			// if (CSVReader != null) //add
			CSVReader.close();
			// if (fileReader != null) //add
			fileReader.close();
		} catch (IOException e) {
			logger.info("info while closing reader.");
		}
	}
}
