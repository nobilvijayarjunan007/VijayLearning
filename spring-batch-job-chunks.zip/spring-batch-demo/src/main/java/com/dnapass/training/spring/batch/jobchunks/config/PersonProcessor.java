package com.dnapass.training.spring.batch.jobchunks.config;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

import org.jboss.logging.Logger;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.batch.item.ItemProcessor;

import com.dnapass.training.spring.batch.jobtasklet.PersonLinesProcessor;

public class PersonProcessor implements ItemProcessor<PersonLine2, PersonLine2>, StepExecutionListener {

	private final Logger logger = Logger.getLogger(PersonLinesProcessor.class.getName());

	@Override
	public void beforeStep(StepExecution stepExecution) {
		logger.info("Line Processor initialized.");

	}

	@Override
	public PersonLine2 process(PersonLine2 line) throws Exception {
		long age = ChronoUnit.YEARS.between(line.getDob(), LocalDate.now());
		logger.info("Calculated age " + age + " for line " + line.toString());
		line.setAge(age);
		return line;
	}

	@Override
	public ExitStatus afterStep(StepExecution stepExecution) {
		logger.info("Line Processor ended.");
		return ExitStatus.COMPLETED;
	}

}
