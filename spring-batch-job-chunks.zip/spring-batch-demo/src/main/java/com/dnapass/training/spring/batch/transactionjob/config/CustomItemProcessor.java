package com.dnapass.training.spring.batch.transactionjob.config;

import org.springframework.batch.item.ItemProcessor;

public class CustomItemProcessor implements ItemProcessor<Transaction, Transaction> {

	@Override
	public Transaction process(Transaction item) throws Exception {
		
		return null;
	}
}
