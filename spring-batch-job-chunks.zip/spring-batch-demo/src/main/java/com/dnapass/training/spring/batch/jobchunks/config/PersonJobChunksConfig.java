package com.dnapass.training.spring.batch.jobchunks.config;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
@EnableBatchProcessing
public class PersonJobChunksConfig {

	@Autowired
	private JobBuilderFactory jobs;

	@Autowired
	private StepBuilderFactory steps;

	// @Bean
	protected Step createProcessLinesStep(ItemReader<PersonLine2> reader,
			ItemProcessor<PersonLine2, PersonLine2> processor, ItemWriter<PersonLine2> writer) {
		return steps.get("processLines1").<PersonLine2, PersonLine2>chunk(2).reader(reader).processor(processor)
				.writer(writer).build();
	}

	//@Bean(name = "chunksJob")//
	public Job job() {
		return jobs.get("chunksJob")
				.start(createProcessLinesStep(new PersonReader(), new PersonProcessor(), new PersonWriter())).build();
	}
}
