package com.dnapass.training.spring.batch.jobtasklet;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
@EnableBatchProcessing
public class PersonJobTaskletConfig {

	@Autowired
	private JobBuilderFactory jobs;
	@Autowired
	private StepBuilderFactory steps;

	 //@Bean
	protected Step readLines() {
		return steps.get("readLines").tasklet(new PersonLinesReader()).build();
	}

	// @Bean
	protected Step processLines() {
		return steps.get("processLines").tasklet(new PersonLinesProcessor()).build();
	}

	 //@Bean
	protected Step writeLines() {
		return steps.get("writeLines").tasklet(new PersonLinesWriter()).build();
	}

	//@Bean(name = "personTaskletBatchJob")//
	public Job job() {

		return jobs.get("personTaskletBatchJob").start(readLines()).next(processLines()).next(writeLines()).build();
	}

}
