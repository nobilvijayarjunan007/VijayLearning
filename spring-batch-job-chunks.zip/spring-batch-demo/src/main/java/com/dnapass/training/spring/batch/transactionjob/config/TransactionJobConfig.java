package com.dnapass.training.spring.batch.transactionjob.config;

import java.net.MalformedURLException;

import javax.sql.DataSource;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.ParseException;
import org.springframework.batch.item.UnexpectedInputException;
import org.springframework.batch.item.database.BeanPropertyItemSqlParameterSourceProvider;
import org.springframework.batch.item.database.JdbcBatchItemWriter;
import org.springframework.batch.item.database.builder.JdbcBatchItemWriterBuilder;
import org.springframework.batch.item.file.FlatFileItemReader;
//import org.springframework.batch.item.file.FlatFileItemWriter;
import org.springframework.batch.item.file.mapping.DefaultLineMapper;
import org.springframework.batch.item.file.transform.DelimitedLineTokenizer;
import org.springframework.batch.item.xml.StaxEventItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.Resource;
import org.springframework.oxm.Marshaller;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;

@Configuration
@EnableBatchProcessing
public class TransactionJobConfig {

	@Autowired
	private JobBuilderFactory jobs;

	@Autowired
	private StepBuilderFactory steps;

	@Value("classpath :transactions.csv")
	private Resource inputCsv;

	@Value("file:src/main/resource/xml/transactions1.xml")
	private Resource outputXml;

//@Bean
	public ItemReader<Transaction> itemReader() throws UnexpectedInputException, ParseException {
		FlatFileItemReader<Transaction> reader = new FlatFileItemReader<Transaction>();
		DelimitedLineTokenizer tokenizer = new DelimitedLineTokenizer();
		String[] tokens = { "id", "type", "amount", "city", "currency" };
		tokenizer.setNames(tokens);
		reader.setResource(inputCsv);
		DefaultLineMapper<Transaction> lineMapper = new DefaultLineMapper<Transaction>();
		lineMapper.setLineTokenizer(tokenizer);
		lineMapper.setFieldSetMapper(new TransactionFieldSetMapper());
		reader.setLineMapper(lineMapper);
		return reader;
	}

//@Bean
	public ItemProcessor<Transaction, Transaction> itemProcessor() {
		return new CustomItemProcessor();
	}

//@Bean
	public ItemWriter<Transaction> itemwriter(Marshaller marshaller) throws MalformedURLException {
		StaxEventItemWriter<Transaction> itemwriter = new StaxEventItemWriter<Transaction>();
		itemwriter.setMarshaller(marshaller);
		itemwriter.setRootTagName("transactions");
		itemwriter.setResource(outputXml);
		return itemwriter;
	}

//@Bean
	public Marshaller marshaller() {
		Jaxb2Marshaller marshaller = new Jaxb2Marshaller();
		marshaller.setClassesToBeBound(new Class[] { Transaction.class });
		return marshaller;

	}

	// @Bean
	protected Step step1(ItemReader<Transaction> reader, ItemProcessor<Transaction, Transaction> processor,
			ItemWriter<Transaction> writer) {
		return steps.get("steps").<Transaction, Transaction>chunk(10).reader(reader).processor(processor).writer(writer)
				.build();
	}

	//@Bean(name = "transactionsBatchJob")//
	public Job job() throws UnexpectedInputException, ParseException, MalformedURLException {
		return jobs.get("firstBatchJob").start(step1(itemReader(), itemProcessor(), itemwriter(marshaller()))).build();

	}

    //@Bean//
	public JdbcBatchItemWriter<Transaction> writer(DataSource dataSource) {
		return new JdbcBatchItemWriterBuilder<Transaction>()
				.itemSqlParameterSourceProvider(new BeanPropertyItemSqlParameterSourceProvider<>())
				.sql("INSERT INTO transaction (id,type,amount,city,currency)VALUES(:id,:type,:city,:amount,:currency)")
				.dataSource(dataSource).build();
	}
}
