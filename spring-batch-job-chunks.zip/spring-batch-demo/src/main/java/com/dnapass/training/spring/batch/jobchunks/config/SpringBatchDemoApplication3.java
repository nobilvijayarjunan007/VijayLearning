package com.dnapass.training.spring.batch.jobchunks.config;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class SpringBatchDemoApplication3 {

	public static void main(String[] args) {
		SpringApplication.run(SpringBatchDemoApplication3.class, args);
	}

	//@Bean
	public CommandLineRunner demo3(JobLauncher jobLauncher, Job chunksJob) {
		return (args) -> {
			System.out.println("Starting the batch job");
			try {
				JobExecution execution = jobLauncher.run(chunksJob, new JobParameters());
				System.out.println("Job Status : " + execution.getStatus());
				System.out.println("Job Completed");

			} catch (Exception e) {
				e.printStackTrace();
				System.out.println("Job failed");

			}
		};
	}
}
