package com.dnapass.training;

import java.util.logging.Logger;

import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.NonTransientResourceException;
import org.springframework.batch.item.ParseException;
import org.springframework.batch.item.UnexpectedInputException;

public class PersonReader implements ItemReader<PersonLine2>, StepExecutionListener {

	private final Logger logger = Logger.getLogger(PersonReader.class.getName());

	private FileUtils2 fu;

	@Override
	public void beforeStep(StepExecution stepExceution) {
		fu = new FileUtils2("persons-chunks-input.csv");
		logger.info("Line Reader initialised.");
	}

	@Override
	public PersonLine2 read()
			throws Exception, UnexpectedInputException, ParseException, NonTransientResourceException {
		PersonLine2 line = fu.readLine();
		if (line != null)
			logger.info("Read line: " + line.toString());
		return line;
	}

	@Override
	public ExitStatus afterStep(StepExecution stepExecution) {
		fu.closeReader();
		logger.info("Line Reader ended.");
		return ExitStatus.COMPLETED;
	}

}
