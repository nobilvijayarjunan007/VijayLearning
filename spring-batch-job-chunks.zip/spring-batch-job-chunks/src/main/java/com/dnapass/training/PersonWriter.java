package com.dnapass.training;

import java.util.List;
import java.util.logging.Logger;

import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.batch.item.ItemWriter;



public class PersonWriter implements ItemWriter<PersonLine2>, StepExecutionListener {

	private final Logger logger = Logger.getLogger(PersonWriter.class.getName());

	private FileUtils2 fu;

	@Override
	public void beforeStep(StepExecution stepExecution) {
		fu = new FileUtils2("person-chunks-output.csv");
		logger.info("Line writer initialized.");
	}

	@Override
	public void write(List<? extends PersonLine2> lines) throws Exception {
		for (PersonLine2 line : lines) {
			fu.writeLine(line);
			logger.info("Wrote line " + line.toString());
		}
	}

	@Override
	public ExitStatus afterStep(StepExecution stepExecution) {
		fu.closeWriter();
		logger.info("Line writer ended.");
		return ExitStatus.COMPLETED;
	}
}
