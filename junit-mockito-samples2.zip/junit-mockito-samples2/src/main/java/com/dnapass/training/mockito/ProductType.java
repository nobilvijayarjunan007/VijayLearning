package com.dnapass.training.mockito;

public enum ProductType {

	FRUIT,GROCERY,FUEL,ELECTRIC
}
