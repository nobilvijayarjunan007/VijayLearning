package com.dnapass.training.mockito;

public class TransactionNotFoundException extends RuntimeException{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public TransactionNotFoundException(Integer id) {
		// TODO Auto-generated constructor stub
	}

	public TransactionNotFoundException() {
		// TODO Auto-generated constructor stub
	}

}
