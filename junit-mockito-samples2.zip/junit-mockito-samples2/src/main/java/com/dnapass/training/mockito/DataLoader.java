package com.dnapass.training.mockito;

import java.util.ArrayList;
import java.util.List;

public class DataLoader {

	public static List<TransactionsEntity> newTransactionEntities() {

		List<TransactionsEntity> transactions = new ArrayList<TransactionsEntity>();

		transactions.add(new TransactionsEntity(null, ProductType.FRUIT, 45.55, "Chennai", "INR"));
		transactions.add(new TransactionsEntity(null, ProductType.GROCERY, 252.22, "london", "GBP"));
		transactions.add(new TransactionsEntity(null, ProductType.ELECTRIC, 20.99, "bangalore", "USD"));
		transactions.add(new TransactionsEntity(null, ProductType.FRUIT, 68.22, "Chennai", "INR"));
		transactions.add(new TransactionsEntity(null, ProductType.FUEL, 90.34, "london", "GBP"));
		transactions.add(new TransactionsEntity(null, ProductType.ELECTRIC, 150.56, "bangalore", "USD"));
		transactions.add(new TransactionsEntity(null, ProductType.GROCERY, 456.99, "Chennai", "INR"));
		transactions.add(new TransactionsEntity(null, ProductType.FUEL, 451.55, "bangalore", "USD"));
		return transactions;
	}

	public static List<Transaction> newTransactions() {

		List<Transaction> transactions = new ArrayList<Transaction>();

		transactions.add(new Transaction(1, ProductType.FRUIT, 45.55, "Chennai", "INR"));
		transactions.add(new Transaction(2, ProductType.GROCERY, 252.22, "london", "GBP"));
		transactions.add(new Transaction(3, ProductType.ELECTRIC, 20.99, "bangalore", "USD"));
		transactions.add(new Transaction(4, ProductType.FRUIT, 68.22, "Chennai", "INR"));
		transactions.add(new Transaction(5, ProductType.FUEL, 90.34, "london", "GBP"));
		transactions.add(new Transaction(6, ProductType.ELECTRIC, 150.56, "bangalore", "USD"));
		transactions.add(new Transaction(7, ProductType.GROCERY, 456.99, "Chennai", "INR"));
		transactions.add(new Transaction(8, ProductType.FUEL, 451.55, "bangalore", "USD"));
		return transactions;
	}
}
