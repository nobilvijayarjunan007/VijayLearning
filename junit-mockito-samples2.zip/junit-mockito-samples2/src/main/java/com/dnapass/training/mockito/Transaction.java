package com.dnapass.training.mockito;

import java.util.Objects;

public class Transaction {
	protected Integer id;

	protected ProductType type;

	protected Double amount;

	protected String city;

	protected String currency;

	protected String invoiceNo;

	public Transaction() {
		super();
	}

	public Transaction(Integer id, ProductType type, Double amount, String city, String currency) {
		super();
		this.id = id;
		this.type = type;
		this.amount = amount;
		this.city = city;
		this.currency = currency;
	}

	public Transaction(Integer id, ProductType type, Double amount, String city, String currency, String invoiceNo) {
		super();
		this.id = id;
		this.type = type;
		this.amount = amount;
		this.city = city;
		this.currency = currency;
		this.invoiceNo = invoiceNo;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public ProductType getType() {
		return type;
	}

	public void setType(ProductType type) {
		this.type = type;
	}

	public Double getAmount() {
		return amount;
	}

	public void setAmount(Double amount) {
		this.amount = amount;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public String getInvoiceNo() {
		return invoiceNo;
	}

	public void setInvoiceNo(String invoiceNo) {
		this.invoiceNo = invoiceNo;
	}

	@Override
	public int hashCode() {
		return Objects.hash(amount, city, currency, id, invoiceNo, type);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Transaction other = (Transaction) obj;
		return Objects.equals(amount, other.amount) && Objects.equals(city, other.city)
				&& Objects.equals(currency, other.currency) && Objects.equals(id, other.id)
				&& Objects.equals(invoiceNo, other.invoiceNo) && type == other.type;
	}

	@Override
	public String toString() {
		return "Transaction [id=" + id + ", type=" + type + ", amount=" + amount + ", city=" + city + ", currency="
				+ currency + ", invoiceNo=" + invoiceNo + "]";
	}

}
