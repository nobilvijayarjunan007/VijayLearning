package com.dnapass.training.mockito;

import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component
public class TransactionLoader implements CommandLineRunner {

	public final TransactionsRepo repository;

	public TransactionLoader(TransactionsRepo repository) {
		this.repository = repository;
	}

	@Override
	public void run(String... args) throws Exception {

		loadtrans();
	}

	private void loadtrans() {

		if (repository.count() == 0) {
			repository.saveAll(DataLoader.newTransactionEntities());

			System.out.println("Sample transaction Loaded");
		}

	}
}
