package com.dnapass.training;

import java.util.List;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import com.dnapass.training.mockito.TransactionsEntity;
import com.dnapass.training.mockito.TransactionsRepo;

@SpringBootApplication
public class JunitMockitoSamples2Application {

	public static void main(String[] args) {
		SpringApplication.run(JunitMockitoSamples2Application.class, args);
	}

	@Bean
	public CommandLineRunner transactionsService1(TransactionsRepo tranrepo) {

		System.out.println("+++++++++++++++++++++++++++++++++++++++++++++");
		return arg -> {

			List<TransactionsEntity> findAll = tranrepo.findAll();
			findAll.stream().forEach(System.out::println);

		};
	}
}
