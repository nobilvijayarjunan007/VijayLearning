package com.dnapass.training.mockito;

import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Pageable;

public interface ITransactionService {
	Transaction createTransaction(Transaction transaction) throws ApplicationException;

	void deleteTransaction(Transaction transaction) throws ApplicationException;

	void deleteTransaction(int id) throws ApplicationException;

	Transaction updateTransaction(Transaction transaction) throws ApplicationException;

	boolean findTransaction(Transaction transaction) throws ApplicationException;

	Transaction findTransactionByIndex(int index) throws ApplicationException;

	Transaction findTransactionById(int id) throws ApplicationException;

	List<Transaction> findTransactionByProductType(ProductType name) throws ApplicationException;

	List<Transaction> findTransactionByProductTypeAndAmount(ProductType name, Double amount)
			throws ApplicationException;

	List<Transaction> findTransactionByProductTypeAmountAndCity(ProductType name, Double amount, String city)
			throws ApplicationException;

	List<Transaction> getTransactions();

	List<Transaction> findTransactionByPageNo(Pageable page);

}
