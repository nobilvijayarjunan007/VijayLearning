package com.dnapass.training.mockito;

import static org.assertj.core.api.Assertions.assertThat;

import java.io.IOException;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import org.junit.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@RunWith(SpringRunner.class)
@SpringBootTest
@AutoConfigureMockMvc
@Rollback(false)
@TestInstance(Lifecycle.PER_CLASS)
public class TransactionRestControllerInegrationTest2 {

	@Autowired
	private MockMvc mvc;

	@Test
	public void contextLoads() throws Exception {
		System.out.println("++++++++++++++++++++++++++++++++++++ contextLoads()++++++++++++++++++++++++++++++++");

		assertThat(mvc).isNotNull();

	}

	@Test

	public void getTransactionList() throws Exception {
		System.out
				.println("++++++++++++++++++++++++++++++++++++ getTransactionList() ++++++++++++++++++++++++++++++++");

		String uri = "/api/v1/transactions";
		MvcResult mvcResult = mvc.perform(MockMvcRequestBuilders.get(uri).accept(MediaType.APPLICATION_JSON_VALUE))
				.andReturn();

		int status = mvcResult.getResponse().getStatus();
		assertEquals(200, status);
		String content = mvcResult.getResponse().getContentAsString();
		System.out.println(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>.content :: " + content);
		List<Transaction> tranList = mapFromJson(content, new TypeReference<List<Transaction>>() {
		});
		tranList.stream().forEach(System.out::println);
		// assertTrue(tranList.size() == 8);
		assertEquals(8, tranList.size());

		System.out.println("getTransactionList () :: " + tranList);
	}

	@Test
	public void createTransaction() throws Exception {
		System.out.println("++++++++++++++++++++++++++++++++++++ createTransaction() ++++++++++++++++++++++++++++++++");

		String uri = "/api/v1/transactions";
		Transaction employee = new Transaction(150, ProductType.FRUIT, 457.55, "Chennai", "INR");
		String inputJson = mapToJson(employee);
		MvcResult mvcResult = mvc.perform(
				MockMvcRequestBuilders.post(uri).contentType(MediaType.APPLICATION_JSON_VALUE).content(inputJson))
				.andReturn();

		int status = mvcResult.getResponse().getStatus();
		assertEquals(201, status);
		String content = mvcResult.getResponse().getContentAsString();
		System.out.println("content :: " + content);
		Transaction tran = mapFromJson(content, Transaction.class);
		assertNotNull(tran);

		System.out.println("tran created :: " + tran);

	}

	@Test
	public void updateTransaction() throws Exception {
		System.out.println("++++++++++++++++++++++++++++++++++++ updateTransaction() ++++++++++++++++++++++++++++++++");

		String uri = "/api/v1/update";
		Transaction transaction = new Transaction(1, ProductType.ELECTRIC, 5555.99, "Mumbai", "INR");
		String inputJson = mapToJson(transaction);
		MvcResult mvcResult = mvc.perform(
				MockMvcRequestBuilders.put(uri).contentType(MediaType.APPLICATION_JSON_VALUE).content(inputJson))
				.andReturn();

		int status = mvcResult.getResponse().getStatus();
		System.out.println("content updated :: " + mvcResult.getResponse());
		assertEquals(200, status);
		String content = mvcResult.getResponse().getContentAsString();
		Transaction tran = mapFromJson(content, Transaction.class);
		assertNotNull(tran);
		assertEquals("Mumbai", tran.getCity());

		System.out.println("tran1 updated :: " + tran);

	}

	@Test
	public void deleteTransaction() throws Exception {
		System.out.println("++++++++++++++++++++++++++++++++++++ deleteTransaction() ++++++++++++++++++++++++++++++++");

		String uri = "/api/v1/transaction/2";

		MvcResult mvcResult = mvc.perform(MockMvcRequestBuilders.delete(uri)).andReturn();
		int status = mvcResult.getResponse().getStatus();
		assertEquals(204, status);
		String content = mvcResult.getResponse().getContentAsString();
		System.out.println("tran deleted :: " + content);
	}

	@Test

	public void getTransactionbyIndex() throws Exception {
		System.out.println(
				"++++++++++++++++++++++++++++++++++++ getTransactionbyIndex() ++++++++++++++++++++++++++++++++");

		String uri = "/api/v1/index?index=1";
		MvcResult mvcResult = mvc.perform(MockMvcRequestBuilders.get(uri).accept(MediaType.APPLICATION_JSON_VALUE))
				.andReturn();

		int status = mvcResult.getResponse().getStatus();
		System.out.println("getTransactionbyIndex+++++++++++++++++++==" + status);
		assertEquals(200, status);
		String content = mvcResult.getResponse().getContentAsString();
		System.out.println(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>.content :: " + content);
		Transaction tran = mapFromJson2(content, new TypeReference<Transaction>() {
		});
		System.out.println(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>.tran :: " + tran);

		assertEquals("USD", tran.getCurrency());

	}

	@Test

	public void getTransactionListByProduct() throws Exception {
		System.out.println(
				"++++++++++++++++++++++++++++++++++++ getTransactionListByProduct() ++++++++++++++++++++++++++++++++");

		String uri = "/api/v1/Product/ELECTRIC";
		MvcResult mvcResult = mvc.perform(MockMvcRequestBuilders.get(uri).accept(MediaType.APPLICATION_JSON_VALUE))
				.andReturn();

		int status = mvcResult.getResponse().getStatus();
		assertEquals(200, status);
		String content = mvcResult.getResponse().getContentAsString();
		System.out.println(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>.content :: " + content);
		List<Transaction> tranList = mapFromJson(content, new TypeReference<List<Transaction>>() {
		});
		tranList.stream().forEach(System.out::println);
		// assertTrue(tranList.size() == 8);
		assertEquals(2, tranList.size());

		System.out.println("getTransactionListBYProduct () :: " + tranList);
	}

	private Transaction mapFromJson2(String content, TypeReference<Transaction> typeReference)
			throws JsonMappingException, JsonProcessingException {
		ObjectMapper objectMapper = new ObjectMapper();
		objectMapper.setSerializationInclusion(Include.NON_NULL);
		return objectMapper.readValue(content, typeReference);
	}

	protected String mapToJson(Object obj) throws JsonProcessingException {
		ObjectMapper objectMapper = new ObjectMapper();
		objectMapper.setSerializationInclusion(Include.NON_NULL);
		return objectMapper.writeValueAsString(obj);
	}

	protected <T> T mapFromJson(String Json, Class<T> clazz)
			throws JsonParseException, JsonMappingException, IOException {
		ObjectMapper objectMapper = new ObjectMapper();
		objectMapper.setSerializationInclusion(Include.NON_NULL);
		return objectMapper.readValue(Json, clazz);
	}

	private List<Transaction> mapFromJson(String content, TypeReference<List<Transaction>> typeReference)
			throws JsonMappingException, JsonProcessingException {

		ObjectMapper objectMapper = new ObjectMapper();
		objectMapper.setSerializationInclusion(Include.NON_NULL);
		return objectMapper.readValue(content, typeReference);
	}
}
