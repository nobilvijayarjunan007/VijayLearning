package com.dnapass.training;


import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JunitMockitoSamples2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
