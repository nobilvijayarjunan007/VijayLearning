package com.dnapass.training.entity;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "users")
public class UserEntity implements Serializable {

	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "user_id")
	private Long id;
	@Column(name = "name")
	private String name;

	private LocalDate creationDate;

	private LocalDate lastLogInDate;

	private Integer age;

	private boolean active;
	@Column(unique = true, nullable = false)
	private String email;

	public UserEntity() {
		super();
	}
	
	

	public UserEntity(Long id, String name, LocalDate creationDate, LocalDate lastLogInDate, Integer age,
			boolean active, String email) {
		super();
		this.id = id;
		this.name = name;
		this.creationDate = creationDate;
		this.lastLogInDate = lastLogInDate;
		this.age = age;
		this.active = active;
		this.email = email;
	}



	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public LocalDate getCreationDate() {
		return creationDate;
	}

	public void setCreationDate(LocalDate creationDate) {
		this.creationDate = creationDate;
	}

	public LocalDate getLastLogInDate() {
		return lastLogInDate;
	}

	public void setLastLogInDate(LocalDate lastLogInDate) {
		this.lastLogInDate = lastLogInDate;
	}

	public Integer getAge() {
		return age;
	}

	public void setAge(Integer age) {
		this.age = age;
	}

	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	@Override
	public int hashCode() {
		return Objects.hash(active, age, creationDate, email, id, lastLogInDate, name);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		UserEntity other = (UserEntity) obj;
		return active == other.active && Objects.equals(age, other.age)
				&& Objects.equals(creationDate, other.creationDate) && Objects.equals(email, other.email)
				&& Objects.equals(id, other.id) && Objects.equals(lastLogInDate, other.lastLogInDate)
				&& Objects.equals(name, other.name);
	}

	@Override
	public String toString() {
		return "UserEntity [id=" + id + ", name=" + name + ", creationDate=" + creationDate + ", lastLogInDate="
				+ lastLogInDate + ", age=" + age + ", active=" + active + ", email=" + email + "]";
	}
	
	

}
