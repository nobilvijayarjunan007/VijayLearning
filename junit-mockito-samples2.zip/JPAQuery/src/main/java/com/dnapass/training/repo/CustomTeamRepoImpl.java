
package com.dnapass.training.repo;

import javax.persistence.EntityManager;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.dnapass.training.entity.TeamEntity;

@Repository
public class CustomTeamRepoImpl implements CustomTeamRepo {
	public static final String SELECT_T_FROM_TEAM_AS_T_WHERE_T_ID_ID = "SELECT t FROM Team AS t WHERE t.id =:id";

	@Autowired
	private EntityManager entityManager;

	@Override
	public TeamEntity findByJPQL5(Long id) {

		return entityManager.createNamedQuery("findByJPQL5", TeamEntity.class).setParameter("id", id).getSingleResult();

	}

	public TeamEntity findByJPQL1(Long id) {
		return entityManager.createQuery(SELECT_T_FROM_TEAM_AS_T_WHERE_T_ID_ID, TeamEntity.class).setParameter("id", id)
				.getSingleResult();
	}

}
