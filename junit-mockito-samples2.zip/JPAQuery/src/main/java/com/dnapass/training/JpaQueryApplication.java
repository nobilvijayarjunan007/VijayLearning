package com.dnapass.training;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import com.dnapass.training.dataloader.DataLoader;
import com.dnapass.training.dataloader.DataLoader2;
import com.dnapass.training.entity.CartEntity;
import com.dnapass.training.entity.ItemsEntity;
import com.dnapass.training.entity.LeagueEntity;
import com.dnapass.training.entity.PlayerEntity;
import com.dnapass.training.entity.TeamEntity;
import com.dnapass.training.entity.UserEntity;
import com.dnapass.training.repo.CartRepo;
import com.dnapass.training.repo.CustomCartRepoImpl;
import com.dnapass.training.repo.CustomTeamRepo;
import com.dnapass.training.repo.CustomTeamRepo2;
import com.dnapass.training.repo.CustomTeamRepo2Impl;
import com.dnapass.training.repo.ItemsRepo;
import com.dnapass.training.repo.LeagueRepo;
import com.dnapass.training.repo.PlayerRepo;
import com.dnapass.training.repo.TeamRepo;
import com.dnapass.training.repo.UserRepo;
import com.dnapass.training.service.UserService;

@SpringBootApplication
public class JpaQueryApplication {

	@Autowired
	TeamRepo teamRepo;
	@Autowired
	PlayerRepo playerRepo;
	@Autowired
	LeagueRepo leagueRepo;
	@Autowired
	UserRepo userRepo;
	@Autowired
	ItemsRepo itemRepo;
	@Autowired
	CartRepo cartRepo;
	@Autowired
	CustomCartRepoImpl customCartImplRepo;
	@Autowired
	CustomTeamRepo2Impl customCartRepo2Impl;
	@Autowired
	CustomTeamRepo customTeamRepo;
	@Autowired
	CustomTeamRepo2 customTeamRepo2;

	public static void main(String[] args) {
		SpringApplication.run(JpaQueryApplication.class, args);

	}

	//@Bean
	public CommandLineRunner userService1(UserService userService) {
		System.out.println("+++++++++++++++++++++++++++++++++++++++++++++");
		return arg -> {

			List<UserEntity> users = new ArrayList<>();

			users.add(new UserEntity(null, "user1", LocalDate.of(2000, 05, 03), LocalDate.of(1997, 04, 04), 24, true,
					"xyz1@gmail.com"));
			users.add(new UserEntity(null, "user2", LocalDate.of(2001, 06, 04), LocalDate.of(1998, 03, 05), 30, true,
					"xyz2@gmail.com"));
			users.add(new UserEntity(null, "user3", LocalDate.of(2002, 07, 05), LocalDate.of(1999, 02, 12), 18, false,
					"xyz3@gmail.com"));
			users.add(new UserEntity(null, "user4", LocalDate.of(2000, 05, 03), LocalDate.of(1997, 04, 04), 24, true,
					"xyz4@gmail.com"));
			users.add(new UserEntity(null, "user5", LocalDate.of(2001, 06, 04), LocalDate.of(1998, 03, 05), 30, true,
					"xyz5@gmail.com"));
			users.add(new UserEntity(null, "user6", LocalDate.of(2002, 07, 05), LocalDate.of(1999, 02, 12), 18, false,
					"xyz6@gmail.com"));

			userRepo.saveAll(users);

			List<String> names = Arrays.asList("user1", "user3");

			// criteria query
			List<UserEntity> findItemsbyNames = userService.findUsersbyNames(names);
			System.out.println("findItemsbyNames >>>" + findItemsbyNames);

			// Native query

			List<UserEntity> findAllUsers = userRepo.findAllUsers();
			System.out.println("findAllUsers >>>" + findAllUsers);

			List<UserEntity> findUsersByAge = userRepo.findUsersByAge();
			System.out.println("findUsersByAge >>>" + findUsersByAge);

			Long countNumberOfUserActive = userRepo.countNumberOfUserActive();
			System.out.println("countNumberOfUserActive >>>" + countNumberOfUserActive);

			// List<UserEntity> findUsersInName=userRepo.findUsersInName();
			// System.out.println("findUsersInName >>>" + findUsersInName);

		};
	}

	// @Bean
	public CommandLineRunner cartRepository() {
		System.out.println("+++++++++++++++++++++++++++++++++++++++++++++");
		return arg -> {

			List<CartEntity> carts = DataLoader.newCartEntities();

			cartRepo.saveAll(carts);

			// Custom JPQL

			System.out.println("Cart before save :: " + carts.get(0));
			System.out.println("Cart before save :: " + carts.get(1));
			CartEntity cart = cartRepo.save(carts.get(0));
			System.out.println("Cart after save :: " + cart);

			CartEntity cart2 = cartRepo.save(carts.get(1));
			System.out.println("Cart after save :: " + cart2);

			cart.getItems().add(new ItemsEntity(null, "itemsname10", 40, 400d));
			cart = cartRepo.save(cart);
			System.out.println("cart after name updated :: " + cart);
			System.out.println("+++++++++++++++++++++++++++++++++++++++++++++");

			CartEntity cart3 = customCartImplRepo.findByJPQL1(1l);
			// Optional<CartEntity> cart = repository.findByJPQL(1l);

			System.out.println("cart :: " + cart3);

			// ++++++++++++++++Criteria Query+++++++++++++++++++++++

			List<ItemsEntity> items = new ArrayList<>();
			items.add(new ItemsEntity(null, "pen", 100, 333.99));
			items.add(new ItemsEntity(null, "pencil", 10, 255.99));
			items.add(new ItemsEntity(null, "Marker", 230, 255.99));
			items.add(new ItemsEntity(null, "pencil", 150, 897.99));

			itemRepo.saveAll(items);
			List<String> asList = Arrays.asList("pen", "pencil");

			List<String> names = new ArrayList<>(asList);

			List<ItemsEntity> findItemsbyNames = customCartImplRepo.findItemsbyNames(names);
			System.out.println(" criteria method : >>>" + findItemsbyNames);

		};

	}

	@Bean
	public CommandLineRunner teamService1() {
		System.out.println("+++++++++++++++++++teamService1()++++++++++++++++++++++++++");

		return arg -> {
			System.out.println("++++++++++++++++++teamService1()+++++++++++++++++++++++++++");
			teamRepo.saveAll(DataLoader.newTeam());
			// JPQL
			System.out.println("+++++++++++++++++++++JPQL query++++++++++++++++++++++++++");

			List<TeamEntity> allTeam = teamRepo.getAllTeam();
			allTeam.stream().forEach(System.out::println);

			List<TeamEntity> findTeamByNameJPQL = teamRepo.findTeamByNameJPQL("CSK");
			System.out.println("findTeamByNameJPQL : " + findTeamByNameJPQL);

			List<TeamEntity> findTeamByCityJPQL = teamRepo.findTeamByCityJPQL("Mumbai");
			System.out.println("findTeamByCityJPQL : " + findTeamByCityJPQL);

			List<TeamEntity> findTeamByNameAndCityJPQL = teamRepo.findTeamByNameAndCityJPQL("CSK", "Chennai");
			System.out.println("findTeamByNameAndCityJPQL : " + findTeamByNameAndCityJPQL);

			List<TeamEntity> findTeamByNameOrCityJPQL = teamRepo.findTeamByNameOrCityJPQL("CSK", "Mumbai");
			System.out.println("findTeamByNameOrCityJPQL : " + findTeamByNameOrCityJPQL);

			// wrong output
			List<TeamEntity> findTeamInCity = teamRepo.findTeamInCity("America");
			System.out.println("findTeamInCity >>>>>>>>>>>>>>>>>>: " + findTeamInCity);

			// wrong output
			List<TeamEntity> findTeamNotInCity = teamRepo.findTeamNotInCity("Chennai");
			System.out.println("findTeamNotInCity >>>>>>>>>>>>>>>>>>: " + findTeamNotInCity);

			Long findMaxId = teamRepo.findMaxId();
			System.out.println("findMaxId : " + findMaxId);

			Long findMinId = teamRepo.findMinId();
			System.out.println("findMinId : " + findMinId);

			TeamEntity findMaxIdTeam = teamRepo.findMaxIdTeam();
			System.out.println("findMaxIdTeam : " + findMaxIdTeam);

			TeamEntity findMinIdTeam = teamRepo.findMinIdTeam();
			System.out.println("findMinIdTeam : " + findMinIdTeam);

			// Auto Query
			System.out.println("+++++++++++++++++++++Auto query++++++++++++++++++++++++++");

			List<TeamEntity> findTeamByNameAuto = teamRepo.findTeamByName("MI");
			System.out.println("findTeamByNameAuto : " + findTeamByNameAuto);

			List<TeamEntity> findTeamByCityAuto = teamRepo.findTeamByCity("Chennai");
			System.out.println("findTeamByCityAuto : " + findTeamByCityAuto);

			List<TeamEntity> findTeamByNameAndCityAuto = teamRepo.findTeamByNameAndCity("CSK", "Chennai");
			System.out.println("findTeamByNameAndCityAuto : " + findTeamByNameAndCityAuto);

			List<TeamEntity> findTeamByNameOrCityAuto = teamRepo.findTeamByNameOrCity("DC", "Kolkatta");
			System.out.println("findTeamByNameOrCityAuto : " + findTeamByNameOrCityAuto);

			// Criteria query

			List<TeamEntity> findAllbyUsingCriteria = customTeamRepo2.findAllbyUsingCriteria();
			System.out.println("+++++++++++++++++++++Criteria query++++++++++++++++++++++++++");
			findAllbyUsingCriteria.stream().forEach(System.out::println);

			// TeamEntity findTeamByNameUsingCriteria =
			// customTeamRepo.findTeamByNameUsingCriteria("CSK");
			// System.out.println("findTeamByNameUsingCriteria : " +
			// findTeamByNameUsingCriteria);
		};

	}

	// @Bean
	public CommandLineRunner playerService1() {

		System.out.println("+++++++++++++++++++++playerService1()++++++++++++++++++++++++");
		return arg -> {
			System.out.println("+++++++++++++++++++playerService1()++++++++++++++++++++++++++");
			teamRepo.saveAll(DataLoader.newTeam());

			// +++++++++++++++++++JPQL+++++++++++++++++++

			List<PlayerEntity> allPlayer = playerRepo.getAllPlayer();
			allPlayer.stream().forEach(System.out::println);

			// by name and position
			PlayerEntity player = playerRepo.findPlayerByNameAndPositionJPQL("Dhoni", "Captain");
			System.out.println("findPlayerByNameAndPositionJPQL : " + player);
			// by name
			PlayerEntity findPlayerByNameJPQL = playerRepo.findPlayerByNameJPQL("Jedeja");
			System.out.println("findPlayerByNameJPQL : " + findPlayerByNameJPQL);
			// by position
			List<PlayerEntity> findPlayersByPositionJPQL = playerRepo.findPlayersByPositionJPQL("FirstOffplayer");
			System.out.println("findPlayersByPositionJPQL : " + findPlayersByPositionJPQL);
			// greater than or equal to
			List<PlayerEntity> findPlayersBySalaryJPQL = playerRepo.findPlayersBySalaryJPQL(500.0);
			System.out.println("findPlayersBySalaryJPQL : " + findPlayersBySalaryJPQL);

			// +++++++++++++++++++Automatic query+++++++++++++++++++

			// by name and position
			PlayerEntity findPlayerByNameAndPosition = playerRepo.findPlayerByNameAndPosition("Dhoni", "Captain");
			System.out.println("findPlayerByNameAndPositionAuto : " + findPlayerByNameAndPosition);
			// by name
			PlayerEntity findPlayerByName = playerRepo.findPlayerByName("Jedeja");
			System.out.println("findPlayerByNameAuto : " + findPlayerByName);
			// by position
			List<PlayerEntity> findPlayersByPosition = playerRepo.findPlayersByPosition("Captain");
			System.out.println("findPlayersByPositionAuto : " + findPlayersByPosition);
			// by salary
			List<PlayerEntity> findPlayersBySalary = playerRepo.findPlayersBySalary(500.0);
			System.out.println("findPlayersBySalaryAuto : " + findPlayersBySalary);

		};

	}

	// @Bean
	public CommandLineRunner leagueService1() {

		System.out.println("+++++++++++++++++++leagueService1()++++++++++++++++++++++++++");
		return arg -> {
			System.out.println("+++++++++++++++++++leagueService1()++++++++++++++++++++++++++");
			teamRepo.saveAll(DataLoader.newTeam());

			// JPQL

			List<LeagueEntity> byNameJPQL = leagueRepo.getByNameJPQL("ICC Match");
			System.out.println("byNameJPQL : " + byNameJPQL);

			List<LeagueEntity> bydTypeJPQL = leagueRepo.getByDTypeJPQL(" IPL Final");
			System.out.println("bydTypeJPQL : " + bydTypeJPQL);

			List<LeagueEntity> bySportJPQL = leagueRepo.getBySportJPQL("Cricket");
			System.out.println("bySportJPQL : " + bySportJPQL);

			// Automatic Query

			List<LeagueEntity> byName = leagueRepo.getByName("ICC Match");
			System.out.println("byNameAuto : " + byName);

			List<LeagueEntity> bydType = leagueRepo.getBydType(" IPL Final");
			System.out.println("bydTypeAuto : " + bydType);

			List<LeagueEntity> bySport = leagueRepo.getBySport("Cricket");
			System.out.println("bySportAuto : " + bySport);

		};

	}

	// @Bean
	public CommandLineRunner teamRepository(TeamRepo repo, PlayerRepo repo2) {

		System.out.println("+++++++++++++++++++++++++++++++++++++++++++++");
		return arg -> {
			repo.saveAll(DataLoader.newTeam());

			// +++++++++++++++++++++ Team +++++++++++++++++++++++++

			// JPQL

			List<TeamEntity> allTeam = repo.getAllTeam();
			allTeam.stream().forEach(System.out::println);

			// Custom Query go to

			/*
			 * TeamEntity team = repo.findByJPQL5(1l);
			 * 
			 * System.out.println("team" + Optional.ofNullable(team));
			 */

			// +++++++++++++++++++++ player +++++++++++++++++++++++++

			// JPQL

			List<PlayerEntity> allPlayer = repo2.getAllPlayer();
			allPlayer.stream().forEach(System.out::println);

			PlayerEntity player = playerRepo.findPlayerByNameAndPositionJPQL("Dhoni", "Captain");
			System.out.println("findPlayerByNameAndPositionJPQL : " + player);

			// Automatic query
			PlayerEntity findPlayerByNameAndPosition = playerRepo.findPlayerByNameAndPosition("Dhoni", "Captain");

			System.out.println("findPlayerByNameAndPositionAuto : " + findPlayerByNameAndPosition);

			// ++++++++++++++++++++++ league +++++++++++++++++++++++++

			// JPQL
			List<LeagueEntity> byNameJPQL = leagueRepo.getByNameJPQL("ICC Match");
			System.out.println("byNameJPQL : " + byNameJPQL);

			List<LeagueEntity> bydTypeJPQL = leagueRepo.getByDTypeJPQL(" ICC ODI Final");
			System.out.println("bydTypeJPQL : " + bydTypeJPQL);

			List<LeagueEntity> bySportJPQL = leagueRepo.getBySportJPQL("Cricket");
			System.out.println("bySportJPQL : " + bySportJPQL);

			// Automatic Query
			List<LeagueEntity> byName = leagueRepo.getByName("ICC Match");
			System.out.println("byNameAuto : " + byName);

			List<LeagueEntity> bydType = leagueRepo.getBydType(" ICC ODI Final");
			System.out.println("bydTypeAuto : " + bydType);

			List<LeagueEntity> bySport = leagueRepo.getBySport("Cricket");

			System.out.println("bySportAuto : " + bySport);

		};

	}

	// @Bean
	public CommandLineRunner teamService2() {
		System.out.println("+++++++++++++++++++++++++++++++++++++++++++++");

		return arg -> {
			System.out.println("+++++++++++++++++++++++++++++++++++++++++++++");
			teamRepo.saveAll(DataLoader2.newTeam());

			List<TeamEntity> allTeam = teamRepo.getAllTeam();

			allTeam.stream().forEach(System.out::println);

		};

	}

	// @Bean
	public CommandLineRunner playerService2() {

		System.out.println("+++++++++++++++++++++++++++++++++++++++++++++");
		return arg -> {
			System.out.println("+++++++++++++++++++++++++++++++++++++++++++++");
			playerRepo.saveAll(DataLoader2.newPlayers1());

			List<PlayerEntity> allPlayer = playerRepo.getAllPlayer();

			allPlayer.stream().forEach(System.out::println);

			PlayerEntity findPlayerByNameAndPositionJPQL = playerRepo.findPlayerByNameAndPositionJPQL("Captain",
					"Dhoni");

			System.out.println("findPlayerByNameAndPositionJPQL : " + findPlayerByNameAndPositionJPQL);

		};

	}

	// @Bean
	public CommandLineRunner leagueService2() {

		System.out.println("+++++++++++++++++++++++++++++++++++++++++++++");
		return arg -> {
			System.out.println("+++++++++++++++++++++++++++++++++++++++++++++");
			leagueRepo.saveAll(DataLoader2.newLeague());

			List<LeagueEntity> allLeague = leagueRepo.getAllLeague();

			allLeague.stream().forEach(System.out::println);

		};

	}
}
