package com.dnapass.training.repo;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Path;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.dnapass.training.entity.CartEntity;
import com.dnapass.training.entity.ItemsEntity;

@Repository
public class CustomCartRepoImpl implements CustomCartRepo {

	public static final String SELECT_C_FROM_CART_ENTITY_AS_C_WHERE_C_ID_ID = "SELECT c FROM CartEntity AS c WHERE c.id =:id";

	@Autowired
	private EntityManager entityManager;

	@Override
	public CartEntity findByJPQL(Long id) {

		return entityManager.createNamedQuery("findByJPQL", CartEntity.class).setParameter("id", id).getSingleResult();

	}

	public CartEntity findByJPQL1(Long id) {
		return entityManager.createQuery(SELECT_C_FROM_CART_ENTITY_AS_C_WHERE_C_ID_ID, CartEntity.class)
				.setParameter("id", id).getSingleResult();
	}

	// it is not executed

	public List<CartEntity> findCartsbyEmails(Set<String> emails) {

		CriteriaBuilder cb = entityManager.getCriteriaBuilder();

		CriteriaQuery<CartEntity> query = cb.createQuery(CartEntity.class);

		Root<CartEntity> cartRoot = query.from(CartEntity.class);

		Path<String> emailPath = cartRoot.get("email");

		List<Predicate> predicates = new ArrayList<>();
		for (String email : emails) {

			predicates.add((Predicate) cb.like(emailPath, email));

		}

		Predicate[] array = (Predicate[]) predicates.toArray(new Predicate[predicates.size()]);

		query.select(cartRoot).where(cb.or(array));

		return entityManager.createQuery(query).getResultList();

	}

	public List<ItemsEntity> findItemsbyNames(List<String> names) {

		CriteriaBuilder cb = entityManager.getCriteriaBuilder();

		CriteriaQuery<ItemsEntity> query = cb.createQuery(ItemsEntity.class);

		Root<ItemsEntity> cartRoot = query.from(ItemsEntity.class);

		Path<String> namePath = cartRoot.get("name");

		List<Predicate> predicates = new ArrayList<>();
		for (String name : names) {

			predicates.add((Predicate) cb.like(namePath, name));

		}

		Predicate[] array = (Predicate[]) predicates.toArray(new Predicate[predicates.size()]);

		query.select(cartRoot).where(cb.or(array));

		return entityManager.createQuery(query).getResultList();

	}

}
