package com.dnapass.training.repo;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.dnapass.training.entity.TeamEntity;

@Repository
public class CustomTeamRepo2Impl implements CustomTeamRepo2 {

	@Autowired
	EntityManager em;

	@Override
	public List<TeamEntity> findAllbyUsingCriteria() {
		CriteriaBuilder criteriaBuilder = em.getCriteriaBuilder();
		CriteriaQuery<TeamEntity> createQuery = criteriaBuilder.createQuery(TeamEntity.class);
		Root<TeamEntity> from = createQuery.from(TeamEntity.class);
		createQuery.select(from);
		List<TeamEntity> resultList = em.createQuery(createQuery).getResultList();
		return resultList;
	}

	
	// Not Working
	/*
	 * @Override public TeamEntity findTeamByNameUsingCriteria(String name1) {
	 * 
	 * CriteriaBuilder criteriaBuilder = em.getCriteriaBuilder();
	 * CriteriaQuery<TeamEntity> createQuery =
	 * criteriaBuilder.createQuery(TeamEntity.class); Root<TeamEntity> from =
	 * createQuery.from(TeamEntity.class);
	 * createQuery.select(from).where(criteriaBuilder.equal(from.get(name1),
	 * name1)); TeamEntity resultList =
	 * em.createQuery(createQuery).getResultList().get(0); return null;
	 * 
	 * }
	 */

}
