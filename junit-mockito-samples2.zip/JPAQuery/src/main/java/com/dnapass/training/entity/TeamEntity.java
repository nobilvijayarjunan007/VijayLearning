package com.dnapass.training.entity;

import java.io.Serializable;
import java.util.List;
import java.util.Objects;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;

@Entity(name = "Team")
//@NamedQueries({ @NamedQuery(name = "findByJPQL5", query = "SELECT t FROM Team AS t WHERE t.id =:id") })
//@NamedQueries({ @NamedQuery(name = "findAllbyUsingCriteria", query = "SELECT t FROM Team AS t") })

public class TeamEntity implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue
	private Long id;
	private String city;
	private String name;
	@ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	@JoinColumn(name = "league_id")
	private LeagueEntity league;
	@ManyToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	private List<PlayerEntity> player;

	public TeamEntity(Long id, String city, String name, LeagueEntity league, List<PlayerEntity> player) {
		super();
		this.id = id;
		this.city = city;
		this.name = name;
		this.league = league;
		this.player = player;
	}

	public TeamEntity() {
		super();
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public LeagueEntity getLeague() {
		return league;
	}

	public void setLeague(LeagueEntity league) {
		this.league = league;
	}

	public List<PlayerEntity> getPlayer() {
		return player;
	}

	public void setPlayer(PlayerEntity player) {

		this.player.add(player);
		player.getTeam().add(this);
	}

	public void setPlayer(List<PlayerEntity> player) {
		this.player = player;
	}

	@Override
	public int hashCode() {
		return Objects.hash(city, id, league, name, player);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		TeamEntity other = (TeamEntity) obj;
		return Objects.equals(city, other.city) && Objects.equals(id, other.id) && Objects.equals(league, other.league)
				&& Objects.equals(name, other.name) && Objects.equals(player, other.player);
	}

	@Override
	public String toString() {
		return "TeamEntity [id=" + id + ", city=" + city + ", name=" + name + ", league=" + league + ", player="
				+ player + "]";
	}

}
