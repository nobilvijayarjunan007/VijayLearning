package com.dnapass.training.entity;

import java.io.Serializable;
import java.util.List;
import java.util.Objects;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity(name = "League")
public class LeagueEntity implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue
	private Long id;

	private String dType;

	private String name;

	private String sport;
	@OneToMany(mappedBy = "league", fetch = FetchType.EAGER, cascade = CascadeType.ALL)
	private List<TeamEntity> teams;

	public LeagueEntity(Long id, String dType, String name, String sport, List<TeamEntity> teams) {
		super();
		this.id = id;
		this.dType = dType;
		this.name = name;
		this.sport = sport;
		this.teams = teams;
	}

	public LeagueEntity() {
		super();
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getdType() {
		return dType;
	}

	public void setdType(String dType) {
		this.dType = dType;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getSport() {
		return sport;
	}

	public void setSport(String sport) {
		this.sport = sport;
	}

	public List<TeamEntity> getTeams() {
		return teams;
	}

	public void setTeams(List<TeamEntity> teams) {
		this.teams = teams;
	}

	@Override
	public int hashCode() {
		return Objects.hash(dType, id, name, sport, teams);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		LeagueEntity other = (LeagueEntity) obj;
		return Objects.equals(dType, other.dType) && Objects.equals(id, other.id) && Objects.equals(name, other.name)
				&& Objects.equals(sport, other.sport) && Objects.equals(teams, other.teams);
	}

	/*
	 * @Override public String toString() { return "LeagueEntity [id=" + id +
	 * ", dType=" + dType + ", name=" + name + ", sport=" + sport + ", teams=" +
	 * teams + "]"; }
	 */

	@Override
	public String toString() {
		return "LeagueEntity [id=" + id + ", dType=" + dType + ", name=" + name + ", sport=" + sport + "]";
	}

}
