package com.dnapass.training.repo;

import java.util.List;

import com.dnapass.training.entity.TeamEntity;

public interface CustomTeamRepo2 {

	List<TeamEntity> findAllbyUsingCriteria();

	// Not working
	// TeamEntity findTeamByNameUsingCriteria(String name);

}
