package com.dnapass.training.mockito;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api")
public class EmployeeController {

	@Autowired
	private IEmployeeService empService;

	@GetMapping("/init")
	String hello() {
		List<Employee> empList = DataLoader.newEmployees();
		for (Employee employee : empList) {
			empService.create(employee);
		}
		return "Hello";
	}

	@GetMapping("/employees")
	ResponseEntity<List<Employee>> findAll() {

		List<Employee> employees = empService.findAll().orElseThrow(() -> new EmployeeNotFoundException());
		System.out.println(">>>>>>>>>>>>>>>>>>>>>>>."+HttpStatus.OK);
		return new ResponseEntity<List<Employee>>(employees, HttpStatus.OK);

	}

//Save Employee
	@PostMapping("/employees")
	ResponseEntity<Employee> create(@RequestBody Employee newEmployee) {
		empService.create(newEmployee).orElseThrow(() -> new EmployeeFoundException(newEmployee.getEmpId()));
		return new ResponseEntity<Employee>(newEmployee, HttpStatus.CREATED);

	}

//Delete Employee with id
	@DeleteMapping("/employees/{id}")
	ResponseEntity<Void> delete(@PathVariable Integer id) {
		empService.delete(id);
		return new ResponseEntity<Void>(HttpStatus.NO_CONTENT);

	}

	@GetMapping("/employees/{id}")
	ResponseEntity<Employee> findOneById(@PathVariable Integer id) {

		Employee employee = empService.findById(id).orElseThrow(() -> new EmployeeNotFoundException(id));
		return new ResponseEntity<Employee>(employee, HttpStatus.OK);

	}

	@PutMapping("/employees/{id}")
	ResponseEntity<Employee> update(@RequestBody Employee newEmployee, @PathVariable Integer id) {
		System.out.println("update method called >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
		Employee employee1 = empService.update(newEmployee, id).orElseThrow(() -> new EmployeeNotFoundException(id));
		return new ResponseEntity<Employee>(employee1, HttpStatus.OK);
	}

//http://localhost:8080/api/employees/10?deptName=abc
	@GetMapping("/employees/{id}/queryparams")
	ResponseEntity<List<Employee>> findOneByIdAndName(@PathVariable Integer id, @RequestParam String deptName) {
		List<Employee> employee = empService.findByIdAndDeptName(id, deptName)
				.orElseThrow(() -> new EmployeeNotFoundException(id));
		return new ResponseEntity<List<Employee>>(employee, HttpStatus.OK);
	}
}
