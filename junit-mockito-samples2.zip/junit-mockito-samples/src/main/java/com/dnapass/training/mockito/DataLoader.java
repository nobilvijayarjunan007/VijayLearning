package com.dnapass.training.mockito;

import java.util.ArrayList;
import java.util.List;

public class DataLoader {

	public static List<EmployeeEntity> newEmployeeEntities() {

		List<EmployeeEntity> empList = new ArrayList<>();

		empList.add(new EmployeeEntity(null, "VIJAY A", "MECH", "CHENNAI"));

		empList.add(new EmployeeEntity(null, "NAVEEN A", "MCA", "CHENNAI"));
		empList.add(new EmployeeEntity(null, "PRIYA A", "CSE", "PUNE"));
		empList.add(new EmployeeEntity(null, "ARJUNAN P", "EEE", "PUNE"));
		empList.add(new EmployeeEntity(null, "SUNDARI A", "AGGRECULTURE", "TAMILNADU"));
		empList.add(new EmployeeEntity(null, "employee6", "dept6", "location6"));

		return empList;

	}

	public static List<Employee> newEmployees() {

		List<Employee> empList = new ArrayList<>();

		empList.add(new Employee(1, "VIJAY A", "MECH", "CHENNAI"));

		empList.add(new Employee(2, "NAVEEN A", "MCA", "CHENNAI"));
		empList.add(new Employee(3, "PRIYA A", "CSE", "PUNE"));
		empList.add(new Employee(4, "ARJUNAN P", "EEE", "PUNE"));
		empList.add(new Employee(5, "SUNDARI A", "AGGRECULTURE", "TAMILNADU"));
		empList.add(new Employee(6, "employee6", "dept6", "location6"));

		return empList;

	}
}
