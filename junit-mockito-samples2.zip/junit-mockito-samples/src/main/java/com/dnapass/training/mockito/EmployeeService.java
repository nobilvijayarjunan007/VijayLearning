package com.dnapass.training.mockito;

import java.sql.SQLException;
import java.util.List;
import java.util.Optional;

import org.springframework.transaction.annotation.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;

@Service
@Transactional(isolation = Isolation.SERIALIZABLE)
public class EmployeeService implements IEmployeeService {

	@Autowired
	private EmployeeRepo employeeRepo;

	@Override
	@Transactional(readOnly = true)
	public Optional<List<Employee>> findAll() {

		List<EmployeeEntity> empEntityList = employeeRepo.findAll();
		List<Employee> empList = EmployeeConverter.convert(empEntityList);

		return Optional.of(empList);
	}

	@Override
	@Transactional(rollbackFor = { SQLException.class })
	public Optional<Employee> create(Employee newEmployee) {

		if (employeeRepo.findById(Long.valueOf(newEmployee.getEmpId())) != null) {

			EmployeeEntity entity = EmployeeConverter.convert(newEmployee);

			employeeRepo.save(entity);
			return Optional.of(EmployeeConverter.convert(entity));

		} else {
			return Optional.empty();
		}

	}

	@Override
	public void delete(Integer id) {

		System.out.println("Employee with " + id + "is deleted");
		Optional<EmployeeEntity> entity = employeeRepo.findById(Long.valueOf(id));
		if (entity.get() != null) {
			employeeRepo.delete(entity.get());
		} else {
			throw new EmployeeNotFoundException(id);
		}

	}

	@Override
	@Transactional(readOnly = true)
	public Optional<Employee> findById(Integer id) {

		Optional<EmployeeEntity> entity = employeeRepo.findById(Long.valueOf(id));

		return Optional.of(EmployeeConverter.convert(entity.get()));

	}

	@Override
	@Transactional(rollbackFor = { SQLException.class })

	public Optional<Employee> update(Employee newEmployee, Integer id) {

		Optional<EmployeeEntity> entity = employeeRepo.findById(Long.valueOf(id));

		if (entity.get() != null) {
			entity.get().setEmpDept(newEmployee.getEmpDept());
			entity.get().setEmpLocation(newEmployee.getEmpLocation());
			entity.get().setEmpName(newEmployee.getEmpName());
			employeeRepo.save(entity.get());
		} else {
			throw new EmployeeNotFoundException(id);
		}

		return Optional.of(EmployeeConverter.convert(entity.get()));

	}

	public Employee getEmployeeByName(String name) {

		EmployeeEntity findByEmpName = employeeRepo.findByEmpName(name);
		return EmployeeConverter.convert(findByEmpName);
	}

	@Override
	public List<Employee> saveAll(List<Employee> employees) {

		List<EmployeeEntity> empEntities = EmployeeConverter.convertToEntity(employees);
		employeeRepo.saveAll(empEntities);

		return EmployeeConverter.convert(empEntities);

	}

	public Optional<List<Employee>> findByIdAndDeptName(Integer id, String deptName) {

		return null;
	}

}
