package com.dnapass.training.mockito;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Bean;

import org.springframework.test.context.junit4.SpringRunner;

import com.dnapass.training.mockito.Employee;
import com.dnapass.training.mockito.EmployeeEntity;
import com.dnapass.training.mockito.EmployeeRepo;
import com.dnapass.training.mockito.EmployeeService;

@RunWith(SpringRunner.class)
public class EmployeeServiceImplIntegrationTest {
	@TestConfiguration
	static class EmployeeServiceImplIntegrationTestContextConfiguration {

		@Bean
		public EmployeeService employeeService() {
			return new EmployeeService();
		}
	}

	@Autowired
	private EmployeeService employeeService;

	@MockBean
	private EmployeeRepo employeeRepository;

	// write test code here
	@Test
	public void contextLoads() throws Exception {
		assertThat(employeeService).isNotNull();
		assertThat(employeeRepository).isNotNull();
	}

	@Before
	public void setUp() {

	}

	@Test
	public void whenvalidName_thenEmployeeShouldBeFound() {

		String name = "employee1";

		// step1
		EmployeeEntity employee = new EmployeeEntity(null, "employee1", "dept1", "location1");

		Mockito.when(employeeRepository.findByEmpName("employee1")).thenReturn(employee);

		// step2

		Employee found = employeeService.getEmployeeByName(name);

		// step3
		assertThat(found.getEmpName()).isEqualTo(name);

		assertThat(found.getEmpDept()).isEqualTo(employee.getEmpDept());

		assertThat(found.getEmpId()).isEqualTo(employee.getId());

		assertThat(found.getEmpLocation()).isEqualTo(employee.getEmpLocation());

	}

}
