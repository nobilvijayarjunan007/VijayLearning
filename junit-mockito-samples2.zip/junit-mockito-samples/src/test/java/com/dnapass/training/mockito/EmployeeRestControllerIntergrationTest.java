package com.dnapass.training.mockito;

import static org.assertj.core.api.Assertions.assertThat;
import static org.hamcrest.CoreMatchers.containsString;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.io.IOException;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@RunWith(SpringRunner.class)
@SpringBootTest
@AutoConfigureMockMvc
@Rollback(false)
@TestInstance(Lifecycle.PER_CLASS)
public class EmployeeRestControllerIntergrationTest {
	@Autowired
	private EmployeeController controller;

	@Autowired
	private MockMvc mvc;
	
	List<Employee> empListExpected = null;

	@Test
	public void contextLoads() throws Exception {
		assertThat(controller).isNotNull();
		assertThat(mvc).isNotNull();
	}

	@Before
	public void setUp() throws Exception {
		String uri = "/api/employees";
		empListExpected = DataLoader.newEmployees();
		Employee employee = empListExpected.get(0);

		String inputJson = mapToJson(employee);

		MvcResult mvcResult = mvc.perform(
				MockMvcRequestBuilders.post(uri).contentType(MediaType.APPLICATION_JSON_VALUE).content(inputJson))
				.andReturn();

		int status = mvcResult.getResponse().getStatus();
		System.out.println("setUp status " + status);

		employee = empListExpected.get(1);

		inputJson = mapToJson(employee);

		mvcResult = mvc.perform(
				MockMvcRequestBuilders.post(uri).contentType(MediaType.APPLICATION_JSON_VALUE).content(inputJson))
				.andReturn();

		status = mvcResult.getResponse().getStatus();
		System.out.println("setUp status " + status);

		employee = empListExpected.get(2);

		inputJson = mapToJson(employee);

		mvcResult = mvc.perform(
				MockMvcRequestBuilders.post(uri).contentType(MediaType.APPLICATION_JSON_VALUE).content(inputJson))
				.andReturn();

		status = mvcResult.getResponse().getStatus();
		System.out.println("setUp status " + status);

		employee = empListExpected.get(3);

		inputJson = mapToJson(employee);

		mvcResult = mvc.perform(
				MockMvcRequestBuilders.post(uri).contentType(MediaType.APPLICATION_JSON_VALUE).content(inputJson))
				.andReturn();

		status = mvcResult.getResponse().getStatus();
		System.out.println("setUp status " + status);

	}

	@Test
	public void shouldReturnDefaultMessage() throws Exception {

		this.mvc.perform(MockMvcRequestBuilders.get("/api/init")).andDo(print()).andExpect(status().isOk())
				.andExpect(content().string(containsString("Hello")));

	}

	@Test

	public void getEmployeeList() throws Exception {
		String uri = "/api/employees";
		MvcResult mvcResult = mvc.perform(MockMvcRequestBuilders.get(uri).accept(MediaType.APPLICATION_JSON_VALUE))
				.andReturn();

		int status = mvcResult.getResponse().getStatus();
		assertEquals(200, status);
		String content = mvcResult.getResponse().getContentAsString();
		System.out.println("content :: " + content);
		List<Employee> empList = mapFromJson(content, new TypeReference<List<Employee>>() {
		});
		assertTrue(empList.size() == 4);
//		assertEquals(empListExpected.get(0), empList.get(0));
//		assertEquals(empListExpected.get(1), empList.get(1));
//		assertEquals(empListExpected.get(2), empList.get(2));
//		assertEquals(empListExpected.get(3), empList.get(3));

		System.out.println("getEmployeeList () :: " + empList);
	}

	@Test
	public void createEmployee() throws Exception {
		String uri = "/api/employees";
		Employee employee = new Employee(108, "employee8", "dept8", "location8");
		String inputJson = mapToJson(employee);
		MvcResult mvcResult = mvc.perform(
				MockMvcRequestBuilders.post(uri).contentType(MediaType.APPLICATION_JSON_VALUE).content(inputJson))
				.andReturn();

		int status = mvcResult.getResponse().getStatus();
		assertEquals(201, status);
		String content = mvcResult.getResponse().getContentAsString();
		System.out.println("content :: " + content);
		Employee emp = mapFromJson(content, Employee.class);
		assertNotNull(emp);

		System.out.println("emp created :: " + emp);

	}

	@Test
	public void updateEmployee() throws Exception {
		String uri = "/api/employees/1";
		Employee employee = new Employee(1, "employee1 updated ", null, null);
		String inputJson = mapToJson(employee);
		MvcResult mvcResult = mvc.perform(
				MockMvcRequestBuilders.put(uri).contentType(MediaType.APPLICATION_JSON_VALUE).content(inputJson))
				.andReturn();

		int status = mvcResult.getResponse().getStatus();
		System.out.println("content updated :: " + mvcResult.getResponse());
		assertEquals(200, status);
		String content = mvcResult.getResponse().getContentAsString();
		Employee emp = mapFromJson(content, Employee.class);
		assertNotNull(emp);
		assertEquals("employee1 updated ", emp.getEmpName());

		System.out.println("emp updated :: " + emp);

	}

	@Test
	public void deleteEmployee() throws Exception {
		String uri = "/api/employees/2";

		MvcResult mvcResult = mvc.perform(MockMvcRequestBuilders.delete(uri)).andReturn();
		int status = mvcResult.getResponse().getStatus();
		assertEquals(204, status);
		String content = mvcResult.getResponse().getContentAsString();
		System.out.println("emp deleted :: " + content);
	}

	protected String mapToJson(Object obj) throws JsonProcessingException {
		ObjectMapper objectMapper = new ObjectMapper();
		objectMapper.setSerializationInclusion(Include.NON_NULL);
		return objectMapper.writeValueAsString(obj);
	}

	protected <T> T mapFromJson(String Json, Class<T> clazz)
			throws JsonParseException, JsonMappingException, IOException {
		ObjectMapper objectMapper = new ObjectMapper();
		objectMapper.setSerializationInclusion(Include.NON_NULL);
		return objectMapper.readValue(Json, clazz);
	}

	private List<Employee> mapFromJson(String content, TypeReference<List<Employee>> typeReference)
			throws JsonMappingException, JsonProcessingException {

		ObjectMapper objectMapper = new ObjectMapper();
		objectMapper.setSerializationInclusion(Include.NON_NULL);
		return objectMapper.readValue(content, typeReference);
	}
}
