
public class Parent {

	public Parent() {
		System.out.println("Parent Constructor Called");
	}
	public void play() {
		System.out.println("parent playing");
	}

	public void eat() {
		System.out.println("parent eating");
	}

	public void sleep() {
		System.out.println("parent sleeping");
	}

	public void work() {
		System.out.println("parent working");
	}

	protected void hide() {
		System.out.println("parent Hiding Atm pin");
	}

}
