package interfacedemo;

public interface EmployeeRule {

	int salary = 25000;
	int wh = 8;

	void work();

	default void training() {
		System.out.println("I am default in interface");
	}
}
