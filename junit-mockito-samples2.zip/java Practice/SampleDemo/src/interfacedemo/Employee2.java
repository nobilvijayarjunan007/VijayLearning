package interfacedemo;

public class Employee2 implements EmployeeRule {

	@Override
	public void work() {
		System.out.println("monday to saturday");

	}

//	@Override
//	public void training() {
//		System.out.println("I am default in employee22222");
//	}

}
