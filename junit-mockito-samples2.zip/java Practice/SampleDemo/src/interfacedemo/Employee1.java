package interfacedemo;

public class Employee1 implements EmployeeRule {

	@Override
	public void work() {
		System.out.println(" manager-monday ans friday");
	}

	public void training() {
		System.out.println("I am default in employee");
	}

}
