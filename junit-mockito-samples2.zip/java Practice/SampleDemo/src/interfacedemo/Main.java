package interfacedemo;

public class Main {

	public static void main(String[] args) {

		Employee1 emp1 = new Employee1();
		emp1.work();
		emp1.training();

		Employee2 emp2 = new Employee2();
		emp2.work();

		EmployeeRule empRule = new Employee1();

		EmployeeRule empRule2 = new Employee2();
		empRule.work();
		System.out.println(emp2.salary);
		System.out.println(emp1.wh);

		empRule.training();
		empRule2.training();

	}

}
