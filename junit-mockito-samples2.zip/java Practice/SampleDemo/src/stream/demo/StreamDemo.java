/*
 * package stream.demo;
 * 
 * import static java.lang.System.out;
 * 
 * import java.io.IOException; import java.nio.charset.Charset; import
 * java.nio.file.Files; import java.nio.file.Paths; import java.util.Arrays;
 * import java.util.List; import java.util.Optional; import
 * java.util.stream.Collectors; import java.util.stream.IntStream; import
 * java.util.stream.Stream;
 * 
 * public class StreamDemo { public static void main(String[] args) throws
 * IOException {
 * 
 * // streamOf(); // arraysInStream(); // fileStream(); // streamIterate(); //
 * streamFilterWithFindAnyAndFindFirst(); // streamFindAnyFindFirstByToList();
 * // streamFilter(); // streamFilterWithFindAny(); // streamMapAndCount();
 * 
 * 
 * }
 * 
 * private static void streamMapAndCount() { List<String> list =
 * Arrays.asList("abc1", "abc2", "abc3"); long size = list.stream().map(element
 * -> { out.println("map was called"); return element.substring(0, 3);
 * }).skip(0).count();
 * 
 * out.println(size);
 * 
 * size = list.stream().skip(2).map(element -> { out.println("map was called");
 * return element.substring(0, 3); }).count();
 * 
 * out.println(size); }
 * 
 * private static void streamFilterWithFindAny() { List<String> list =
 * Arrays.asList("abc1", "abc2", "abc3"); Optional<String> string =
 * list.stream().filter(element -> { out.println("filter() was called"); return
 * element.contains("3"); }).map(element -> { out.println("map() was called");
 * return element.toUpperCase(); }).findFirst();
 * 
 * out.println(string); }
 * 
 * private static void streamFilter() { List<String> list =
 * Arrays.asList("abc1", "abc2", "abc3");
 * 
 * Stream<String> stream1 = list.stream().filter(element -> {
 * out.println("filter() was called"); return element.contains("2");
 * }).map(element -> { out.println("map() was called"); return
 * element.toUpperCase(); });
 * 
 * out.println(stream1); stream1.forEach(System.out::println); }
 * 
 * private static void streamFindAnyFindFirstByToList() { List<String> elements
 * = Stream.of("abc", "bcd", "c").filter(element -> element.contains("b"))
 * .collect(Collectors.toList()); out.println(elements);
 * 
 * Optional<String> anyElement = elements.stream().findAny(); Optional<String>
 * firstElement = elements.stream().findFirst();
 * 
 * out.println(anyElement); out.println(firstElement); }
 * 
 * private static void streamFilterWithFindAnyAndFindFirst() { Stream<String>
 * stream = Stream.of("a", "b", "c").filter(element -> element.contains("b"));
 * out.println(stream); Optional<String> anyElement = stream.findAny();
 * 
 * out.println(anyElement); out.println(anyElement.get());
 * 
 * stream = Stream.of("a", "b", "c").filter(element -> element.contains("b"));
 * 
 * Optional<String> firstElement = stream.findFirst();
 * 
 * out.println(firstElement); out.println(firstElement.get()); }
 * 
 * private static void streamIterate() { Stream<Integer> intNumbers =
 * Stream.iterate(0, n -> n + 10); intNumbers.limit(5).forEach(out::println);//
 * 0,10,20,30,40 }
 * 
 * private static void fileStream() throws IOException { Stream<String> lines =
 * Files.lines(Paths.get("C:\\Users\\vijay_a\\sample1.txt"),
 * Charset.defaultCharset()); long numberOfsLines = lines.count();
 * out.println(numberOfsLines); }
 * 
 * private static void arraysInStream() { int[] numbersArray = { 1, 2, 3, 4 };
 * 
 * IntStream numbersFromArray = Arrays.stream(numbersArray); //
 * IntStream.range(0,0)
 * 
 * out.println(numbersFromArray); numbersFromArray.forEach(System.out::println);
 * }
 * 
 * private static void streamOf() { Stream<Integer> numbersFromValues =
 * Stream.of(1, 2, 3, 4); out.println(numbersFromValues); //
 * numbersFromValues.forEach(num -> System.out.println(num)); // above or below
 * numbersFromValues.forEach(System.out::println); } }
 */