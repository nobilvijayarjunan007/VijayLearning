/*
 * package stream.demo;
 * 
 * import java.util.HashSet; import java.util.Set;
 * 
 * #2. Employee Class has method evaluate(). Set<Employee> empList. it has 1000
 * employee objects. write code to invoke evaluate() method on all emp objects
 * using stream public class StreamsDemo {
 * 
 * public static void main(String[] args) {
 * 
 * evaluate(); }
 * 
 * public static void evaluate() {
 * 
 * Set<Employee> empList = new HashSet<>(); for (int i = 1; i <= 1000; i++) {
 * String name = "name" + i; String dept = "dept" + i; String location =
 * "location" + i; Long id = (long) i; empList.add(new Employee(id, name, dept,
 * location)); } System.out.println(empList); } }
 */