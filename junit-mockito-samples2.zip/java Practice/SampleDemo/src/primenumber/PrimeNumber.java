package primenumber;

import java.util.ArrayList;
import java.util.List;

public class PrimeNumber {
	public static void main(String[] args) {
		isTheGivenNumberIsPrimeOrNot(997);
		getPrimeNumberOnly(1, 10);
		getNonPrimeNumberOnly(1, 10);
		List<Integer> primeNumbersList = getPrimeNumbersList(900, 1000);
		System.out.println(primeNumbersList);
	}

	private static List<Integer> getPrimeNumbersList(int from, int to) {
		List<Integer> primeNumbers = new ArrayList<>();
		for (int num = from; num <= to; num++) {
			int m = num / 2;
			boolean flag = true;
			if (num == 0 || num == 1) {
			} else {
				for (int i = 2; i <= m; i++) {
					if (num % i == 0) {
						flag = false;
						break;
					}
				}
				if (flag) {
					primeNumbers.add(num);
				}
			}
		}
		return primeNumbers;
	}

	private static void isTheGivenNumberIsPrimeOrNot(int num) {
		int m = num / 2;
		boolean flag = true;
		if (num == 0 || num == 1) {
			System.out.println(num + " is not prime number");
		} else {
			for (int i = 2; i <= m; i++) {
				if (num % i == 0) {
					System.out.println(num + " is not prime number");
					flag = false;
					break;
				}
			}
			if (flag) {
				System.out.println(num + " is a prime number");
			}
		}
	}

	private static void getPrimeNumberOnly(int from, int to) {
		for (int num = from; num <= to; num++) {
			int m = num / 2;
			boolean flag = true;
			if (num == 0 || num == 1) {
			} else {
				for (int i = 2; i <= m; i++) {
					if (num % i == 0) {
						flag = false;
						break;
					}
				}
				if (flag) {
					System.out.println(num + " is a prime number");
				}
			}
		}
	}

	private static void getNonPrimeNumberOnly(int from, int to) {
		for (int num = from; num <= to; num++) {
			int m = num / 2;
			boolean flag = true;
			if (num == 0 || num == 1) {
				System.out.println(num + " is not prime number");
			} else {
				for (int i = 2; i <= m; i++) {
					if (num % i == 0) {
						System.out.println(num + " is not prime number");
						flag = false;
						break;
					}
				}
				if (flag) {
				}
			}
		}
	}
}
