package primenumber;

/*1. write new method which takes inout="Gangala Rajendra Prasad"
And returns "Prasad, Gangala Rajendra"*/
public class StringNameDemo {

	public static void main(String[] args) {

		String result = stringDemo("Gangala Rajendra Prasad");
		System.out.println(result);

	}

	private static String stringDemo(String input) {
		int lastIndexOf = input.lastIndexOf(" ");
		String substring = input.substring(lastIndexOf + 1);
		String substring2 = input.substring(0, lastIndexOf);
		return substring + ", " + substring2;
	}

}
