
public class TestDemo {

	public static void main(String[] args) {
		System.out.println("Hello Vijay");

		TestDemo test = new TestDemo();
		Parent parent = new Parent();
		Child child = new Child();
		Child child2 = new Child(2000);

		child.play();
		child.eat();
		child.sleep();
		child.work();
		child.hide();
		parent.hide();

		System.out.print("1");
		System.out.println(child instanceof Parent);
		System.out.print("2");
		System.out.println(parent instanceof Child);
		System.out.print("3");
		System.out.println(child instanceof Child);
		System.out.print("4");
		System.out.println(parent instanceof Parent);
		System.out.print("5");
		System.out.println(test instanceof TestDemo);
		
		

	}
}
