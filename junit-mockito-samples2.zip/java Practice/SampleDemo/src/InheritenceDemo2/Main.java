package InheritenceDemo2;

public class Main {

	public static void main(String[] args) {

		Parent parent = new Parent();

		parent.hide();
		parent.play();
		parent.work();

		Child child = new Child();

		child.hide();
		child.play();
		child.work();
		
		
		Parent parent1 = new Child();
		
		parent1.hide();
		parent1.play();
		parent1.work();
		
		
		

	}

}
