package InheritenceDemo2;

public class Child extends Parent {

	public void play() {
		System.out.println("child playing");
	}

	public void eat() {
		System.out.println("child eating");
	}

	public void sleep() {
		System.out.println("child sleeping");
	}

	public void work() {
		System.out.println("child working");
	}

	protected void hide() {
		System.out.println("child Hiding Atm pin");
	}
}
