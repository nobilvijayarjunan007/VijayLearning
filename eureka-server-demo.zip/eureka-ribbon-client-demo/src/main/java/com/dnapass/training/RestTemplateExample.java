package com.dnapass.training;

import java.util.stream.IntStream;

import org.hibernate.internal.build.AllowSysOut;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

@Component
public class RestTemplateExample {

	@Autowired
	private RestTemplate restTemplate;

	public void run(String... args) throws Exception {
		System.out.println("+++++++++++++++++++++++++++++++++++++++=======");
		IntStream.range(1, 20).forEach(i -> {
			System.out.println("+++++++++++++++++++++++++++++++++++++++=======");
			String greeting = this.restTemplate.getForObject("http://eureka-client-demo/hello", String.class);
			System.out.println("load balanced rest template =============" + greeting);
		});
	}

}
