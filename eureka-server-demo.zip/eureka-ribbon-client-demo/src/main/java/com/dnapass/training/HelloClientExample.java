package com.dnapass.training;

import java.util.stream.IntStream;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component
public class HelloClientExample implements CommandLineRunner {

	@Autowired
	private HelloClient helloClient;

	@Override
	public void run(String... args) throws Exception {
		IntStream.range(1, 20).forEach(i -> {

			System.out.println("HelloClientExample :: feign client =========" + this.helloClient.sayHello());

		});
	}

}
