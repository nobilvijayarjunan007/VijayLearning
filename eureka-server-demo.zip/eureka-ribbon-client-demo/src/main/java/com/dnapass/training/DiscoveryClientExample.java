package com.dnapass.training;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.cloud.client.ServiceInstance;
import org.springframework.cloud.client.discovery.DiscoveryClient;
import org.springframework.stereotype.Component;
import org.apache.commons.lang.builder.ToStringBuilder;

@Component
public class DiscoveryClientExample implements CommandLineRunner {

	@Autowired
	private DiscoveryClient discoveryClient;

	@Override
	public void run(String... args) throws Exception {
		discoveryClient.getInstances("eureka-client-demo").forEach((ServiceInstance s) -> {

			System.out.println("discoveryClient.getInstances : " + ToStringBuilder.reflectionToString(s));

		});

	}
}
