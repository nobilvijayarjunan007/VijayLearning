/*
 * package com.dnapass.training.dataloader;
 * 
 * import java.util.Arrays; import java.util.List;
 * 
 * import com.dnapass.training.entities.CustomerEntity; import
 * com.dnapass.training.entities.EmployeeEntity; import
 * com.dnapass.training.entities.OfficeEntity; import
 * com.dnapass.training.entities.OrderEntity; import
 * com.dnapass.training.entities.PaymentEntity;
 * 
 * public class DataLoader3 {
 * 
 * public static List<EmployeeEntity> newEmployee() {
 * 
 * EmployeeEntity employee1 = new EmployeeEntity(null, "Firrelli", "Jeff",
 * "x9273", "jfirrelli@classicmodelcars.com", reportingManager(),
 * "VP Marketing", newOffice(), null); EmployeeEntity employee2 = new
 * EmployeeEntity(null, "Patterson", "William", "x4871",
 * "wpatterson@classicmodelcars.com", reportingHead2(), "Sales Manager (APAC)",
 * newOffice(), null);
 * 
 * PaymentEntity payment1 = new PaymentEntity(null, "2004-10-19", 15000, null);
 * PaymentEntity payment2 = new PaymentEntity(null, "2009-11-29", 67000, null);
 * 
 * CustomerEntity cust1 = new CustomerEntity(null, "Atelier graphique",
 * "Schmitt", "Carine ", "40.32.2555", "54, rue Royale", null, "Nantes", null,
 * "44000", "France", "21000.00", null, newOrder(), payment1); CustomerEntity
 * cust2 = new CustomerEntity(null, "Atelier graphique", "Schmitt", "Carine ",
 * "40.32.2555", "54, rue Royale", null, "Nantes", null, "44000", "France",
 * "21000.00", null, newOrder(), payment1);
 * 
 * CustomerEntity cust3 = new CustomerEntity(null, "Signal Gift Stores", "King",
 * "Jean", "7025551838", "8489 Strong St.", null, "Las Vegas", "NV", "83030",
 * "USA", "71800.00", null, newOrder(), payment2);
 * 
 * List<CustomerEntity> customers = employee1.getCustomers();
 * 
 * customers.add(cust1); customers.add(cust2);
 * 
 * List<CustomerEntity> customers2 = employee2.getCustomers();
 * 
 * customers2.add(cust3);
 * 
 * return Arrays.asList(employee1, employee2); }
 * 
 * private static List<OrderEntity> newOrder() {
 * 
 * OrderEntity o1 = new OrderEntity(null, "2003-01-06", "2003-01-13",
 * "2003-01-10", "Shipped", "chech on availability", null, null); OrderEntity o2
 * = new OrderEntity(null, "2003-01-06", "2003-01-13", "2003-01-10", "Shipped",
 * "chech on availability", null, null);
 * 
 * return Arrays.asList(o1, o2); }
 * 
 * private static EmployeeEntity reportingHead2() {
 * 
 * EmployeeEntity employee = new EmployeeEntity();
 * employee.setFirstName("manager"); employee.setEmail("xyz@abc.com");
 * 
 * return employee; }
 * 
 * private static EmployeeEntity reportingManager() { EmployeeEntity employee =
 * new EmployeeEntity(); employee.setFirstName("head");
 * employee.setEmail("head@abc.com");
 * 
 * return employee; }
 * 
 * private static OfficeEntity newOffice() {
 * 
 * return new OfficeEntity(null, "San Francisco", "+1 650 219 4782",
 * "100 Market Street", "Suite 300", "CA", "USA", "94080", "NA", null); }
 * 
 * }
 */