
package com.dnapass.training.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dnapass.training.dataloader2.DataLoader4;
import com.dnapass.training.entities.CustomerEntity;
import com.dnapass.training.entities.EmployeeEntity;
import com.dnapass.training.entities.OrderDetailEntity;
import com.dnapass.training.entities.OrderEntity;
import com.dnapass.training.entities.ProductEntity;
import com.dnapass.training.repo.CustomerRepo;

@Service
public class CustomerService {

	@Autowired
	private CustomerRepo customerRepo;

	public CustomerService(CustomerRepo repo) {
		super();
		this.customerRepo = repo;
	}

	public CustomerService() {
		super();

	}

	public void create() {

		CustomerEntity customer1 = DataLoader4.customersLoader().get(0);

		EmployeeEntity employee1 = DataLoader4.employeesLoader().get(0);

  	    employee1.setOffices(DataLoader4.officeDetailsLoader().get(0));
		customer1.setEmployee(employee1);

		customer1.setPayments(DataLoader4.paymentLoader().get(0));

     	List<OrderEntity> orders = DataLoader4.ordersLoader();

		OrderDetailEntity orderDetail = DataLoader4.orderDetailsLoader().get(0);

		ProductEntity product = DataLoader4.productsLoader().get(0);

		product.setProductLines(DataLoader4.productsLinesLoader().get(0));

     	orderDetail.setProducts(product);

		orders.get(0).setOrderDetails(orderDetail);

  	customer1.setOrders(orders);

		CustomerEntity save = customerRepo.save(customer1);
System.out.println(save);
	}

	/*
	 * public void find(OfficeEntity office) {
	 * 
	 * customerRepo.findById(office.getOfficeCode());
	 * 
	 * }
	 * 
	 * public void delete(OfficeEntity office) {
	 * 
	 * customerRepo.delete(office);
	 * 
	 * }
	 * 
	 * public OfficeEntity update(OfficeEntity office, Long id) {
	 * 
	 * Optional<OfficeEntity> office1 = customerRepo.findAll().stream() .filter(off
	 * -> off.getOfficeCode() == office.getOfficeCode() && off.getCity() ==
	 * office.getCity()) .findAny(); office1.get().setCity("Chennai");
	 * 
	 * return office1.get();
	 * 
	 * }
	 */
}
