package com.dnapass.training.dataloader;

import java.util.ArrayList;
import java.util.List;

import com.dnapass.training.entities.CustomerEntity;
import com.dnapass.training.entities.CustomerPaymentKey;
import com.dnapass.training.entities.EmployeeEntity;
import com.dnapass.training.entities.OfficeEntity;
import com.dnapass.training.entities.OrderDetailEntity;
import com.dnapass.training.entities.OrderEntity;
import com.dnapass.training.entities.PaymentEntity;
import com.dnapass.training.entities.ProductEntity;
import com.dnapass.training.entities.ProductLineEntity;
import com.dnapass.training.entities.ProductOrderKey;

public class DataLoader1 {

	public static CustomerEntity newCustomer() {

		CustomerEntity customer;
		customer = new CustomerEntity(null, "Atelier graphique", "Schmitt", "Carine ", "40.32.2555", "54, rue Royale",
				null, "Nantes", null, "44000", "France", "21000.00", newEmployee(), null, null);

		List<OrderEntity> list = new ArrayList();
		list.add(newOrder());
		customer.setOrders(list);
		customer.setPayments(newPayment());

		return customer;

	}

	private static PaymentEntity newPayment() {

		CustomerPaymentKey customerPaymentKey = new CustomerPaymentKey();
		customerPaymentKey.setCheckNumber(2223344l);

		return new PaymentEntity(null, null, "2004-10-19", 15000, null);
	}

	private static OrderEntity newOrder() {

		return new OrderEntity(null, "2003-01-06", "2003-01-13", "2003-01-10", "Shipped", "chech on availability", null,
				newOrderDeatils());

	}

	private static OrderDetailEntity newOrderDeatils() {

		ProductOrderKey productOrderKey = new ProductOrderKey();

		return new OrderDetailEntity(null, null, 30, 136.00, 3, newProduct(), null);
	}

	private static ProductEntity newProduct() {

		return new ProductEntity(null, "Motorcycles", "1:10", "Min Lin Diecast",
				"This replica features working kickstand, front suspension, gear-shift lever, footbrake lever, drive chain, wheels and steering. All parts are particularly delicate due to their precise scale and require special care and attention.",
				"7933", 48.81, 95.70, newProductLine(), null);
	}

	private static ProductLineEntity newProductLine() {

		return new ProductLineEntity("Classic Cars",
				"Attention car enthusiasts: Make your wildest car ownership dreams come true.", null, null, null);
	}

	private static EmployeeEntity newEmployee() {

		EmployeeEntity employee1 = new EmployeeEntity(null, "Firrelli", "Jeff", "x9273",
				"jfirrelli@classicmodelcars.com", reportingManager(), "VP Marketing", newOffice(), null);
		EmployeeEntity employee2 = new EmployeeEntity(null, "Patterson", "William", "x4871",
				"wpatterson@classicmodelcars.com", reportingHead2(), "Sales Manager (APAC)", newOffice(), null);

		/*
		 * List<EmployeeEntity> arrayList = new ArrayList<EmployeeEntity>();
		 * arrayList.add(employee1); arrayList.add(employee2);
		 */

		return employee1;
	}

	private static OfficeEntity newOffice() {

		return new OfficeEntity("off1", "San Francisco", "+1 650 219 4782", "100 Market Street", "Suite 300", "CA",
				"USA", "94080", "NA", null);
	}

	private static EmployeeEntity reportingHead2() {

		EmployeeEntity employee = new EmployeeEntity();
		employee.setFirstName("manager");
		employee.setEmail("xyz@abc.com");

		return employee;
	}

	private static EmployeeEntity reportingManager() {
		EmployeeEntity employee = new EmployeeEntity();
		employee.setFirstName("head");
		employee.setEmail("head@abc.com");

		return employee;
	}

}
