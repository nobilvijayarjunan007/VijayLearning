package com.dnapass.training;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import com.dnapass.training.dataloader.DataLoader1;
import com.dnapass.training.entities.CustomerEntity;
import com.dnapass.training.repo.CustomerRepo;
import com.dnapass.training.repo.EmployeeRepo;
import com.dnapass.training.repo.OfficeRepo;
import com.dnapass.training.service.CustomerService;
import com.dnapass.training.service.EmployeeService;
import com.dnapass.training.service.OfficeService;
import com.dnapass.training.service.ProductService;

@SpringBootApplication
public class EntityRelationshipApplication {

	public static void main(String[] args) {
		SpringApplication.run(EntityRelationshipApplication.class, args);

		/*
		 * ConfigurableApplicationContext cac =
		 * SpringApplication.run(EntityRelationshipApplication.class, args); OfficeRepo
		 * officerepo = cac.getBean(OfficeRepo.class);
		 * 
		 * OfficeEntity off = new OfficeEntity("NYC", "+1 212 555 3000",
		 * "523 East 53rd Street", "apt. 5A", "NY", "USA", "10022", "NA");
		 * EmployeeEntity emp1 = new EmployeeEntity("Patterson", "William", "x4871",
		 * "wpatterson@classicmodelcars.com", 1056, "Sales Manager (APAC)", off);
		 * EmployeeEntity emp2 = new EmployeeEntity("Bondur", "Gerard", "x5408",
		 * "gbondur@classicmodelcars.com", 1056, "Sale Manager (EMEA)", off);
		 * 
		 * List<EmployeeEntity> emps = Arrays.asList(emp1, emp2);
		 * 
		 * off.setEmployees(emps);
		 * 
		 * officerepo.save(off);
		 */

	}

	// @Bean
	public CommandLineRunner customerRepo2(CustomerService service) {

		System.out.println("Customer Details");
		return args -> {
			System.out.println("Customer Details here!!!");
			service.create();
		};

	}

	@Bean
	public CommandLineRunner customerRepo1(CustomerRepo repo) {

		System.out.println("Customer Details");
		return args -> {
			System.out.println("Customer Details here!!!");
			CustomerEntity newCustomer = DataLoader1.newCustomer();
			System.out.println(newCustomer);
			CustomerEntity save = repo.save(newCustomer);
			System.out.println(save);
		};

	}

	// @Bean
	public CommandLineRunner officeRepo1(OfficeService service) {

		return args -> {

			/*
			 * List<OfficeEntity> officeDetails = DataLoader2.officeDetailsLoader();
			 * service.createAll(officeDetails);
			 * 
			 * 
			 * EmployeeEntity emp1 = new EmployeeEntity(111, "kumar", "vijay", "xyz",
			 * "vijay@xyz.com", 333, "Developer"); EmployeeEntity emp2 = new
			 * EmployeeEntity(222, "kumar", "ajith", "abc", "ajith@xyz.com", 333, "Tester");
			 * List<EmployeeEntity> emps = Arrays.asList(emp1, emp2); OfficeEntity off = new
			 * OfficeEntity(100l, "Chennai", "9003951289", "No1 street1", "No2 Street2",
			 * "Tamilnadu", "India", "603312", "NA", emps); off.setEmployees(emps);
			 * service.create(off);
			 * 
			 */
		};

	}

	// @Bean
	public CommandLineRunner employeeRepo1(EmployeeService service) {

		return args -> {

			/*
			 * List<EmployeeEntity> empsDetails = DataLoader2.employeesLoader();
			 * service.createAll(empsDetails);
			 */

		};

	}

	// @Bean
	public CommandLineRunner officeRepository1(OfficeRepo officeRepo) {

		return args -> {

			/*
			 * OfficeEntity off = new OfficeEntity("NYC", "+1 212 555 3000",
			 * "523 East 53rd Street", "apt. 5A", "NY", "USA", "10022", "NA");
			 * EmployeeEntity emp1 = new EmployeeEntity("Patterson", "William", "x4871",
			 * "wpatterson@classicmodelcars.com", 1056, "Sales Manager (APAC)", off);
			 * EmployeeEntity emp2 = new EmployeeEntity("Bondur", "Gerard", "x5408",
			 * "gbondur@classicmodelcars.com", 1056, "Sale Manager (EMEA)", off);
			 * 
			 * List<EmployeeEntity> emps = Arrays.asList(emp1, emp2);
			 * 
			 * off.setEmployees(emps);
			 * 
			 * officeRepo.save(off);
			 */

		};

	}

	// @Bean
	public CommandLineRunner employeeRepo1(EmployeeRepo repo) {

		return args -> {

			/*
			 * EmployeeEntity emp1 = new EmployeeEntity("Murphy", "Diane", "x5800",
			 * "dmurphy@classicmodelcars.com", 0, "President");
			 * 
			 * 
			 * CustomerEntity cust1 = new CustomerEntity("Atelier graphique", "Schmitt",
			 * "Carine ", "40.32.2555", "54, rue Royale", "-", "Nantes", "-", "44000",
			 * "France", "21000.00", emp1); CustomerEntity cust2 = new
			 * CustomerEntity("Signal Gift Stores", "King", "Jean", "7025551838",
			 * "8489 Strong St.", null, "Las Vegas", "NV", "83030", "USA", "71800.00",
			 * emp1);
			 * 
			 * List<CustomerEntity> customers = Arrays.asList(cust1, cust2);
			 * 
			 * emp1.setCustomers(customers);
			 * 
			 * repo.save(emp1);
			 */

		};

	}

	// @Bean
	public CommandLineRunner productRepo(ProductService service) {

		return args -> {

			/*
			 * service.createAll(null);
			 */
		};

	}

	// >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>/

	// @Bean
	public CommandLineRunner officeRepository(OfficeRepo repository, EmployeeRepo repo) {

		return args -> {

			/*
			 * List<OfficeEntity> officeDetailsLoader = DataLoader2.officeDetailsLoader1();
			 * List<EmployeeEntity> employeesLoader = DataLoader2.employeesLoader1();
			 * 
			 * List<EmployeeEntity> asList = Arrays.asList(employeesLoader.get(0),
			 * employeesLoader.get(1), employeesLoader.get(2));
			 * officeDetailsLoader.get(0).setEmployees(asList);
			 * 
			 * 
			 * List<OfficeEntity> saveAll = repository.saveAll(officeDetailsLoader);
			 * 
			 * saveAll.stream().forEach(System.out::println);
			 */

		};

	}

	/*
	 * //@Bean public CommandLineRunner empRepo2(EmployeeRepo repo) {
	 * System.out.println("Employee Details"); return args -> {
	 * System.out.println("Employee Details here!!!"); List<EmployeeEntity>
	 * newEmployee = DataLoader3.newEmployee(); repo.saveAll(newEmployee);
	 * newEmployee.stream().forEach(System.out::println); };
	 * 
	 * }
	 */

}
