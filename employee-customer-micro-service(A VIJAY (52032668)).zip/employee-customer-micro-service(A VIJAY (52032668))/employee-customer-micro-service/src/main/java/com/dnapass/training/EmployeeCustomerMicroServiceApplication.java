package com.dnapass.training;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.context.annotation.Bean;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.dnapass.training.controller.CustomerClient;
import com.dnapass.training.models.Customer;
import com.dnapass.training.models.Employee;

@SpringBootApplication
@EnableEurekaClient
@EnableFeignClients
@RestController
public class EmployeeCustomerMicroServiceApplication {

	private static final String HTTP_EMPLOYEE_MICRO_SERVICE_API_EMPLOYEES_LIST = "http://employee-micro-service/employeeapi/employeesList";

	// @Autowired
	private RestTemplate restTemplate;

	@Autowired
	private CustomerClient customerFeignClient;

	public static void main(String[] args) {
		SpringApplication.run(EmployeeCustomerMicroServiceApplication.class, args);
	}

	@LoadBalanced
	@Bean
	public RestTemplate restTemplate(RestTemplateBuilder builder) {

		restTemplate = builder.build();
		return restTemplate;
	}

	@GetMapping("/hello")
	public String findEmployee() {
		return "Employee-Customer micro service working";
	}

	// without gate way
	@GetMapping("/find/{id}")
	public String findEmployeeById(@PathVariable(name = "id") Long id) {

		ResponseEntity<String> cust = restTemplate
				.getForEntity("http://customer-micro-service/customerapi/customers/" + id, String.class);
		ResponseEntity<String> emp = restTemplate
				.getForEntity("http://employee-micro-service/employeeapi/employees/" + id, String.class);

		return emp.getBody() + cust.getBody();

	}

	// without gate way
	@GetMapping("/api/employee/{id}")
	public Employee findEmployees(@PathVariable(name = "id") Long id) {
		// method 1

		List<Employee> employee = restTemplate.getForObject(HTTP_EMPLOYEE_MICRO_SERVICE_API_EMPLOYEES_LIST, List.class);

		System.out.println("+++++++method one++++++" + employee);

		// method 2

		ResponseEntity<List<Employee>> response = restTemplate.exchange(HTTP_EMPLOYEE_MICRO_SERVICE_API_EMPLOYEES_LIST,
				HttpMethod.GET, null, new ParameterizedTypeReference<List<Employee>>() {
				});

		System.out.println("+++++++++++++Method two+++++++++++" + response);

		Employee employee2 = response.getBody().stream().filter((emp) -> emp.getEmployeeNumber() == id).findAny().get();

		System.out.println("++++++++Streaming method +++++++++" + employee2);
		// method 1

		ResponseEntity<List<Customer>> customers = customerFeignClient.getCustomers();

		System.out.println("++++++++++++feign client+++++++++++++" + customers);

		List<Customer> customer = customers.getBody().stream().filter(cust -> cust.getSales_RepEmployeeNumber() == id)
				.collect(Collectors.toList());

		System.out.println("++++++++++++feign client+++++++++++++" + customer);
		employee2.setCustomers(customer);
		return employee2;
	}

	// with gateway

	@GetMapping("/get")
	public String findEmployeebyGateway1() {

		ResponseEntity<String> cust = restTemplate
				.getForEntity("http://employee-customer-gateway-api/customerapi/customersList/", String.class);
		ResponseEntity<String> emp = restTemplate
				.getForEntity("http://employee-customer-gateway-api/employeeapi/employeesList/", String.class);

		return emp.getBody() + cust.getBody();

	}

	// with gatway
	@GetMapping("/api/employees/{id}")
	public Employee findEmployeesbyGateway(@PathVariable(name = "id") Long id) {

		ResponseEntity<List<Employee>> response = restTemplate.exchange(
				"http://employee-customer-gateway-api/employeeapi/employeesList", HttpMethod.GET, null,
				new ParameterizedTypeReference<List<Employee>>() {
				});

		System.out.println("+++++++++++++Method two+++++++++++" + response);

		Employee employee2 = response.getBody().stream().filter((emp) -> emp.getEmployeeNumber() == id).findAny().get();

		System.out.println("++++++++Streaming method +++++++++" + employee2);

		ResponseEntity<List<Customer>> customers = customerFeignClient.getCustomers();

		System.out.println("++++++++++++feign client+++++++++++++" + customers);

		List<Customer> customer = customers.getBody().stream().filter(cust -> cust.getSales_RepEmployeeNumber() == id)
				.collect(Collectors.toList());

		System.out.println("++++++++++++feign client+++++++++++++" + customer);
		employee2.setCustomers(customer);
		return employee2;

	}
}
