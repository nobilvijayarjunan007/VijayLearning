package com.dnapass.training.controller;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.dnapass.training.models.Customer;

//@FeignClient(name = "${feign.name}", url = "${feign.uri}", fallback = CustomerClientFallback.class)
//@FeignClient("employee-customer-api-gateway")
@FeignClient("employee-customer-gateway-api")
public interface CustomerClient {
	@RequestMapping(method = RequestMethod.GET, value = "/customerapi/customersList")
	ResponseEntity<List<Customer>> getCustomers();

}
