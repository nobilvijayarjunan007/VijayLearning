package com.dnapass.training.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.dnapass.training.entity.EmployeeEntity;
import com.dnapass.training.entity.OfficeEntity;
import com.dnapass.training.exception.ApplicationException;
import com.dnapass.training.service.EmployeeService;
import com.dnapass.training.service.OfficeService;

@RequestMapping("/employeeapi")
@RestController
public class EmployeeController {

	@Autowired
	private EmployeeService empService;

	@Autowired
	private OfficeService offService;

	@RequestMapping(method = RequestMethod.POST, value = "/employees")
	public ResponseEntity<EmployeeEntity> addEmployee(@RequestBody EmployeeEntity employee)
			throws ApplicationException {

		EmployeeEntity newEmp = empService.addEmployee(employee);

		HttpHeaders httpHeaders = new HttpHeaders();
		httpHeaders.add("employee", "/api/employees" + newEmp.getEmployeeNumber().toString());

		return new ResponseEntity<>(newEmp, httpHeaders, HttpStatus.CREATED);
	}

	@RequestMapping(method = RequestMethod.GET, value = "/employees/{empId}")
	public ResponseEntity<EmployeeEntity> findEmployee(@PathVariable(name = "empId") Long id) {

		EmployeeEntity Emp = empService.findEmployeeById(id);

		return new ResponseEntity<>(Emp, HttpStatus.OK);
	}

	@RequestMapping(method = RequestMethod.GET, value = "/employeesOffice/{OfficeId}")
	public ResponseEntity<OfficeEntity> findOffice(@PathVariable(name = "OfficeId") String id) {

		OfficeEntity office = offService.findOffice(id);

		return new ResponseEntity<>(office, HttpStatus.OK);
	}

	@RequestMapping(method = RequestMethod.GET, value = "/employeesList")
	public ResponseEntity<List<EmployeeEntity>> findEmployees() {

		List<EmployeeEntity> findEmployees = empService.findEmployees();
		return new ResponseEntity<>(findEmployees, HttpStatus.OK);
	}

	@RequestMapping(method = RequestMethod.GET, value = "/officesList")
	public ResponseEntity<List<OfficeEntity>> findOffices() {

		List<OfficeEntity> offices = offService.findOffices();
		return new ResponseEntity<>(offices, HttpStatus.OK);
	}

	@RequestMapping(method = RequestMethod.PUT, value = "/employees/{empId}")
	public ResponseEntity<EmployeeEntity> addEmployeeOffice(@RequestBody OfficeEntity office,
			@PathVariable(name = "empId") Long id) {
		EmployeeEntity addEmployeeOffice = empService.addEmployeeOffice(office, id);
		return new ResponseEntity<>(addEmployeeOffice, HttpStatus.OK);
	}

	// No needed???????????????????????????????????????????????????????????????
	@RequestMapping(method = RequestMethod.POST, value = "/emp/{officeName}")
	public OfficeEntity addEmployeeOffice(@RequestBody EmployeeEntity employee,
			@PathVariable(name = "officeName") String officeId) {
		OfficeEntity addEmployeeOffice = empService.addEmployeeOffice(employee, officeId);
		return addEmployeeOffice;
	}

}
