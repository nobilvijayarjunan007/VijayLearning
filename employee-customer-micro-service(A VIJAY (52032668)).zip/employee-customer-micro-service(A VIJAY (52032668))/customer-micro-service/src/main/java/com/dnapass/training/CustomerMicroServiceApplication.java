package com.dnapass.training;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.context.annotation.Bean;

import com.dnapass.training.dataloader.DataLoader1;
import com.dnapass.training.entities.CustomerEntity;
import com.dnapass.training.entities.PaymentEntity;
import com.dnapass.training.repo.CustomerRepo;
import com.dnapass.training.repo.PaymentRepo;
import com.dnapass.training.service.CustomerService;
import com.dnapass.training.service.PaymentService;

@SpringBootApplication
@EnableEurekaClient
public class CustomerMicroServiceApplication {
	@Autowired
	private CustomerRepo customerRepo;
	@Autowired
	private PaymentRepo payRepo;

	@Autowired
	private CustomerService custService;

	@Autowired
	private PaymentService paymentService;

	public static void main(String[] args) {
		SpringApplication.run(CustomerMicroServiceApplication.class, args);
	}

	@Bean
	public CommandLineRunner customerRepo2() {

		System.out.println("+++++++++++++++++++++++++++++++++++++++++++++++++++");
		return args -> {
			System.out.println("++++++++++++++++++++Custommer Details here!!!+++++++++++++++++++++++++++");

			List<CustomerEntity> customerLoader = DataLoader1.customersLoader();
			customerRepo.saveAll(customerLoader);
			// post test
			CustomerEntity customer = new CustomerEntity(null, "Australian Collectors, Co.", "Ferguson", "Peter",
					"03 9520 4555", "636 St Kilda Road", "Level 3", "Melbourne", "Victoria", "3004", "Australia",
					"117300.00");
			CustomerEntity addCustomer = custService.addCustomer(customer);
			System.out.println("++++++++++++addCustomer POST +++++++++++>>>>>" + addCustomer);

			
			/*
			 * PaymentEntity payment = new PaymentEntity("GD036336", "2004-10-19", 6066);
			 * 
			 * CustomerEntity addCustomerPayment = custService.addCustomerPayment(payment,
			 * 3l); System.out.println("addCustomerPayment+++++++++" + addCustomerPayment);
			 */
			 
		};

	}

}
