package com.dnapass.training.exception;

public class ErrorMessage {

	private String errorCode;

	private String errorCodeDescription;

	public ErrorMessage(String errorCode, String errorCodeDescription) {
		super();
		this.errorCode = errorCode;
		this.errorCodeDescription = errorCodeDescription;
	}

}
