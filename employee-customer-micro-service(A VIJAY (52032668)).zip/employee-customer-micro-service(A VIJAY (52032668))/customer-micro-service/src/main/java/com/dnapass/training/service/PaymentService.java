package com.dnapass.training.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dnapass.training.entities.PaymentEntity;
import com.dnapass.training.repo.PaymentRepo;

@Service
public class PaymentService {

	@Autowired
	private PaymentRepo payRepo;

	public PaymentEntity findPayment(String CheckNo, Long CustId) {
		PaymentEntity payment = payRepo.findAll().stream().filter(
				pay -> pay.getCheckNumber().equals(CheckNo) && pay.getCustomer().getCustomerNumber().equals(CustId))
				.findAny().get();

		return payment;
	}

	public List<PaymentEntity> findPayments() {
		List<PaymentEntity> payments = payRepo.findAll();
		return payments;
	}
}
