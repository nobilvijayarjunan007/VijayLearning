
package com.dnapass.training.entities;

import java.io.Serializable;
import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Embeddable;

//@Embeddable
public class CustomerPaymentKey implements Serializable {

	private static final long serialVersionUID = 1L;

	private CustomerEntity customer;

	private String checkNumber;

	public CustomerPaymentKey() {
		super();
	}

	public CustomerPaymentKey(CustomerEntity customer, String checkNumber) {
		super();
		this.customer = customer;
		this.checkNumber = checkNumber;
	}

	public CustomerEntity getCustomerNumber() {
		return customer;
	}

	public void setCustomerNumber(CustomerEntity customer) {
		this.customer = customer;
	}

	public String getCheckNumber() {
		return checkNumber;
	}

	public void setCheckNumber(String checkNumber) {
		this.checkNumber = checkNumber;
	}

	@Override
	public int hashCode() {
		return Objects.hash(checkNumber, customer);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CustomerPaymentKey other = (CustomerPaymentKey) obj;
		return Objects.equals(checkNumber, other.checkNumber) && Objects.equals(customer, other.customer);
	}

	@Override
	public String toString() {
		return "CustomerPaymentKey [customerNumber=" + customer + ", checkNumber=" + checkNumber + "]";
	}

}
