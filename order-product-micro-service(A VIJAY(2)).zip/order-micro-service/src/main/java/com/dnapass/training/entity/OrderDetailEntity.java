package com.dnapass.training.entity;

import java.io.Serializable;
import java.util.Objects;

import javax.persistence.CascadeType;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.MapsId;
import javax.persistence.OneToOne;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;

@Entity(name = "OrderDetails")
@IdClass(CompositeKeyClass.class)
public class OrderDetailEntity implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	// @GeneratedValue
	private Long productCode;
	private Integer quantityOrdered;
	private Double priceEach;

	private Integer orderLineNumber;
	// @JsonManagedReference
	@JsonBackReference
	@MapsId
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "order_Number")
	private ProductLineEntity orders;

	public OrderDetailEntity() {
		super();
	}

	public OrderDetailEntity(Long productCode, Integer quantityOrdered, Double priceEach, Integer orderLineNumber,
			ProductLineEntity orders) {
		super();
		this.productCode = productCode;
		this.quantityOrdered = quantityOrdered;
		this.priceEach = priceEach;
		this.orderLineNumber = orderLineNumber;
		this.orders = orders;
	}

	public OrderDetailEntity(Long productCode, Integer quantityOrdered, Double priceEach, Integer orderLineNumber) {
		super();
		this.productCode = productCode;
		this.quantityOrdered = quantityOrdered;
		this.priceEach = priceEach;
		this.orderLineNumber = orderLineNumber;
	}

	public Long getProductCode() {
		return productCode;
	}

	public void setProductCode(Long productCode) {
		this.productCode = productCode;
	}

	public Integer getQuantityOrdered() {
		return quantityOrdered;
	}

	public void setQuantityOrdered(Integer quantityOrdered) {
		this.quantityOrdered = quantityOrdered;
	}

	public Double getPriceEach() {
		return priceEach;
	}

	public void setPriceEach(Double priceEach) {
		this.priceEach = priceEach;
	}

	public Integer getOrderLineNumber() {
		return orderLineNumber;
	}

	public void setOrderLineNumber(Integer orderLineNumber) {
		this.orderLineNumber = orderLineNumber;
	}

	public ProductLineEntity getOrders() {
		return orders;
	}

	public void setOrders(ProductLineEntity orders) {
		this.orders = orders;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((orderLineNumber == null) ? 0 : orderLineNumber.hashCode());
		result = prime * result + ((orders == null) ? 0 : orders.hashCode());
		result = prime * result + ((priceEach == null) ? 0 : priceEach.hashCode());
		result = prime * result + ((productCode == null) ? 0 : productCode.hashCode());
		result = prime * result + ((quantityOrdered == null) ? 0 : quantityOrdered.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		OrderDetailEntity other = (OrderDetailEntity) obj;
		if (orderLineNumber == null) {
			if (other.orderLineNumber != null)
				return false;
		} else if (!orderLineNumber.equals(other.orderLineNumber))
			return false;
		if (orders == null) {
			if (other.orders != null)
				return false;
		} else if (!orders.equals(other.orders))
			return false;
		if (priceEach == null) {
			if (other.priceEach != null)
				return false;
		} else if (!priceEach.equals(other.priceEach))
			return false;
		if (productCode == null) {
			if (other.productCode != null)
				return false;
		} else if (!productCode.equals(other.productCode))
			return false;
		if (quantityOrdered == null) {
			if (other.quantityOrdered != null)
				return false;
		} else if (!quantityOrdered.equals(other.quantityOrdered))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "OrderDetailEntity [productCode=" + productCode + ", quantityOrdered=" + quantityOrdered + ", priceEach="
				+ priceEach + ", orderLineNumber=" + orderLineNumber + ", orders=" + orders + "]";
	}

}
