package com.dnapass.training.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dnapass.training.entity.OrderDetailEntity;
import com.dnapass.training.repo.OrderDetailRepo;
import com.dnapass.training.repo.OrderRepo;

@Service
public class OrderDetailService {

	@Autowired
	private OrderRepo orederRepo;
	@Autowired
	private OrderDetailRepo orderDetailRepo;

	public List<OrderDetailEntity> findOrderDetails() {

		List<OrderDetailEntity> orderDetailsList = orderDetailRepo.findAll();
		return orderDetailsList;
	}

	public OrderDetailEntity findOrderDetail(Long orderId, Long productId) {

		OrderDetailEntity orderDetailEntity = orderDetailRepo.findAll().stream().filter(
				ord -> ord.getProductCode().equals(productId) && ord.getOrders().getOrderNumber().equals(orderId))
				.findAny().get();
		return orderDetailEntity;
	}

}
