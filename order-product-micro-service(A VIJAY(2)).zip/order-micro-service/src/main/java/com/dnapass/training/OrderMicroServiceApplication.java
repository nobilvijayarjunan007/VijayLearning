package com.dnapass.training;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.context.annotation.Bean;

import com.dnapass.training.dataloader.DataLoader;
import com.dnapass.training.entity.ProductLineEntity;
import com.dnapass.training.repo.OrderRepo;

@SpringBootApplication
@EnableEurekaClient
public class OrderMicroServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(OrderMicroServiceApplication.class, args);
	}

	@Autowired
	private OrderRepo orderRepo;

	@Bean
	public CommandLineRunner orderService1() {

		System.out.println("+++++++++++++++++++++++++++++++++++++++++++++++++++");
		return args -> {
			System.out.println("++++++++++++++++++++Order Details here!!!+++++++++++++++++++++++++++");
			List<ProductLineEntity> orders = DataLoader.orders();
			orderRepo.saveAll(orders);

		};

	}

}
