package com.dnapass.training.service;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.dnapass.training.entity.OrderDetailEntity;
import com.dnapass.training.entity.ProductLineEntity;
import com.dnapass.training.exception.ApplicationException;
import com.dnapass.training.repo.OrderDetailRepo;
import com.dnapass.training.repo.OrderRepo;

@Service
public class OrderService {

	@Autowired
	private OrderRepo orederRepo;
	@Autowired
	private OrderDetailRepo orderDetailRepo;

	public ProductLineEntity addOrder(ProductLineEntity order) throws ApplicationException {
		List<ProductLineEntity> orderList = orederRepo.findAll();
		Optional<ProductLineEntity> existorder = orderList.stream().filter(c -> c.equals(order)).findFirst();
		if (existorder.isPresent()) {
			throw new ApplicationException("Order Already exists");
		}
		ProductLineEntity newOrder = orederRepo.save(order);

		return newOrder;
	}

	public Page<ProductLineEntity> findOrdersByPageWise(Pageable page) {

		Page<ProductLineEntity> ordersList = orederRepo.findAll(page);

		return ordersList;
	}

	public ProductLineEntity findOrder(Long id) {

		Optional<ProductLineEntity> order = orederRepo.findById(id);

		return order.get();

	}

	public List<ProductLineEntity> findOrders() {

		List<ProductLineEntity> ordersList = orederRepo.findAll();

		return ordersList;
	}

	public ProductLineEntity addOrderDetail(Long orderId, OrderDetailEntity orderDetail) {
		Optional<ProductLineEntity> order = orederRepo.findById(orderId);
		order.get().setOrderDetails(Arrays.asList(orderDetail));
		return orederRepo.save(order.get());
	}
}
