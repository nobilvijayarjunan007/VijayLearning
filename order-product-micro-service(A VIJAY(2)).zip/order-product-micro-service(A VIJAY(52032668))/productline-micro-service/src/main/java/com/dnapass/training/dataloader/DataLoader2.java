package com.dnapass.training.dataloader;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;

import com.dnapass.training.entity.ProductEntity;
import com.dnapass.training.entity.ProductLineEntity;

public class DataLoader2 {

	public static List<ProductLineEntity> productsLinesData() {
		List<ProductLineEntity> productLines = new ArrayList<>();

		ProductLineEntity pl1 = new ProductLineEntity("Classic Cars",
				"Attention car enthusiasts: Make your wildest car ownership dreams come true. ", null, null);
		pl1.getProducts().addAll(newProduct1(pl1));
		productLines.add(pl1);
		ProductLineEntity pl2 = new ProductLineEntity("Planes",
				"Unique, diecast airplane and helicopter replicas suitable for collections, as well as home, office or classroom decorations.",
				null, null);
		pl2.getProducts().addAll(newProduct2(pl2));
		productLines.add(pl2);
		ProductLineEntity pl3 = new ProductLineEntity("Ships",
				"The perfect holiday or anniversary gift for executives, clients, friends, and family. These handcrafted model ships are unique,",
				null, null);

		ProductLineEntity pl4 = new ProductLineEntity("Trains",
				"Model trains are a rewarding hobby for enthusiasts of all ages. Whether you\"re looking for collectible wooden trains, electric streetcars or locomotives,",
				null, null);

		////////////

		return productLines;

	}

	private static List<ProductEntity> newProduct1(ProductLineEntity pl1) {
		List<ProductEntity> products = new ArrayList<>();

		ProductEntity prod1 = new ProductEntity(null, "1969 Harley Davidson Ultimate Chopper", "1:10",
				"Min Lin Diecast",
				"This replica features working kickstand, front suspension, gear-shift lever, footbrake lever, drive chain, wheels and steering.",
				"7933", 48.81, 95.70, pl1);

		ProductEntity prod2 = new ProductEntity(null, "1952 Alpine Renault 1300", "1:10", "Classic Metal Creations",
				"Turnable front wheels; steering function; detailed interior; detailed engine; opening hood; opening trunk; opening doors; and detailed chassis.",
				"7305", 98.58, 214.30, pl1);
		products.add(prod1);
		products.add(prod2);

		return products;
	}

	private static List<ProductEntity> newProduct2(ProductLineEntity pl2) {
		List<ProductEntity> products = new ArrayList<>();

		ProductEntity prod1 = new ProductEntity(null, "1969 Harley Davidson Ultimate Chopper", "1:10",
				"Min Lin Diecast",
				"This replica features working kickstand, front suspension, gear-shift lever, footbrake lever, drive chain, wheels and steering.",
				"7933", 48.81, 95.70, pl2);

		ProductEntity prod2 = new ProductEntity(null, "1952 Alpine Renault 1300", "1:10", "Classic Metal Creations",
				"Turnable front wheels; steering function; detailed interior; detailed engine; opening hood; opening trunk; opening doors; and detailed chassis.",
				"7305", 98.58, 214.30, pl2);
		products.add(prod1);
		products.add(prod2);

		return products;
	}

}
