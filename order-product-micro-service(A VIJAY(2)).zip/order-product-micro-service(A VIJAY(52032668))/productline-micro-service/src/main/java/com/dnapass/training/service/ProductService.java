package com.dnapass.training.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dnapass.training.entity.ProductEntity;
import com.dnapass.training.repo.ProductLineRepo;
import com.dnapass.training.repo.ProductRepo;

@Service
public class ProductService {

	@Autowired
	private ProductLineRepo productLineRepo;
	@Autowired
	private ProductRepo productRepo;

	public List<ProductEntity> findProducts() {

		List<ProductEntity> orderDetailsList = productRepo.findAll();
		return orderDetailsList;
	}

	public ProductEntity findProduct(String productLineId, Long productId) {

		ProductEntity ProductEntity = productRepo.findAll().stream()
				.filter(prod -> prod.getProductCode().equals(productId)
						&& prod.getProductLines().getProductLine().equals(productLineId))
				.findAny().get();
		return ProductEntity;
	}
}
