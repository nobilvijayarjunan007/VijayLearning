package com.dnapass.training.dataloader;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.dnapass.training.entity.ProductEntity;
import com.dnapass.training.entity.ProductLineEntity;

public class Dataloader {
	public static List<ProductEntity> loadProducts() {
		List<ProductEntity> products = new ArrayList<>();
		ProductLineEntity prodLine = new ProductLineEntity("Classic-Cars",
				"Attention car enthusiasts: Make your wildest car ownership dreams come true.", null, null);
		ProductEntity prod1 = new ProductEntity(null, "1969 Harley Davidson Ultimate Chopper", "1:10",
				"Min Lin Diecast", "This replica features working kickstand, front suspension, gear-shift lever.",
				"7933", 48.81, 95.70);
		ProductEntity prod2 = new ProductEntity(null, "1952 Alpine Renault 1300", "1:10", "Classic Metal Creations",
				"Turnable front wheels; steering function; detailed interior; detailed engine; opening hood", "7305",
				98.58, 214.30);
		prod1.setProductLines(prodLine);
		prod2.setProductLines(prodLine);
		products.add(prod1);
		products.add(prod2);
		return products;

	}

	public static List<ProductLineEntity> productsLinesData() {
		List<ProductLineEntity> productLines = new ArrayList<>();

		ProductLineEntity pl1 = new ProductLineEntity("Classic Cars",
				"Attention car enthusiasts: Make your wildest car ownership dreams come true. ", null, null);

		ProductLineEntity pl2 = new ProductLineEntity("Planes",
				"Unique, diecast airplane and helicopter replicas suitable for collections, as well as home, office or classroom decorations.",
				null, null);

		ProductLineEntity pl3 = new ProductLineEntity("Ships",
				"The perfect holiday or anniversary gift for executives, clients, friends, and family. These handcrafted model ships are unique,",
				null, null);

		ProductLineEntity pl4 = new ProductLineEntity("Trains",
				"Model trains are a rewarding hobby for enthusiasts of all ages. Whether you\"re looking for collectible wooden trains, electric streetcars or locomotives,",
				null, null);

		////////////

		ProductEntity prod1 = new ProductEntity(null, "1969 Harley Davidson Ultimate Chopper", "1:10",
				"Min Lin Diecast",
				"This replica features working kickstand, front suspension, gear-shift lever, footbrake lever, drive chain, wheels and steering.",
				"7933", 48.81, 95.70, pl1);

		ProductEntity prod2 = new ProductEntity(null, "1952 Alpine Renault 1300", "1:10", "Classic Metal Creations",
				"Turnable front wheels; steering function; detailed interior; detailed engine; opening hood; opening trunk; opening doors; and detailed chassis.",
				"7305", 98.58, 214.30, pl3);

		ProductEntity prod3 = new ProductEntity(null, "1996 Moto Guzzi 1100i", "1:10", "Highway 66 Mini Classics",
				"Official Moto Guzzi logos and insignias, saddle bags located on side of motorcycle, detailed engine, working steering,",
				"6625", 68.99, 118.94, pl1);

		ProductEntity prod4 = new ProductEntity(null, "2003 Harley-Davidson Eagle Drag Bike", "1:10",
				"Red Start Diecast",
				"Model features, official Harley Davidson logos and insignias, detachable rear wheelie bar, heavy diecast metal with resin parts",
				"5582", 91.02, 193.66, pl1);

		pl1.setProducts(Arrays.asList(prod1, prod3, prod4));
		pl3.setProducts(Arrays.asList(prod2));

		productLines.add(pl1);
		productLines.add(pl2);
		productLines.add(pl3);
		productLines.add(pl4);
		return productLines;

	}

	public static List<ProductEntity> productsData() {
		List<ProductEntity> products = new ArrayList<>();

		ProductLineEntity pl1 = new ProductLineEntity("Classic Cars",
				"Attention car enthusiasts: Make your wildest car ownership dreams come true. ", null, null);

		ProductLineEntity pl2 = new ProductLineEntity("Planes",
				"Unique, diecast airplane and helicopter replicas suitable for collections, as well as home, office or classroom decorations.",
				null, null);

		ProductLineEntity pl3 = new ProductLineEntity("Ships",
				"The perfect holiday or anniversary gift for executives, clients, friends, and family. These handcrafted model ships are unique,",
				null, null);

		ProductLineEntity pl4 = new ProductLineEntity("Trains",
				"Model trains are a rewarding hobby for enthusiasts of all ages. Whether you\"re looking for collectible wooden trains, electric streetcars or locomotives,",
				null, null);

		////////////

		ProductEntity prod1 = new ProductEntity(null, "1969 Harley Davidson Ultimate Chopper", "1:10",
				"Min Lin Diecast",
				"This replica features working kickstand, front suspension, gear-shift lever, footbrake lever, drive chain, wheels and steering.",
				"7933", 48.81, 95.70, pl1);

		ProductEntity prod2 = new ProductEntity(null, "1952 Alpine Renault 1300", "1:10", "Classic Metal Creations",
				"Turnable front wheels; steering function; detailed interior; detailed engine; opening hood; opening trunk; opening doors; and detailed chassis.",
				"7305", 98.58, 214.30, pl3);

		ProductEntity prod3 = new ProductEntity(null, "1996 Moto Guzzi 1100i", "1:10", "Highway 66 Mini Classics",
				"Official Moto Guzzi logos and insignias, saddle bags located on side of motorcycle, detailed engine, working steering,",
				"6625", 68.99, 118.94, pl1);

		ProductEntity prod4 = new ProductEntity(null, "2003 Harley-Davidson Eagle Drag Bike", "1:10",
				"Red Start Diecast",
				"Model features, official Harley Davidson logos and insignias, detachable rear wheelie bar, heavy diecast metal with resin parts",
				"5582", 91.02, 193.66, pl1);

		pl1.setProducts(Arrays.asList(prod1, prod3, prod4));
		pl3.setProducts(Arrays.asList(prod2));

		products.add(prod1);
		products.add(prod2);
		products.add(prod3);
		products.add(prod4);

		return products;

	}

	public static List<ProductLineEntity> productsLinesLoader() {
		List<ProductLineEntity> productLines = new ArrayList<>();

		productLines.add(new ProductLineEntity("Classic Cars",
				"Attention car enthusiasts: Make your wildest car ownership dreams come true. ", null, null));

		productLines.add(new ProductLineEntity("Planes",
				"Unique, diecast airplane and helicopter replicas suitable for collections, as well as home, office or classroom decorations. Models contain stunning details such as official logos and insignias, rotating jet engines and propellers, retractable wheels, and so on. Most come fully assembled and with a certificate of authenticity from their manufacturers.",
				null, null, null));

		productLines.add(new ProductLineEntity("Ships",
				"The perfect holiday or anniversary gift for executives, clients, friends, and family. These handcrafted model ships are unique, stunning works of art that will be treasured for generations! They come fully assembled and ready for display in the home or office. We guarantee the highest quality, and best value.",
				null, null, null));

		productLines.add(new ProductLineEntity("Trains",
				"Model trains are a rewarding hobby for enthusiasts of all ages. Whether you\"re looking for collectible wooden trains, electric streetcars or locomotives, you\"ll find a number of great choices for any budget within this category. The interactive aspect of trains makes toy trains perfect for young children. The wooden train sets are ideal for children under the age of 5.",
				null, null, null));

		productLines.add(new ProductLineEntity("Trucks and Buses",
				"The Truck and Bus models are realistic replicas of buses and specialized trucks produced from the early 1920s to present. The models range in size from 1:12 to 1:50 scale and include numerous limited edition and several out-of-production vehicles. Materials used include tin, diecast and plastic. All models include a certificate of authenticity from their manufacturers and are a perfect ornament for the home and office.",
				null, null, null));

		productLines.add(new ProductLineEntity("Vintage Cars",
				"Our Vintage Car models realistically portray automobiles produced from the early 1900s through the 1940s. Materials used include Bakelite, diecast, plastic and wood. Most of the replicas are in the 1:18 and 1:24 scale sizes, which provide the optimum in detail and accuracy. Prices range from $30.00 up to $180.00 for some special limited edition replicas. All models include a certificate of authenticity from their manufacturers and come fully assembled and ready for display in the home or office.",
				null, null, null));

		productLines.add(new ProductLineEntity("Motorcycles",
				"Our motorcycles are state of the art replicas of classic as well as contemporary motorcycle legends such as Harley Davidson, Ducati and Vespa. Models contain stunning details such as official logos, rotating wheels, working kickstand, front suspension, gear-shift lever, footbrake lever, and drive chain. Materials used include diecast and plastic. The models range in size from 1:10 to 1:50 scale and include numerous limited edition and several out-of-production vehicles. All models come fully assembled and ready for display in the home or office. Most include a certificate of authenticity.",
				null, null));

		return productLines;

	}

	public static List<ProductEntity> productsLoader() {
		List<ProductEntity> products = new ArrayList<>();

		products.add(new ProductEntity(null, "1969 Harley Davidson Ultimate Chopper", "1:10", "Min Lin Diecast",
				"This replica features working kickstand, front suspension, gear-shift lever, footbrake lever, drive chain, wheels and steering. All parts are particularly delicate due to their precise scale and require special care and attention.",
				"7933", 48.81, 95.70, null));

		products.add(new ProductEntity(null, "1952 Alpine Renault 1300", "1:10", "Classic Metal Creations",
				"Turnable front wheels; steering function; detailed interior; detailed engine; opening hood; opening trunk; opening doors; and detailed chassis.",
				"7305", 98.58, 214.30, null));

		products.add(new ProductEntity(null, "1996 Moto Guzzi 1100i", "1:10", "Highway 66 Mini Classics",
				"Official Moto Guzzi logos and insignias, saddle bags located on side of motorcycle, detailed engine, working steering, working suspension, two leather seats, luggage rack, dual exhaust pipes, small saddle bag located on handle bars, two-tone paint with chrome accents, superior die-cast detail , rotating wheels , working kick stand, diecast metal with plastic parts and baked enamel finish.",
				"6625", 68.99, 118.94, null));

		products.add(new ProductEntity(null, "2003 Harley-Davidson Eagle Drag Bike", "1:10", "Red Start Diecast",
				"Model features, official Harley Davidson logos and insignias, detachable rear wheelie bar, heavy diecast metal with resin parts, authentic multi-color tampo-printed graphics, separate engine drive belts, free-turning front fork, rotating tires and rear racing slick, certificate of authenticity, detailed engine, display stand\r\n, precision diecast replica, baked enamel finish, 1:10 scale model, removable fender, seat and tank cover piece for displaying the superior detail of the v-twin engine",
				"5582", 91.02, 193.66, null));

		products.add(new ProductEntity(null, "1972 Alfa Romeo GTA", "1:10", "Motor City Art Classics",
				"Features include: Turnable front wheels; steering function; detailed interior; detailed engine; opening hood; opening trunk; opening doors; and detailed chassis.",
				"3252", 85.68, 136.00, null));

		products.add(new ProductEntity(null, "1962 LanciaA Delta 16V", "1:10", "Second Gear Diecast",
				"Features include: Turnable front wheels; steering function; detailed interior; detailed engine; opening hood; opening trunk; opening doors; and detailed chassis.",
				"6791", 103.42, 147.74, null));

		products.add(new ProductEntity(null, "1968 Ford Mustang", "1:12", "Autoart Studio Design",
				"Hood, doors and trunk all open to reveal highly detailed interior features. Steering wheel actually turns the front wheels. Color dark green.",
				"68", 95.34, 194.57, null));

		products.add(new ProductEntity(null, "2001 Ferrari Enzo", "1:12", "Second Gear Diecast",
				"Turnable front wheels; steering function; detailed interior; detailed engine; opening hood; opening trunk; opening doors; and detailed chassis.",
				"3619", 95.59, 207.80, null));

		products.add(new ProductEntity(null, "Pont Yacht", "1:72", "Unimax Art Galleries",
				"Measures 38 inches Long x 33 3/4 inches High. Includes a stand.\r\nMany extras including rigging, long boats, pilot house, anchors, etc. Comes with 2 masts, all square-rigged",
				"414", 33.30, 54.60, null));
		return products;

	}
}
