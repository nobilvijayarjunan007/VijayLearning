




package com.dnapass.training.entity;

import java.io.Serializable;
import java.util.Objects;

import javax.persistence.Embeddable;

//@Embeddable
public class CompositeKeyClass implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private OrderEntity orders;
	
	private Long productCode;

	public CompositeKeyClass() {
		super();
	}

	public CompositeKeyClass(OrderEntity orders, Long productCode) {
		super();
		this.orders = orders;
		this.productCode = productCode;
	}

	public OrderEntity getOrders() {
		return orders;
	}

	public void setOrders(OrderEntity orders) {
		this.orders = orders;
	}

	public Long getProductCode() {
		return productCode;
	}

	public void setProductCode(Long productCode) {
		this.productCode = productCode;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((orders == null) ? 0 : orders.hashCode());
		result = prime * result + ((productCode == null) ? 0 : productCode.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CompositeKeyClass other = (CompositeKeyClass) obj;
		if (orders == null) {
			if (other.orders != null)
				return false;
		} else if (!orders.equals(other.orders))
			return false;
		if (productCode == null) {
			if (other.productCode != null)
				return false;
		} else if (!productCode.equals(other.productCode))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "IdClass [orders=" + orders + ", productCode=" + productCode + "]";
	}

}
