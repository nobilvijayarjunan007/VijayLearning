package com.dnapass.training.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.dnapass.training.entity.OrderDetailEntity;
import com.dnapass.training.entity.OrderEntity;
import com.dnapass.training.exception.ApplicationException;
import com.dnapass.training.service.OrderDetailService;
import com.dnapass.training.service.OrderService;

@RestController
@RequestMapping("/orderapi")
public class OrderController {

	@Autowired
	private OrderService orderService;

	@Autowired
	private OrderDetailService orderDetService;

	@RequestMapping(method = RequestMethod.POST, value = "/orders")
	public ResponseEntity<OrderEntity> addCustomer(@RequestBody OrderEntity order) throws ApplicationException {

		OrderEntity newOrder = orderService.addOrder(order);

		HttpHeaders httpHeaders = new HttpHeaders();
		httpHeaders.add("orders", "/orders" + newOrder.getOrderNumber().toString());

		return new ResponseEntity<>(newOrder, httpHeaders, HttpStatus.CREATED);
	}

	@RequestMapping(method = RequestMethod.GET, value = "/order/{orderId}")
	public ResponseEntity<OrderEntity> findOrder(@PathVariable(name = "orderId") Long orderId) {

		OrderEntity order = orderService.findOrder(orderId);

		return new ResponseEntity<>(order, HttpStatus.OK);
	}

	@RequestMapping(method = RequestMethod.GET, value = "/orders")
	public ResponseEntity<List<OrderEntity>> findOrders() {

		List<OrderEntity> orders = orderService.findOrders();

		return new ResponseEntity<>(orders, HttpStatus.OK);
	}

	@RequestMapping(method = RequestMethod.GET, value = "/orderDetails")
	public ResponseEntity<List<OrderDetailEntity>> findOrderDetails() {

		List<OrderDetailEntity> orderDtailsList = orderDetService.findOrderDetails();

		return new ResponseEntity<>(orderDtailsList, HttpStatus.OK);
	}

	@RequestMapping(method = RequestMethod.PUT, value = "/orders/{orderId}")
	public ResponseEntity<OrderEntity> addOrderDetail(@PathVariable(name = "orderId") Long orderId,
			@RequestBody OrderDetailEntity orderDetail) {

		OrderEntity neworderDetail = orderService.addOrderDetail(orderId, orderDetail);

		return new ResponseEntity<>(neworderDetail, HttpStatus.OK);
	}

	@RequestMapping(method = RequestMethod.GET, value = "/orders/{orderId}/{productId}")
	public ResponseEntity<OrderDetailEntity> findOrderDetail(@PathVariable(name = "orderId") Long orderId,
			@PathVariable(name = "productId") Long productId) {

		OrderDetailEntity orderDetail = orderDetService.findOrderDetail(orderId, productId);

		return new ResponseEntity<>(orderDetail, HttpStatus.OK);
	}

}
