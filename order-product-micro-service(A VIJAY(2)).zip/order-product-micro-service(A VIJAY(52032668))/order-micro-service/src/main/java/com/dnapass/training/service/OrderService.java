package com.dnapass.training.service;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dnapass.training.entity.OrderDetailEntity;
import com.dnapass.training.entity.OrderEntity;
import com.dnapass.training.exception.ApplicationException;
import com.dnapass.training.repo.OrderDetailRepo;
import com.dnapass.training.repo.OrderRepo;

@Service
public class OrderService {

	@Autowired
	private OrderRepo orederRepo;
	@Autowired
	private OrderDetailRepo orderDetailRepo;

	public OrderEntity addOrder(OrderEntity order) throws ApplicationException {
		List<OrderEntity> orderList = orederRepo.findAll();
		Optional<OrderEntity> existorder = orderList.stream().filter(c -> c.equals(order)).findFirst();
		if (existorder.isPresent()) {
			throw new ApplicationException("Order Already exists");
		}
		OrderEntity newOrder = orederRepo.save(order);

		return newOrder;
	}

	public OrderEntity findOrder(Long id) {

		Optional<OrderEntity> order = orederRepo.findById(id);

		return order.get();

	}

	public List<OrderEntity> findOrders() {

		List<OrderEntity> ordersList = orederRepo.findAll();

		return ordersList;
	}

	public OrderEntity addOrderDetail(Long orderId, OrderDetailEntity orderDetail) {
		Optional<OrderEntity> order = orederRepo.findById(orderId);
		order.get().setOrderDetails(Arrays.asList(orderDetail));
		return orederRepo.save(order.get());
	}
}
