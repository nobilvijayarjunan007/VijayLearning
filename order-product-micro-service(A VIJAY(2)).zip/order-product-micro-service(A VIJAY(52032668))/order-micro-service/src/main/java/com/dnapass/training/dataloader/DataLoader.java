package com.dnapass.training.dataloader;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.dnapass.training.entity.OrderDetailEntity;
import com.dnapass.training.entity.OrderEntity;

public class DataLoader {

	public static List<OrderEntity> orders() {

		List<OrderEntity> orders = new ArrayList<>();

		OrderEntity order1 = new OrderEntity(null, "2003-01-06", "2003-01-13", "2003-01-10", "Shipped", "comment1");

		OrderEntity order2 = new OrderEntity(null, "2003-01-09", "2003-01-18", "2003-01-11", "Shipped",
				"Check on availability.");

		OrderEntity order3 = new OrderEntity(null, "2003-02-24", "2003-03-03", "2003-02-26", "Shipped",
				"Difficult to negotiate with customer. We need more marketing materials");

		OrderDetailEntity od1 = new OrderDetailEntity(1l, 30, 136.00, 3, order1);

		OrderDetailEntity od2 = new OrderDetailEntity(2l, 50, 1500.00, 4, order1);

		OrderDetailEntity od3 = new OrderDetailEntity(3l, 25, 1300.00, 5, order2);

		OrderDetailEntity od4 = new OrderDetailEntity(3l, 2, 135.00, 5, order3);

		order1.setOrderDetails(Arrays.asList(od1, od2));
		order2.setOrderDetails(Arrays.asList(od3));
		order3.setOrderDetails(Arrays.asList(od4));

		orders.add(order1);
		orders.add(order2);
		orders.add(order3);
		return orders;
	}

	/* Data for the table `orders` */

	// insert into
	// `orders`(`orderNumber`,`orderDate`,`requiredDate`,`shippedDate`,`status`,`comments`,`customerNumber`)
	// values
	//
	// (10100,"2003-01-06","2003-01-13","2003-01-10","Shipped",NULL,363),
	//
	// (10101,"2003-01-09","2003-01-18","2003-01-11","Shipped","Check on
	// availability.",128),
	//
	// (10102,"2003-01-10","2003-01-18","2003-01-14","Shipped",NULL,181),
	//
	// (10103,"2003-01-29","2003-02-07","2003-02-02","Shipped",NULL,121),
	//
	// (10104,"2003-01-31","2003-02-09","2003-02-01","Shipped",NULL,141),
	//
	// (10105,"2003-02-11","2003-02-21","2003-02-12","Shipped",NULL,145),
	//
	// (10106,"2003-02-17","2003-02-24","2003-02-21","Shipped",NULL,278),
	//
	// (10107,"2003-02-24","2003-03-03","2003-02-26","Shipped","Difficult to
	// negotiate with customer. We need more marketing materials",131),
	//
	// (10108,"2003-03-03","2003-03-12","2003-03-08","Shipped",NULL,385),

	// (10425,"2005-05-31","2005-06-07",NULL,"In Process",NULL,119);

	////////////////////////////////////////////

	/* Data for the table `orderdetails` */

	// insert into
	// `orderdetails`(`orderNumber`,`productCode`,`quantityOrdered`,`priceEach`,`orderLineNumber`)
	// values
	//
	// (10100,"S18_1749",30,"136.00",3),
	//
	// (10100,"S18_2248",50,"55.09",2),
	//
	// (10100,"S18_4409",22,"75.46",4),
	//
	// (10100,"S24_3969",49,"35.29",1),
	//
	// (10101,"S18_2325",25,"108.06",4),
	//
	// (10101,"S18_2795",26,"167.06",1),
	//
	// (10101,"S24_1937",45,"32.53",3),
	//
	// (10101,"S24_2022",46,"44.35",2),
	//
	// (10102,"S18_1342",39,"95.55",2),
	//
	//
	// (10425,"S50_1392",18,"94.92",2);

}
