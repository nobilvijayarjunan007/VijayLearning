package com.dnapass.training;

import java.util.Arrays;
import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.context.annotation.Bean;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.dnapass.training.model.Order;
import com.dnapass.training.model.OrderDetail;
import com.dnapass.training.model.Product;
import com.dnapass.training.model.ProductLine;

@SpringBootApplication
@RestController
@EnableEurekaClient
@EnableFeignClients
public class OrderProductlineMicroServiceApplication {
	private static final String HTTP_PRODUCTLINE_MICRO_SERVICE_PRODUCTLINEAPI_PRODUCT_LINES = "http://order-productline-api-gateway/productlineapi/productLines";

	// @Autowired
	private RestTemplate restTemplate;

	@Autowired(required = true)
	private OrderFeignClient orderFeignClient;

	public static void main(String[] args) {
		SpringApplication.run(OrderProductlineMicroServiceApplication.class, args);
	}

	@LoadBalanced
	@Bean
	public RestTemplate restTemplate(RestTemplateBuilder builder) {

		restTemplate = builder.build();
		return restTemplate;
	}

	@GetMapping("/hello")
	public String findEmployee() {
		return "Order Productline micro service working";
	}

//	
//??????????????????????/
	@GetMapping("/api/order/{id}")
	public Order findEmployees(@PathVariable(name = "id") Long id) {

		ResponseEntity<List<Product>> response1 = restTemplate.exchange(
				"http://order-productline-api-gateway/productlineapi/products", HttpMethod.GET, null,
				new ParameterizedTypeReference<List<Product>>() {
				});

		Product product = response1.getBody().stream().filter(p -> p.getProductCode() == 1l).findAny().get();

		System.out.println("+++++++++++++Method two+++++++++++" + response1);
		ResponseEntity<List<ProductLine>> response = restTemplate.exchange(
				HTTP_PRODUCTLINE_MICRO_SERVICE_PRODUCTLINEAPI_PRODUCT_LINES, HttpMethod.GET, null,
				new ParameterizedTypeReference<List<ProductLine>>() {
				});

		System.out.println("+++++++++++++Method two+++++++++++" + response);

		ResponseEntity<List<Order>> orders = orderFeignClient.getOrders();

		System.out.println("++++++++++++feign client+++++++++++++" + orders);

		Order order1 = orders.getBody().stream().filter(order -> order.getOrderNumber() == id).findAny().get();

		System.out.println("++++++++++++feign client+++++++++++++" + order1);

		ResponseEntity<List<OrderDetail>> orderDetailsList = orderFeignClient.getOrderDetails();

		System.out.println("++++++++++++feign client+++++++++++++" + orderDetailsList);
		OrderDetail orderDetail = orderDetailsList.getBody().stream().filter(od -> od.getProductCode() == id).findAny()
				.get();

		orderDetail.setProduct(product);
		System.out.println("++++++++++++feign client+++++++++++++" + orderDetailsList);
		order1.setOrderDetails(Arrays.asList(orderDetail));
		return order1;
	}

}
