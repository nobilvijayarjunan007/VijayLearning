package com.dnapass.training;

import java.util.stream.IntStream;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.cloud.client.ServiceInstance;
import org.springframework.cloud.client.loadbalancer.LoadBalancerClient;
import org.springframework.stereotype.Component;

@Component
public class SpringLoadBalancerExample implements CommandLineRunner {

	@Autowired
	private LoadBalancerClient loadBalancer;

	public void run(String... strings) throws Exception {

		IntStream.range(1, 10).forEach(i -> {
			ServiceInstance instance = loadBalancer.choose("productline-micro-service");
			System.out.println("=============================" + i);
			System.out.println("Spring load balancer :" + ToStringBuilder.reflectionToString(instance));

		});

	}

}
