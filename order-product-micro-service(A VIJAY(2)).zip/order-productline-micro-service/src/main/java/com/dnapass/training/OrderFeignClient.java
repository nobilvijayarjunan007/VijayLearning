package com.dnapass.training;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.dnapass.training.model.Order;
import com.dnapass.training.model.OrderDetail;

@FeignClient("order-productline-api-gateway")
public interface OrderFeignClient {
	@RequestMapping(method = RequestMethod.GET, value = "/orderapi/orders")
	ResponseEntity<List<Order>> getOrders();

	@RequestMapping(method = RequestMethod.GET, value = "/orderapi/orderDetails")
	ResponseEntity<List<OrderDetail>> getOrderDetails();

}
