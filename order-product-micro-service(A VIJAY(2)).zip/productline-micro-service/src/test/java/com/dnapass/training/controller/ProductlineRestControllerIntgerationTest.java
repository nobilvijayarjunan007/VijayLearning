package com.dnapass.training.controller;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.io.IOException;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.dnapass.training.entity.ProductLineEntity;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@RunWith(SpringRunner.class)
@SpringBootTest
@AutoConfigureMockMvc
@Rollback(false)
//@TestInstance(Lifecycle.PER_CLASS)

public class ProductlineRestControllerIntgerationTest {

	@Autowired
	private MockMvc mvc;

	@Test
	public void contextLoads() throws Exception {

		assertThat(mvc).isNotNull();
	}

	@Test
	public void getProductlineList() throws Exception {
		String uri = "/productlineapi/productLines";
		MvcResult mvcResult = mvc.perform(MockMvcRequestBuilders.get(uri).accept(MediaType.APPLICATION_JSON_VALUE))
				.andReturn();

		int status = mvcResult.getResponse().getStatus();
		assertEquals(200, status);
		String content = mvcResult.getResponse().getContentAsString();
		System.out.println("content :: " + content);
		List<ProductLineEntity> empList = mapFromJson(content, new TypeReference<List<ProductLineEntity>>() {
		});
		// assertTrue(empList.size() == 4);

		// assertEquals(empList.size(), 1);

	}

	@Test
	public void getProductList() throws Exception {
		String uri = "/productlineapi/products";
		MvcResult mvcResult = mvc.perform(MockMvcRequestBuilders.get(uri).accept(MediaType.APPLICATION_JSON_VALUE))
				.andReturn();

		int status = mvcResult.getResponse().getStatus();
		assertEquals(200, status);
		String content = mvcResult.getResponse().getContentAsString();
		System.out.println("content :: " + content);

	}

	@Test
	public void saveProductLine() throws Exception {
		String uri = "/productlineapi/productlines";
		ProductLineEntity productLineEntity = new ProductLineEntity("Classic Cars",
				"Attention car enthusiasts: Make your wildest car ownership dreams come true. ", null, null);
		String inputJson = mapToJson(productLineEntity);
		MvcResult mvcResult = mvc.perform(
				MockMvcRequestBuilders.post(uri).contentType(MediaType.APPLICATION_JSON_VALUE).content(inputJson))
				.andReturn();
		System.out.println("mvcResult>>>>>>>>>>>>>>>>>>>>>>>>>" + mvcResult.getResponse().getStatus());
		int status = mvcResult.getResponse().getStatus();
		System.out.println(">>>>>>>>>>>>>>>>>>>>>>>>>" + status);
		assertEquals(201, status);
		String content = mvcResult.getResponse().getContentAsString();
		System.out.println("content ::>>>>>>>>>>>>>>>>>>>>>>>> " + content);
		ProductLineEntity pl = mapFromJson(content, ProductLineEntity.class);
		assertNotNull(pl);

		System.out.println("productline created :: >>>>>>>>>>>>>>>>>>>>> " + pl);

	}

	@Test
	public void getProductLineById() throws Exception {
		String uri = "/productlineapi/orderlines/1";
		MvcResult mvcResult = mvc.perform(MockMvcRequestBuilders.get(uri).accept(MediaType.APPLICATION_JSON_VALUE))
				.andReturn();

		int status = mvcResult.getResponse().getStatus();
		System.out.println(status);
		assertEquals(200, status);
		String content = mvcResult.getResponse().getContentAsString();
		System.out.println("content :: >>>>>>>>>>>>getProductline>>>>>>>>>>>>>>" + content);
		ProductLineEntity productline = mapFromJson2(content, new TypeReference<ProductLineEntity>() {
		});

		System.out.println("getProductline () :: " + productline);
	}

	@Test
	public void getProductById() throws Exception {
		String uri = "/productapi/products/1";
		MvcResult mvcResult = mvc.perform(MockMvcRequestBuilders.get(uri).accept(MediaType.APPLICATION_JSON_VALUE))
				.andReturn();

		int status = mvcResult.getResponse().getStatus();
		System.out.println(status);
		assertEquals(200, status);
		String content = mvcResult.getResponse().getContentAsString();
		System.out.println("content :: >>>>>>>>>>>>GET Product>>>>>>>>>>>>>>" + content);

	}

	private ProductLineEntity mapFromJson2(String content, TypeReference<ProductLineEntity> typeReference)
			throws JsonMappingException, JsonProcessingException {
		ObjectMapper objectMapper = new ObjectMapper();
		objectMapper.setSerializationInclusion(Include.NON_NULL);
		return objectMapper.readValue(content, typeReference);
	}

	protected String mapToJson(Object obj) throws JsonProcessingException {
		ObjectMapper objectMapper = new ObjectMapper();
		objectMapper.setSerializationInclusion(Include.NON_NULL);
		return objectMapper.writeValueAsString(obj);
	}

	protected <T> T mapFromJson(String Json, Class<T> clazz)
			throws JsonParseException, JsonMappingException, IOException {
		ObjectMapper objectMapper = new ObjectMapper();
		objectMapper.setSerializationInclusion(Include.NON_NULL);
		return objectMapper.readValue(Json, clazz);
	}

	private List<ProductLineEntity> mapFromJson(String content, TypeReference<List<ProductLineEntity>> typeReference)
			throws JsonMappingException, JsonProcessingException {

		ObjectMapper objectMapper = new ObjectMapper();
		objectMapper.setSerializationInclusion(Include.NON_NULL);
		return objectMapper.readValue(content, typeReference);
	}
}
