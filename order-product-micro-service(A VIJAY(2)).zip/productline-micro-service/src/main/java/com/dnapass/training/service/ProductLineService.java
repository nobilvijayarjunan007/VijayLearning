package com.dnapass.training.service;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.dnapass.training.entity.ProductEntity;
import com.dnapass.training.entity.ProductLineEntity;
import com.dnapass.training.exception.ApplicationException;
import com.dnapass.training.repo.ProductLineRepo;
import com.dnapass.training.repo.ProductRepo;

@Service
public class ProductLineService {

	@Autowired
	private ProductLineRepo productLineRepo;
	@Autowired
	private ProductRepo productRepo;

	public ProductLineEntity addProductLine(ProductLineEntity productLine) throws ApplicationException {
		List<ProductLineEntity> productLineList = productLineRepo.findAll();
		Optional<ProductLineEntity> existProductLine = productLineList.stream().filter(c -> c.equals(productLine))
				.findFirst();
		if (existProductLine.isPresent()) {
			throw new ApplicationException("ProductLine Already exists");
		}
		ProductLineEntity newProductLine = productLineRepo.save(productLine);

		return newProductLine;
	}

	public ProductLineEntity findProductLine(String productLineid) {

		Optional<ProductLineEntity> productLine = productLineRepo.findById(productLineid);

		return productLine.get();

	}

	public List<ProductLineEntity> findProductLines() {

		List<ProductLineEntity> productLineList = productLineRepo.findAll();

		return productLineList;
	}

	public Page<ProductLineEntity> findproductlineByPageWise(Pageable page) {

		Page<ProductLineEntity> productLineList = productLineRepo.findAll(page);

		return productLineList;
	}

	public ProductLineEntity addProduct(String productLineId, ProductEntity product) {
		Optional<ProductLineEntity> productLine = productLineRepo.findById(productLineId);
		productLine.get().setProducts(Arrays.asList(product));
		return productLineRepo.save(productLine.get());
	}

}
