package com.dnapass.training.spring.micro.service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
