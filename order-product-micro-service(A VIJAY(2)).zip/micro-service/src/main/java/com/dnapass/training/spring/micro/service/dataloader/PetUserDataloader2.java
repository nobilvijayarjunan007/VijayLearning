package com.dnapass.training.spring.micro.service.dataloader;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.dnapass.training.spring.micro.service.repo.PetRepo;
import com.dnapass.training.spring.micro.service.repo.UserRepo;

@Component
public class PetUserDataloader2 implements CommandLineRunner {

	@Autowired
	private UserRepo userRepo;
	// @Autowired
	// private PetRepo petRepo;

	@Override
	public void run(String... args) throws Exception {

		loadUser();

	}

	private void loadUser() {
		if (userRepo.count() == 0) {

			userRepo.saveAll(DataLoader3.newUsers());

			System.out.println("USER AND PET loaded");

		}

	}

}
