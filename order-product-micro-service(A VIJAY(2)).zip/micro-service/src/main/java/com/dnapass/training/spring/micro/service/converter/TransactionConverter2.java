package com.dnapass.training.spring.micro.service.converter;

import java.util.ArrayList;
import java.util.List;

import org.springframework.data.domain.Page;

import com.dnapass.training.spring.micro.service.dto.Transaction;
import com.dnapass.training.spring.micro.service.entity.TransactionsEntity;

public class TransactionConverter2 {

	public Transaction convert(TransactionsEntity entity) {

		return new Transaction(entity.getId(), entity.getType(), entity.getAmount(), entity.getCity(),
				entity.getCurrency());

	}

	public TransactionsEntity convert(Transaction model) {

		return new TransactionsEntity(model.getId(), model.getType(), model.getAmount(), model.getCity(),
				model.getCurrency());
	}

	public List<Transaction> convert(List<TransactionsEntity> tranEntityList) {

		List<Transaction> tranList = new ArrayList<>();

		for (TransactionsEntity entity : tranEntityList) {

			Transaction tran = convert(entity);
			tranList.add(tran);

		}

		return tranList;
	}

	public List<TransactionsEntity> convert1(List<Transaction> tranModelList) {

		List<TransactionsEntity> tranList = new ArrayList<>();

		for (Transaction model : tranModelList) {

			TransactionsEntity tran = convert(model);
			tranList.add(tran);

		}

		return tranList;

	}

	public List<Transaction> convert(Page<TransactionsEntity> tranEntityList) {
		List<Transaction> tranList = new ArrayList<>();

		for (TransactionsEntity entity : tranEntityList) {

			Transaction tran = convert(entity);
			tranList.add(tran);

		}

		return tranList;

	}

}
