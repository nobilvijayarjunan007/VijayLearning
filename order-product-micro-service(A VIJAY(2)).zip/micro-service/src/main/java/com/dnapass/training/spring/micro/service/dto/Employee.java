package com.dnapass.training.spring.micro.service.dto;

import java.util.Date;
import java.util.Objects;

public class Employee {


	private Integer empId;
	private String empName;
	private String empDept;
	private String empLocation;
	private Date empHireDate;
	private Double salary;
	
	public Employee() {
		super();
	}

	public Employee(Integer empId, String empName, String empDept, String empLocation) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.empDept = empDept;
		this.empLocation = empLocation;
	}

	public Employee(Integer empId, String empName, String empDept, String empLocation, Date empHireDate,
			Double salary) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.empDept = empDept;
		this.empLocation = empLocation;
		this.empHireDate = empHireDate;
		this.salary = salary;
	}

	public Integer getEmpId() {
		return empId;
	}

	public void setEmpId(Integer empId) {
		this.empId = empId;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public String getEmpDept() {
		return empDept;
	}

	public void setEmpDept(String empDept) {
		this.empDept = empDept;
	}

	public String getEmpLocation() {
		return empLocation;
	}

	public void setEmpLocation(String empLocation) {
		this.empLocation = empLocation;
	}

	public Date getEmpHireDate() {
		return empHireDate;
	}

	public void setEmpHireDate(Date empHireDate) {
		this.empHireDate = empHireDate;
	}

	public Double getSalary() {
		return salary;
	}

	public void setSalary(Double salary) {
		this.salary = salary;
	}

	@Override
	public int hashCode() {
		return Objects.hash(empDept, empHireDate, empId, empLocation, empName, salary);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Employee other = (Employee) obj;
		return Objects.equals(empDept, other.empDept) && Objects.equals(empHireDate, other.empHireDate)
				&& Objects.equals(empId, other.empId) && Objects.equals(empLocation, other.empLocation)
				&& Objects.equals(empName, other.empName) && Objects.equals(salary, other.salary);
	}

	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empName=" + empName + ", empDept=" + empDept + ", empLocation="
				+ empLocation + ", empHireDate=" + empHireDate + ", salary=" + salary + "]";
	}
	
	
	
}
