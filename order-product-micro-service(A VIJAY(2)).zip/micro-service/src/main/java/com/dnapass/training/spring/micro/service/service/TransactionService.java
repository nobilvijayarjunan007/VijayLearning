package com.dnapass.training.spring.micro.service.service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
//import org.springframework.boot.autoconfigure.data.web.SpringDataWebProperties.Pageable;
import org.springframework.stereotype.Service;

import com.dnapass.training.spring.micro.service.converter.TransactionConverter2;
import com.dnapass.training.spring.micro.service.dto.Transaction;
import com.dnapass.training.spring.micro.service.entity.TransactionsEntity;
import com.dnapass.training.spring.micro.service.enums.ProductType;
import com.dnapass.training.spring.micro.service.exception.ApplicationException;
import com.dnapass.training.spring.micro.service.repo.TransactionsRepo;
import com.dnapass.training.spring.micro.service.validator.TransactionValidator;

@Service

public class TransactionService implements ITransactionService {

	@Autowired
	private TransactionsRepo repository;

	TransactionConverter2 converter = new TransactionConverter2();

	@Override
	public Transaction createTransaction(Transaction newTransaction) throws ApplicationException {
		TransactionValidator.validateNewTransaction(newTransaction);
		TransactionsEntity transaction = converter.convert(newTransaction);
		List<TransactionsEntity> transactions = repository.findAll();
		Optional<TransactionsEntity> tran = transactions.stream().filter(t -> t.equals(transaction)).findFirst();
		if (tran.isPresent()) {
			throw new ApplicationException("Transaction Already Exists");
		}
		return converter.convert(repository.save(transaction));
	}

	@Override
	public void deleteTransaction(Transaction transaction) throws ApplicationException {
		TransactionValidator.validateDeleteTransaction(transaction);
		TransactionsEntity tran = converter.convert(transaction);
		if (!findTransaction(transaction)) {

			throw new ApplicationException();
		}
		repository.delete(tran);

	}

	@Override
	public void deleteTransaction(int id) throws ApplicationException {
		TransactionValidator.validateDeleteTransaction(id);

		if (findTransactionById(id) == null) {

			throw new ApplicationException("Transaction Not Found");
		}
		repository.deleteById(id);

	}

	@Override
	public Transaction updateTransaction(Transaction transaction) throws ApplicationException {
		TransactionValidator.validateUpdateTransaction(transaction);
		TransactionsEntity tranEntity = converter.convert(transaction);
		Optional<TransactionsEntity> tran = repository.findById(tranEntity.getId());
		if (!tran.isPresent()) {
			throw new ApplicationException("Transaction Not Found");
		} else {
			TransactionsEntity transactionsEntity = tran.get();
			transactionsEntity.setAmount(tranEntity.getAmount());
			transactionsEntity.setCity(tranEntity.getCity());
			transactionsEntity.setCurrency(tranEntity.getCurrency());
			transactionsEntity.setAmount(tranEntity.getAmount());

			return converter.convert(repository.save(transactionsEntity));
		}
	}

	@Override
	public boolean findTransaction(Transaction transaction) throws ApplicationException {

		TransactionsEntity tranEntity = converter.convert(transaction);
		List<TransactionsEntity> transactions = repository.findAll();
		Optional<TransactionsEntity> tran = transactions.stream().filter(t -> t.equals(tranEntity)).findFirst();
		if (!tran.isPresent()) {
			return false;
		}
		return true;
	}

	@Override
	public Transaction findTransactionByIndex(int index) throws ApplicationException {

		List<TransactionsEntity> transactions = repository.findAll();
		if (transactions.size() <= index) {
			throw new ApplicationException("Invalid index value");
		}
		TransactionsEntity transactionsEntity = transactions.get(index);
		if (transactionsEntity == null) {
			throw new ApplicationException("Transaction not found");
		}

		return converter.convert(transactionsEntity);
	}

	@Override
	public Transaction findTransactionById(int id) throws ApplicationException {
		TransactionValidator.validateFindTransactionById(id);
		Optional<TransactionsEntity> tran = repository.findById(id);
		if (!tran.isPresent()) {
			throw new ApplicationException("Transaction not found");
		}
		return converter.convert(tran.get());
	}

	@Override
	public List<Transaction> findTransactionByProductType(ProductType name) throws ApplicationException {
		TransactionValidator.validateProductType(name);
		List<TransactionsEntity> transactions = repository.findAll();

		List<TransactionsEntity> tran = transactions.stream().filter(t -> t.getType() == name)
				.collect(Collectors.toList());

		// System.out.println(tran);
		if (tran.isEmpty()) {
			throw new ApplicationException("Transaction not found with productType");
		}

		return converter.convert(tran);
	}

	@Override
	public List<Transaction> findTransactionByProductTypeAndAmount(ProductType name, Double amount)
			throws ApplicationException {
		TransactionValidator.validateTransactionProductTypeAmount(amount, name);
		List<TransactionsEntity> transactions = repository.findAll();

		List<TransactionsEntity> trans = transactions.stream()
				.filter(t -> t.getType() == name && t.getAmount().compareTo(amount) == 0).collect(Collectors.toList());

		if (trans.isEmpty()) {
			throw new ApplicationException("Transaction not found");
		}

		return converter.convert(trans);

	}

	@Override
	public List<Transaction> findTransactionByProductTypeAmountAndCity(ProductType name, Double amount, String city)
			throws ApplicationException {
		TransactionValidator.validateTransactionProductTypeAmountAndCity(amount, name, city);
		List<TransactionsEntity> transactions = repository.findAll();
		List<TransactionsEntity> trans = transactions.stream()
				.filter(t -> t.getType() == name && t.getAmount().compareTo(amount) == 0 && t.getCity().equals(city))
				.collect(Collectors.toList());

		if (trans.isEmpty()) {
			throw new ApplicationException("Transaction not found");
		}

		return converter.convert(trans);
	}

	@Override
	public List<Transaction> getTransactions() {

		return converter.convert(repository.findAll());
	}

	public void setTransactions(List<TransactionsEntity> transactions) {
		repository.saveAll(transactions);
	}

	// pageable

	@Override
	public List<Transaction> findTransactionByPageNo(Pageable page) {
		Page<TransactionsEntity> trans = repository.findAll(page);
		List<Transaction> transactions = converter.convert(trans);

		return transactions;
	}

}
