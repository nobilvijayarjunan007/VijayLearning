package com.dnapass.training.spring.micro.service.validator;

import java.util.List;

import com.dnapass.training.spring.micro.service.dto.User;
import com.dnapass.training.spring.micro.service.exception.ApplicationException;

public class UserValidator {

	public static void validateNewUser(User user) throws ApplicationException {

		if (user == null) {
			throw new ApplicationException("Transaction can not be null");
		}

		userFieldsNull(user);

	}

	private static void userFieldsNull(User user) throws ApplicationException {

		validateId(user);
		valiadteName(user);
		validatePassword(user);

	}

	public static void validateId(User user) throws ApplicationException {

		if (user.getUserId() == null) {

			throw new ApplicationException("Id is mandatory");
		}

	}

	public static void validateId(Integer id) throws ApplicationException {

		if (id < 0) {

			throw new ApplicationException("Invalid Id");
		}

	}

	public static void valiadteName(User user) throws ApplicationException {
		if (user.getUserName() == null) {
			throw new ApplicationException("Name can not be null");
		}

	}

	public static void validatePassword(User user) throws ApplicationException {

		if (user.getPassWord() == null) {
			throw new ApplicationException("Password can't be null");

		}
	}

	public static void validateDeleteUser(User user) throws ApplicationException {
		if (user == null) {
			throw new ApplicationException("user can not be null");
		}

	}

	public static void UserCheck(List<User> users, User user) throws ApplicationException {
		if (user == null) {
			throw new ApplicationException("User can not be null");
		}

	}

	public static void validateUser(User user) throws ApplicationException {
		if (user == null) {
			throw new ApplicationException("User can not be null");
		}

	}

	public static void validateUserByNameAndPassword(String name, String password) throws ApplicationException {
		if (name == null && password == null) {
			throw new ApplicationException("Name and Password should not be null");

		}

	}

	// >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>.>
	public static void validateUpdateUser(User user) throws ApplicationException {
		if (user == null) {
			throw new ApplicationException("User can not be null");
		}
		userFieldsNull(user);
	}

	public static void validateDeleteUser(int i) throws ApplicationException {

		Integer ii = i;

		if (ii == null) {
			throw new ApplicationException("Id can not be null");
		}

	}

	public static void validateFindUserById(Integer id) throws ApplicationException {

		if (id == null) {
			throw new ApplicationException("Id can not be null");

		}

	}

	public static void validateCheckTransactioContainsOrNot(User user) throws ApplicationException {

		if (user == null) {
			throw new ApplicationException("user can not be null");

		}
	}

	public static void validateAndGetTransactionListBasedOnIdAndProductType(Integer id, String name)
			throws ApplicationException {

		if (id == null && name == null) {
			throw new ApplicationException("name and Id  should not be null");

		}
	}

	public static void validateAndGetTransactionListBasedOnIdProductTypeAndCity(Integer id, String name,
			String password) throws ApplicationException {
		if (id == null && name == null && password == null) {
			throw new ApplicationException("password , Id and name  should not be null");

		}

	}

}
