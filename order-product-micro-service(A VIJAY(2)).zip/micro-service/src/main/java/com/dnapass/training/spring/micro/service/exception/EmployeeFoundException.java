package com.dnapass.training.spring.micro.service.exception;

public class EmployeeFoundException extends RuntimeException {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public EmployeeFoundException(Integer id) {
		super("Find employee with id " + id);
	}

	public EmployeeFoundException(String string) {
		
	}
}
