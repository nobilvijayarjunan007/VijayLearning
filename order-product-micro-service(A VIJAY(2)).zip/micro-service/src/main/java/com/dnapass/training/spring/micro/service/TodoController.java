package com.dnapass.training.spring.micro.service;

import java.util.List;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.v3.oas.annotations.parameters.RequestBody;

@RestController
@RequestMapping("/api/v1/todos")
public class TodoController {

	TodoService1 todoService;

	public TodoController(TodoService1 todoService) {
		super();
		this.todoService = todoService;
	}

	//
	//
	@GetMapping
	public ResponseEntity<List<Todo>> getAllTodos() {

		List<Todo> todos = todoService.getTodos();

		return new ResponseEntity<>(todos, HttpStatus.OK);
	}

	//
	//
	@GetMapping({ "/{todoId}" })
	public ResponseEntity<Todo> getTodo(@PathVariable Long todoId) {

		return new ResponseEntity<>(todoService.getTodoById(todoId), HttpStatus.OK);
	}

	//
	//

	@PostMapping
	public ResponseEntity<Todo> saveTodo(@RequestBody Todo todo) {

		Todo todo1 = todoService.insert(todo);
		HttpHeaders httpHeaders = new HttpHeaders();
		httpHeaders.add("todo", "/api/v1/todos" + todo1.getId().toString());

		return new ResponseEntity<>(todo1, httpHeaders, HttpStatus.CREATED);
	}
	// the function receives a PUT request,update the Todo with the specified Id
	// and return the updated Todo

	@PutMapping({ "/{todoId}" })
	public ResponseEntity<Todo> updateTodo(@PathVariable("todoId") Long todoId, @RequestBody Todo todo) {
		todoService.updateTodo(todoId, todo);
		return new ResponseEntity<>(todoService.getTodoById(todoId), HttpStatus.OK);

	}

	// The function receives a DELETE request, deletes the todo with the specified
	// Id
	@DeleteMapping({ "/{todoId}" })
	public ResponseEntity<?> deleteTodo(@PathVariable("todoId") Long todoId) {
		todoService.deleteTodo(todoId);
		return new ResponseEntity<>(HttpStatus.NO_CONTENT);
	}
}
