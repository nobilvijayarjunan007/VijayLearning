package com.dnapass.training.spring.micro.service.controller;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.dnapass.training.spring.micro.service.dto.Transaction;
import com.dnapass.training.spring.micro.service.enums.ProductType;
import com.dnapass.training.spring.micro.service.exception.ApplicationException;
import com.dnapass.training.spring.micro.service.exception.TransactionNotFoundException;
import com.dnapass.training.spring.micro.service.service.ITransactionService;

@RestController
@RequestMapping("/api/v1/transaction")
public class TransactionController {

	Logger logger = LoggerFactory.getLogger(TransactionController.class);
	@Autowired
	private ITransactionService service;

	@GetMapping("/")
	ResponseEntity<List<Transaction>> findAll() {

		List<Transaction> trans = service.getTransactions();
		return new ResponseEntity<List<Transaction>>(trans, HttpStatus.OK);

	}

	// Save Transaction

	@PostMapping("/")
	ResponseEntity<Transaction> create(@RequestBody Transaction tran) throws ApplicationException {

		Transaction create = service.createTransaction(tran);
		return new ResponseEntity<Transaction>(create, HttpStatus.CREATED);

	}

	// Delete Transaction with id

	@DeleteMapping("/{id}")
	ResponseEntity<Void> delete(@PathVariable Integer id) throws ApplicationException {
		service.deleteTransaction(id);
		return new ResponseEntity<Void>(HttpStatus.NO_CONTENT);

	}

	@GetMapping("/{id}")
	ResponseEntity<Transaction> findById(@PathVariable Integer id)
			throws TransactionNotFoundException, ApplicationException {

		Transaction transaction = service.findTransactionById(id);
		return new ResponseEntity<Transaction>(transaction, HttpStatus.OK);

	}

	@PutMapping("/update")
	ResponseEntity<Transaction> update(@RequestBody Transaction newTransaction)
			throws TransactionNotFoundException, ApplicationException {
		Transaction transaction = service.updateTransaction(newTransaction);

		return new ResponseEntity<Transaction>(transaction, HttpStatus.OK);
	}

	@GetMapping("/Product/{prod}")
	ResponseEntity<List<Transaction>> findByProduct(@PathVariable ProductType prod) throws ApplicationException {

		List<Transaction> transaction = service.findTransactionByProductType(prod);

		return new ResponseEntity<List<Transaction>>(transaction, HttpStatus.OK);

	}

	@GetMapping("/Product/{prod}/Amount{amount}")
	ResponseEntity<List<Transaction>> findByProductAndAmount(@PathVariable ProductType prod, Double amount)
			throws ApplicationException {

		List<Transaction> transaction = service.findTransactionByProductTypeAndAmount(prod, amount);

		return new ResponseEntity<List<Transaction>>(transaction, HttpStatus.OK);

	}

	@GetMapping("/Product/{prod}/Amount{amount/City{city}")
	ResponseEntity<List<Transaction>> findByProductAmountAndCity(@PathVariable ProductType prod, Double amount,
			String city) throws ApplicationException {

		List<Transaction> transaction = service.findTransactionByProductTypeAmountAndCity(prod, amount, city);

		return new ResponseEntity<List<Transaction>>(transaction, HttpStatus.OK);

	}

	//

	@GetMapping("/PageWise")
	ResponseEntity<List<Transaction>> findTransactionsByPabeWise(@RequestParam Integer page, @RequestParam Integer size,
			@RequestParam String sort) throws ApplicationException {
		PageRequest of = PageRequest.of(page, size, Sort.by(sort));
		List<Transaction> transaction = service.findTransactionByPageNo(of);

		return new ResponseEntity<List<Transaction>>(transaction, HttpStatus.OK);

	}

	@GetMapping("/index")
	ResponseEntity<Transaction> findTransactionsByIndex(@RequestParam int index) throws ApplicationException {
		Transaction transaction = service.findTransactionByIndex(index);

		return new ResponseEntity<Transaction>(transaction, HttpStatus.OK);

	}
}
