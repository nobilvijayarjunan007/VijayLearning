package com.dnapass.training.spring.micro.service.dataloader;

import java.util.ArrayList;
import java.util.List;

import com.dnapass.training.spring.micro.service.entity.PetEntity;
import com.dnapass.training.spring.micro.service.entity.UserEntity;



public class DataLoader3 {
	public static List<UserEntity> newUsers() {

		List<UserEntity> users = new ArrayList<>();

		UserEntity userEntity = new UserEntity(null, "user1", "1234");
		userEntity.getPets().addAll(newPets1(userEntity));
		users.add(userEntity);
		UserEntity userEntity2 = new UserEntity(null, "user2", "4567");
		userEntity2.getPets().addAll(newPets2(userEntity2));
		users.add(userEntity2);
		UserEntity userEntity3 = new UserEntity(null, "user3", "8900");
		userEntity3.getPets().addAll(newPets3(userEntity3));
		users.add(userEntity3);

		return users;
	}

	private static List<PetEntity> newPets3(UserEntity user) {
		List<PetEntity> pets = new ArrayList<>();
		pets.add(new PetEntity(null, "CAT", 3, "MU", user));
		pets.add(new PetEntity(null, "Dog", 2, "EN", user));
		pets.add(new PetEntity(null, "Parrot", 1, "CH", user));

		return pets;
	}

	private static List<PetEntity> newPets2(UserEntity user) {
		List<PetEntity> pets = new ArrayList<>();
		pets.add(new PetEntity(null, "CAT", 3, "CH", user));

		return pets;
	}

	private static List<PetEntity> newPets1(UserEntity user) {

		List<PetEntity> pets = new ArrayList<>();

		pets.add(new PetEntity(null, "Dog", 2, "DL", user));
		pets.add(new PetEntity(null, "Parrot", 1, "CH", user));

		return pets;
	}
}
