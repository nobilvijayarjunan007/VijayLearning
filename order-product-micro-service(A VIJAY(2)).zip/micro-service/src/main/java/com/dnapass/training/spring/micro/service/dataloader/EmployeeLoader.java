package com.dnapass.training.spring.micro.service.dataloader;

import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.dnapass.training.spring.micro.service.entity.EmployeeEntity;
import com.dnapass.training.spring.micro.service.repo.EmployeeRepo;

@Component
public class EmployeeLoader implements CommandLineRunner {

	public final EmployeeRepo repository;

	public EmployeeLoader(EmployeeRepo repository) {
		this.repository = repository;
	}

	@Override
	public void run(String... args) throws Exception {

		loadEmployees();
	}

	private void loadEmployees() {
		if (repository.count() == 0) {
			repository.save(new EmployeeEntity(3l, "vijay", "engg", "location1"));
			repository.save(new EmployeeEntity(4l, "Arjunan", "Medical", "location2"));
			System.out.println("Sample Employees Loaded");
		}

	}

}
