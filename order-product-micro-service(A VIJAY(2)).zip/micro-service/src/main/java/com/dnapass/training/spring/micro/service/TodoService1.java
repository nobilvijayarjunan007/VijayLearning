package com.dnapass.training.spring.micro.service;

import java.util.List;

public interface TodoService1 {

	List<Todo>getTodos();
	
	Todo getTodoById(Long id);
	
	Todo insert (Todo todo);
	
	Todo updateTodo(Long id,Todo todo);
	
	void deleteTodo(Long todoid);
	
}