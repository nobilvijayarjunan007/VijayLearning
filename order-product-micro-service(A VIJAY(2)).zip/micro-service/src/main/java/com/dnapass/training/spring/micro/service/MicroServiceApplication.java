package com.dnapass.training.spring.micro.service;

import java.util.Arrays;
import java.util.concurrent.atomic.AtomicLong;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import springfox.documentation.swagger2.annotations.EnableSwagger2;

@SpringBootApplication
@RestController
@EnableSwagger2
public class MicroServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(MicroServiceApplication.class, args);
	}

	private static final String template = "Hello,%s!";
	private final AtomicLong counter = new AtomicLong();

	@GetMapping("/greeting")

	public Greeting greeting(@RequestParam(value = "name1", defaultValue = "World") String name) {

		return new Greeting(counter.incrementAndGet(), String.format(template, name));
	}

	//@Bean
	public CommandLineRunner empRepository(ApplicationContext ctx) {
		return args -> {

			System.out.println("Let's inspect the beans provided by spring boot :");

			String[] beanNames = ctx.getBeanDefinitionNames();
			Arrays.sort(beanNames);
			for (String beanName : beanNames) {

				System.out.println(beanName);
			}

		};

	}

}
