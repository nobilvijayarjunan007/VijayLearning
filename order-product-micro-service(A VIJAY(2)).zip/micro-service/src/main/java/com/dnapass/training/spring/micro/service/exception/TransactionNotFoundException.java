package com.dnapass.training.spring.micro.service.exception;

public class TransactionNotFoundException extends RuntimeException{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public TransactionNotFoundException(Integer id) {
		// TODO Auto-generated constructor stub
	}

	public TransactionNotFoundException() {
		// TODO Auto-generated constructor stub
	}

}
