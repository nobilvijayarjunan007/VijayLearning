package com.dnapass.training.spring.micro.service.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dnapass.training.spring.micro.service.converter.EmployeeConverter;
import com.dnapass.training.spring.micro.service.dto.Employee;
import com.dnapass.training.spring.micro.service.entity.EmployeeEntity;
import com.dnapass.training.spring.micro.service.exception.EmployeeNotFoundException;
import com.dnapass.training.spring.micro.service.repo.EmployeeRepo;

@Service
public class EmployeeService implements IEmployeeService {

	@Autowired
	private EmployeeRepo employeeRepo;

	@Override
	public Optional<List<Employee>> findAll() {

		List<EmployeeEntity> empEntityList = employeeRepo.findAll();
		List<Employee> empList = EmployeeConverter.convert(empEntityList);

		return Optional.of(empList);
	}

	@Override
	public Optional<Employee> create(Employee newEmployee) {

		// Long id = Long.valueOf(newEmployee.getEmpId());

		// employeeRepo.findById(Long.valueOf(newEmployee.getEmpId()))
		if (employeeRepo.findById(Long.valueOf(newEmployee.getEmpId())) != null) {

			EmployeeEntity entity = EmployeeConverter.convert(newEmployee);

			employeeRepo.save(entity);
			return Optional.of(EmployeeConverter.convert(entity));

		} else {
			return Optional.empty();
		}

		/*
		 * EmployeeEntity entity = EmployeeConverter.convert(newEmployee);
		 * 
		 * employeeRepo.save(entity); return
		 * Optional.of(EmployeeConverter.convert(entity));
		 */

	}

	@Override
	public void delete(Integer id) {

		System.out.println("Employee with " + id + "is deleted");
		Optional<EmployeeEntity> entity = employeeRepo.findById(Long.valueOf(id));
		if (entity.get() != null) {
			employeeRepo.delete(entity.get());
		} else {
			throw new EmployeeNotFoundException(id);
		}

	}

	@Override
	public Optional<Employee> findById(Integer id) {

		Optional<EmployeeEntity> entity = employeeRepo.findById(Long.valueOf(id));

		return Optional.of(EmployeeConverter.convert(entity.get()));

	}

	@Override
	public Optional<Employee> update(Employee newEmployee, Integer id) {

		Optional<EmployeeEntity> entity = employeeRepo.findById(Long.valueOf(id));

		if (entity.get() != null) {
			entity.get().setEmpDept(newEmployee.getEmpDept());
			entity.get().setEmpLocation(newEmployee.getEmpLocation());
			entity.get().setEmpName(newEmployee.getEmpName());
			employeeRepo.save(entity.get());
		} else {
			throw new EmployeeNotFoundException(id);
		}

		return Optional.of(EmployeeConverter.convert(entity.get()));

	}

	/*
	 * @Override public EmployeeEntity getEmployeeByName(String name) {
	 * 
	 * return EmployeeConverter.convert(employeeRepo.findByEmplName(name)); }
	 */

	@Override
	public List<Employee> saveAll(List<Employee> employees) {

		List<EmployeeEntity> empEntities = EmployeeConverter.convertToEntity(employees);
		employeeRepo.saveAll(empEntities);

		return EmployeeConverter.convert(empEntities);

	}

	public Optional<List<Employee>> findByIdAndDeptName(Integer id, String deptName) {

		return null;
	}

}
