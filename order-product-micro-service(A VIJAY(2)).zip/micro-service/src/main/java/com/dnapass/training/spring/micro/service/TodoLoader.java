package com.dnapass.training.spring.micro.service;

import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component
public class TodoLoader implements CommandLineRunner {

	public final TodoRepository todoRepository;

	public TodoLoader(TodoRepository todoRepository) {
		this.todoRepository = todoRepository;
	}

	@Override
	public void run(String... args) throws Exception {
		loadTodos();

	}

	private void loadTodos() {
		if (todoRepository.count() == 0) {
			todoRepository.save(new Todo("Go to market", "buy eggs from market", TodoStatus.NOT_COMPLETED));
			todoRepository.save(new Todo("Go to training", "Complete assignments", TodoStatus.NOT_COMPLETED));
			System.out.println("Sample Todos Loaded");
		}

	}

}