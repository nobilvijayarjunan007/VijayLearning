package com.dnapass.training.spring.micro.service.converter;

import java.util.ArrayList;
import java.util.List;

import com.dnapass.training.spring.micro.service.dto.Transaction;
import com.dnapass.training.spring.micro.service.entity.TransactionsEntity;

public class TransactionConverter {

	public static List<Transaction> convert(List<TransactionsEntity> tranEntityList) {

		List<Transaction> tranList = null;

		if (tranEntityList != null) {
			tranList = new ArrayList<>();
			for (TransactionsEntity entity : tranEntityList) {

				Transaction tran = convert(entity);
				tranList.add(tran);

			}

		}

		return tranList;
	}

	public static Transaction convert(TransactionsEntity entity) {
		Transaction t = null;
		if (entity != null) {
			t = new Transaction();
			if (entity.getId() != null)

				t.setId(entity.getId().intValue());
			t.setAmount(entity.getAmount());
			t.setCity(entity.getCity());
			t.setCurrency(entity.getCurrency());
			t.setType(entity.getType());

		}

		return t;

	}

	public static TransactionsEntity convert(Transaction newtran) {

		TransactionsEntity tran = null;
		if (newtran != null) {
			tran = new TransactionsEntity();
			tran.setId(Integer.valueOf(newtran.getId()));

			tran.setAmount(newtran.getAmount());
			tran.setCity(newtran.getCity());
			tran.setCurrency(newtran.getCurrency());
			tran.setType(newtran.getType());

		}
		return tran;
	}
}
