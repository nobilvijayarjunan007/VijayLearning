package com.dnapass.training.spring.micro.service.entity;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

import com.dnapass.training.spring.micro.service.enums.ProductType;

@Entity
public class TransactionsEntity implements Serializable, Cloneable, Comparable<TransactionsEntity> {

	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue
	protected Integer id;
	protected ProductType type;

	protected Double amount;

	protected String city;
	protected String currency;

	public TransactionsEntity() {
		super();
	}

	public TransactionsEntity(Integer id, ProductType type, Double amount, String city, String currency) {
		super();
		this.id = id;
		this.type = type;
		this.amount = amount;
		this.city = city;
		this.currency = currency;
	}

	public int compareTo(TransactionsEntity arg0) {
		// TODO Auto-generated method stub
		return 0;
	}

	public Integer getId() {
		return id;
	}
	@Id
	@GeneratedValue
	public void setId(Integer id) {
		this.id = id;
	}

	public ProductType getType() {
		return type;
	}

	public void setType(ProductType type) {
		this.type = type;
	}

	public Double getAmount() {
		return amount;
	}

	public void setAmount(Double amount) {
		this.amount = amount;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((amount == null) ? 0 : amount.hashCode());
		result = prime * result + ((city == null) ? 0 : city.hashCode());
		result = prime * result + ((currency == null) ? 0 : currency.hashCode());
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		result = prime * result + ((type == null) ? 0 : type.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		TransactionsEntity other = (TransactionsEntity) obj;
		if (amount == null) {
			if (other.amount != null)
				return false;
		} else if (!amount.equals(other.amount))
			return false;
		if (city == null) {
			if (other.city != null)
				return false;
		} else if (!city.equals(other.city))
			return false;
		if (currency == null) {
			if (other.currency != null)
				return false;
		} else if (!currency.equals(other.currency))
			return false;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		if (type != other.type)
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Transactions [" + (id != null ? "id=" + id + ", " : "") + (type != null ? "type=" + type + ", " : "")
				+ (amount != null ? "amount=" + amount + ", " : "") + (city != null ? "city=" + city + ", " : "")
				+ (currency != null ? "currency=" + currency : "") + "]";
	}

}
