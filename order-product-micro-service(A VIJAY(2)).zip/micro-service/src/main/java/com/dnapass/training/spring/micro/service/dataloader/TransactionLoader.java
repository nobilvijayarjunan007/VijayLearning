package com.dnapass.training.spring.micro.service.dataloader;

import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.dnapass.training.spring.micro.service.entity.TransactionsEntity;
import com.dnapass.training.spring.micro.service.enums.ProductType;
import com.dnapass.training.spring.micro.service.repo.TransactionsRepo;

@Component
public class TransactionLoader implements CommandLineRunner {

	public final TransactionsRepo repository;

	public TransactionLoader(TransactionsRepo repository) {
		this.repository = repository;
	}

	@Override
	public void run(String... args) throws Exception {

		loadtrans();
	}

	private void loadtrans() {

		DataLoader.newTransaction();
		if (repository.count() == 0) {
			repository.saveAll(DataLoader.newTransaction());
			// repository.save(new TransactionsEntity(100, ProductType.FRUIT, 45.55,
			// "Chennai", "INR"));
			// repository.save(new TransactionsEntity(200, ProductType.FRUIT, 5555.55,
			// "Delhi", "INR"));
			System.out.println("Sample transaction Loaded");
		}

	}
}
