package com.dnapass.training.spring.micro.service.exception;

public class EmployeeNotFoundException extends RuntimeException {
	
	
	private static final long serialVersionUID = 1L;

	public EmployeeNotFoundException(Integer id) {
		super("Could not find employee " + id);
	}

	public EmployeeNotFoundException() {
		super("Could not find employees ");
		
	}

}
