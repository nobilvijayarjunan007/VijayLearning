package com.dnapass.training.spring.micro.service.enums;

public enum ProductType {

	FRUIT,GROCERY,FUEL,ELECTRIC
}
