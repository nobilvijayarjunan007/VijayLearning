package com.dnapass.training.spring.micro.service.dataloader;

import java.util.ArrayList;
import java.util.List;

import com.dnapass.training.spring.micro.service.entity.TransactionsEntity;

import com.dnapass.training.spring.micro.service.enums.ProductType;

public class DataLoader {

	public static List<TransactionsEntity> newTransaction() {

		List<TransactionsEntity> transactions = new ArrayList<TransactionsEntity>();

		transactions.add(new TransactionsEntity(null, ProductType.FRUIT, 45.55, "Chennai", "INR"));
		transactions.add(new TransactionsEntity(null, ProductType.GROCERY, 252.22, "london", "GBP"));
		transactions.add(new TransactionsEntity(null, ProductType.ELECTRIC, 20.99, "bangalore", "USD"));
		transactions.add(new TransactionsEntity(null, ProductType.FRUIT, 68.22, "Chennai", "INR"));
		transactions.add(new TransactionsEntity(null, ProductType.FUEL, 90.34, "london", "GBP"));
		transactions.add(new TransactionsEntity(null, ProductType.ELECTRIC, 150.56, "bangalore", "USD"));
		transactions.add(new TransactionsEntity(null, ProductType.GROCERY, 456.99, "Chennai", "INR"));
		transactions.add(new TransactionsEntity(null, ProductType.FUEL, 451.55, "bangalore", "USD"));
		return transactions;
	}
}
