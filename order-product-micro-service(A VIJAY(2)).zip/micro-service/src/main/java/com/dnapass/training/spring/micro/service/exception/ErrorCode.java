package com.dnapass.training.spring.micro.service.exception;

public enum ErrorCode {
	APP0001,APP0002 ,APP0003
}
