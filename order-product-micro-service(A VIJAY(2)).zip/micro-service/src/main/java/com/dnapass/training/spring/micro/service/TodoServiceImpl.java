package com.dnapass.training.spring.micro.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.sun.xml.bind.v2.TODO;

@Service
public class TodoServiceImpl implements TodoService1 {

	TodoRepository todoRepository;

	public TodoServiceImpl(TodoRepository todoRepository) {
		this.todoRepository = todoRepository;
	}

	@Override
	public List<Todo> getTodos() {

		List<Todo> todos = new ArrayList<>();
		todoRepository.findAll().forEach(todos::add);
		return todos;
	}

	@Override
	public Todo getTodoById(Long id) {
		List<Todo> todos = new ArrayList<>();
		 return  todoRepository.findById(id).get();
		
	}

	@Override
	public Todo insert(Todo todo) {
		return todoRepository.save(todo);
	}

	@Override
	public Todo updateTodo(Long id, Todo todo) {
		Todo todoFromDb = todoRepository.findById(id).get();
		System.out.println(todoFromDb.toString());
		todoFromDb.setTodoStatus(todo.getTodoStatus());
		todoFromDb.setDescription(todo.getDescription());
		todoFromDb.setTitle(todo.getTitle());
		return todoRepository.save(todoFromDb);

	}

	@Override
	public void deleteTodo(Long todoId) {
		todoRepository.deleteById(todoId);
	}

}

