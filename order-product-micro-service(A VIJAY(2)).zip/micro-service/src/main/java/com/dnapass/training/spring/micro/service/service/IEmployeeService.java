package com.dnapass.training.spring.micro.service.service;

import java.util.List;
import java.util.Optional;

import com.dnapass.training.spring.micro.service.dto.Employee;
import com.dnapass.training.spring.micro.service.entity.EmployeeEntity;

public interface IEmployeeService {

	Optional<List<Employee>> findAll();

	Optional<Employee> create(Employee newEmployee);

	void delete(Integer id);

	Optional<Employee> findById(Integer id);

	Optional<Employee> update(Employee newEmployee, Integer id);

	//EmployeeEntity getEmployeeByName(String name);

	List<Employee> saveAll(List<Employee> employees);

	Optional<List<Employee>> findByIdAndDeptName(Integer id, String deptName);

}