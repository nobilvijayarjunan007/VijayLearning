package com.dnapass.training.spring.micro.service.dataloader;

import java.util.ArrayList;
import java.util.List;

import com.dnapass.training.spring.micro.service.entity.PetEntity;
import com.dnapass.training.spring.micro.service.entity.UserEntity;

public class DataLoader2 {

	public static List<UserEntity> newUsers() {

		List<UserEntity> users = new ArrayList<>();

		users.add(new UserEntity(null, "user1", "1234", null));
		users.add(new UserEntity(null, "user2", "4567", null));
		users.add(new UserEntity(null, "user3", "8900", null));

		return users;
	}

	public static List<PetEntity> newPets() {
		List<PetEntity> pets = new ArrayList<>();
		pets.add(new PetEntity(null, "CAT", 3, "CH", newUsers().get(0)));
		pets.add(new PetEntity(null, "Dog", 2, "CH", newUsers().get(1)));
		pets.add(new PetEntity(null, "Parrot", 1, "CH", newUsers().get(2)));
		pets.add(new PetEntity(null, "CAT", 3, "CH", newUsers().get(1)));
		pets.add(new PetEntity(null, "Dog", 2, "CH", newUsers().get(0)));
		pets.add(new PetEntity(null, "Parrot", 1, "CH", newUsers().get(2)));

		return pets;
	}

}
