package com.dnapass.training.spring.micro.service.converter;

import java.util.ArrayList;
import java.util.List;

import com.dnapass.training.spring.micro.service.dto.Pet;
import com.dnapass.training.spring.micro.service.entity.PetEntity;



public class PetConverter {
	public static List<Pet> convert(List<PetEntity> petEntityList) {

		List<Pet> petList = null;

		if (petEntityList != null) {
			petList = new ArrayList<>();
			for (PetEntity entity : petEntityList) {

				Pet pet = convert(entity);
				petList.add(pet);

			}

		}

		return petList;
	}

	public static Pet convert(PetEntity entity) {
		Pet pet = null;
		if (entity != null) {
			pet = new Pet();
			if (entity.getPetId() != null)

				pet.setPetId(entity.getPetId());
			pet.setPetName(entity.getPetName());
			pet.setAge(entity.getAge());
			pet.setPetPlace(entity.getPetPlace());
			//pet.setUser(entity.getUser());

		}

		return pet;

	}

	public static PetEntity convert(Pet newpet) {

		PetEntity pet = null;
		if (newpet != null) {
			pet = new PetEntity();

			pet.setPetId(Long.valueOf(newpet.getPetId()));
			pet.setPetName(newpet.getPetName());
			pet.setAge(newpet.getAge());
			pet.setPetPlace(newpet.getPetPlace());

		}
		return pet;
	}

	public static List<PetEntity> convertToEntity(List<Pet> petList) {

		List<PetEntity> petEntityList = null;

		if (petList != null) {
			petEntityList = new ArrayList<>();
			for (Pet pet : petList) {

				PetEntity entity = convert(pet);
				petEntityList.add(entity);

			}

		}

		return petEntityList;
	}

}
