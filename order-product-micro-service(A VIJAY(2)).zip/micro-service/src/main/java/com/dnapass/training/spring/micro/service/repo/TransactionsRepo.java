package com.dnapass.training.spring.micro.service.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.dnapass.training.spring.micro.service.entity.TransactionsEntity;

@Repository
public interface TransactionsRepo extends JpaRepository<TransactionsEntity, Integer> {

}
