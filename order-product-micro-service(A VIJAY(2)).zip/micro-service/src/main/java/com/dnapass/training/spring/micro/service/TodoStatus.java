package com.dnapass.training.spring.micro.service;

public enum TodoStatus {
COMPLETED,NOT_COMPLETED
}
