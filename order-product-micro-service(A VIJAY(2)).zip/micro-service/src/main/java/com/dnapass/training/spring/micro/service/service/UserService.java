
package com.dnapass.training.spring.micro.service.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dnapass.training.spring.micro.service.converter.PetConverter;
import com.dnapass.training.spring.micro.service.converter.UserConverter;
import com.dnapass.training.spring.micro.service.dto.Pet;
import com.dnapass.training.spring.micro.service.dto.User;
import com.dnapass.training.spring.micro.service.entity.PetEntity;
import com.dnapass.training.spring.micro.service.entity.UserEntity;
import com.dnapass.training.spring.micro.service.exception.ApplicationException;
import com.dnapass.training.spring.micro.service.repo.UserRepo;

@Service
public class UserService {

	@Autowired
	private UserRepo userRepo;

	//working fine
	public Optional<User> saveUser(User user) throws ApplicationException {

		UserEntity userEntity = UserConverter.convert(user);
		List<UserEntity> users = userRepo.findAll();
		Optional<UserEntity> user1 = users.stream().filter(u -> u.equals(userEntity)).findFirst();
		if (user1.isPresent()) {
			throw new ApplicationException("User Already Exists");
		}
		return Optional.of(UserConverter.convert(userRepo.save(userEntity)));
	}

	// working fine

	public Optional<List<Pet>> getMyPets(Long userId) {
		Optional<UserEntity> userEntity = userRepo.findById(userId);
		List<PetEntity> pets = userEntity.get().getPets();
		return Optional.of(PetConverter.convert(pets));

	}

}
