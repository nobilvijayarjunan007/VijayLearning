package com.dnapass.training.spring.micro.service.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.dnapass.training.spring.micro.service.dto.Pet;
import com.dnapass.training.spring.micro.service.dto.User;
import com.dnapass.training.spring.micro.service.entity.PetEntity;
import com.dnapass.training.spring.micro.service.entity.UserEntity;
import com.dnapass.training.spring.micro.service.exception.ApplicationException;
import com.dnapass.training.spring.micro.service.service.PetService;
import com.dnapass.training.spring.micro.service.service.UserService;

@RestController

@RequestMapping("/api/v1")
public class MainController {

	@Autowired
	private PetService petService;
	@Autowired
	private UserService userService;

	// Working fine
	@PostMapping("/savePet")
	public ResponseEntity<Pet> savePet(@RequestBody Pet pet) throws ApplicationException {

		Pet petModel = petService.savePet(pet).get();

		HttpHeaders httpHeaders = new HttpHeaders();
		httpHeaders.add("pet", "api/v1" + petModel.getPetId().toString());
		return new ResponseEntity<>(petModel, httpHeaders, HttpStatus.CREATED);

	}

	// Working Fine
	@GetMapping("/home")
	public ResponseEntity<List<Pet>> home() throws ApplicationException {

		List<Pet> petList = petService.getAllPets().get();

		return new ResponseEntity<>(petList, HttpStatus.OK);

	}

	// working fine

	@PutMapping("/buyPet")
	public ResponseEntity<Pet> buyPet(@RequestParam Long petId, @RequestParam Long userId) throws ApplicationException {

		Pet petModel = petService.buyPet(petId, userId).get();

		return new ResponseEntity<>(petModel, HttpStatus.OK);

	}

	

	// Working Fine
	@PostMapping("/saveUser")
	public ResponseEntity<User> saveUser(@RequestBody User user) throws ApplicationException {
		User user2 = userService.saveUser(user).get();
		HttpHeaders httpHeaders = new HttpHeaders();
		httpHeaders.add("todo", "/api/v1" + user2.getUserId().toString());

		return new ResponseEntity<>(user2, httpHeaders, HttpStatus.CREATED);
	}

	// Working Fine
	@GetMapping("/myPets")
	public ResponseEntity<List<Pet>> myPets(@RequestParam Long userId) throws ApplicationException {

		List<Pet> petModel = userService.getMyPets(userId).get();

		return new ResponseEntity<>(petModel, HttpStatus.OK);

	}

}
