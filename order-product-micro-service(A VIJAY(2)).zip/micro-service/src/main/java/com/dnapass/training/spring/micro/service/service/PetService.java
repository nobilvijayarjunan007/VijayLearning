package com.dnapass.training.spring.micro.service.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dnapass.training.spring.micro.service.converter.PetConverter;
import com.dnapass.training.spring.micro.service.dto.Pet;
import com.dnapass.training.spring.micro.service.entity.PetEntity;
import com.dnapass.training.spring.micro.service.entity.UserEntity;
import com.dnapass.training.spring.micro.service.exception.ApplicationException;
import com.dnapass.training.spring.micro.service.repo.PetRepo;
import com.dnapass.training.spring.micro.service.repo.UserRepo;

@Service
public class PetService {

	@Autowired
	private PetRepo petRepo;

	@Autowired
	private UserRepo userRepo;

	// working fine
	public Optional<Pet> savePet(Pet pet) throws ApplicationException {

		PetEntity petEntity = PetConverter.convert(pet);
		List<PetEntity> pets = petRepo.findAll();
		Optional<PetEntity> pet1 = pets.stream().filter(p -> p.equals(petEntity)).findFirst();
		if (pet1.isPresent()) {
			throw new ApplicationException("Pet Already Exists");
		}
		return Optional.of(PetConverter.convert(petRepo.save(petEntity)));
	}

	// working fine
	public Optional<List<Pet>> getAllPets() {

		List<PetEntity> petsList = petRepo.findAll();
		return Optional.of(PetConverter.convert(petsList));

	}

	// working fine

	public Optional<Pet> buyPet(Long petId, Long userId) throws ApplicationException {
		Optional<PetEntity> petEntity = petRepo.findById(petId);
		Optional<UserEntity> userEntity = userRepo.findById(userId);
		if (petEntity.get().getUser() == null) {
			List<PetEntity> petsList = userEntity.get().getPets();
			if (petsList == null) {
				petsList = new ArrayList<>();

			}
			petsList.add(petEntity.get());
			userEntity.get().setPets(petsList);
			petEntity.get().setUser(userEntity.get());
			petRepo.save(petEntity.get());
			// userRepo.save(userEntity.get());

		} else {
			throw new ApplicationException("Pet is Sold Out");

		}
		return Optional.of(PetConverter.convert(petEntity.get()));

	}

	// Not in usecase

	public Optional<Pet> getMyPet(Long id) throws ApplicationException {

		Optional<PetEntity> pet = petRepo.findById(id);
		if (!pet.isPresent()) {
			throw new ApplicationException("Pet not found");
		}
		return Optional.of(PetConverter.convert(pet.get()));
	}

	/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	public boolean findPet(Pet pet) throws ApplicationException {

		PetEntity convert = PetConverter.convert(pet);
		List<PetEntity> pets = petRepo.findAll();
		Optional<PetEntity> pet1 = pets.stream().filter(p -> p.equals(convert)).findFirst();
		if (!pet1.isPresent()) {
			return false;
		}
		return true;
	}

	public Optional<Pet> buyPet2(Long petId, Long userId) throws ApplicationException {
		Optional<PetEntity> pet1 = petRepo.findById(petId);
		if (!pet1.isPresent()) {
			throw new ApplicationException("Pet Not Found");
		} else {
			pet1.get().getUser().setUserId(userId);

			return Optional.of(PetConverter.convert(petRepo.save(pet1.get())));
		}

	}

	// >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

	public void deletePetById(Long id) throws ApplicationException {

		if (getMyPet(id) == null) {

			throw new ApplicationException("Pet Not Found");
		}
		petRepo.deleteById(id);

	}

	public void deletePet(Pet pet) throws ApplicationException {

		PetEntity convert = PetConverter.convert(pet);
		if (!findPet(pet)) {

			throw new ApplicationException();
		}
		petRepo.delete(convert);

	}

	public Pet updatePet(Pet pet) throws ApplicationException {

		PetEntity petEntity = PetConverter.convert(pet);
		Optional<PetEntity> pet1 = petRepo.findById(petEntity.getPetId());
		if (!pet1.isPresent()) {
			throw new ApplicationException("Pet Not Found");
		} else {
			PetEntity petEntity1 = pet1.get();
			petEntity1.setAge(petEntity.getAge());
			petEntity1.setPetName(petEntity.getPetName());
			petEntity1.setPetPlace(petEntity.getPetPlace());
			petEntity1.setUser(petEntity.getUser());

			return PetConverter.convert(petRepo.save(petEntity1));
		}
	}

	public Pet findPetByIndex(int index) throws ApplicationException {

		List<PetEntity> pets = petRepo.findAll();
		if (pets.size() <= index) {
			throw new ApplicationException("Invalid index value");
		}
		PetEntity petEntity = pets.get(index);
		if (petEntity == null) {
			throw new ApplicationException("Pet not found");
		}

		return PetConverter.convert(petEntity);
	}

	public List<Pet> findPetByName(String name) throws ApplicationException {

		List<PetEntity> pets = petRepo.findAll();

		List<PetEntity> matchedPets = pets.stream().filter(p -> p.getPetName() == name).collect(Collectors.toList());

		// System.out.println(tran);
		if (matchedPets.isEmpty()) {
			throw new ApplicationException("Pets not found with name");
		}

		return PetConverter.convert(matchedPets);
	}

//	@Override
//	public List<Transaction> findTransactionByProductTypeAndAmount(ProductType name, Double amount)
//			throws ApplicationException {
//		TransactionValidator.validateTransactionProductTypeAmount(amount, name);
//		List<TransactionsEntity> transactions = repository.findAll();
//
//		List<TransactionsEntity> trans = transactions.stream()
//				.filter(t -> t.getType() == name && t.getAmount().compareTo(amount) == 0).collect(Collectors.toList());
//
//		if (trans.isEmpty()) {
//			throw new ApplicationException("Transaction not found");
//		}
//
//		return converter.convert(trans);

//	}
//
//	@Override
//	public List<Transaction> findTransactionByProductTypeAmountAndCity(ProductType name, Double amount, String city)
//			throws ApplicationException {
//		TransactionValidator.validateTransactionProductTypeAmountAndCity(amount, name, city);
//		List<TransactionsEntity> transactions = repository.findAll();
//		List<TransactionsEntity> trans = transactions.stream()
//				.filter(t -> t.getType() == name && t.getAmount().compareTo(amount) == 0 && t.getCity().equals(city))
//				.collect(Collectors.toList());
//
//		if (trans.isEmpty()) {
//			throw new ApplicationException("Transaction not found");
//		}
//
//		return converter.convert(trans);
//	}
//
//	@Override
//	public List<Transaction> getTransactions() {
//
//		return converter.convert(repository.findAll());
//	}
//
//	public void setTransactions(List<TransactionsEntity> transactions) {
//		repository.saveAll(transactions);
//	}

}
