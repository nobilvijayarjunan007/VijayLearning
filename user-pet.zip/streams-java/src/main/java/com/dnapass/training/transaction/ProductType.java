package com.dnapass.training.transaction;

public enum ProductType {

	FRUIT,GROCERY,FUEL,ELECTRIC
}
