package com.dnapass.training.transaction.dataloader;

import java.util.ArrayList;
import java.util.List;

import com.dnapass.training.transaction.ProductType;
import com.dnapass.training.transaction.Transaction;



public class DataLoader {

	
	public static List<Transaction> newTransaction() {

		List<Transaction> transactions = new ArrayList<Transaction>();

		transactions.add(new Transaction(100, ProductType.FRUIT, 45.55, "Chennai", "INR"));
		transactions.add(new Transaction(101, ProductType.GROCERY, 252.22, "london", "GBP"));
		transactions.add(new Transaction(102, ProductType.ELECTRIC, 20.99, "bangalore", "USD"));
		transactions.add(new Transaction(103, ProductType.FRUIT, 68.22, "Chennai", "INR"));
		transactions.add(new Transaction(104, ProductType.FUEL, 90.34, "london", "GBP"));
		transactions.add(new Transaction(105, ProductType.ELECTRIC, 150.56, "bangalore", "USD"));
		transactions.add(new Transaction(106, ProductType.GROCERY, 456.99, "Chennai", "INR"));
		transactions.add(new Transaction(107, ProductType.FUEL, 451.55, "bangalore", "USD"));
		return transactions;
	}
}
