package com.dnapass.training.transaction.validator;

import java.util.List;

import com.dnapass.training.transaction.ProductType;
import com.dnapass.training.transaction.Transaction;
import com.dnapass.training.transaction.exception.ApplicationException;

public class TransactionValidator {

	public static void validateNewTransaction(Transaction transaction) throws ApplicationException {

		if (transaction == null) {
			throw new ApplicationException("Transaction can not be null");
		}

		transactionFieldsNull(transaction);

	}

	private static void transactionFieldsNull(Transaction transaction) throws ApplicationException {

		validateId(transaction);
		valiadteAmount(transaction);
		validateCity(transaction);
		validateCurrency(transaction);
		validateType(transaction);
	}

	public static void validateId(Transaction transaction) throws ApplicationException {

		if (transaction.getId() == null) {

			throw new ApplicationException("Id is mandatory");
		}

	}

	public static void validateId(Integer id) throws ApplicationException {

		if (id < 0) {

			throw new ApplicationException("Invalid Id");
		}

	}

	public static void valiadteAmount(Transaction transaction) throws ApplicationException {
		if (transaction.getAmount() == null || transaction.getAmount() < 0) {
			throw new ApplicationException("Amount must be greater than zero and amount can't be null ");
		}

	}

	public static void validateCity(Transaction transaction) throws ApplicationException {

		if (transaction.getCity() == null) {
			throw new ApplicationException("city can't be null");

		}
	}

	public static void validateCurrency(Transaction transaction) throws ApplicationException {

		if (transaction.getCurrency() == null) {
			throw new ApplicationException("currency should not be null");

		}
	}

	public static void validateType(Transaction transaction) throws ApplicationException {

		if (transaction.getType() == null) {
			throw new ApplicationException("Type should not be null");

		}
	}

	public static void validateDeleteTransaction(Transaction transaction) throws ApplicationException {
		if (transaction == null) {
			throw new ApplicationException("Transaction can not be null");
		}

	}

	public static void transactionCheck(List<Transaction> transactions, Transaction transaction, String city)
			throws ApplicationException {
		if (transaction == null) {
			throw new ApplicationException("Transaction can not be null");
		}

	}

	public static void validateTransaction(Transaction transaction) throws ApplicationException {
		if (transaction == null) {
			throw new ApplicationException("Transaction can not be null");
		}

	}

	public static void validateProductType(ProductType type) throws ApplicationException {
		if (type == null) {
			throw new ApplicationException("ProductType can not be null");
		}

	}

	public static void validateTransactionProductTypeAmountAndCity(Double amount, ProductType prod, String city)
			throws ApplicationException {
		if (amount == null && prod == null && city == null) {
			throw new ApplicationException("ProductType , Id and city  should not be null");

		}

	}

	public static void validateTransactionProductTypeAmount(Double amount, ProductType prod)
			throws ApplicationException {
		if (amount == null && prod == null) {
			throw new ApplicationException("ProductType , Id and city  should not be null");

		}

	}

	// >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>.>
	public static void validateUpdateTransaction(Transaction transaction) throws ApplicationException {
		if (transaction == null) {
			throw new ApplicationException("Transaction can not be null");
		}
		transactionFieldsNull(transaction);
	}

	public static void validateAndDeleteTransaction(int i) throws ApplicationException {

		Integer ii = i;

		if (ii == null) {
			throw new ApplicationException("Id can not be null");
		}

	}

	public static void validateFindTransactionById(Integer id) throws ApplicationException {

		if (id == null) {
			throw new ApplicationException("Id can not be null");

		}

	}

	public static void validateCheckTransactioContainsOrNot(Transaction transaction) throws ApplicationException {

		if (transaction == null) {
			throw new ApplicationException("Transaction can not be null");

		}
	}

	public static void validateAndGetTransactionListBasedOnIdAndProductType(Integer id, ProductType prod)
			throws ApplicationException {

		if (id == null && prod == null) {
			throw new ApplicationException("ProductType and Id  should not be null");

		}
	}

	public static void validateAndGetTransactionListBasedOnIdProductTypeAndCity(Integer id, ProductType prod,
			String city) throws ApplicationException {
		if (id == null && prod == null && city == null) {
			throw new ApplicationException("ProductType , Id and city  should not be null");

		}

	}

}
