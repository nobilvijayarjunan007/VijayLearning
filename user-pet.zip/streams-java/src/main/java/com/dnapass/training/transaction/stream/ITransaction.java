package com.dnapass.training.transaction.stream;

import java.util.List;

import com.dnapass.training.transaction.ProductType;
import com.dnapass.training.transaction.Transaction;
import com.dnapass.training.transaction.exception.ApplicationException;

public interface ITransaction {

	List<Transaction> getTransactions();

	void setTransactions(List<Transaction> transactions);

	void createTransaction(Transaction transaction) throws ApplicationException;

	void deleteTransaction(Transaction transaction) throws ApplicationException;

	void deleteTransactionById(Integer i) throws ApplicationException;

	Transaction updateTransaction(Transaction transaction) throws ApplicationException;

	Transaction findTransactionById(Integer id) throws ApplicationException;

	List<Transaction> findTransactionByProductType(ProductType type) throws ApplicationException;

	Transaction findTransactionByIndex(Integer index) throws ApplicationException;

	Transaction findTransaction(Transaction transaction) throws ApplicationException;

	List<Transaction> findByProductTypeAndAmount(ProductType prod, Double amount) throws ApplicationException;

	List<Transaction> findByProductTypeAmountAndCity(ProductType prod, Double amount, String city)
			throws ApplicationException;

	boolean findTransaction2(Transaction transaction) throws ApplicationException;

}