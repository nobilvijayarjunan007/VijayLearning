package com.dnapass.training.transaction.stream;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import com.dnapass.training.transaction.ProductType;
import com.dnapass.training.transaction.Transaction;
import com.dnapass.training.transaction.dataloader.DataLoader;
import com.dnapass.training.transaction.exception.ApplicationException;
import com.dnapass.training.transaction.validator.TransactionValidator;

import ch.qos.logback.core.net.SyslogOutputStream;

public class TransactionInMemoryRepoUsingStream implements ITransaction {

	private List<Transaction> transactions = DataLoader.newTransaction();

	@Override
	public List<Transaction> getTransactions() {
		return transactions;
	}

	@Override
	public void setTransactions(List<Transaction> transactions) {
		this.transactions = transactions;
	}

	@Override
	public void createTransaction(Transaction transaction) throws ApplicationException {

		TransactionValidator.validateNewTransaction(transaction);

		Optional<Transaction> tran = transactions.stream().filter(t -> t.getId() == transaction.getId()).findFirst();
		if (tran.isPresent()) {
			throw new ApplicationException("Transaction is Already Exist !!!");
		} else {
			transactions.add(transaction);
		}

	}

	@Override
	public void deleteTransaction(Transaction transaction) throws ApplicationException {

		TransactionValidator.validateDeleteTransaction(transaction);

		Optional<Transaction> tran = transactions.stream()
				.filter(t -> t.getId() == transaction.getId() && t.getAmount().equals(transaction.getAmount())
						&& t.getCity().equals(transaction.getCity()) && t.getType().equals(transaction.getType()))
				.findAny();
		System.out.println(tran);
		if (tran.isPresent()) {
			transactions.remove(tran.get());
		} else {
			throw new ApplicationException("Transaction not Found !!!");
		}

	}

	@Override
	public void deleteTransactionById(Integer i) throws ApplicationException {
		TransactionValidator.validateId(i);
		Optional<Transaction> tran = transactions.stream().filter(t -> t.getId() == i).findFirst();
		if (tran.isPresent()) {
			transactions.remove(tran.get());

		} else {
			throw new ApplicationException("Transaction not Found !!!");
		}

	}

	@Override
	public Transaction updateTransaction(Transaction transaction) throws ApplicationException {

		TransactionValidator.validateUpdateTransaction(transaction);
		Optional<Transaction> tran = transactions.stream().filter(t -> t.getId() == transaction.getId()).findFirst();
		if (tran.isPresent()) {

			tran.get().setAmount(transaction.getAmount());
			tran.get().setCity(transaction.getCity());
			tran.get().setType(transaction.getType());
			tran.get().setCurrency(transaction.getCurrency());
			return tran.get();
		} else {
			throw new ApplicationException("Transaction not Found !!!");
		}

	}

	@Override
	public Transaction findTransactionById(Integer id) throws ApplicationException {

		TransactionValidator.validateFindTransactionById(id);
		Optional<Transaction> tran = transactions.stream().filter(t -> t.getId() == id).findAny();
		if (tran.isPresent()) {
			return tran.get();
		} else {
			throw new ApplicationException("Transaction not Found !!!");

		}
	}

	@Override
	public List<Transaction> findTransactionByProductType(ProductType type) throws ApplicationException {
		TransactionValidator.validateProductType(type);
		List<Transaction> tran = transactions.stream().filter(t -> t.getType() == type).collect(Collectors.toList());
		if (!tran.isEmpty()) {
			return tran;
		} else {
			throw new ApplicationException("Transaction not Found with product Type !!!");

		}
	}

	@Override
	public Transaction findTransactionByIndex(Integer index) throws ApplicationException {

		if (transactions.size() <= index) {
			throw new ApplicationException("invalid index value !!!");
		}
		Transaction tran = transactions.get(index);
		if (tran == null) {
			throw new ApplicationException("Transaction not Found !!!");
		}
		return tran;
	}

	@Override
	public Transaction findTransaction(Transaction transaction) throws ApplicationException {
		TransactionValidator.validateCheckTransactioContainsOrNot(transaction);

		Optional<Transaction> tran = transactions.stream()
				.filter(t -> t.getId() == transaction.getId() && t.getAmount() == transaction.getAmount()
						&& t.getCity() == transaction.getCity() && t.getType() == transaction.getType())
				.findAny();
		if (tran.isPresent()) {
			return tran.get();
		} else {
			throw new ApplicationException("Transaction not Found !!!");

		}

	}

	@Override
	public boolean findTransaction2(Transaction transaction) throws ApplicationException {
		TransactionValidator.validateCheckTransactioContainsOrNot(transaction);

		Optional<Transaction> tran = transactions.stream()
				.filter(t -> t.getId() == transaction.getId() && t.getAmount() == transaction.getAmount()
						&& t.getCity() == transaction.getCity() && t.getType() == transaction.getType())
				.findAny();
		if ( tran.get()==transaction) {
			
			return true;
		} else {
			return false;

		}

	}

	@Override
	public List<Transaction> findByProductTypeAndAmount(ProductType prod, Double amount) throws ApplicationException {
		TransactionValidator.validateTransactionProductTypeAmount(amount, prod);
		List<Transaction> tranList = transactions.stream()
				.filter(t -> t.getType() == prod && t.getAmount().compareTo(amount) == 0).collect(Collectors.toList());

		if (!tranList.isEmpty()) {
			return tranList;
		} else {
			throw new ApplicationException("Transaction not Found !!!");
		}

	}

	@Override
	public List<Transaction> findByProductTypeAmountAndCity(ProductType prod, Double amount, String city)
			throws ApplicationException {
		TransactionValidator.validateTransactionProductTypeAmountAndCity(amount, prod, city);
		List<Transaction> tranList = transactions.stream()
				.filter(t -> t.getType() == prod && t.getAmount().compareTo(amount) == 0 && t.getCity().equals(city))
				.collect(Collectors.toList());

		if (!tranList.isEmpty()) {
			return tranList;
		} else {
			throw new ApplicationException("Transaction not Found !!!");
		}
	}
}
