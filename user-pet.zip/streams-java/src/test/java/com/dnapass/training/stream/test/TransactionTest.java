package com.dnapass.training.stream.test;

import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.Rule;
import org.junit.jupiter.api.Test;
import org.junit.rules.ExpectedException;

import com.dnapass.training.transaction.ProductType;
import com.dnapass.training.transaction.Transaction;
import com.dnapass.training.transaction.dataloader.DataLoader;
import com.dnapass.training.transaction.exception.ApplicationException;
import com.dnapass.training.transaction.stream.TransactionInMemoryRepoUsingStream;
import com.dnapass.training.transaction.validator.TransactionValidator;

public class TransactionTest {

	private java.util.List<Transaction> list = DataLoader.newTransaction();

	TransactionInMemoryRepoUsingStream transactionSerivce = new TransactionInMemoryRepoUsingStream();
	@SuppressWarnings("deprecation")
	@Rule
	public ExpectedException exceptionRule = ExpectedException.none();

	@Test
	public void testSizeOfTransaction() throws ApplicationException {

		assertEquals(8, transactionSerivce.getTransactions().size());

	}

	@Test
	public void testCreateTransaction() throws ApplicationException {
		transactionSerivce.createTransaction(new Transaction(108, ProductType.GROCERY, 500.00, "Velore", "GBG"));

		assertEquals(9, transactionSerivce.getTransactions().size());

	}

	@Test
	public void testCreateTransactionWithProductTYPENull() throws ApplicationException {

		exceptionRule.expectMessage("Type should not be null");
		exceptionRule.expect(ApplicationException.class);
		// transactionSerivce.createTransaction(new Transaction(100, null, 500.00,
		// "Velore", "GBG"));

		TransactionValidator.validateType(new Transaction(100, null, 500.00, "Velore", "GBG"));
	}

	@Test
	public void testCreateTransactionWithNullTransaction() throws ApplicationException {

		exceptionRule.expectMessage("Transaction can not be null");
		exceptionRule.expect(ApplicationException.class);
		transactionSerivce.createTransaction(null);

	}

	@Test
	public void testCreateTransactionCityAsNull() throws ApplicationException {

		exceptionRule.expectMessage("city can't be null");
		exceptionRule.expect(ApplicationException.class);
		transactionSerivce.createTransaction(new Transaction(111, ProductType.GROCERY, 500.00, null, "GBG"));

	}

	@Test
	public void testDeleteTransaction() throws ApplicationException {
		// System.out.println(transactionSerivce.getTransactions().size());
		transactionSerivce.deleteTransaction(new Transaction(100, ProductType.FRUIT, 45.55, "Chennai", "INR"));
		assertEquals(7, transactionSerivce.getTransactions().size());

	}

	@Test
	public void testDeleteTransactionWithNull() throws ApplicationException {
		exceptionRule.expectMessage("Transaction can not be null");
		exceptionRule.expect(ApplicationException.class);
		transactionSerivce.deleteTransaction(null);

	}

	@Test
	public void testDeleteInvalidTransaction() throws ApplicationException {
		exceptionRule.expect(ApplicationException.class);
		exceptionRule.expectMessage("Transaction not Found !!!");
		transactionSerivce.deleteTransaction(new Transaction(33, ProductType.FUEL, 33.33, "london", "GBP"));
		assertEquals(8, transactionSerivce.getTransactions().size());
	}

	@Test
	public void testDeleteTransactionWithId() throws ApplicationException {

		transactionSerivce.deleteTransactionById(100);
		assertEquals(7, transactionSerivce.getTransactions().size());

	}

	@Test
	public void testUpdateTransaction() throws ApplicationException {
		Transaction trn = new Transaction(100, ProductType.FRUIT, 45.55, "Chennai", "INR");
		assertEquals("Chennai", transactionSerivce.findTransactionById(100).getCity());

	}

	@Test
	public void testUpdateTransactionWithNullTransaction() throws ApplicationException {
		exceptionRule.expect(ApplicationException.class);
		exceptionRule.expectMessage("Transaction can not be null");
		transactionSerivce.updateTransaction(null);

	}

	@Test
	public void testUpdateTransactionWithInvalidId() throws ApplicationException {
		Transaction trn = new Transaction(150, ProductType.FUEL, 33.33, "london", "GBP");
		exceptionRule.expect(ApplicationException.class);
		exceptionRule.expectMessage("Transaction not Found !!!");
		transactionSerivce.updateTransaction(trn);

	}

	@Test
	public void testFindTransaction() throws ApplicationException {
		assertTrue(
				transactionSerivce.findTransaction2(new Transaction(100, ProductType.FRUIT, 45.55, "Chennai", "INR")));
	}

//	@Test
//	public void testFindTransactionWithNullTransaction()throws ApplicationException{
//		exceptionRule.expect(ApplicationException.class);
//		exceptionRule.expectMessage("Transaction must be provided");
//		assertFalse(transactionSerivce.findTransaction(null));
//		
//	}	
//
//	@Test
//	public void testFindTransactionWithInvalidTransaction()throws ApplicationException{
//		exceptionRule.expect(ApplicationException.class);
//		exceptionRule.expectMessage("Transaction not found");
//		assertFalse(transactionSerivce.findTransaction(new Transaction(333,ProductType.FUEL,33.33,"london","GBP")));
//		
//	}
//	@Test
//	public void testFindTransactionByIndex()throws ApplicationException{
//		Integer i =127;
//		assertEquals(i,transactionSerivce.findTransactionByIndex(7).getId());
//		
//	}
//	@Test
//	public void testFindTransactionByIndexWithInvalidIndex()throws ApplicationException{
//		Integer i =127;
//		exceptionRule.expect(ApplicationException.class);
//		exceptionRule.expectMessage("Invalid index value");
//		assertEquals(i,transactionSerivce.findTransactionByIndex(333).getId());
//	}
//		
//	@Test
//	public void testFindTransactionById()throws ApplicationException{
//		Integer i =127;
//		assertEquals(i,transactionSerivce.findTransactionById(127).getId());
//	}
//	@Test
//	public void testFindTransactionByIdWithInvalidId()throws ApplicationException{
//		exceptionRule.expect(ApplicationException.class);
//		exceptionRule.expectMessage("Transaction not found");
//		assertEquals(null,transactionSerivce.findTransactionById(333).getId());
//		}
//
//	@Test
//	public void testFindTransactionByProductType()throws ApplicationException{
//		assertEquals(5,transactionSerivce.findTransactionByProductType(ProductType.FUEL).size());
//		
//	}
//
//	@Test
//	public void testFindTransactionByProductTypeWithInvalidType()throws ApplicationException{
//		exceptionRule.expect(ApplicationException.class);
//		exceptionRule.expectMessage("Product type cannot be null");
//		assertEquals(5,transactionSerivce.findTransactionByProductType(null).size());
//		
//	}
//
//	@Test
//	public void testFindTransactionByAmountAndProductType()throws ApplicationException{
//		
//		List<Transaction>list1 = new ArrayList<>();
//		list1.add(new Transaction (125,ProductType.GROCERY,1300.33,"Bangalore","INR"));
//		assertEquals(list1, transactionSerivce.FindTransactionByAmountAndProductType(ProductType.GROCERIES,1300.33));
//		
//	}
//
//	@Test
//	public void testFindTransactionByAmountAndProductTypeWithInvalidType()throws ApplicationException{
//		exceptionRule.expect(ApplicationException.class);
//		exceptionRule.expectMessage("Product type cannot be null");
//		assertEquals(null,transactionSerivce.findTransactionByProductTypeAndAmount(null),127.0));
//
//	}

	// >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>.

	@Test
	public void GetIdAfterTransaction() {

		Transaction tran1 = new Transaction(1020, ProductType.FRUIT, 45.55, "Chennai", "INR");

		assertEquals(1020, tran1.getId(), 0.01);

	}

	@Test
	public void displaySizeOfTheListBeforeAddingNewTransaction() {

		assertEquals(8, list.size(), 0.01);

	}

	@Test
	public void displaySizeOfTheListAfterAddingNewTransaction() {

		Transaction tran1 = new Transaction(1020, ProductType.FRUIT, 455.55, "Chennai", "INR");
		list.add(tran1);
		assertEquals(9, list.size(), 0.01);

	}

	@Test
	public void SizeOfTheListAfterRemovingTransaction() {

		list.remove(1);

		list.remove(2);

		assertEquals(6, list.size(), 0.01);

	}

	@Test
	public void SizeOfTheListAfterAddingAndRemovingTransaction() {

		list.remove(1);
		Transaction tran1 = new Transaction(1020, ProductType.FRUIT, 455.55, "Chennai", "INR");
		list.add(tran1);
		list.remove(tran1);

		assertEquals(7, list.size(), 0.01);

	}

	@Test
	public void SizeOfTheListAfterAddingNewTransaction() {

		assertEquals(8, list.size(), 0.01);

	}
}
