package com.dnapass.training.streamsjava;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StreamsJavaApplicationTests {

	@Test
	void contextLoads() {
	}

}
