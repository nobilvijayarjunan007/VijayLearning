package com.hcl.cs;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.Before;
import org.junit.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Bean;
import org.springframework.test.context.junit4.SpringRunner;

import com.hcl.cs.entity.PetEntity;
import com.hcl.cs.model.Pet;
import com.hcl.cs.repo.PetRepo;
import com.hcl.cs.service.PetService;

@RunWith(SpringRunner.class)
@SpringBootTest
@TestInstance(Lifecycle.PER_CLASS)
public class PetServiceImplIntegrationTest {

	@TestConfiguration
	static class PetServiceImplIntegrationTestContextConfiguration {

		@Bean
		public PetService userService5() {
			return new PetService();
		}
	}

	@Autowired
	private PetService petService;
	@MockBean
	private PetRepo petRepo;

	@Test
	public void contextLoads() throws Exception {
		assertThat(petService).isNotNull();
		assertThat(petRepo).isNotNull();
	}

	@Before
	public void setUp() {

	}

	@Test
	public void whenvalidName_thenPetShouldBeFound() {

		String name = "CAT";

		// step1
		PetEntity pet = new PetEntity(null, "CAT", 3, "CH", null);

		Mockito.when(petRepo.findByPetName(name)).thenReturn(pet);

		// step2

		Pet found = petService.getPetByName(name);

		// step3
		assertThat(found.getPetName()).isEqualTo(name);

		assertThat(found.getAge()).isEqualTo(pet.getAge());

		assertThat(found.getPetPlace()).isEqualTo(pet.getPetPlace());

	}

}
