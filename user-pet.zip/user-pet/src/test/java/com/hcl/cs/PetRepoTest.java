package com.hcl.cs;

import java.util.ArrayList;
import java.util.List;

import org.assertj.core.api.Assertions;
import org.junit.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.hcl.cs.dataloader.DataLoader;
import com.hcl.cs.dataloader.DataLoader2;
import com.hcl.cs.entity.PetEntity;
import com.hcl.cs.repo.PetRepo;

import junit.framework.Assert;

@RunWith(SpringRunner.class)
@SpringBootTest
@TestInstance(Lifecycle.PER_METHOD)
public class PetRepoTest {

	@Autowired
	private PetRepo petRepo;

	List<PetEntity> petEntities = DataLoader.petEntities();

	@Test
	public void sizeOfRepo() {
		List<PetEntity> saveAll = petRepo.saveAll(petEntities);
		System.out.println(saveAll);
		long count = petRepo.count();
		System.out.println(count);
		Assert.assertEquals(count, petEntities.size());

	}

	@Test
	public void findAllOfRepo() {
		List<PetEntity> saveAll = petRepo.saveAll(petEntities);
		System.out.println(saveAll);

		Assertions.assertThat(petRepo.findAll()).isEqualTo(petEntities);

	}

	@Test
	public void saveRepo() {
		List<PetEntity> saveAll = petRepo.saveAll(petEntities);
		System.out.println(saveAll);
		PetEntity petEntity = new PetEntity(null, "CAT", 3, "CH");
		petRepo.save(petEntity);
		Assert.assertEquals(7, petRepo.count());

	}

	@Test
	public void deleteRepo() {
		List<PetEntity> saveAll = petRepo.saveAll(petEntities);
		System.out.println(saveAll);
		PetEntity petEntity = new PetEntity(null, "CAT", 3, "CH");
		petRepo.deleteAll();
		Assert.assertEquals(0, petRepo.count());

	}

	@Test
	public void deleteTest() {
		List<PetEntity> saveAll = petRepo.saveAll(petEntities);
		System.out.println(saveAll);

		petRepo.deleteById(1l);
		Assert.assertEquals(5, petRepo.count());

	}

	///////////////////////////////////////////////////////////////////////////////////////////

	/////////////////////////////////////////////////////////////////////////////////////////
	List<PetEntity> newPets = DataLoader2.newPets();

	@Test
	public void test1SizeOfRepo() {

		petRepo.saveAll(newPets);
		List<PetEntity> list = petRepo.findAll();
		Assert.assertEquals(list.size(), petRepo.count());

	}

	@Test
	public void test2FindAll() {

		petRepo.saveAll(newPets);
		List<PetEntity> list = petRepo.findAll();
		org.assertj.core.api.Assertions.assertThat(list).isNotEmpty();

	}

	@Test
	public void test3save() {

		PetEntity petEntity = new PetEntity(null, "ParrotRed", 1, "CcH", null);

		petRepo.save(petEntity);
		List<PetEntity> list = petRepo.findAll();
		org.assertj.core.api.Assertions.assertThat(list.size()).isEqualTo(7);

	}

	@Test
	public void test4saveAll() {

		PetEntity petEntity = new PetEntity(null, "ParrotRed", 1, "CcH", null);
		PetEntity petEntity2 = new PetEntity(null, "ParrotRed2", 1, "CcH", null);
		PetEntity petEntity3 = new PetEntity(null, "ParrotRed3", 1, "CcH", null);
		List<PetEntity> list1 = new ArrayList<>();
		list1.add(petEntity3);
		list1.add(petEntity2);
		list1.add(petEntity);
		petRepo.saveAll(list1);
		List<PetEntity> list = petRepo.findAll();
		org.assertj.core.api.Assertions.assertThat(list.size()).isEqualTo(9);

	}

}
