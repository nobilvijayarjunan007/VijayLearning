package com.hcl.cs;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.Before;
import org.junit.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Bean;
import org.springframework.test.context.junit4.SpringRunner;

import com.hcl.cs.entity.UserEntity;
import com.hcl.cs.model.User;
import com.hcl.cs.repo.UserRepo;
import com.hcl.cs.service.UserService;

@RunWith(SpringRunner.class)
@TestInstance(Lifecycle.PER_CLASS)
public class UserServiceImplIntegrationTest {

	@TestConfiguration
	static class UserServiceImplIntegrationTestContextConfiguration {

		@Bean
		public UserService userService() {
			return new UserService();
		}
	}

	@Autowired
	private UserService userService;
	@MockBean
	private UserRepo userRepo;

	@Test
	public void contextLoads() throws Exception {
		assertThat(userService).isNotNull();
		assertThat(userRepo).isNotNull();
	}

	@Before
	public void setUp() {

	}

	@Test
	public void whenvalidName_thenUserShouldBeFound() {

		String name = "user1";

		// step1
		UserEntity user = new UserEntity(null, "user1", "1234", null);

		Mockito.when(userRepo.findByUserName(name)).thenReturn(user);

		// step2

		User found = userService.getUserByName(name);

		// step3
		assertThat(found.getUserName()).isEqualTo(name);

		assertThat(found.getPassWord()).isEqualTo(user.getPassWord());

	}

}
