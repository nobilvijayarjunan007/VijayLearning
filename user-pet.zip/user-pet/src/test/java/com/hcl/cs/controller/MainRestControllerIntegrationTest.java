package com.hcl.cs.controller;

import static org.assertj.core.api.Assertions.assertThat;
import static org.hamcrest.CoreMatchers.containsString;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.io.IOException;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.hcl.cs.controller.MainController;
import com.hcl.cs.dataloader.DataLoader2;
import com.hcl.cs.model.Pet;
import com.hcl.cs.model.User;

@RunWith(SpringRunner.class)
@SpringBootTest
@AutoConfigureMockMvc
@Rollback(false)
@TestInstance(Lifecycle.PER_CLASS)
public class MainRestControllerIntegrationTest {

	@Autowired
	private MockMvc mvc;

	List<User> userListExpected = null;

	List<Pet> petListExpected = null;

	@Test
	public void contextLoads() throws Exception {

		assertThat(mvc).isNotNull();
	}

	@BeforeEach
	public void setUp() throws Exception {
		String uri = "/api/v1/saveUser";
		userListExpected = DataLoader2.newUsersModel();
		User user = userListExpected.get(0);

		String inputJson = mapToJson(user);

		MvcResult mvcResult = mvc.perform(
				MockMvcRequestBuilders.post(uri).contentType(MediaType.APPLICATION_JSON_VALUE).content(inputJson))
				.andReturn();

		int status = mvcResult.getResponse().getStatus();
		System.out.println("setUp status >>>>>>>>>>>>>>>>>>>" + status);

		user = userListExpected.get(1);

		inputJson = mapToJson(user);

		mvcResult = mvc.perform(
				MockMvcRequestBuilders.post(uri).contentType(MediaType.APPLICATION_JSON_VALUE).content(inputJson))
				.andReturn();

		status = mvcResult.getResponse().getStatus();
		System.out.println("setUp status >>>>>>>>>>>>>" + status);

		//

		uri = "api/v1/savePet";

		petListExpected = DataLoader2.newPetsModel();
		Pet pet = petListExpected.get(0);
		System.out.println(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>" + pet);
		inputJson = mapToJson(pet);

		mvcResult = mvc.perform(
				MockMvcRequestBuilders.post(uri).contentType(MediaType.APPLICATION_JSON_VALUE).content(inputJson))
				.andReturn();

		status = mvcResult.getResponse().getStatus();
		System.out.println("setUp status >>>>>>>>>>>>>>>>>>" + status);

		pet = petListExpected.get(1);
		System.out.println(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>" + pet);

		inputJson = mapToJson(pet);

		mvcResult = mvc.perform(
				MockMvcRequestBuilders.post(uri).contentType(MediaType.APPLICATION_JSON_VALUE).content(inputJson))
				.andReturn();

		status = mvcResult.getResponse().getStatus();
		System.out.println("setUp status >>>>>>>>>>>>>>>>>>>>>" + status);
	}

	@Test
	public void shouldReturnDefaultMessage1() throws Exception {

		this.mvc.perform(MockMvcRequestBuilders.get("/api/v1/init/pet")).andDo(print()).andExpect(status().isOk())
				.andExpect(content().string(containsString("Hello Pet")));

	}

	@Test
	public void shouldReturnDefaultMessage2() throws Exception {

		this.mvc.perform(MockMvcRequestBuilders.get("/api/v1/init/user")).andDo(print()).andExpect(status().isOk())
				.andExpect(content().string(containsString("Hello User")));

	}

	@Test
	public void getPetList() throws Exception {
		String uri = "/api/v1/home";
		MvcResult mvcResult = mvc.perform(MockMvcRequestBuilders.get(uri).accept(MediaType.APPLICATION_JSON_VALUE))
				.andReturn();

		int status = mvcResult.getResponse().getStatus();
		assertEquals(200, status);
		String content = mvcResult.getResponse().getContentAsString();
		System.out.println("content :: " + content);
		List<Pet> petList = mapFromJson(content, new TypeReference<List<Pet>>() {
		});
		petList.stream().forEach(System.out::println);
		assertTrue(petList.size() == 7);

	}

	@Test
	public void savePet() throws Exception {
		String uri = "/api/v1/savePet";
		Pet pet = new Pet(2l, "Pet1", 3, "CH");
		String inputJson = mapToJson(pet);
		MvcResult mvcResult = mvc.perform(
				MockMvcRequestBuilders.post(uri).contentType(MediaType.APPLICATION_JSON_VALUE).content(inputJson))
				.andReturn();
		System.out.println("mvcResult>>>>>>>>>>>>>>>>>>>>>>>>>" + mvcResult.getResponse().getStatus());
		int status = mvcResult.getResponse().getStatus();
		System.out.println(">>>>>>>>>>>>>>>>>>>>>>>>>" + status);
		assertEquals(201, status);
		String content = mvcResult.getResponse().getContentAsString();
		System.out.println("content ::>>>>>>>>>>>>>>>>>>>>>>>> " + content);
		Pet pet1 = mapFromJson(content, Pet.class);
		assertNotNull(pet1);

		System.out.println("pet created :: >>>>>>>>>>>>>>>>>>>>> " + pet1);

	}

	@Test
	public void saveUser() throws Exception {
		String uri = "/api/v1/saveUser";
		User user = new User(2l, "user200", "XYZ***");
		String inputJson = mapToJson(user);
		MvcResult mvcResult = mvc.perform(
				MockMvcRequestBuilders.post(uri).contentType(MediaType.APPLICATION_JSON_VALUE).content(inputJson))
				.andReturn();

		int status = mvcResult.getResponse().getStatus();
		assertEquals(201, status);
		String content = mvcResult.getResponse().getContentAsString();
		System.out.println("content :: " + content);
		User user1 = mapFromJson(content, User.class);
		assertNotNull(user1);

		System.out.println("User created ::  " + user1);

	}

	@Test
	public void getMyPet() throws Exception {
		String uri = "/api/v1/myPets?userId=1";
		MvcResult mvcResult = mvc.perform(MockMvcRequestBuilders.get(uri).accept(MediaType.APPLICATION_JSON_VALUE))
				.andReturn();

		int status = mvcResult.getResponse().getStatus();
		System.out.println(status);
		assertEquals(200, status);
		String content = mvcResult.getResponse().getContentAsString();
		System.out.println("content :: >>>>>>>>>>>>getMyPet>>>>>>>>>>>>>>" + content);
		List<Pet> petList = mapFromJson(content, new TypeReference<List<Pet>>() {
		});

		System.out.println("getPetList () :: " + petList);
	}

	@Test
	public void buyPet() throws Exception {

		String uri = "/api/v1/savePet";
		Pet pet = new Pet(11l, "Pet2222", 10, "yy");
		String inputJson = mapToJson(pet);
		MvcResult mvcResult = mvc.perform(
				MockMvcRequestBuilders.post(uri).contentType(MediaType.APPLICATION_JSON_VALUE).content(inputJson))
				.andReturn();
		System.out.println("mvcResult>>>>>>>>>>>++++++++++++++>>>>>>>>>>>>>>" + mvcResult.getResponse().getStatus());
		int status = mvcResult.getResponse().getStatus();
		System.out.println(">>>>>>>>>>>>++++++++++++++++>>>>>>>>>>>>>" + status);
		assertEquals(201, status);
		String content = mvcResult.getResponse().getContentAsString();
		System.out.println("content ::>>>>>>>>>>>+++++++++++>>>>>>>>>>>>> " + content);
		Pet pet1 = mapFromJson(content, Pet.class);
		assertNotNull(pet1);

		System.out.println("pet created :: >>>>>>>>>>++++++++++>>>>>>>>>>> " + pet1);
/////////////////////////////////////////////////////////////////////////////////

		String uri2 = "/api/v1/saveUser";
		User user = new User(12l, "user22222", "XYZ***890");
		String inputJson2 = mapToJson(user);
		MvcResult mvcResult2 = mvc.perform(
				MockMvcRequestBuilders.post(uri2).contentType(MediaType.APPLICATION_JSON_VALUE).content(inputJson2))
				.andReturn();

		int status2 = mvcResult2.getResponse().getStatus();
		assertEquals(201, status2);
		String content2 = mvcResult2.getResponse().getContentAsString();
		System.out.println("content :: " + content2);
		User user1 = mapFromJson(content2, User.class);
		assertNotNull(user1);

		System.out.println("User created :: +++++++++++++++++++++++++++" + user1);

		String uri3 = "/api/v1/buyPet?petId=11&userId=12";
		Pet pet3 = new Pet(11l, "Pet2222", 10, "yy");
		String inputJson3 = mapToJson(pet3);
		MvcResult mvcResult4 = mvc.perform(
				MockMvcRequestBuilders.put(uri3).contentType(MediaType.APPLICATION_JSON_VALUE).content(inputJson3))
				.andReturn();

		int statuss4 = mvcResult4.getResponse().getStatus();
		System.out.println("content updated :: " + mvcResult4.getResponse());
		assertEquals(200, statuss4);
		String content4 = mvcResult4.getResponse().getContentAsString();
		System.out.println("pet updated content >>>>>>>>>>>>>>>>>>>>>> "+content4);
		Pet petupdate = mapFromJson(content4, Pet.class);
		assertNotNull(petupdate);
		assertEquals("Pet2222", petupdate.getPetName());

		System.out.println("pet updated :: >>>>>>" + petupdate);

	}

	protected String mapToJson(Object obj) throws JsonProcessingException {
		ObjectMapper objectMapper = new ObjectMapper();
		objectMapper.setSerializationInclusion(Include.NON_NULL);
		return objectMapper.writeValueAsString(obj);
	}

	private List<Pet> mapFromJson(String content, TypeReference<List<Pet>> typeReference)
			throws JsonMappingException, JsonProcessingException {

		ObjectMapper objectMapper = new ObjectMapper();
		objectMapper.setSerializationInclusion(Include.NON_NULL);
		return objectMapper.readValue(content, typeReference);
	}

	private List<User> mapFromJson2(String content, TypeReference<List<User>> typeReference)
			throws JsonMappingException, JsonProcessingException {

		ObjectMapper objectMapper = new ObjectMapper();
		objectMapper.setSerializationInclusion(Include.NON_NULL);
		return objectMapper.readValue(content, typeReference);
	}

	protected <T> T mapFromJson(String Json, Class<T> clazz)
			throws JsonParseException, JsonMappingException, IOException {
		ObjectMapper objectMapper = new ObjectMapper();
		objectMapper.setSerializationInclusion(Include.NON_NULL);
		return objectMapper.readValue(Json, clazz);
	}

}
