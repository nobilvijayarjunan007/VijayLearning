package com.hcl.cs;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.hcl.cs.dataloader.DataLoader2;
import com.hcl.cs.entity.PetEntity;
import com.hcl.cs.entity.UserEntity;
import com.hcl.cs.repo.UserRepo;

@ExtendWith(SpringExtension.class)
@SpringBootTest
@TestInstance(Lifecycle.PER_METHOD)
public class UserRepoTest {

	@Autowired
	UserRepo userRepo;

	List<UserEntity> newUsers = DataLoader2.newUsers();

	@Test
	public void testSave() {

		userRepo.save(new UserEntity(null, "user1", "1234", null));
		userRepo.saveAll(newUsers);

		List<UserEntity> findAll = userRepo.findAll();

		assertEquals(7, findAll.size());

	}

	@Test
	public void testSizeofUserRepo() {

		userRepo.saveAll(newUsers);

		List<UserEntity> findAll = userRepo.findAll();
		findAll.stream().forEach(System.out::println);
		assertEquals(10, findAll.size());

	}

	@Test
	public void testAfterDeletionofUserRepo() {

		userRepo.deleteById(1l);

		List<UserEntity> findAll = userRepo.findAll();
		findAll.stream().forEach(System.out::println);
		assertEquals(9, findAll.size());

	}
}
