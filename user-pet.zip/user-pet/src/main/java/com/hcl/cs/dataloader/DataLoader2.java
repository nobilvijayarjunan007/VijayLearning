package com.hcl.cs.dataloader;

import java.util.ArrayList;
import java.util.List;

import com.hcl.cs.entity.PetEntity;
import com.hcl.cs.entity.UserEntity;
import com.hcl.cs.model.Pet;
import com.hcl.cs.model.User;

public class DataLoader2 {

	public static List<UserEntity> newUsers() {

		List<UserEntity> users = new ArrayList<>();

		users.add(new UserEntity(null, "user1", "1234", null));
		users.add(new UserEntity(null, "user2", "4567", null));
		users.add(new UserEntity(null, "user3", "8900", null));

		return users;
	}

	public static List<PetEntity> newPets() {
		List<PetEntity> pets = new ArrayList<>();
		pets.add(new PetEntity(null, "CAT", 3, "CH", newUsers().get(0)));
		pets.add(new PetEntity(null, "Dog", 2, "CH", newUsers().get(1)));
		pets.add(new PetEntity(null, "Parrot", 1, "CH", newUsers().get(2)));
		pets.add(new PetEntity(null, "CAT", 3, "CH", newUsers().get(1)));
		pets.add(new PetEntity(null, "Dog", 2, "CH", newUsers().get(0)));
		pets.add(new PetEntity(null, "Parrot", 1, "CH", newUsers().get(2)));

		return pets;
	}

	// Model

	public static List<User> newUsersModel() {

		List<User> users = new ArrayList<>();

		users.add(new User(100l, "user1", "1234"));
		users.add(new User(200l, "user2", "4567"));
		users.add(new User(300l, "user3", "8900"));

		return users;
	}

	public static List<Pet> newPetsModel() {
		List<Pet> pets = new ArrayList<>();
		pets.add(new Pet(1l, "CAT", 3, "CH"));
		pets.add(new Pet(2l, "Dog", 2, "DL"));
		pets.add(new Pet(600l, "Parrot", 1, "CH"));
		pets.add(new Pet(700l, "CAT", 3, "CH"));
		pets.add(new Pet(800l, "Dog", 2, "CH"));
		pets.add(new Pet(900l, "Parrot", 1, "CH"));

		return pets;
	}

}
