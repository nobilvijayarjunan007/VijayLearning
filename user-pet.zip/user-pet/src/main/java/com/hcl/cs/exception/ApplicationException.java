package com.hcl.cs.exception;

import java.io.FileNotFoundException;
import java.util.List;

public class ApplicationException extends Exception {

	private static final long serialVersionUID = 1L;

	List<ErrorMessage> list;

	public ApplicationException(String message) {
		super(message);
	}

	public ApplicationException() {
		super();

	}

	public ApplicationException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);

	}

	public ApplicationException(String message, Throwable cause) {
		super(message, cause);

	}

	public ApplicationException(Throwable cause) {
		super(cause);

	}

	public ApplicationException(Integer id) {

	}

	//

	public ApplicationException(FileNotFoundException e, String message) {

	}

	public List<ErrorMessage> getList() {
		return list;
	}

	public void setList(List<ErrorMessage> list) {
		this.list = list;
	}

	public void add(ErrorMessage err) {
		this.list.add(err);
	}

	public void remove(ErrorMessage err) {
		this.list.remove(err);
	}

}
