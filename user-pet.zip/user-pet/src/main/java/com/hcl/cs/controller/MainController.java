package com.hcl.cs.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.hcl.cs.dataloader.DataLoader2;
import com.hcl.cs.exception.ApplicationException;
import com.hcl.cs.exception.PetNotFoundException;
import com.hcl.cs.exception.UserNotFoundException;
import com.hcl.cs.model.Pet;
import com.hcl.cs.model.User;
import com.hcl.cs.service.PetService;
import com.hcl.cs.service.UserService;
import com.hcl.cs.validator.PetValidator;
import com.hcl.cs.validator.UserValidator;

import springfox.documentation.swagger2.annotations.EnableSwagger2;

@RestController
@EnableSwagger2
@RequestMapping("/api/v1")
public class MainController {

	@Autowired
	private PetService petService;
	@Autowired
	private UserService userService;

	@GetMapping("/init/user")
	String helloUser() throws ApplicationException {
		List<User> userModelList = DataLoader2.newUsersModel();
		for (User user : userModelList) {
			userService.saveUser(user);
		}
		return "Hello User";
	}

	@GetMapping("/init/pet")
	String helloPet() throws ApplicationException {
		List<Pet> petModelList = DataLoader2.newPetsModel();
		for (Pet pet : petModelList) {
			petService.savePet(pet);
		}
		return "Hello Pet";
	}

	@PostMapping("/savePet")
	public ResponseEntity<Pet> savePet(@RequestBody Pet pet) throws ApplicationException, PetNotFoundException {
 
		PetValidator.validatePet(pet);
		Pet petModel = petService.savePet(pet).get();

		HttpHeaders httpHeaders = new HttpHeaders();
		httpHeaders.add("pet", "api/v1" + petModel.getPetId().toString());
		return new ResponseEntity<>(petModel, httpHeaders, HttpStatus.CREATED);

	}

	@GetMapping("/home")
	public ResponseEntity<List<Pet>> home() throws ApplicationException {

		List<Pet> petList = petService.getAllPets().get();

		return new ResponseEntity<>(petList, HttpStatus.OK);

	}

	@PutMapping("/buyPet")
	public ResponseEntity<Pet> buyPet(@RequestParam Long petId, @RequestParam Long userId) throws ApplicationException, PetNotFoundException, UserNotFoundException {
		PetValidator.validatePetIdAndUserId(petId, userId);
		Pet petModel = petService.buyPet(petId, userId).get();

		return new ResponseEntity<>(petModel, HttpStatus.OK);

	}

	@PostMapping("/saveUser")
	public ResponseEntity<User> saveUser(@RequestBody User user) throws ApplicationException {
		UserValidator.validateUser(user);
		User user2 = userService.saveUser(user).get();
		HttpHeaders httpHeaders = new HttpHeaders();
		httpHeaders.add("todo", "/api/v1" + user2.getUserId().toString());

		return new ResponseEntity<>(user2, httpHeaders, HttpStatus.CREATED);
	}

	@GetMapping("/myPets")
	public ResponseEntity<List<Pet>> myPets(@RequestParam Long userId) throws ApplicationException {
		UserValidator.validateId(userId);
		List<Pet> petModel = userService.getMyPets(userId).get();

		return new ResponseEntity<>(petModel, HttpStatus.OK);

	}

}
