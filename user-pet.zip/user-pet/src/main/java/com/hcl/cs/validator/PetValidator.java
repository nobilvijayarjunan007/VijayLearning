package com.hcl.cs.validator;

import com.hcl.cs.exception.PetNotFoundException;
import com.hcl.cs.exception.UserNotFoundException;
import com.hcl.cs.model.Pet;

public class PetValidator {

	public static void validatePetIdAndUserId(Long petId, Long userId)
			throws PetNotFoundException, UserNotFoundException {
		if (petId == null) {
			throw new PetNotFoundException("There is no pet by that id " + petId);
		}

		validateUserId(userId);

	}

	private static void validateUserId(Long userId) throws UserNotFoundException {
		if (userId == null) {
			throw new UserNotFoundException("There is no user id by that id" + userId);
		}

	}

	public static void validatePet(Pet pet) throws PetNotFoundException {
		if (pet == null) {
			throw new PetNotFoundException("Pet can not be null");
		}
		validateField(pet);

	}

	private static void validateField(Pet pet) throws PetNotFoundException {
		validatecPetId(pet.getPetId());
		validatePetName(pet.getPetName());
		validatePetPlace(pet.getPetPlace());
	}

	private static void validatePetPlace(String petPlace) throws PetNotFoundException {
		if (petPlace == null) {
			throw new PetNotFoundException("Pet place cant be null");
		}

	}

	private static void validatePetName(String petName) throws PetNotFoundException {
		if (petName == null) {
			throw new PetNotFoundException("Pet Name can not be null");
		}

	}

	private static void validatecPetId(Long petId) throws PetNotFoundException {

		if (petId == null) {
			throw new PetNotFoundException("Ped id can not be null");
		}

	}

}
