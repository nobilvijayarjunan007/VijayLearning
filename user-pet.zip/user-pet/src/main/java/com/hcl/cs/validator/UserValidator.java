package com.hcl.cs.validator;

import java.util.List;

import com.hcl.cs.exception.ApplicationException;
import com.hcl.cs.model.User;

public class UserValidator {

	public static void validateNewUser(User user) throws ApplicationException {

		if (user == null) {
			throw new ApplicationException("user can not be null");
		}

		userFieldsNull(user);

	}

	private static void userFieldsNull(User user) throws ApplicationException {

		validateId(user.getUserId());
		valiadteName(user);
		validatePassword(user);

	}

	public static void validateId(Long userId) throws ApplicationException {

		if (userId == null) {
			UserValidator.validateById(userId);
			throw new ApplicationException("Id is mandatory");
		}

	}

	public static void validateById(Long id) throws ApplicationException {

		if (id < 0) {

			throw new ApplicationException("Invalid Id");
		}

	}

	public static void valiadteName(User user) throws ApplicationException {
		if (user.getUserName() == null) {
			throw new ApplicationException("Name can not be null");
		}

	}

	public static void validatePassword(User user) throws ApplicationException {

		if (user.getPassWord() == null) {
			throw new ApplicationException("Password can't be null");

		}
	}

	public static void validateDeleteUser(User user) throws ApplicationException {
		if (user == null) {
			throw new ApplicationException("user can not be null");
		}

	}

	public static void UserCheck(List<User> users, User user) throws ApplicationException {
		if (user == null) {
			throw new ApplicationException("User can not be null");
		}

	}

	public static void validateUser(User user) throws ApplicationException {
		if (user == null) {
			throw new ApplicationException("User can not be null");
		}

	}

	public static void validateUserByNameAndPassword(String name, String password) throws ApplicationException {
		if (name == null && password == null) {
			throw new ApplicationException("Name and Password should not be null");

		}

	}

	// >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>.>
	public static void validateUpdateUser(User user) throws ApplicationException {
		if (user == null) {
			throw new ApplicationException("User can not be null");
		}
		userFieldsNull(user);
	}

	public static void validateDeleteUser(int i) throws ApplicationException {

		Integer ii = i;

		if (ii == null) {
			throw new ApplicationException("Id can not be null");
		}

	}

	public static void validateFindUserById(Integer id) throws ApplicationException {

		if (id == null) {
			throw new ApplicationException("Id can not be null");

		}

	}

	public static void validateCheckTransactioContainsOrNot(User user) throws ApplicationException {

		if (user == null) {
			throw new ApplicationException("user can not be null");

		}
	}

	public static void validateAndGetTransactionListBasedOnIdAndProductType(Integer id, String name)
			throws ApplicationException {

		if (id == null && name == null) {
			throw new ApplicationException("name and Id  should not be null");

		}
	}

	public static void validateAndGetTransactionListBasedOnIdProductTypeAndCity(Integer id, String name,
			String password) throws ApplicationException {
		if (id == null && name == null && password == null) {
			throw new ApplicationException("password , Id and name  should not be null");

		}

	}

}
