
package com.hcl.cs.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hcl.cs.converter.PetConverter;
import com.hcl.cs.converter.UserConverter;
import com.hcl.cs.entity.PetEntity;
import com.hcl.cs.entity.UserEntity;
import com.hcl.cs.exception.ApplicationException;
import com.hcl.cs.model.Pet;
import com.hcl.cs.model.User;
import com.hcl.cs.repo.PetRepo;
import com.hcl.cs.repo.UserRepo;

@Service
public class UserService {

	@Autowired
	private UserRepo userRepo;

	public Optional<User> saveUser(User user) throws ApplicationException {

		UserEntity userEntity = UserConverter.convert(user);
		List<UserEntity> users = userRepo.findAll();
		Optional<UserEntity> user1 = users.stream().filter(u -> u.equals(userEntity)).findFirst();
		if (user1.isPresent()) {
			throw new ApplicationException("User Already Exists");
		}
		return Optional.of(UserConverter.convert(userRepo.save(userEntity)));
	}

	public Optional<List<Pet>> getMyPets(Long id) {
		Optional<UserEntity> userEntity = userRepo.findById(id);
		List<PetEntity> pets = userEntity.get().getPets();
		return Optional.of(PetConverter.convert(pets));

	}

	//
	public User getUserByName(String name) {

		UserEntity findByName = userRepo.findByUserName(name);
		return UserConverter.convert(findByName);
	}

}
