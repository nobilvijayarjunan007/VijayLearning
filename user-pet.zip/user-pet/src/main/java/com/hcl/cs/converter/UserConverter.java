package com.hcl.cs.converter;

import java.util.ArrayList;
import java.util.List;

import com.hcl.cs.entity.UserEntity;
import com.hcl.cs.model.User;

public class UserConverter {

	public static List<User> convert(List<UserEntity> userEntityList) {

		List<User> userList = null;

		if (userEntityList != null) {
			userList = new ArrayList<>();
			for (UserEntity entity : userEntityList) {

				User user = convert(entity);
				userList.add(user);

			}

		}

		return userList;
	}

	public static User convert(UserEntity entity) {
		User user = null;
		if (entity != null) {
			user = new User();
			if (entity.getUserId() != null)

				user.setUserId(entity.getUserId());
			user.setUserName(entity.getUserName());
			user.setPassWord(entity.getPassWord());

		}

		return user;

	}

	public static UserEntity convert(User newUser) {

		UserEntity user = null;
		if (newUser != null) {
			user = new UserEntity();

			user.setUserId(Long.valueOf(newUser.getUserId()));
			user.setUserName(newUser.getUserName());
			user.setPassWord(newUser.getPassWord());

		}
		return user;
	}

	public static List<UserEntity> convertToEntity(List<User> userList) {

		List<UserEntity> userEntityList = null;

		if (userList != null) {
			userEntityList = new ArrayList<>();
			for (User user : userList) {

				UserEntity entity = convert(user);

				userEntityList.add(entity);

			}

		}

		return userEntityList;
	}

}
