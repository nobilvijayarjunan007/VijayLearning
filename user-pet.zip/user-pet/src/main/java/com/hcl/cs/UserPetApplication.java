package com.hcl.cs;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.web.bind.annotation.RestController;

import com.hcl.cs.dataloader.DataLoader;
import com.hcl.cs.dataloader.DataLoader2;
import com.hcl.cs.entity.PetEntity;
import com.hcl.cs.entity.UserEntity;
import com.hcl.cs.repo.PetRepo;
import com.hcl.cs.repo.UserRepo;
import com.hcl.cs.service.PetService;
import com.hcl.cs.service.UserService;

@SpringBootApplication
@RestController
public class UserPetApplication {

	public static void main(String[] args) {
		SpringApplication.run(UserPetApplication.class, args);
	}

	@Autowired
	private UserRepo userRepo;
	@Autowired
	private PetRepo petRepo;
	@Autowired
	private UserService userService;
	@Autowired
	private PetService petService;

	@Bean
	public CommandLineRunner userService1() {

		System.out.println("+++++++++++++++++++++++++++++++++++++++++++++");
		return arg -> {

			List<UserEntity> newUsers = DataLoader.newUsers();

			List<UserEntity> saveAll = userRepo.saveAll(newUsers);

			System.out.println(saveAll);

		};

	}

	// @Bean
	public CommandLineRunner petService1() {

		System.out.println("+++++++++++++++++++++++++++++++++++++++++++++");
		return arg -> {

			List<PetEntity> newPets = DataLoader2.newPets();
			petRepo.saveAll(newPets);

		};

	}
}