package com.hcl.cs.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.hcl.cs.entity.PetEntity;

@Repository
public interface PetRepo extends JpaRepository<PetEntity, Long> {

	PetEntity findByPetName(String string);
}
