package com.dnapass.training;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RequestMapping("/consumer")
@RestController
public class ConsumerController {

	@Autowired
	private FeignDemo feignDemo;

	@RequestMapping(value = "/world/{name}", method = RequestMethod.GET)
	public String get(@PathVariable("name") String name) {
		return feignDemo.world(name);
	}

}
