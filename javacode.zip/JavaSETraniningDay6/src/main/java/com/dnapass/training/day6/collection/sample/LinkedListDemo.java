package com.dnapass.training.day6.collection.sample;

import java.util.*;

public class LinkedListDemo {

	public static void main(String args[]) {

		LinkedList<String> colors = new LinkedList<String>();
		colors.add("Red");
		colors.add("Black");
		colors.add("Blue");
		colors.add("Yellow");
		colors.add("Pink");
		colors.add("White");

		System.out.print("The linked list :" + colors);

		for (String element : colors) {
			System.out.println(element);
		}

		ListIterator p = colors.listIterator();

		while (p.hasNext()) {
			System.out.println(p.next());
		}

		while (p.hasPrevious()) {
			System.out.println(p.hasPrevious());
		}

		Iterator it = colors.descendingIterator();

		System.out.println("Element is Reverse Order");
		while (it.hasNext()) {
			System.out.print(it.next());
		}

		colors.add(1, "Yello");
		System.out.println("The linked list :" + colors);

		colors.addFirst("white");
		colors.addLast("pink");

		LinkedList<String> newColorList = new LinkedList<String>();
		newColorList.add("white");
		newColorList.add("pink");

		colors.addAll(1, newColorList);
		String first_element = colors.getFirst();

		String last_element = colors.getLast();
		System.out.println("Last Element is : " + last_element);

		colors.remove(2);
		System.out.println("The new linked list " + colors);

		String firstElement = colors.removeFirst();
		System.out.println("Element Remove :" + firstElement);

		String lastElement = colors.removeLast();
		System.out.println("Element Removed : " + lastElement);
		System.out.println("The New linked list" + colors);

		colors.clear();

		System.out.print("The new Linked list " + colors);

		Collections.swap(colors, 0, 2);
		System.out.println("The New Linked list after swap :" + colors);

		System.out.println("Linked list before shuffling :" + colors);
		Collections.shuffle(colors);
		System.out.println("Linked list after shuffling :" + colors);

		LinkedList<String> c1 = new LinkedList<String>();
		c1.add("Red");
		c1.add("Green");
		c1.add("Black");
		c1.add("White");
		c1.add("Pink");
		System.out.println("List of First linked list :" + c1);

		System.out.println("Removed element : " + c1.pop());
		String x = c1.peekFirst();

		System.out.println("First element in the list : " + x);

		x = c1.peekLast();
		System.out.println("last element in the list " + x);

		if (c1.contains("Green"))
			System.out.println("Color Green Contain in the list ");
		else
			System.out.println("Color Green not contain in the list");

		if (c1.contains("orange"))
			System.out.println("Color Orange Contain in the list ");
		else
			System.out.println("Color Orange not contain in the list");

		System.out.println("Check the above linked list is empty or not " + c1.isEmpty());
		c1.removeAll(c1);
		System.out.println("linked list after remove " + c1);
		System.out.println("Check the above linked list is empty or not " + c1.isEmpty());

		c1.set(1, "orange");
		System.out.println("The value of second element changed");
		System.out.println("New Linked list : " + c1);

		List<String> list = new ArrayList<String>(c1);

		for (String str : list) {
			System.out.println(str);
		}

		LinkedList<String> c2 = new LinkedList<String>();
		c2.add("Red");
		c2.add("green");
		c2.add("Black");
		c2.add("Pink");
		System.out.println("List of second linked list " + c2);

		LinkedList<String> a = new LinkedList<String>();
		a.addAll(c1);
		a.addAll(c2);
		System.out.println("New Linked list : " + a);

		System.out.println("Original list 	 : " + c1);
		LinkedList<String> newc1 = new LinkedList<String>();
		newc1 = (LinkedList) c1.clone();
		System.out.println("Cloned linked list : " + newc1);

	}
}
