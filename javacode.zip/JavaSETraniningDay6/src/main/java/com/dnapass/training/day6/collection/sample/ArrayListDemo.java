package com.dnapass.training.day6.collection.sample;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class ArrayListDemo {

	public static void main(String[] args) {

		List<String> color = null;
		color = new ArrayList<String>();

		color.add("Red");
		color.add("Green");
		color.add("orange");
		color.add("white");
		color.add("Black");

		System.out.println(color.toString());

		for (String element : color) {
			System.out.println(element);
		}

		color.add(0, "pink");
		color.add(5, "Yellow");

		System.out.println(color);

		String element = color.get(0);
		System.out.println("First Element :- " + element);
		element = color.get(2);
		System.out.println("Third element :- " + element);

		color.set(2, "Yellow");
		System.out.println(color);

		color.remove(2);
		System.out.println("After Remove third element  from list : \n" + color);

		if (color.contains("Red"))
			System.out.println("Found the element ");
		else
			System.out.println("There is no such element ");

		Collections.sort(color);

		System.out.println("After sorting List :- " + color);

		List<String> list2 = new ArrayList<String>();
		list2.add("A");
		list2.add("B");
		list2.add("C");
		list2.add("D");
		Collections.swap(list2, 0, 2);
		System.out.println("After Swaping :- " + list2);
		for (String b : color) {
			System.out.println(b);
		}

		// assertEquals("C" , list2.get(0));
		// assertEquals("A", list2.get(2));

		ArrayList<String> c2 = new ArrayList<String>();
		c2.add("Red");
		c2.add("Green");
		c2.add("Black");
		c2.add("Pink");
		System.out.println("List of Second array :- " + c2);

		ArrayList<String> a = new ArrayList<String>();
		a.addAll(color);
		a.addAll(c2);
		System.out.println("New Arrray :" + a);

		ArrayList<String> newc1 = (ArrayList<String>) c2.clone();
		newc1 = c2;

		System.out.println("Clone array list : " + newc1);

		color.removeAll(color);
		System.out.println("Array list after remove all element " + element);

		c2.trimToSize();
		System.out.println(color);
		method();

		c2.ensureCapacity(6);
		c2.add("White");
		c2.add("Pink");
		c2.add("Yellow");
		method();

		ArrayList<String> color1 = new ArrayList<String>();

		color1.add("Red");
		color1.add("Green");

		System.out.println("Original Array list : " + color);

		String new_color = "white";
		color1.set(1, new_color);

		// int num = color.size();
		System.out.println("Replace Second element with 'white");

		for (int i = 0; i < color1.size(); i++) {
			System.out.println(color1.get(i));
		}

	}

	static void method() {
		System.out.println("hii");
	}

}
