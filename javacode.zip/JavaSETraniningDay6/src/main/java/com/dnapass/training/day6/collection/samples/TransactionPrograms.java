package com.dnapass.training.day6.collection.samples;

import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import com.dnapass.training.day6.transaction.ProductType;
import com.dnapass.training.day6.transaction.TransactionDataLoader;
import com.dnapass.training.day6.transaction.TransactionsEntity;

public class TransactionPrograms {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Map<Integer,TransactionsEntity> map = new HashMap<Integer,TransactionsEntity>();
		
		map.put(1, new TransactionsEntity (100, ProductType.FRUIT, 45.55, "Chennai", "INR"));
		map.put(2,new TransactionsEntity (101, ProductType.GROCERY, 252.22, "london", "GBP"));
		map.put(3,new TransactionsEntity (102, ProductType.ELECTRIC, 20.99, "bangalore", "USD"));
		map.put(4,new TransactionsEntity (103, ProductType.FRUIT, 68.22, "Chennai", "INR"));
		map.put(5,new TransactionsEntity (104, ProductType.FUEL, 90.34, "london", "GBP"));
		map.put(6,new TransactionsEntity (105, ProductType.ELECTRIC, 150.56, "bangalore", "USD"));
		map.put(7,new TransactionsEntity (106, ProductType.GROCERY, 456.99, "Chennai", "INR"));
		map.put(8,new TransactionsEntity (107, ProductType.FUEL, 451.55, "bangalore", "USD"));

		TransactionValidator.changeTransactionTypeFuelIntoElectric(map);
		TransactionValidator.removeTransactionHappenedInLondon(map);
		
		
		
		
}

	

	

	

	}


