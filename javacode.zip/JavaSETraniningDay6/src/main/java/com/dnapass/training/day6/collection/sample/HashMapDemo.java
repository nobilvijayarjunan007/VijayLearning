package com.dnapass.training.day6.collection.sample;

import java.util.HashMap;
import java.util.Map.Entry;

public class HashMapDemo {

	public static void main(String args[]) {
		HashMap<Integer, String> hash_map = new HashMap<Integer, String>();
		hash_map.put(1, "Red");
		hash_map.put(2, "Green");
		hash_map.put(3, "black");
		hash_map.put(4, "white");
		hash_map.put(5, "blue");
		for (Entry<Integer, String> x : hash_map.entrySet()) {
			System.out.println(x.getKey() + "" + x.getValue());
		}

		System.out.println("Size of the hash map : " + hash_map.size());

		HashMap<Integer, String> hash_map1 = new HashMap<Integer, String>();
		HashMap<Integer, String> hash_map2 = new HashMap<Integer, String>();

		hash_map.put(1, "Red");
		hash_map.put(2, "Green");
		hash_map.put(3, "Black");
		System.out.println("\n Value in first map : " + hash_map1);
		hash_map2.put(4, "White");
		hash_map.put(5, "Blue");
		hash_map.put(6, "Organge");
		System.out.println("\n values in second map : " + hash_map2);

	}
}
