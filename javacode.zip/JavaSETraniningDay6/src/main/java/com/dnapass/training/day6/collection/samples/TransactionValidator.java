package com.dnapass.training.day6.collection.samples;

import java.util.Iterator;
import java.util.Map;

import com.dnapass.training.day6.transaction.ProductType;
import com.dnapass.training.day6.transaction.TransactionsEntity;

public class TransactionValidator {

	public static void removeTransactionHappenedInLondon(Map<Integer, TransactionsEntity> map) {
		Iterator<Map.Entry<Integer, TransactionsEntity>> i = map.entrySet().iterator();

		while (i.hasNext()) {

			Map.Entry<Integer, TransactionsEntity> me = i.next();
			if ("london".equals(me.getValue().getCity())) {
				i.remove();

			}

		}
		System.out.println(map);

		Iterator it = map.entrySet().iterator();
		while (it.hasNext()) {

			System.out.println(it.next());
		}
	}

	public static void changeTransactionTypeFuelIntoElectric(Map<Integer, TransactionsEntity> map) {
		Iterator<Map.Entry<Integer, TransactionsEntity>> i = map.entrySet().iterator();

		while (i.hasNext()) {

			Map.Entry<Integer, TransactionsEntity> me = i.next();
			if (ProductType.FUEL.equals(me.getValue().getType())) {
				me.getValue().setType(ProductType.ELECTRIC);

			}

		}
		System.out.println(map);

		Iterator it = map.entrySet().iterator();
		while (it.hasNext()) {

			System.out.println(it.next());
		}

	}
}
