package com.dnapass.training.day6.transaction.service;

import com.dnapass.training.day6.transaction.ProductType;
import com.dnapass.training.day6.transaction.TransactionsEntity;


public class TransactionValidator {

	public static void validateTransaction(TransactionsEntity transaction) throws ApplicationException {

		if (transaction == null) {
			throw new ApplicationException("Transaction can not be null");
		}

		transactionFieldsNull(transaction);

	}

	public static void validateAndDeleteTransaction(TransactionsEntity transaction) throws ApplicationException {
		if (transaction == null) {
			throw new ApplicationException("Transaction can not be null");
		}

	}

	public static void validateAndUpdateTransaction(TransactionsEntity transaction) throws ApplicationException {
		if (transaction == null) {
			throw new ApplicationException("Transaction can not be null");
		}
		transactionFieldsNull(transaction);
	}

	@SuppressWarnings("unused")
	public static void validateAndDeleteTransaction(int i) throws ApplicationException {

		Integer ii = i;

		if (ii == null) {
			throw new ApplicationException("Id can not be null");
		}

	}

	public static void validateAndFindTransactionById(Integer id) throws ApplicationException {

		if (id == null) {
			throw new ApplicationException("Id can not be null");

		}

	}

	public static void validateAndCheckTransactioContainsOrNot(TransactionsEntity transaction) throws ApplicationException {

		if (transaction == null) {
			throw new ApplicationException("Transaction can not be null");

		}
	}

	public static void validateAndGetTransactionListBasedOnIdAndProductType(Integer id, ProductType prod)
			throws ApplicationException {

		if (id == null && prod == null) {
			throw new ApplicationException("ProductType and Id  should not be null");

		}
	}

	public static void validateAndGetTransactionListBasedOnIdProductTypeAndCity(Integer id, ProductType prod, String city)
			throws ApplicationException {
		if (id == null && prod == null && city == null) {
			throw new ApplicationException("ProductType , Id and city  should not be null");

		}

	}

	public static void transactionFieldsNull(TransactionsEntity transaction) throws ApplicationException {

		transactionFieldIdNull(transaction);
		transactionFieldAmountNull(transaction);
		transactionFieldCityNull(transaction);
		transactionFieldCurrencyNull(transaction);
		transactionFieldTypeNull(transaction);
	}

	public static void transactionFieldIdNull(TransactionsEntity transaction) throws ApplicationException {

		if (transaction.getId() == null) {

			throw new ApplicationException("Id can't be null");
		}

	}

	public static void transactionFieldAmountNull(TransactionsEntity transaction) throws ApplicationException {
		if (transaction.getAmount() == null) {
			throw new ApplicationException("Amount must be greater than zero and amount can't be null ");
		}

	}

	public static void transactionFieldCityNull(TransactionsEntity transaction) throws ApplicationException {

		if (transaction.getCity() == null) {
			throw new ApplicationException("city can't be null ");

		}
	}

	public static void transactionFieldCurrencyNull(TransactionsEntity transaction) throws ApplicationException {

		if (transaction.getCurrency() == null) {
			throw new ApplicationException("currency should not be null");

		}
	}

	public static void transactionFieldTypeNull(TransactionsEntity transaction) throws ApplicationException {

		if (transaction.getType() == null) {
			throw new ApplicationException("Type should not be null");

		}
	}

}
