package com.dnapass.training.day6.transaction;

public enum ProductType {

	FRUIT,GROCERY,FUEL,ELECTRIC
}
