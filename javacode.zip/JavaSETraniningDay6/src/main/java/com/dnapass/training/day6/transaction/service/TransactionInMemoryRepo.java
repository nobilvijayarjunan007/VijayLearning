package com.dnapass.training.day6.transaction.service;

import java.util.*;

import com.dnapass.training.day6.transaction.ProductType;
import com.dnapass.training.day6.transaction.TransactionDataLoader;
import com.dnapass.training.day6.transaction.TransactionsEntity;

public class TransactionInMemoryRepo implements ITransactionRepo {

	public static List<TransactionsEntity> transactionDatabase = new ArrayList<TransactionsEntity>();

	static {
		transactionDatabase = TransactionDataLoader.newTransaction();
	}

	public static void main(String[] args) throws ApplicationException {

		System.out.println(transactionDatabase);
		/*
		 * List<Transactions> list = new
		 * TransactionInMemoryRepo().findByIdAndProductTypeAndCity(100,
		 * ProductType.FRUIT, "Chennai"); System.out.println(list);
		 * 
		 * List<Transactions> list1 = new
		 * TransactionInMemoryRepo().findByIdAndProductType(100, ProductType.FRUIT);
		 * System.out.println(list1);
		 */
	}

	@SuppressWarnings("unused")
	public boolean createTransaction(TransactionsEntity transaction) throws ApplicationException {

		TransactionValidator.validateTransaction(transaction);
		boolean flag = true;
		for (TransactionsEntity tran : transactionDatabase) {
			if (tran.getId() == transaction.getId()) {

				flag = false;
				throw new ApplicationException("Transaction is Already Exist !!!");

			}

		}

		transactionDatabase.add(transaction);
		return flag;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.dnapass.training.day6.transaction.service.ITransactionRepo#delete(com.
	 * dnapass.training.day6.transaction.Transactions)
	 */
	public boolean delete(TransactionsEntity transaction) throws ApplicationException {

		TransactionValidator.validateAndDeleteTransaction(transaction);
		boolean flag = true;
		int count = 0;
		for (TransactionsEntity tran : transactionDatabase) {
			if (tran.getId() != transaction.getId()) {
				flag = false;
			} else if (tran.getId() == transaction.getId())// if equals method
			{
				count++;
				System.out.println("Before " + transactionDatabase.size());
				transactionDatabase.remove(transaction);
				System.out.println("After " + transactionDatabase.size());
			}

		}
		if (count == 0) {

			throw new ApplicationException("Transaction not Found !!!");
		}
		return flag;
	}

	@SuppressWarnings("unused")
	public boolean update(TransactionsEntity transaction) throws ApplicationException {

		TransactionValidator.validateAndUpdateTransaction(transaction);
		boolean flag = false;
		int count = 0;
		for (TransactionsEntity tran : transactionDatabase) {
			if (tran.getId() != transaction.getId()) {
				flag = true;
			} else if (tran.getId() == transaction.getId()) {
				count++;
				transactionDatabase.add(transaction);
				System.out.println(transactionDatabase);
			}

		}
		if (count == 0) {

			throw new ApplicationException("Transaction not Found !!!");
		}
		return flag;
		// transactionDatabase.add(transaction);
	}

	// @SuppressWarnings({ "unused", "static-access" })
	private void delete(int i) throws ApplicationException {
		TransactionValidator.validateAndDeleteTransaction(i);
		// boolean flag = false;
		int count = 0;
		for (TransactionsEntity tran : transactionDatabase) {
			if (tran.getId() != i) {
				// flag = true;
			} else if (tran.getId() == i) {
				count++;
				transactionDatabase.remove(i);
			}

		}
		if (count == 0) {

			throw new ApplicationException("Transaction not Found !!!");
		}

		// transactionDatabase.remove(i);

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.dnapass.training.day6.transaction.service.ITransactionRepo#findById(java.
	 * lang.Integer)
	 */
	// @SuppressWarnings("static-access")
	public TransactionsEntity findById(Integer id) throws ApplicationException {

		TransactionValidator.validateAndFindTransactionById(id);
		// boolean flag = false;
		int count = 0;
		TransactionsEntity tranById = new TransactionsEntity();
		for (TransactionsEntity tran : transactionDatabase) {
			if (tran.getId() != id) {
				// flag = true;
			} else if (tran.getId() == id) {
				count++;
				tranById = transactionDatabase.get(id);
			}

		}
		if (count == 0) {

			throw new ApplicationException("Transaction not Found !!!");
		}

		return tranById;
	}

	/*
	 * public void delete() {
	 * 
	 * }
	 */

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.dnapass.training.day6.transaction.service.ITransactionRepo#find(com.
	 * dnapass.training.day6.transaction.Transactions)
	 */
	public boolean find(TransactionsEntity transaction) throws ApplicationException {
		TransactionValidator.validateAndCheckTransactioContainsOrNot(transaction);
		boolean flag = false;// true;
		int count = 0;
		for (TransactionsEntity tran : transactionDatabase) {
			if (tran.getId() != transaction.getId()) {
				// flag = false;
			} else if (tran.getId() == transaction.getId()) {
				count++;
				flag = true;

			}

			// if (!flag) {
			if (count == 0) {
				throw new ApplicationException("Transaction not Found !!!");
			}
		}
		return flag;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.dnapass.training.day6.transaction.service.ITransactionRepo#
	 * findByIdAndProductType(java.lang.Integer,
	 * com.dnapass.training.day6.transaction.ProductType)
	 */
	@SuppressWarnings("static-access")
	public List<TransactionsEntity> findByIdAndProductType(Integer id, ProductType prod) throws ApplicationException {
		TransactionValidator.validateAndGetTransactionListBasedOnIdAndProductType(id, prod);
		// boolean flag = false;
		int count = 0;
		List<TransactionsEntity> newList = new ArrayList();

		for (TransactionsEntity tran : transactionDatabase) {
			if (tran.getId() != id && tran.getType() != prod) {
				// flag = true;
			}

			else if (tran.getId() == id || tran.getType() == prod) {
				count++;
				newList.add(tran);
			}

		}

		if (count == 0) {

			throw new ApplicationException("There is no Transaction By that Type and Id !!!");
		}
		return newList;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.dnapass.training.day6.transaction.service.ITransactionRepo#
	 * findByIdAndProductTypeAndCity(java.lang.Integer,
	 * com.dnapass.training.day6.transaction.ProductType, java.lang.String)
	 */
	@SuppressWarnings("static-access")
	public List<TransactionsEntity> findByIdAndProductTypeAndCity(Integer id, ProductType prod, String city)
			throws ApplicationException {
		TransactionValidator.validateAndGetTransactionListBasedOnIdProductTypeAndCity(id, prod, city);
		// boolean flag = false;
		int count = 0;
		List<TransactionsEntity> newList = new ArrayList();

		for (TransactionsEntity tran : transactionDatabase) {
			if (tran.getId() != id && tran.getType() != prod && tran.getCity() != city) {
				// flag = true;

			} else if (tran.getId() == id || tran.getType() == prod || tran.getCity() == city) {
				// System.out.println(tran);

				count++;
				newList.add(tran);
			}

		}
		if (count == 0) {

			throw new ApplicationException("There is no Transaction By that Id,Type and city !!!");
		}
		return newList;
	}
}
