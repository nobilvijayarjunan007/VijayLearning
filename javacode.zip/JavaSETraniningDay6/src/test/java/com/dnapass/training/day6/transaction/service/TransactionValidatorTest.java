package com.dnapass.training.day6.transaction.service;

import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;

import com.dnapass.training.day6.transaction.ProductType;
import com.dnapass.training.day6.transaction.TransactionsEntity;

public class TransactionValidatorTest {

	
	@SuppressWarnings("deprecation")
	@Rule
	public ExpectedException exceptionRule = ExpectedException.none();

	@Test
	public void IfTransationIsNull() throws ApplicationException {

		exceptionRule.expectMessage("Transaction can not be null");
		exceptionRule.expect(ApplicationException.class);
		TransactionValidator.validateTransaction(null);

	}

	@Test
	public void IfTransationIsNullWhenValidateAndDeleteTransaction() throws ApplicationException {

		exceptionRule.expectMessage("Transaction can not be null");
		exceptionRule.expect(ApplicationException.class);
		TransactionValidator.validateAndDeleteTransaction(null);
		;

	}

	@Test
	public void IfTransationIsNullWhenValidateAndUpdateTransaction() throws ApplicationException {

		exceptionRule.expectMessage("Transaction can not be null");
		exceptionRule.expect(ApplicationException.class);
		TransactionValidator.validateAndUpdateTransaction(null);

	}

	@Test
	public void IfIdIsNullWhenValidateAndFindTransactioById() throws ApplicationException {

		exceptionRule.expectMessage("Id can not be null");
		exceptionRule.expect(ApplicationException.class);
		TransactionValidator.validateAndFindTransactionById(null);

	}

	@Test
	public void IfIdAndProductAreNullWhenValidateAndGetTransactionListBasedOnIdAndProductType()
			throws ApplicationException {

		exceptionRule.expectMessage("ProductType and Id  should not be null");
		exceptionRule.expect(ApplicationException.class);
		TransactionValidator.validateAndGetTransactionListBasedOnIdAndProductType(null, null);

	}

	@Test
	public void IfIdAndProductAreNullWhenValidateAndGetTransactionListBasedOnIdProductTypeAndCity()
			throws ApplicationException {

		exceptionRule.expectMessage("ProductType , Id and city  should not be null");
		exceptionRule.expect(ApplicationException.class);
		TransactionValidator.validateAndGetTransactionListBasedOnIdProductTypeAndCity(null, null, null);

	}

	@Test
	public void IfTransactionFieldIdNull() throws ApplicationException {
		TransactionsEntity tran = new TransactionsEntity(null, ProductType.FRUIT, 45.55, "Chennai", "INR");
		exceptionRule.expectMessage("Id can't be null");
		exceptionRule.expect(ApplicationException.class);
		TransactionValidator.transactionFieldIdNull(tran);

	}

	@Test
	public void IfTransactionFieldAmountNull() throws ApplicationException {
		TransactionsEntity tran = new TransactionsEntity(200, ProductType.FRUIT, null, "Chennai", "INR");
		exceptionRule.expectMessage("Amount must be greater than zero and amount can't be null ");
		exceptionRule.expect(ApplicationException.class);
		TransactionValidator.transactionFieldAmountNull(tran);

	}

	@Test
	public void IfTransactionFieldCityNull() throws ApplicationException {
		TransactionsEntity tran = new TransactionsEntity(200, ProductType.FRUIT, 555.55, null, "INR");
		exceptionRule.expectMessage("city can't be null ");
		exceptionRule.expect(ApplicationException.class);
		TransactionValidator.transactionFieldCityNull(tran);

	}

	@Test
	public void IfTransactionFieldCurrencyNull() throws ApplicationException {
		TransactionsEntity tran = new TransactionsEntity(200, ProductType.FRUIT, 555.55, "Chennai", null);
		exceptionRule.expectMessage("currency should not be null");
		exceptionRule.expect(ApplicationException.class);
		TransactionValidator.transactionFieldCurrencyNull(tran);

	}

	@Test
	public void IfTransactionFieldTypeNull() throws ApplicationException {
		TransactionsEntity tran = new TransactionsEntity(200, null, 555.55, "Chennai", "INR");
		exceptionRule.expectMessage("Type should not be null");
		exceptionRule.expect(ApplicationException.class);
		TransactionValidator.transactionFieldTypeNull(tran);

	}
}
