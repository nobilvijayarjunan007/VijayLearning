package com.dnapass.training.day6.transaction.test.suite.service;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

import com.dnapass.training.day6.transaction.TransactionsTest;
import com.dnapass.training.day6.transaction.service.TransactionInMemoryRepoTest;
import com.dnapass.training.day6.transaction.service.TransactionValidatorTest;

@RunWith(Suite.class)
@Suite.SuiteClasses({TransactionsTest.class,TransactionInMemoryRepoTest.class,TransactionValidatorTest.class})
public class TestSuiteDay6 {

}
