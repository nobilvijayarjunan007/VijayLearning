package com.dnapass.training.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.dnapass.training.entities.ProductEntity;
import com.dnapass.training.repo.ProductRepo;

@Service
public class ProductService {

	private ProductRepo repository;
	
	public void createAll(List<ProductEntity> products) {
		
		repository.saveAll(products);
		
	}
	
	
	
}
