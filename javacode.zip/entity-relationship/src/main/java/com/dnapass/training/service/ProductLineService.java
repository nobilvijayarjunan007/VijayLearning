package com.dnapass.training.service;

import org.springframework.stereotype.Service;

@Service
public class ProductLineService {

}
