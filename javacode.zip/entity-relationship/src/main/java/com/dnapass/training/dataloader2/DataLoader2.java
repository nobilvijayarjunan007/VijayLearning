/*
 * package com.dnapass.training.dataloader2;
 * 
 * import java.util.ArrayList; import java.util.List;
 * 
 * import com.dnapass.training.entities.CustomerEntity; import
 * com.dnapass.training.entities.EmployeeEntity; import
 * com.dnapass.training.entities.OfficeEntity; import
 * com.dnapass.training.entities.ProductEntity; import
 * com.dnapass.training.models.Employee; import
 * com.dnapass.training.models.Office; import
 * com.dnapass.training.models.Products;
 * 
 * public class DataLoader2 { List<OfficeEntity> off;
 * 
 * public static List<OfficeEntity> officeDetailsLoader() { List<OfficeEntity>
 * offices = new ArrayList<>(); offices.add(new OfficeEntity(1l,
 * "San Francisco", "+1 650 219 4782", "100 Market Street", "Suite 300", "CA",
 * "USA", "94080", "NA", null));
 * 
 * offices.add(new OfficeEntity(2l, "Boston", "+1 215 837 0825",
 * "1550 Court Place", "Suite 102", "MA", "USA", "02107", "NA", null));
 * 
 * offices.add(new OfficeEntity(3l, "NYC", "+1 212 555 3000",
 * "523 East 53rd Street", "apt. 5A", "NY", "USA", "10022", "NA", null));
 * 
 * offices.add(new OfficeEntity(4l, "Paris", "+33 14 723 4404",
 * "43 Rue Jouffroy D\"abbans", null, null, "France", "75017", "EMEA", null));
 * 
 * offices.add(new OfficeEntity(5l, "Tokyo", "+81 33 224 5000", "4-1 Kioicho",
 * null, "Chiyoda-Ku", "Japan", "102-8578", "Japan", null));
 * 
 * offices.add(new OfficeEntity(6l, "Sydney", "+61 2 9264 2451",
 * "5-11 Wentworth Avenue", "Floor #2", null, "Australia", "NSW 2010", "APAC",
 * null));
 * 
 * offices.add(new OfficeEntity(7l, "London", "+44 20 7877 2041",
 * "25 Old Broad Street", "Level 7", null, "UK", "EC2N 1HN", "EMEA", null));
 * 
 * return offices; }
 * 
 * public static List<EmployeeEntity> employeesLoader() {
 * 
 * List<EmployeeEntity> emps = new ArrayList<>(); emps.add(new
 * EmployeeEntity(1002, "Murphy", "Diane", "x5800",
 * "dmurphy@classicmodelcars.com", null, "President", null, null));
 * 
 * 
 * emps.add(new EmployeeEntity(1056, "Patterson", "Mary", "x4611",
 * "mpatterso@classicmodelcars.com", 1002, "VP Sales", null, null));
 * 
 * emps.add(new EmployeeEntity(1076, "Firrelli", "Jeff", "x9273",
 * "jfirrelli@classicmodelcars.com", 1002, "VP Marketing", null, null));
 * 
 * emps.add(new EmployeeEntity(1088, "Patterson", "William", "x4871",
 * "wpatterson@classicmodelcars.com", 1056, "Sales Manager (APAC)", null,
 * null));
 * 
 * emps.add(new EmployeeEntity(1102, "Bondur", "Gerard", "x5408",
 * "gbondur@classicmodelcars.com", 1056, "Sale Manager (EMEA)", null, null));
 * 
 * emps.add(new EmployeeEntity(1143, "Bow", "Anthony", "x5428",
 * "abow@classicmodelcars.com", 1056, "Sales Manager (NA)", null, null));
 * 
 * emps.add(new EmployeeEntity(1165, "Jennings", "Leslie", "x3291",
 * "ljennings@classicmodelcars.com", 1143, "Sales Rep", null, null));
 * 
 * emps.add(new EmployeeEntity(1166, "Thompson", "Leslie", "x4065",
 * "lthompson@classicmodelcars.com", 1143, "Sales Rep", null, null));
 * 
 * emps.add(new EmployeeEntity(1188, "Firrelli", "Julie", "x2173",
 * "jfirrelli@classicmodelcars.com", 1143, "Sales Rep", null, null));
 * 
 * emps.add(new EmployeeEntity(1216, "Patterson", "Steve", "x4334",
 * "spatterson@classicmodelcars.com", 1143, "Sales Rep", null, null));
 * 
 * emps.add(new EmployeeEntity(1286, "Tseng", "Foon Yue", "x2248",
 * "ftseng@classicmodelcars.com", 1143, "Sales Rep", null, null));
 * 
 * emps.add(new EmployeeEntity(1323, "Vanauf", "George", "x4102",
 * "gvanauf@classicmodelcars.com", 1143, "Sales Rep", null, null));
 * 
 * emps.add(new EmployeeEntity(1337, "Bondur", "Loui", "x6493",
 * "lbondur@classicmodelcars.com", 1102, "Sales Rep", null, null));
 * 
 * emps.add(new EmployeeEntity(1370, "Hernandez", "Gerard", "x2028",
 * "ghernande@classicmodelcars.com", 1102, "Sales Rep", null, null));
 * 
 * emps.add(new EmployeeEntity(1401, "Castillo", "Pamela", "x2759",
 * "pcastillo@classicmodelcars.com", 1102, "Sales Rep", null, null));
 * 
 * emps.add(new EmployeeEntity(1501, "Bott", "Larry", "x2311",
 * "lbott@classicmodelcars.com", 1102, "Sales Rep", null, null));
 * 
 * emps.add(new EmployeeEntity(1504, "Jones", "Barry", "x102",
 * "bjones@classicmodelcars.com", 1102, "Sales Rep", null, null));
 * 
 * emps.add(new EmployeeEntity(1611, "Fixter", "Andy", "x101",
 * "afixter@classicmodelcars.com", 1088, "Sales Rep", null, null));
 * 
 * emps.add(new EmployeeEntity(1612, "Marsh", "Peter", "x102",
 * "pmarsh@classicmodelcars.com", 1088, "Sales Rep", null, null));
 * 
 * emps.add(new EmployeeEntity(1619, "King", "Tom", "x103",
 * "tking@classicmodelcars.com", 1088, "Sales Rep", null, null));
 * 
 * emps.add(new EmployeeEntity(1621, "Nishi", "Mami", "x101",
 * "mnishi@classicmodelcars.com", 1056, "Sales Rep", null, null));
 * 
 * emps.add(new EmployeeEntity(1625, "Kato", "Yoshimi", "x102",
 * "ykato@classicmodelcars.com", 1621, "Sales Rep", null, null));
 * 
 * emps.add(new EmployeeEntity(1702, "Gerard", "Martin", "x2312",
 * "mgerard@classicmodelcars.com", 1102, "Sales Rep", null, null));
 * 
 * return emps;
 * 
 * }
 * 
 * public static List<OfficeEntity> officeDetailsLoader1() { List<OfficeEntity>
 * offices = new ArrayList<>(); offices.add(new OfficeEntity("San Francisco",
 * "+1 650 219 4782", "100 Market Street", "Suite 300", "CA", "USA", "94080",
 * "NA"));
 * 
 * offices.add(new OfficeEntity("Boston", "+1 215 837 0825", "1550 Court Place",
 * "Suite 102", "MA", "USA", "02107", "NA"));
 * 
 * offices.add(new OfficeEntity("NYC", "+1 212 555 3000",
 * "523 East 53rd Street", "apt. 5A", "NY", "USA", "10022", "NA"));
 * 
 * offices.add(new OfficeEntity("Paris", "+33 14 723 4404",
 * "43 Rue Jouffroy D\"abbans", null, null, "France", "75017", "EMEA"));
 * 
 * offices.add(new OfficeEntity("Tokyo", "+81 33 224 5000", "4-1 Kioicho", null,
 * "Chiyoda-Ku", "Japan", "102-8578", "Japan"));
 * 
 * offices.add(new OfficeEntity("Sydney", "+61 2 9264 2451",
 * "5-11 Wentworth Avenue", "Floor #2", null, "Australia", "NSW 2010", "APAC"));
 * 
 * offices.add(new OfficeEntity("London", "+44 20 7877 2041",
 * "25 Old Broad Street", "Level 7", null, "UK", "EC2N 1HN", "EMEA"));
 * 
 * return offices; }
 * 
 * public static List<EmployeeEntity> employeesLoader1() {
 * 
 * List<OfficeEntity> off = officeDetailsLoader1(); List<EmployeeEntity> emps =
 * new ArrayList<>();
 * 
 * emps.add(new EmployeeEntity("Murphy", "Diane", "x5800",
 * "dmurphy@classicmodelcars.com", 0, "President", off.get(0)));
 * 
 * emps.add(new EmployeeEntity("Patterson", "Mary", "x4611",
 * "mpatterso@classicmodelcars.com", 1002, "VP Sales", off.get(0)));
 * 
 * emps.add(new EmployeeEntity("Firrelli", "Jeff", "x9273",
 * "jfirrelli@classicmodelcars.com", 1002, "VP Marketing", off.get(0)));
 * 
 * emps.add(new EmployeeEntity("Patterson", "William", "x4871",
 * "wpatterson@classicmodelcars.com", 1056, "Sales Manager (APAC)",
 * off.get(1)));
 * 
 * emps.add(new EmployeeEntity("Bondur", "Gerard", "x5408",
 * "gbondur@classicmodelcars.com", 1056, "Sale Manager (EMEA)", off.get(1)));
 * 
 * emps.add(new EmployeeEntity("Bow", "Anthony", "x5428",
 * "abow@classicmodelcars.com", 1056, "Sales Manager (NA)", off.get(1)));
 * 
 * emps.add(new EmployeeEntity("Jennings", "Leslie", "x3291",
 * "ljennings@classicmodelcars.com", 1143, "Sales Rep", off.get(2)));
 * 
 * emps.add(new EmployeeEntity("Thompson", "Leslie", "x4065",
 * "lthompson@classicmodelcars.com", 1143, "Sales Rep", off.get(2)));
 * 
 * emps.add(new EmployeeEntity("Firrelli", "Julie", "x2173",
 * "jfirrelli@classicmodelcars.com", 1143, "Sales Rep", off.get(2)));
 * 
 * emps.add(new EmployeeEntity("Patterson", "Steve", "x4334",
 * "spatterson@classicmodelcars.com", 1143, "Sales Rep", off.get(2)));
 * 
 * emps.add(new EmployeeEntity("Tseng", "Foon Yue", "x2248",
 * "ftseng@classicmodelcars.com", 1143, "Sales Rep", off.get(3)));
 * 
 * emps.add(new EmployeeEntity("Vanauf", "George", "x4102",
 * "gvanauf@classicmodelcars.com", 1143, "Sales Rep", off.get(3)));
 * 
 * emps.add(new EmployeeEntity("Bondur", "Loui", "x6493",
 * "lbondur@classicmodelcars.com", 1102, "Sales Rep", off.get(3)));
 * 
 * emps.add(new EmployeeEntity("Hernandez", "Gerard", "x2028",
 * "ghernande@classicmodelcars.com", 1102, "Sales Rep", off.get(3)));
 * 
 * emps.add(new EmployeeEntity("Castillo", "Pamela", "x2759",
 * "pcastillo@classicmodelcars.com", 1102, "Sales Rep", off.get(4)));
 * 
 * emps.add(new EmployeeEntity("Bott", "Larry", "x2311",
 * "lbott@classicmodelcars.com", 1102, "Sales Rep", off.get(4)));
 * 
 * emps.add(new EmployeeEntity("Jones", "Barry", "x102",
 * "bjones@classicmodelcars.com", 1102, "Sales Rep", off.get(4)));
 * 
 * emps.add(new EmployeeEntity("Fixter", "Andy", "x101",
 * "afixter@classicmodelcars.com", 1088, "Sales Rep", off.get(4)));
 * 
 * emps.add(new EmployeeEntity("Marsh", "Peter", "x102",
 * "pmarsh@classicmodelcars.com", 1088, "Sales Rep", off.get(5)));
 * 
 * emps.add( new EmployeeEntity("King", "Tom", "x103",
 * "tking@classicmodelcars.com", 1088, "Sales Rep", off.get(0)));
 * 
 * emps.add(new EmployeeEntity("Nishi", "Mami", "x101",
 * "mnishi@classicmodelcars.com", 1056, "Sales Rep", off.get(5)));
 * 
 * emps.add(new EmployeeEntity("Kato", "Yoshimi", "x102",
 * "ykato@classicmodelcars.com", 1621, "Sales Rep", off.get(6)));
 * 
 * emps.add(new EmployeeEntity("Gerard", "Martin", "x2312",
 * "mgerard@classicmodelcars.com", 1102, "Sales Rep", off.get(6)));
 * 
 * return null;
 * 
 * }
 * 
 * 
 * private static List<ProductEntity> productsLoader() { List<ProductEntity>
 * products = new ArrayList<>(); products.add(new ProductEntity("S10_1678",
 * "1969 Harley Davidson Ultimate Chopper", "Motorcycles", "1:10",
 * "Min Lin Diecast",
 * "This replica features working kickstand, front suspension, gear-shift lever, footbrake lever, drive chain, wheels and steering. All parts are particularly delicate due to their precise scale and require special care and attention."
 * , "7933", 48.81, 95.70));
 * 
 * products.add(new ProductEntity("S10_1949", "1952 Alpine Renault 1300",
 * "Classic Cars", "1:10", "Classic Metal Creations",
 * "Turnable front wheels; steering function; detailed interior; detailed engine; opening hood; opening trunk; opening doors; and detailed chassis."
 * , "7305", 98.58, 214.30));
 * 
 * products.add(new ProductEntity("S10_2016", "1996 Moto Guzzi 1100i",
 * "Motorcycles", "1:10", "Highway 66 Mini Classics",
 * "Official Moto Guzzi logos and insignias, saddle bags located on side of motorcycle, detailed engine, working steering, working suspension, two leather seats, luggage rack, dual exhaust pipes, small saddle bag located on handle bars, two-tone paint with chrome accents, superior die-cast detail , rotating wheels , working kick stand, diecast metal with plastic parts and baked enamel finish."
 * , "6625", 68.99, 118.94));
 * 
 * products.add(new Products("S10_4698", "2003 Harley-Davidson Eagle Drag Bike",
 * "Motorcycles", "1:10", "Red Start Diecast",
 * "Model features, official Harley Davidson logos and insignias, detachable rear wheelie bar, heavy diecast metal with resin parts, authentic multi-color tampo-printed graphics, separate engine drive belts, free-turning front fork, rotating tires and rear racing slick, certificate of authenticity, detailed engine, display stand\r\n, precision diecast replica, baked enamel finish, 1:10 scale model, removable fender, seat and tank cover piece for displaying the superior detail of the v-twin engine"
 * , "5582", 91.02, 193.66));
 * 
 * products.add(new Products("S10_4757", "1972 Alfa Romeo GTA", "Classic Cars",
 * "1:10", "Motor City Art Classics",
 * "Features include: Turnable front wheels; steering function; detailed interior; detailed engine; opening hood; opening trunk; opening doors; and detailed chassis."
 * , "3252", 85.68, 136.00));
 * 
 * products.add(new Products("S10_4962", "1962 LanciaA Delta 16V",
 * "Classic Cars", "1:10", "Second Gear Diecast",
 * "Features include: Turnable front wheels; steering function; detailed interior; detailed engine; opening hood; opening trunk; opening doors; and detailed chassis."
 * , "6791", 103.42, 147.74));
 * 
 * products.add(new Products("S12_1099", "1968 Ford Mustang", "Classic Cars",
 * "1:12", "Autoart Studio Design",
 * "Hood, doors and trunk all open to reveal highly detailed interior features. Steering wheel actually turns the front wheels. Color dark green."
 * , "68", 95.34, 194.57));
 * 
 * products.add(new Products("S12_1108", "2001 Ferrari Enzo", "Classic Cars",
 * "1:12", "Second Gear Diecast",
 * "Turnable front wheels; steering function; detailed interior; detailed engine; opening hood; opening trunk; opening doors; and detailed chassis."
 * , "3619", 95.59, 207.80));
 * 
 * products.add(new Products("S72_3212", "Pont Yacht", "Ships", "1:72",
 * "Unimax Art Galleries",
 * "Measures 38 inches Long x 33 3/4 inches High. Includes a stand.\r\nMany extras including rigging, long boats, pilot house, anchors, etc. Comes with 2 masts, all square-rigged"
 * , "414", 33.30, 54.60)); return products;
 * 
 * // }
 * 
 * }
 */