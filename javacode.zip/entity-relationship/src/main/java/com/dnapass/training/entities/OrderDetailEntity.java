package com.dnapass.training.entities;

import java.io.Serializable;
import java.util.Objects;

import javax.persistence.CascadeType;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.JoinColumn;
import javax.persistence.MapsId;
import javax.persistence.OneToOne;

@Entity(name = "OrderDetails")
@IdClass(ProductOrderKey.class)
public class OrderDetailEntity implements Serializable {

	private static final long serialVersionUID = 1L;

	// @EmbeddedId
	// private ProductOrderKey productOrderKey;
	@Id
	@GeneratedValue
	private Integer orderNumber;
	@Id
	@GeneratedValue
	private Long productCode;
	private Integer quantityOrdered;
	private Double priceEach;

	private Integer orderLineNumber;

	// @MapsId("productCodePk")
	@OneToOne(cascade = CascadeType.ALL)
	// @JoinColumn(name = "product_Code")
	private ProductEntity products;

	// @MapsId("orderNumberPk")

	@OneToOne(cascade = CascadeType.ALL)
	// @JoinColumn(name = "order_Number")
	private OrderEntity orders;

	public OrderDetailEntity() {
		super();
	}

	public OrderDetailEntity(Integer orderNumber, Long productCode, Integer quantityOrdered, Double priceEach,
			Integer orderLineNumber, ProductEntity products, OrderEntity orders) {
		super();
		this.orderNumber = orderNumber;
		this.productCode = productCode;
		this.quantityOrdered = quantityOrdered;
		this.priceEach = priceEach;
		this.orderLineNumber = orderLineNumber;
		this.products = products;
		this.orders = orders;
	}

	public Integer getOrderNumber() {
		return orderNumber;
	}

	public void setOrderNumber(Integer orderNumber) {
		this.orderNumber = orderNumber;
	}

	public Long getProductCode() {
		return productCode;
	}

	public void setProductCode(Long productCode) {
		this.productCode = productCode;
	}

	public Integer getQuantityOrdered() {
		return quantityOrdered;
	}

	public void setQuantityOrdered(Integer quantityOrdered) {
		this.quantityOrdered = quantityOrdered;
	}

	public Double getPriceEach() {
		return priceEach;
	}

	public void setPriceEach(Double priceEach) {
		this.priceEach = priceEach;
	}

	public Integer getOrderLineNumber() {
		return orderLineNumber;
	}

	public void setOrderLineNumber(Integer orderLineNumber) {
		this.orderLineNumber = orderLineNumber;
	}

	public ProductEntity getProducts() {
		return products;
	}

	public void setProducts(ProductEntity products) {
		this.products = products;
	}

	public OrderEntity getOrders() {
		return orders;
	}

	public void setOrders(OrderEntity orders) {
		this.orders = orders;
	}

	@Override
	public int hashCode() {
		return Objects.hash(orderLineNumber, orderNumber, orders, priceEach, productCode, products, quantityOrdered);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		OrderDetailEntity other = (OrderDetailEntity) obj;
		return Objects.equals(orderLineNumber, other.orderLineNumber) && Objects.equals(orderNumber, other.orderNumber)
				&& Objects.equals(orders, other.orders) && Objects.equals(priceEach, other.priceEach)
				&& Objects.equals(productCode, other.productCode) && Objects.equals(products, other.products)
				&& Objects.equals(quantityOrdered, other.quantityOrdered);
	}

	@Override
	public String toString() {
		return "\nOrderDetailEntity [orderNumber=" + orderNumber + ", productCode=" + productCode + ", quantityOrdered="
				+ quantityOrdered + ", priceEach=" + priceEach + ", orderLineNumber=" + orderLineNumber + ", products="
				+ products + ", orders=" + orders + "]";
	}

}
