
package com.dnapass.training.entities;

import java.io.Serializable;
import java.util.Objects;

import javax.persistence.Embeddable;

//@Embeddable
public class ProductOrderKey implements Serializable {

	/**
	* 
	*/
	private static final long serialVersionUID = 1L;
	private Integer orderNumber;
	private Long productCode;

	public ProductOrderKey() {
		super();
	}

	public ProductOrderKey(Integer orderNumber, Long productCode) {
		super();
		this.orderNumber = orderNumber;
		this.productCode = productCode;
	}

	public Integer getOrderNumber() {
		return orderNumber;
	}

	public void setOrderNumber(Integer orderNumber) {
		this.orderNumber = orderNumber;
	}

	public Long getProductCode() {
		return productCode;
	}

	public void setProductCode(Long productCode) {
		this.productCode = productCode;
	}

	@Override
	public int hashCode() {
		return Objects.hash(orderNumber, productCode);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ProductOrderKey other = (ProductOrderKey) obj;
		return Objects.equals(orderNumber, other.orderNumber) && Objects.equals(productCode, other.productCode);
	}

	@Override
	public String toString() {
		return "ProductOrderKey [orderNumber=" + orderNumber + ", productCode=" + productCode + "]";
	}

}
