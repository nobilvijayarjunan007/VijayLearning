package com.dnapass.training.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dnapass.training.entities.EmployeeEntity;
import com.dnapass.training.entities.OfficeEntity;
import com.dnapass.training.repo.EmployeeRepo;

@Service
public class EmployeeService {

	@Autowired
	private EmployeeRepo empRepo;

	public void createAll(List<EmployeeEntity> empsDetails) {

		empRepo.saveAll(empsDetails);

	}

}
