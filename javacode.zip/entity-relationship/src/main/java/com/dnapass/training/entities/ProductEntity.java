package com.dnapass.training.entities;

import java.io.Serializable;
import java.util.Objects;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.MapsId;
import javax.persistence.OneToOne;

@Entity(name = "Products")
public class ProductEntity implements Serializable {

	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long productCode;
	private String productName;

	private String productScale;
	private String productVendor;
	private String productDescription;
	private String quantityInStock;
	private Double buyPrice;
	private Double MSRP;
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "product_Line")
	private ProductLineEntity productLines;

	@OneToOne(mappedBy = "products", cascade = CascadeType.ALL, orphanRemoval = true)
	private OrderDetailEntity orderDetails;

	public ProductEntity() {
		super();
	}

	public ProductEntity(Long productCode, String productName, String productScale, String productVendor,
			String productDescription, String quantityInStock, Double buyPrice, Double mSRP,
			ProductLineEntity productLines, OrderDetailEntity orderDetails) {
		super();
		this.productCode = productCode;
		this.productName = productName;
		this.productScale = productScale;
		this.productVendor = productVendor;
		this.productDescription = productDescription;
		this.quantityInStock = quantityInStock;
		this.buyPrice = buyPrice;
		MSRP = mSRP;
		this.productLines = productLines;
		this.orderDetails = orderDetails;
	}

	@Override
	public int hashCode() {
		return Objects.hash(MSRP, buyPrice, orderDetails, productCode, productDescription, productLines, productName,
				productScale, productVendor, quantityInStock);
	}

	public Long getProductCode() {
		return productCode;
	}

	public void setProductCode(Long productCode) {
		this.productCode = productCode;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getProductScale() {
		return productScale;
	}

	public void setProductScale(String productScale) {
		this.productScale = productScale;
	}

	public String getProductVendor() {
		return productVendor;
	}

	public void setProductVendor(String productVendor) {
		this.productVendor = productVendor;
	}

	public String getProductDescription() {
		return productDescription;
	}

	public void setProductDescription(String productDescription) {
		this.productDescription = productDescription;
	}

	public String getQuantityInStock() {
		return quantityInStock;
	}

	public void setQuantityInStock(String quantityInStock) {
		this.quantityInStock = quantityInStock;
	}

	public Double getBuyPrice() {
		return buyPrice;
	}

	public void setBuyPrice(Double buyPrice) {
		this.buyPrice = buyPrice;
	}

	public Double getMSRP() {
		return MSRP;
	}

	public void setMSRP(Double mSRP) {
		MSRP = mSRP;
	}

	public ProductLineEntity getProductLines() {
		return productLines;
	}

	public void setProductLines(ProductLineEntity productLines) {
		this.productLines = productLines;
	}

	public OrderDetailEntity getOrderDetails() {
		return orderDetails;
	}

	public void setOrderDetails(OrderDetailEntity orderDetails) {
		this.orderDetails = orderDetails;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ProductEntity other = (ProductEntity) obj;
		return Objects.equals(MSRP, other.MSRP) && Objects.equals(buyPrice, other.buyPrice)
				&& Objects.equals(orderDetails, other.orderDetails) && Objects.equals(productCode, other.productCode)
				&& Objects.equals(productDescription, other.productDescription)
				&& Objects.equals(productLines, other.productLines) && Objects.equals(productName, other.productName)
				&& Objects.equals(productScale, other.productScale)
				&& Objects.equals(productVendor, other.productVendor)
				&& Objects.equals(quantityInStock, other.quantityInStock);
	}

	@Override
	public String toString() {
		return "\nProductEntity [productCode=" + productCode + ", productName=" + productName + ", productScale="
				+ productScale + ", productVendor=" + productVendor + ", productDescription=" + productDescription
				+ ", quantityInStock=" + quantityInStock + ", buyPrice=" + buyPrice + ", MSRP=" + MSRP
				+ ", productLines=" + productLines + ", orderDetails=" + orderDetails + "]";
	}

	

}
