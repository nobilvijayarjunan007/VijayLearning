package com.dnapass.training.entities;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

@Entity(name = "Employees")
public class EmployeeEntity implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)

	private Long employeeNumber;
	private String lastName;
	private String firstName;
	private String extension;
	private String email;
	@OneToOne(cascade = CascadeType.ALL)
	private EmployeeEntity manager;
	// private Long reportsTo;
	private String jobTitle;
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "office_code")
	private OfficeEntity offices;

	@OneToMany(mappedBy = "employee", cascade = CascadeType.ALL, orphanRemoval = true) //

	private List<CustomerEntity> customers = new ArrayList<>();

	public EmployeeEntity() {
		super();
	}

	public EmployeeEntity(Long employeeNumber, String lastName, String firstName, String extension, String email,
			EmployeeEntity manager, String jobTitle, OfficeEntity offices, List<CustomerEntity> customers) {
		super();
		this.employeeNumber = employeeNumber;
		this.lastName = lastName;
		this.firstName = firstName;
		this.extension = extension;
		this.email = email;
		this.manager = manager;
		this.jobTitle = jobTitle;
		this.offices = offices;
		this.customers = customers;
	}

	public Long getEmployeeNumber() {
		return employeeNumber;
	}

	public void setEmployeeNumber(Long employeeNumber) {
		this.employeeNumber = employeeNumber;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getExtension() {
		return extension;
	}

	public void setExtension(String extension) {
		this.extension = extension;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public EmployeeEntity getManager() {
		return manager;
	}

	public void setManager(EmployeeEntity manager) {
		this.manager = manager;
	}

	public String getJobTitle() {
		return jobTitle;
	}

	public void setJobTitle(String jobTitle) {
		this.jobTitle = jobTitle;
	}

	public OfficeEntity getOffices() {
		return offices;
	}

	public void setOffices(OfficeEntity offices) {
		this.offices = offices;
	}

	public List<CustomerEntity> getCustomers() {
		return customers;
	}

	public void setCustomers(List<CustomerEntity> customers) {
		this.customers = customers;
	}

	@Override
	public int hashCode() {
		return Objects.hash(customers, email, employeeNumber, extension, firstName, jobTitle, lastName, manager,
				offices);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		EmployeeEntity other = (EmployeeEntity) obj;
		return Objects.equals(customers, other.customers) && Objects.equals(email, other.email)
				&& Objects.equals(employeeNumber, other.employeeNumber) && Objects.equals(extension, other.extension)
				&& Objects.equals(firstName, other.firstName) && Objects.equals(jobTitle, other.jobTitle)
				&& Objects.equals(lastName, other.lastName) && Objects.equals(manager, other.manager)
				&& Objects.equals(offices, other.offices);
	}

	@Override
	public String toString() {
		return "\nEmployeeEntity [employeeNumber=" + employeeNumber + ", lastName=" + lastName + ", firstName="
				+ firstName + ", extension=" + extension + ", email=" + email + ", manager=" + manager + ", jobTitle="
				+ jobTitle + ", offices=" + offices + ", customers=" + customers + "]";
	}

}
