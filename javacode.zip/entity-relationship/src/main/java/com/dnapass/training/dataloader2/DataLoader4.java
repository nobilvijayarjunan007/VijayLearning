package com.dnapass.training.dataloader2;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;

import com.dnapass.training.entities.CustomerEntity;
import com.dnapass.training.entities.EmployeeEntity;
import com.dnapass.training.entities.OfficeEntity;
import com.dnapass.training.entities.OrderDetailEntity;
import com.dnapass.training.entities.OrderEntity;
import com.dnapass.training.entities.PaymentEntity;
import com.dnapass.training.entities.ProductEntity;
import com.dnapass.training.entities.ProductLineEntity;
import com.dnapass.training.models.Customer;
import com.dnapass.training.models.OrderDetails;
import com.dnapass.training.models.Orders;
import com.dnapass.training.models.Payment;
import com.dnapass.training.models.ProductLine;
import com.dnapass.training.models.Products;

public class DataLoader4 {

	public static List<OfficeEntity> officeDetailsLoader() {
		List<OfficeEntity> offices = new ArrayList<>();
		offices.add(new OfficeEntity("office1", "San Francisco", "+1 650 219 4782", "100 Market Street", "Suite 300", "CA",
				"USA", "94080", "NA", null));

		offices.add(new OfficeEntity("office2", "Boston", "+1 215 837 0825", "1550 Court Place", "Suite 102", "MA", "USA",
				"02107", "NA", null));

		offices.add(new OfficeEntity("office3", "NYC", "+1 212 555 3000", "523 East 53rd Street", "apt. 5A", "NY", "USA",
				"10022", "NA", null));

		offices.add(new OfficeEntity("office4", "Paris", "+33 14 723 4404", "43 Rue Jouffroy D\"abbans", null, null,
				"France", "75017", "EMEA", null));

		offices.add(new OfficeEntity("off5", "Tokyo", "+81 33 224 5000", "4-1 Kioicho", null, "Chiyoda-Ku", "Japan",
				"102-8578", "Japan", null));

		offices.add(new OfficeEntity("off6", "Sydney", "+61 2 9264 2451", "5-11 Wentworth Avenue", "Floor #2", null,
				"Australia", "NSW 2010", "APAC", null));

		offices.add(new OfficeEntity("off7", "London", "+44 20 7877 2041", "25 Old Broad Street", "Level 7", null, "UK",
				"EC2N 1HN", "EMEA", null));

		return offices;
	}

	public static List<EmployeeEntity> employeesLoader() {
		List<EmployeeEntity> emps = new ArrayList<>();

		emps.add(new EmployeeEntity(null, "Murphy", "Diane", "x5800", "dmurphy@classicmodelcars.com", null, "President",
				null, null));

		emps.add(new EmployeeEntity(null, "Patterson", "Mary", "x4611", "mpatterso@classicmodelcars.com", null,
				"VP Sales", null, null));

		emps.add(new EmployeeEntity(null, "Firrelli", "Jeff", "x9273", "jfirrelli@classicmodelcars.com", null,
				"VP Marketing", null, null));

		emps.add(new EmployeeEntity(null, "Patterson", "William", "x4871", "wpatterson@classicmodelcars.com", null,
				"Sales Manager (APAC)", null, null));

		emps.add(new EmployeeEntity(null, "Bondur", "Gerard", "x5408", "gbondur@classicmodelcars.com", null,
				"Sale Manager (EMEA)", null, null));

		emps.add(new EmployeeEntity(null, "Bow", "Anthony", "x5428", "abow@classicmodelcars.com", null,
				"Sales Manager (NA)", null, null));

		emps.add(new EmployeeEntity(null, "Jennings", "Leslie", "x3291", "ljennings@classicmodelcars.com", null,
				"Sales Rep", null, null));

		emps.add(new EmployeeEntity(null, "Thompson", "Leslie", "x4065", "lthompson@classicmodelcars.com", null,
				"Sales Rep", null, null));

		emps.add(new EmployeeEntity(null, "Firrelli", "Julie", "x2173", "jfirrelli@classicmodelcars.com", null,
				"Sales Rep", null, null));

		emps.add(new EmployeeEntity(null, "Patterson", "Steve", "x4334", "spatterson@classicmodelcars.com", null,
				"Sales Rep", null, null));

		emps.add(new EmployeeEntity(null, "Tseng", "Foon Yue", "x2248", "ftseng@classicmodelcars.com", null,
				"Sales Rep", null, null));

		emps.add(new EmployeeEntity(null, "Vanauf", "George", "x4102", "gvanauf@classicmodelcars.com", null,
				"Sales Rep", null, null));

		emps.add(new EmployeeEntity(null, "Bondur", "Loui", "x6493", "lbondur@classicmodelcars.com", null, "Sales Rep",
				null, null));

		emps.add(new EmployeeEntity(null, "Hernandez", "Gerard", "x2028", "ghernande@classicmodelcars.com", null,
				"Sales Rep", null, null));

		emps.add(new EmployeeEntity(null, "Castillo", "Pamela", "x2759", "pcastillo@classicmodelcars.com", null,
				"Sales Rep", null, null));

		emps.add(new EmployeeEntity(null, "Bott", "Larry", "x2311", "lbott@classicmodelcars.com", null, "Sales Rep",
				null, null));

		emps.add(new EmployeeEntity(null, "Jones", "Barry", "x102", "bjones@classicmodelcars.com", null, "Sales Rep",
				null, null));

		emps.add(new EmployeeEntity(null, "Fixter", "Andy", "x101", "afixter@classicmodelcars.com", null, "Sales Rep",
				null, null));

		emps.add(new EmployeeEntity(null, "Marsh", "Peter", "x102", "pmarsh@classicmodelcars.com", null, "Sales Rep",
				null, null));

		emps.add(new EmployeeEntity(null, "King", "Tom", "x103", "tking@classicmodelcars.com", null, "Sales Rep", null,
				null));

		emps.add(new EmployeeEntity(null, "Nishi", "Mami", "x101", "mnishi@classicmodelcars.com", null, "Sales Rep",
				null, null));

		emps.add(new EmployeeEntity(null, "Kato", "Yoshimi", "x102", "ykato@classicmodelcars.com", null, "Sales Rep",
				null, null));

		emps.add(new EmployeeEntity(null, "Gerard", "Martin", "x2312", "mgerard@classicmodelcars.com", null,
				"Sales Rep", null, null));

		return emps;
	}

	public static List<CustomerEntity> customersLoader() {
		List<CustomerEntity> customers = new ArrayList<>();

		customers.add(new CustomerEntity(null, "Atelier graphique", "Schmitt", "Carine ", "40.32.2555",
				"54, rue Royale", null, "Nantes", null, "44000", "France", "21000.00", null, null, null));

		customers.add(new CustomerEntity(null, "Signal Gift Stores", "King", "Jean", "7025551838", "8489 Strong St.",
				null, "Las Vegas", "NV", "83030", "USA", "71800.00", null, null, null));

		customers.add(new CustomerEntity(null, "Australian Collectors, Co.", "Ferguson", "Peter", "03 9520 4555",
				"636 St Kilda Road", "Level 3", "Melbourne", "Victoria", "3004", "Australia", "117300.00", null, null,
				null));

		customers.add(new CustomerEntity(null, "La Rochelle Gifts", "Labrune", "Janine ", "40.67.8555",
				"67, rue des Cinquante Otages", null, "Nantes", null, "44000", "France", "118200.00", null, null,
				null));

		customers.add(new CustomerEntity(null, "Kelly\"s Gift Shop", "Snowden", "Tony", "+64 9 5555500",
				"Arenales 1938 3\"A\"", null, "Auckland  ", null, null, "New Zealand", "110000.00", null, null, null));
		return customers;
	}

	public static List<OrderEntity> ordersLoader() {

		List<OrderEntity> orders = new ArrayList<>();
		orders.add(new OrderEntity(null, "2003-01-06", "2003-01-13", "2003-01-10", "Shipped", null, null, null));

		orders.add(new OrderEntity(null, "2003-01-09", "2003-01-18", "2003-01-11", "Shipped", "Check on availability.",
				null, null));

		orders.add(new OrderEntity(null, "2003-01-10", "2003-01-18", "2003-01-14", "Shipped", null, null, null));

		orders.add(new OrderEntity(null, "2003-01-29", "2003-02-07", "2003-02-02", "Shipped", null, null, null));
		orders.add(new OrderEntity(null, "2003-01-31", "2003-02-09", "2003-02-01", "Shipped", null, null, null));

		orders.add(new OrderEntity(null, "2003-02-11", "2003-02-21", "2003-02-12", "Shipped", null, null, null));

		orders.add(new OrderEntity(null, "2003-02-17", "2003-02-24", "2003-02-21", "Shipped", null, null, null));

		orders.add(new OrderEntity(null, "2003-02-24", "2003-03-03", "2003-02-26", "Shipped",
				"Difficult to negotiate with customer. We need more marketing materials", null, null));

		orders.add(new OrderEntity(null, "2003-03-03", "2003-03-12", "2003-03-08", "Shipped", null, null, null));

		return orders;
	}

	public static List<PaymentEntity> paymentLoader() {

		List<PaymentEntity> payments = new ArrayList<>();
		payments.add(new PaymentEntity(null, null, "2004-10-19", 6066, null));
		payments.add(new PaymentEntity(null, null, "2003-06-05", 14571, null));
		payments.add(new PaymentEntity(null, null, "2004-12-18", 1676, null));
		payments.add(new PaymentEntity(null, null, "2004-12-17", 14191, null));
		payments.add(new PaymentEntity(null, null, "2003-06-06", 32641, null));
		payments.add(new PaymentEntity(null, null, "2004-08-20", 33347, null));
		payments.add(new PaymentEntity(null, null, "2003-05-20", 45864, null));
		payments.add(new PaymentEntity(null, null, "2004-12-15", 82261, null));
		payments.add(new PaymentEntity(null, null, "2003-05-31", 7565, null));
		payments.add(new PaymentEntity(null, null, "2004-03-10", 44894, null));
		payments.add(new PaymentEntity(null, null, "2004-12-31", 52166, null));

		return payments;

	}

	public static List<ProductLineEntity> productsLinesLoader() {
		List<ProductLineEntity> productLines = new ArrayList<>();

		productLines.add(new ProductLineEntity("Classic Cars",
				"Attention car enthusiasts: Make your wildest car ownership dreams come true. ",
				null, null, null));

		productLines.add(new ProductLineEntity("Motorcycles",
				"Our motorcycles are state of the art replicas of classic as well as contemporary motorcycle legends such as Harley Davidson, Ducati and Vespa. Models contain stunning details such as official logos, rotating wheels, working kickstand, front suspension, gear-shift lever, footbrake lever, and drive chain. Materials used include diecast and plastic. The models range in size from 1:10 to 1:50 scale and include numerous limited edition and several out-of-production vehicles. All models come fully assembled and ready for display in the home or office. Most include a certificate of authenticity.",
				null, null, null));

		productLines.add(new ProductLineEntity("Planes",
				"Unique, diecast airplane and helicopter replicas suitable for collections, as well as home, office or classroom decorations. Models contain stunning details such as official logos and insignias, rotating jet engines and propellers, retractable wheels, and so on. Most come fully assembled and with a certificate of authenticity from their manufacturers.",
				null, null, null));

		productLines.add(new ProductLineEntity("Ships",
				"The perfect holiday or anniversary gift for executives, clients, friends, and family. These handcrafted model ships are unique, stunning works of art that will be treasured for generations! They come fully assembled and ready for display in the home or office. We guarantee the highest quality, and best value.",
				null, null, null));

		productLines.add(new ProductLineEntity("Trains",
				"Model trains are a rewarding hobby for enthusiasts of all ages. Whether you\"re looking for collectible wooden trains, electric streetcars or locomotives, you\"ll find a number of great choices for any budget within this category. The interactive aspect of trains makes toy trains perfect for young children. The wooden train sets are ideal for children under the age of 5.",
				null, null, null));

		productLines.add(new ProductLineEntity("Trucks and Buses",
				"The Truck and Bus models are realistic replicas of buses and specialized trucks produced from the early 1920s to present. The models range in size from 1:12 to 1:50 scale and include numerous limited edition and several out-of-production vehicles. Materials used include tin, diecast and plastic. All models include a certificate of authenticity from their manufacturers and are a perfect ornament for the home and office.",
				null, null, null));

		productLines.add(new ProductLineEntity("Vintage Cars",
				"Our Vintage Car models realistically portray automobiles produced from the early 1900s through the 1940s. Materials used include Bakelite, diecast, plastic and wood. Most of the replicas are in the 1:18 and 1:24 scale sizes, which provide the optimum in detail and accuracy. Prices range from $30.00 up to $180.00 for some special limited edition replicas. All models include a certificate of authenticity from their manufacturers and come fully assembled and ready for display in the home or office.",
				null, null, null));
		return productLines;

	}

	public static List<ProductEntity> productsLoader() {
		List<ProductEntity> products = new ArrayList<>();

		products.add(new ProductEntity(null, "1969 Harley Davidson Ultimate Chopper", "1:10", "Min Lin Diecast",
				"This replica features working kickstand, front suspension, gear-shift lever, footbrake lever, drive chain, wheels and steering. All parts are particularly delicate due to their precise scale and require special care and attention.",
				"7933", 48.81, 95.70, null, null));

		products.add(new ProductEntity(null, "1952 Alpine Renault 1300", "1:10", "Classic Metal Creations",
				"Turnable front wheels; steering function; detailed interior; detailed engine; opening hood; opening trunk; opening doors; and detailed chassis.",
				"7305", 98.58, 214.30, null, null));

		products.add(new ProductEntity(null, "1996 Moto Guzzi 1100i", "1:10", "Highway 66 Mini Classics",
				"Official Moto Guzzi logos and insignias, saddle bags located on side of motorcycle, detailed engine, working steering, working suspension, two leather seats, luggage rack, dual exhaust pipes, small saddle bag located on handle bars, two-tone paint with chrome accents, superior die-cast detail , rotating wheels , working kick stand, diecast metal with plastic parts and baked enamel finish.",
				"6625", 68.99, 118.94, null, null));

		products.add(new ProductEntity(null, "2003 Harley-Davidson Eagle Drag Bike", "1:10", "Red Start Diecast",
				"Model features, official Harley Davidson logos and insignias, detachable rear wheelie bar, heavy diecast metal with resin parts, authentic multi-color tampo-printed graphics, separate engine drive belts, free-turning front fork, rotating tires and rear racing slick, certificate of authenticity, detailed engine, display stand\r\n, precision diecast replica, baked enamel finish, 1:10 scale model, removable fender, seat and tank cover piece for displaying the superior detail of the v-twin engine",
				"5582", 91.02, 193.66, null, null));

		products.add(new ProductEntity(null, "1972 Alfa Romeo GTA", "1:10", "Motor City Art Classics",
				"Features include: Turnable front wheels; steering function; detailed interior; detailed engine; opening hood; opening trunk; opening doors; and detailed chassis.",
				"3252", 85.68, 136.00, null, null));

		products.add(new ProductEntity(null, "1962 LanciaA Delta 16V", "1:10", "Second Gear Diecast",
				"Features include: Turnable front wheels; steering function; detailed interior; detailed engine; opening hood; opening trunk; opening doors; and detailed chassis.",
				"6791", 103.42, 147.74, null, null));

		products.add(new ProductEntity(null, "1968 Ford Mustang", "1:12", "Autoart Studio Design",
				"Hood, doors and trunk all open to reveal highly detailed interior features. Steering wheel actually turns the front wheels. Color dark green.",
				"68", 95.34, 194.57, null, null));

		products.add(new ProductEntity(null, "2001 Ferrari Enzo", "1:12", "Second Gear Diecast",
				"Turnable front wheels; steering function; detailed interior; detailed engine; opening hood; opening trunk; opening doors; and detailed chassis.",
				"3619", 95.59, 207.80, null, null));

		products.add(new ProductEntity(null, "Pont Yacht", "1:72", "Unimax Art Galleries",
				"Measures 38 inches Long x 33 3/4 inches High. Includes a stand.\r\nMany extras including rigging, long boats, pilot house, anchors, etc. Comes with 2 masts, all square-rigged",
				"414", 33.30, 54.60, null, null));
		return products;

	}

	public static List<OrderDetailEntity> orderDetailsLoader() {
		List<OrderDetailEntity> orderDetails = new ArrayList<>();

		orderDetails.add(new OrderDetailEntity(null, null, 30, 136.00, 3, null, null));

		orderDetails.add(new OrderDetailEntity(null, null, 50, 55.09, 2, null, null));

		orderDetails.add(new OrderDetailEntity(null, null, 22, 75.46, 4, null, null));

		orderDetails.add(new OrderDetailEntity(null, null, 49, 35.29, 1, null, null));

		orderDetails.add(new OrderDetailEntity(null, null, 25, 108.06, 4, null, null));

		orderDetails.add(new OrderDetailEntity(null, null, 26, 167.06, 1, null, null));

		orderDetails.add(new OrderDetailEntity(null, null, 45, 32.53, 3, null, null));

		orderDetails.add(new OrderDetailEntity(null, null, 46, 44.35, 2, null, null));

		orderDetails.add(new OrderDetailEntity(null, null, 39, 95.55, 2, null, null));

		orderDetails.add(new OrderDetailEntity(null, null, 18, 94.92, 2, null, null));

		return orderDetails;

	}
}
