
package com.dnapass.training.entities;

import java.io.Serializable;
import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Embeddable;

//@Embeddable
public class CustomerPaymentKey implements Serializable {

	private static final long serialVersionUID = 1L;

	private Integer customerNumber;

	private Long checkNumber;

	public CustomerPaymentKey() {
		super();
	}

	public CustomerPaymentKey(Integer customerNumber, Long checkNumber) {
		super();
		this.customerNumber = customerNumber;
		this.checkNumber = checkNumber;
	}

	public Integer getCustomerNumber() {
		return customerNumber;
	}

	public void setCustomerNumber(Integer customerNumber) {
		this.customerNumber = customerNumber;
	}

	public Long getCheckNumber() {
		return checkNumber;
	}

	public void setCheckNumber(Long checkNumber) {
		this.checkNumber = checkNumber;
	}

	@Override
	public int hashCode() {
		return Objects.hash(checkNumber, customerNumber);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CustomerPaymentKey other = (CustomerPaymentKey) obj;
		return Objects.equals(checkNumber, other.checkNumber) && Objects.equals(customerNumber, other.customerNumber);
	}

	@Override
	public String toString() {
		return "CustomerPaymentKey [customerNumber=" + customerNumber + ", checkNumber=" + checkNumber + "]";
	}

}
