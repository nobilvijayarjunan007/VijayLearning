package com.dnapass.training.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.dnapass.training.entity.PlayerEntity;
import com.dnapass.training.entity.TeamEntity;

@Repository
public interface TeamRepo extends JpaRepository<TeamEntity, Long> {

	@Query("select t from Team t")
	public List<TeamEntity> getAllTeam();

	@Query("SELECT t FROM Team t WHERE t.name=:name")
	public List<TeamEntity> findTeamByNameJPQL(@Param(value = "name") String name);

	@Query("SELECT t FROM Team t WHERE t.city=:cityname")
	public List<TeamEntity> findTeamByCityJPQL(@Param(value = "cityname") String city);

	@Query("SELECT t FROM Team t WHERE t.name=:teamname AND t.city=:cityname")
	public List<TeamEntity> findTeamByNameAndCityJPQL(@Param(value = "teamname") String name,
			@Param(value = "cityname") String city);

	@Query("SELECT t FROM Team t WHERE t.name=:teamname OR t.city=:cityname")
	public List<TeamEntity> findTeamByNameOrCityJPQL(@Param(value = "teamname") String name,
			@Param(value = "cityname") String city);

	@Query("SELECT t FROM Team t WHERE t.city IN (city)")
	public List<TeamEntity> findTeamInCity(@Param(value = "city") String city);

	@Query("SELECT t FROM Team t WHERE t.city NOT IN (city)")
	public List<TeamEntity> findTeamNotInCity(@Param(value = "city") String city);

	@Query("SELECT MAX(id) FROM Team t")
	public Long findMaxId();

	@Query("SELECT MIN(id) FROM Team t")
	public Long findMinId();

	@Query("SELECT t FROM Team t WHERE t.id=(SELECT MAX(id) FROM Team t)")
	public TeamEntity findMaxIdTeam();
	
	@Query("SELECT t FROM Team t WHERE t.id=(SELECT MIN(id) FROM Team t)")
	public TeamEntity findMinIdTeam();

	// Auto query

	public List<TeamEntity> findTeamByName(String name);

	public List<TeamEntity> findTeamByCity(String city);

	public List<TeamEntity> findTeamByNameAndCity(String name, String city);

	public List<TeamEntity> findTeamByNameOrCity(String name, String city);

	

}
