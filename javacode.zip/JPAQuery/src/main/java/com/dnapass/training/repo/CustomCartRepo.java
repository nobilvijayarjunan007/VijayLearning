package com.dnapass.training.repo;

import org.springframework.stereotype.Repository;

import com.dnapass.training.entity.CartEntity;

@Repository
public interface CustomCartRepo {

	public CartEntity findByJPQL(Long id);

}
