
package com.dnapass.training.repo;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.dnapass.training.entity.TeamEntity;

@Repository
public interface CustomTeamRepo {
	
	
	 public TeamEntity findByJPQL5(Long id);

	
}
