package com.dnapass.training.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.dnapass.training.entity.LeagueEntity;

@Repository
public interface LeagueRepo extends JpaRepository<LeagueEntity, Long> {

	@Query("select l from League l")
	public List<LeagueEntity> getAllLeague();

	@Query("select l from League l where l.name=:name")
	public List<LeagueEntity> getByNameJPQL(String name);

	@Query("select l from League l where l.dType=:dType")
	public List<LeagueEntity> getByDTypeJPQL(@Param(value = "dType") String dType);

	@Query("select l from League l where l.sport=:sport")
	public List<LeagueEntity> getBySportJPQL(String sport);

	// >> default Automatic query

	public List<LeagueEntity> getByName(String name);

	public List<LeagueEntity> getBydType(String dType);

	public List<LeagueEntity> getBySport(String sport);

}
