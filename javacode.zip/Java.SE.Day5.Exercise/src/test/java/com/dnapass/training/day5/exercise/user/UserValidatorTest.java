package com.dnapass.training.day5.exercise.user;

import org.junit.Assert;
import org.junit.Test;

public class UserValidatorTest {

	UserEntity user = new UserEntity();
	@Test
	public void test1() {
		
		Assert.assertEquals("VijayArjunan",EntityDataLoader.newUserEntity().getName());
		
		
	}
	@Test
	public void test2() {
		
		user.setName("VIJAY ARJUNAN");
		
		Assert.assertEquals("VIJAY ARJUNAN",user.getName());
		
		
	}
	
	@Test
	public void test3() {
		
		user.setId(421215114089L);;
		
		Assert.assertEquals(421215114089L,user.getId(),0.0);
		
		
	}
}
