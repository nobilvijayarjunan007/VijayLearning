package com.dnapass.training.user.test.suite.day5;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

import com.dnapass.training.day5.exercise.contact.ContactValidatorTest;
import com.dnapass.training.day5.exercise.contact.ContactValidatorTest2;
import com.dnapass.training.day5.exercise.sample.ArraySamplesTest;
import com.dnapass.training.day5.exercise.user.UserValidatorTest;
import com.dnapass.training.day5.user.UserValidator1Test;
import com.dnapass.training.day5.user.UserValidator1Test2;

@RunWith(Suite.class)
@Suite.SuiteClasses({ContactValidatorTest.class,ContactValidatorTest2.class,ArraySamplesTest.class,UserValidatorTest.class,UserValidator1Test.class,UserValidator1Test2.class})
public class TestSuiteDay5 {

}
