package com.dnapass.training.day5.user;

import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;

import junit.framework.Assert;

public class UserValidator1Test {

	
	@SuppressWarnings("deprecation")
	@Rule
	public ExpectedException exceptionRule = ExpectedException.none();
	
	@Test
	public void ifNameIsNull_NameValidationFail()  throws ApplicationException{
		
		exceptionRule.expectMessage("Name should not be null");
		exceptionRule.expect(ApplicationException.class);
		
		UserValidator1.validateName(null);
	}
	
	//>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>...
	
	
	@SuppressWarnings("deprecation")
	@Rule
	public ExpectedException exceptionRule2 = ExpectedException.none();
	@Test
	public void ifNameIsNull_ageValidationFail()  throws ApplicationException{
		
		exceptionRule2.expectMessage("age is should not be greater than 150 " + "\n" + "age should not be less than 18");
		exceptionRule2.expect(ApplicationException.class);
		
		UserValidator1.validateAge(156);
		
	}
	
	//>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>....
	
	
	@SuppressWarnings("deprecation")
	@Rule
	public ExpectedException exceptionRule1 = ExpectedException.none();
	@Test
	public void ifNameIsNull_CityValidationFail()  throws ApplicationException{
		
		exceptionRule1.expectMessage("City Name should not be null");
		exceptionRule1.expect(ApplicationException.class);
		
		UserValidator1.validateName(null);
	}
	
	
	
	
	
	
	
	
	
	
	
	

	/*@Test
	public void test1() throws ApplicationException {
		User user = new User() ;
		//user.setName(null);
		Assert.assertTrue(UserValidatror1.validateName("vijay"));
		
		
	}
	@Test
	public void test2() throws ApplicationException {
		User user = new User() ;
		user.setName("vijay");
		Assert.assertTrue(UserValidatror1.validateName(null));
		
		
	}
	@Test
	public void test3() throws ApplicationException {
		User user = new User() ;
		user.setName("vijay");
		Assert.assertFalse(UserValidatror1.validateName(null));
		
		
	}*/
	
	
	
	
	
	
	
	
	
	
}
