package com.dnapass.training.day5.exercise.user;

import java.util.ArrayList;
import java.util.List;

public class EntityDataLoader {

	public static UserEntity newUserEntity() {

		// <UserEntity> userList = new ArrayList<>();

		AddressEntity addressEntity = new AddressEntity(100L, "NewStreet", "Chennai", null);

		UserEntity userEntity = new UserEntity(421215L, "VijayArjunan", addressEntity);
		userEntity.setAddress(addressEntity);
		userEntity.getId();
		userEntity.getName();
		userEntity.getAddress().getCity();

		userEntity.getAddress().getStreet();
		//userEntity.setId(800L);
		//.setName("bb");
		return userEntity;
	}
}
