package com.dnapass.training.day5.exercise.arraysample;

public class CharaterUtil {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String[][] names = { { " vijay ", " arjunan ", " priya " }, 
				             { " sundari ", " naveen " } };
		
		
		String str = names[0][0];
	     str = names[0][1];
		  str = names[0][2];
		  
		  str=names[1][0];
		  str=names[1][1];
		System.out.println(names.length);//2
		
		System.out.println(names[0].length);//3
		
		System.out.println(names[1].length);//2
		
		for(int row=0;row<names.length;row++) {
			
			for(int col=0;col<names[row].length;col++) {
				
				System.out.print(names[row][col]);
				
			}
			System.out.println();
		}
		
	}

}
