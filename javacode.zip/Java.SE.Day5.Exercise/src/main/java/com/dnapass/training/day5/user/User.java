package com.dnapass.training.day5.user;

public class User {

	private String name;
	private String working;
	private String emailId;
	private String abouttMe;
	private int age;

	public User() {
		super();
	}

	public User(String name, String working, String emailId, String abouttMe, int age) {
		super();
		this.name = name;
		this.working = working;
		this.emailId = emailId;
		this.abouttMe = abouttMe;
		this.age = age;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getWorking() {
		return working;
	}

	public void setWorking(String working) {
		this.working = working;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getAbouttMe() {
		return abouttMe;
	}

	public void setAbouttMe(String abouttMe) {
		this.abouttMe = abouttMe;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	@Override
	public String toString() {
		return "User [" + (name != null ? "name=" + name + ", " : "")
				+ (working != null ? "working=" + working + ", " : "")
				+ (emailId != null ? "emailId=" + emailId + ", " : "")
				+ (abouttMe != null ? "abouttMe=" + abouttMe + ", " : "") + "age=" + age + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((abouttMe == null) ? 0 : abouttMe.hashCode());
		result = prime * result + age;
		result = prime * result + ((emailId == null) ? 0 : emailId.hashCode());
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		result = prime * result + ((working == null) ? 0 : working.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		User other = (User) obj;
		if (abouttMe == null) {
			if (other.abouttMe != null)
				return false;
		} else if (!abouttMe.equals(other.abouttMe))
			return false;
		if (age != other.age)
			return false;
		if (emailId == null) {
			if (other.emailId != null)
				return false;
		} else if (!emailId.equals(other.emailId))
			return false;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		if (working == null) {
			if (other.working != null)
				return false;
		} else if (!working.equals(other.working))
			return false;
		return true;
	}

}
