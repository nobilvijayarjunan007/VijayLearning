package com.dnapass.training.day5.contacts;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.dnapass.training.day5.user.ApplicationException;

public class ContactValidator {

	static Logger logger = LoggerFactory.getLogger(ContactValidator.class);

	@SuppressWarnings("unused")
	public static Long validateId(Long id) throws ApplicationException {

		Long ID = null;
		if (id == null) {

			throw new ApplicationException("Id can not be null");

		} else {
			ID = id;
		}

		logger.info(">>" + id);
		return ID;
	}

	public static String validateName(String name) throws ApplicationException {
		String name1 = null;
		if (name == null || name == "" || name.trim().isEmpty()) {

			throw new ApplicationException("Name can't be null");

		} else {
			name1 = name;
		}

		System.out.println(name1);

		return name1;
	}

	public static String validatePhoneNumber(String num) throws ApplicationException {

		Pattern p = Pattern.compile("(0|91)?[6-9][0-9]{9}");
		String result = null;
		Matcher m = p.matcher(num);
		if (m.find()) {
			result = m.group() + " is valid mobile number";
			System.out.println(result);

		} else {
			throw new ApplicationException("your number should be Match to the Mobile number pattern");
		}

		return result;
	}
	public static String validateHomePhoneNumber(String num) throws ApplicationException {

		Pattern p = Pattern.compile("(0|044)?[4-9][0-9]{9}");
		String result = null;
		Matcher m = p.matcher(num);
		if (m.find()) {
			result = m.group() + " is valid landline number";
			System.out.println(result);

		} else {
			throw new ApplicationException("your number should be Match to the landline number pattern");
		}

		return result;
	}

	public static String validateEmailId(String email) throws ApplicationException {

		Pattern p = Pattern.compile("^[a-zA-Z0-9+_.-]+@[a-zA-Z0-9.-]+$");
		String result = null;
		Matcher m = p.matcher(email);
		if (m.find()) {
			result = m.group() + " is valid email id";
			System.out.println(result);

		} else {
			throw new ApplicationException("your email id should be Match to the mail id pattern");
		}

		return result;
	}

}
