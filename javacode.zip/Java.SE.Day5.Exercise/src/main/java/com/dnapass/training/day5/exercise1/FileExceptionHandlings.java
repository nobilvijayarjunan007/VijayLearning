package com.dnapass.training.day5.exercise1;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class FileExceptionHandlings {

	static Logger logger = LoggerFactory.getLogger(FileExceptionHandlings.class);

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		File file = new File("vijay.xml");
		try {

			FileInputStream reader = new FileInputStream(file);

		} catch (FileNotFoundException fe) {

			logger.error(fe.getMessage());
			logger.error(fe.getLocalizedMessage());
			logger.error(" class name is " + fe.getClass());

		}
		// FileNotFoundException
		catch (Exception e) {

			e.printStackTrace();

		}
	}

}
