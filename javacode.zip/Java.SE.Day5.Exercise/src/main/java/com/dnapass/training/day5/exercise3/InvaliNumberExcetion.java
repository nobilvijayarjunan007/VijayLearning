package com.dnapass.training.day5.exercise3;

public class InvaliNumberExcetion extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private int baseNumber ;
	private int powerOfNumber;
	private String message = "java.lang.Exception: n and p should not be zero.\r\n" + 
			"java.lang.Exception: n or p should not be negative.\r\n" + 
			"java.lang.Exception: n or p should not be negative.\r\n" + 
			"";
	
	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public String getMessage() {
		return message;
	}

	public int getBaseNumber() {
		return baseNumber;
	}

	public void setBaseNumber(int baseNumber) {
		this.baseNumber = baseNumber;
	}

	public int getPowerOfNumber() {
		return powerOfNumber;
	}

	public void setPowerOfNumber(int powerOfNumber) {
		this.powerOfNumber = powerOfNumber;
	}

	public InvaliNumberExcetion(int baseNumber, int powerOfNumber) {
		super();
		this.baseNumber = baseNumber;
		this.powerOfNumber = powerOfNumber;
	}
	
}
