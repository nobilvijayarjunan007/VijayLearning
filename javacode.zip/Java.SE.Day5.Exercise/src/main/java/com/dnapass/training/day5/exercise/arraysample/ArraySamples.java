package com.dnapass.training.day5.exercise.arraysample;

import java.util.Arrays;
import java.util.Scanner;

public class ArraySamples {

	public static void main(String[] args) {

		/*
		 * int numbers[] = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 }; int sum =
		 * ArraySamples.sum(numbers); System.out.println(sum); //
		 * >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>. int numbers2[] = { 1, 2,
		 * 3, 4, 5 }; sum = ArraySamples.sum(numbers2); System.out.println(sum); //
		 * >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>.
		 * 
		 * int n; Scanner sc = new Scanner(System.in);
		 * System.out.println("Enter the number of Elements yyou want to store:"); n =
		 * sc.nextInt(); int[] array = new int[n];
		 * System.out.println("Enter the element of the array"); for (int i = 0; i <= n
		 * - 1; i++) { System.out.println("Enter the element : " + i); array[i] =
		 * sc.nextInt();
		 * 
		 * }
		 * 
		 * sum = ArraySamples.sum(array); System.out.println(sum);
		 */
		// >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>.

		int[] numbers3 = new int[] { 50, 100, 150 };
		double avg = ArraySamples.average(numbers3);
		System.out.println(avg);

		// >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>.

		search();
		findIndex();
		sort();
	}

	private static void sort() {
		int[] numbers = {2000,2300,500,987,345,7890};
		String []names= {"vijay","arjunan","priya","naveen","sundari"};
		System.out.println("original numbers"+Arrays.toString(numbers));
		System.out.println("original numbers"+Arrays.toString(names));
		Arrays.sort(numbers);
		Arrays.sort(names);
		System.out.println(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
		
		System.out.println("original numbers"+Arrays.toString(numbers));
		System.out.println("original numbers"+Arrays.toString(names));
		
	}

	public static double average(int[] numbers3) {
		int sum = 0;// count = 0;
		int avg = 0;

		for (int i = 0; i < numbers3.length; i++) {

			// count++;
			sum += numbers3[i];
			avg = sum / numbers3.length;
		}
		return avg;
		
	
	}

	public static int sum(int[] numbers) {
		int sum = 0;
		for (int i = 0; i < numbers.length; i++) {

			sum += numbers[i];
		}
		return sum;
	}

	public static boolean contains(int[] arr, int item) {

		for (int n : arr) {
			if (item == n) {
				return true;
			}
		}
		return false;
	}

	public static void search() {
		int[] num = { 1990, 2000, 2010, 2020, 1999, 1997, 2013 };
		System.out.println(contains(num, 2013));
		System.out.println(contains(num, 2015));
	}
	
	public static void findIndex() {
		int[] num = { 1990, 2000, 2010, 2020, 1999, 1997, 2013 };
		System.out.println(findIndex(num, 2013));
		System.out.println(findIndex(num, 2015));
	}

	public static int findIndex(int[] num, int item) {
		for(int i=0;i<num.length;i++) {
			
			if(num[i]==item) { return 1;};
			
		}
		return -1;
	}
	

}
