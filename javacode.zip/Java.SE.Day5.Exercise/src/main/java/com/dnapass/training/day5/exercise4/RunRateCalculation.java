package com.dnapass.training.day5.exercise4;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.InputMismatchException;
import java.util.Scanner;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.dnapass.training.day5.exercise3.MyCalculator;

public class RunRateCalculation {

	static Logger logger = LoggerFactory.getLogger(MyCalculator.class);

	public static void main(String[] args) throws ArithmeticException,NumberFormatException,InputMismatchException {
		/*
		 * BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		 * System.out.println("Enter  total Runs"); int totalRuns = br.read();
		 * br.readLine(); System.out.println("Enter overs faced"); int totalOversFaced =
		 * br.read();
		 */
		try {
			Scanner scan = new Scanner(System.in);
			System.out.println("Enter Total Run");
			int totalRuns = scan.nextInt();
			System.out.println("Enter total Overs Faced ");

			int totalOversFaced = scan.nextInt();

			int runRate = calculateRunRate(totalOversFaced, totalRuns);
			logger.info(" Run Rate is " + runRate);

		} catch (NumberFormatException ne) {
			logger.info("message" + ne.getClass());

		}catch (ArithmeticException ae) {
			logger.info("message" + ae.getClass());

		} catch(InputMismatchException ime) {
			
			logger.info("message "+ime.getClass());
		}
		
		catch (Exception e) {
			

		}

	}

	private static int calculateRunRate(int totalOversFaced, int totalRuns) {

		logger.info("totalOversFaced " + totalOversFaced);
		logger.info("totalRuns " + totalRuns);
		int runRate = totalRuns / totalOversFaced;

		return runRate;
	}

}
