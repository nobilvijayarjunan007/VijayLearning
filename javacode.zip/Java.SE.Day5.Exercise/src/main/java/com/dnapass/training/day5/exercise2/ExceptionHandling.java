package com.dnapass.training.day5.exercise2;

import java.util.InputMismatchException;
import java.util.Scanner;
import static java.lang.System.*;

import java.io.IOException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ExceptionHandling {
	static Logger logger = LoggerFactory.getLogger(ExceptionHandling.class); 
	public static void main(String[] args) throws IOException {
		
		try {

			Scanner scan = new Scanner(System.in);
			
			System.out.println("Enter first number" );
			int a =scan.nextInt();
			System.out.println("Enter second number" );
			int b =scan.nextInt();
			int result=division(a,b);
			System.out.println(result);
			
		}
		catch(ArithmeticException ae) {
			logger.error(" "+ae.getMessage());
			logger.error(" "+ae.getLocalizedMessage());
			logger.error(" "+ae.fillInStackTrace());
			logger.error(" "+ae.getCause());
			logger.error(" "+ae.getClass());
		}
		catch(InputMismatchException ime) {
			logger.error(" "+ime.getMessage());
			logger.error(" "+ime.getLocalizedMessage());
			logger.error(" "+ime.fillInStackTrace());
			logger.error(" "+ime.getCause());
			logger.error(" "+ime.getClass());
		}
		
		catch(Exception e) {
			
			e.printStackTrace();
			
		}
		finally { in.close();}

	}

	private static int division(int i, int j) {
		
		int result  = i/j;
		
		return result;
	}

}
