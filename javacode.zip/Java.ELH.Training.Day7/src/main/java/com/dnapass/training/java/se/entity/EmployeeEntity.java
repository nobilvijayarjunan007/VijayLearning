package com.dnapass.training.java.se.entity;

import java.io.Serializable;
import java.util.Objects;

public class EmployeeEntity  implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Long Id;
	private String empName;
	private String empDept;
	private String empLocation;
	
	public EmployeeEntity() {
		super();
	}

	public EmployeeEntity(Long empId, String empName, String empDept, String empLocation) {
		super();
		this.Id = empId;
		this.empName = empName;
		this.empDept = empDept;
		this.empLocation = empLocation;
	}

	public Long getId() {
		return Id;
	}

	public void setId(Long empId) {
		this.Id = empId;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public String getEmpDept() {
		return empDept;
	}

	public void setEmpDept(String empDept) {
		this.empDept = empDept;
	}

	public String getEmpLocation() {
		return empLocation;
	}

	public void setEmpLocation(String empLocation) {
		this.empLocation = empLocation;
	}

	@Override
	public int hashCode() {
		return Objects.hash(empDept, Id, empLocation, empName);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		EmployeeEntity other = (EmployeeEntity) obj;
		return Objects.equals(empDept, other.empDept) && Objects.equals(Id, other.Id)
				&& Objects.equals(empLocation, other.empLocation) && Objects.equals(empName, other.empName);
	}

	@Override
	public String toString() {
		return "EmployeeEntity [empId=" + Id + ", empName=" + empName + ", empDept=" + empDept + ", empLocation="
				+ empLocation + "]";
	}
	
	
}
