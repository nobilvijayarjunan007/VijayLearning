package com.dnapass.training.java.se.converter;

import java.util.ArrayList;
import java.util.List;

import com.dnapass.training.java.se.entity.EmployeeEntity;
import com.dnapass.training.java.se.model.Employee;

public class EmployeeConverter {

	public static List<Employee> convert(List<EmployeeEntity> empEntityList) {

		List<Employee> empList = null;

		if (empEntityList != null) {
			empList = new ArrayList<>();
			for (EmployeeEntity entity : empEntityList) {

				Employee emp = convert(entity);
				empList.add(emp);

			}

		}

		return empList;
	}

	public static Employee convert(EmployeeEntity entity) {
		Employee emp = null;
		if (entity != null) {
			emp = new Employee();
			if (entity.getId() != null)

			emp.setEmpId(entity.getId().intValue());
			emp.setEmpName(entity.getEmpName());
			emp.setEmpLocation(entity.getEmpLocation());
			emp.setEmpDept(entity.getEmpDept());

		}

		return emp;

	}
	
	public static EmployeeEntity convert(Employee newEmployee) {
		
		EmployeeEntity emp=null;
		if(newEmployee!=null) {
			emp = new EmployeeEntity();
			emp.setId(Long.valueOf(newEmployee.getEmpId()));
			emp.setEmpName(newEmployee.getEmpName());
			emp.setEmpLocation(newEmployee.getEmpLocation());
			emp.setEmpDept(newEmployee.getEmpDept());
			
			
		}
		return emp;
	}
	public static List<EmployeeEntity> convertToEntity(List<Employee> empList) {

		List<EmployeeEntity> empEntityList = null;

		if (empList != null) {
			empEntityList = new ArrayList<>();
			for (Employee emp : empList) {

				EmployeeEntity entity = convert(emp);
				empEntityList.add(entity);

			}

		}

		return empEntityList;
	}
	
}
