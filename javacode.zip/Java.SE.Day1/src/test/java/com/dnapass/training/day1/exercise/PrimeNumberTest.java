package com.dnapass.training.day1.exercise;

import org.junit.Assert;
import org.junit.Test;

public class PrimeNumberTest {

	@Test
	public void test1() {
		
		Assert.assertEquals("6 not a prime number",PrimeNumber.findTheNumberIsPrimeOrNot(6));
		
	}
	
	@Test
	public void test2() {
		
		Assert.assertEquals("11 is a prime number",PrimeNumber.findTheNumberIsPrimeOrNot(11));
		
	}
}
