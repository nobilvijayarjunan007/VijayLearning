package com.dnapass.training.day1.exercise;

import org.junit.Test;

import junit.framework.Assert;

public class SwappingTest {
	@Test
	public void Test1() {

		
		Assert.assertEquals(true,Swapping.swap1(4, 6));

	}
	@Test
	public void Test2() {

		
		Assert.assertEquals(true,Swapping.swap1(-4, -6));

	}
}
