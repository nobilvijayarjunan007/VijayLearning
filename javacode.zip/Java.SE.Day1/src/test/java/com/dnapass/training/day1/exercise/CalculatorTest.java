package com.dnapass.training.day1.exercise;

import org.junit.Test;

import junit.framework.Assert;

public class CalculatorTest {

	@SuppressWarnings("deprecation")
	@Test
	public void isItOdd_Or_EvenWhenWeSumThreeNumberTest() {

		Assert.assertEquals(150, Calculator.displaySumOfThreeNumbers(50,50,50), 0.01);// 50,50,50

	}
	@SuppressWarnings("deprecation")
	@Test
	public void isItOdd_Or_EvenWhenWeSumThreeNumberTest1() {

		Assert.assertEquals(90, Calculator.displaySumOfThreeNumbers(45,0,45), 0.01);// 45,0,45

	}
	@SuppressWarnings("deprecation")
	@Test
	public void isItOdd_Or_EvenWhenWeSumThreeNumberTest2() {

		Assert.assertEquals(9, Calculator.displaySumOfThreeNumbers(3,3,3), 0.01);// 3,3,3

	}
}
