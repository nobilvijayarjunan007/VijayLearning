package com.dnapass.training.day1.exercise;

import org.junit.Test;

import junit.framework.Assert;

public class FizzBuzzTest {

	@SuppressWarnings("deprecation")
	@Test
	public void test1_TheLoopingOfFizzAndBuzzBasedOnCondition() {

		Assert.assertEquals("buzz", FizzBuzz.displayTheLoopingOfFizzAndBuzzBasedOnCondition2(5));

	}

	@SuppressWarnings("deprecation")
	@Test
	public void test2_TheLoopingOfFizzAndBuzzBasedOnCondition() {

		Assert.assertEquals("fizz", FizzBuzz.displayTheLoopingOfFizzAndBuzzBasedOnCondition2(3));

	}

	@SuppressWarnings("deprecation")
	@Test
	public void test3_TheLoopingOfFizzAndBuzzBasedOnCondition() {

		Assert.assertEquals("fizz buzz", FizzBuzz.displayTheLoopingOfFizzAndBuzzBasedOnCondition2(15));

	}

}
