
package com.dnapass.training.day1.exercise;

import org.junit.Test;

import junit.framework.Assert;

public class ASCCI_ValueTest {

	@SuppressWarnings("deprecation")
	@Test
	public void test1OfASCCI_Value() {

		Assert.assertEquals(65, ASCII_Value.getASCII_ValueOfGivenCharacter('A'));// CHAR A

	}

	@SuppressWarnings("deprecation")
	@Test
	public void test2OfASCCI_Value() {

		Assert.assertEquals(64, ASCII_Value.getASCII_ValueOfGivenCharacter('@'));// CHAR @

	}

	@SuppressWarnings("deprecation")
	@Test
	public void test3OfASCCI_Value() {

		Assert.assertEquals(48, ASCII_Value.getASCII_ValueOfGivenCharacter('0'));// CHAR 0

	}

	@SuppressWarnings("deprecation")
	@Test
	public void test4OfASCCI_Value() {

		Assert.assertEquals(61, ASCII_Value.getASCII_ValueOfGivenCharacter('='));// CHAR =

	}
}
