package com.dnapass.training.day1.exercise;

import org.junit.Assert;
import org.junit.Test;

public class MathematicsTest {

	@Test
	public void test1() {
		
		Assert.assertEquals(15,Mathematics.addTwoNumbers(8, 7));
		
	}
	@Test
	public void test2() {
		
		Assert.assertEquals(1,Mathematics.subTwoNumbers(8, 7));
		
	}
	@Test
	public void test3() {
		
		Assert.assertEquals(56,Mathematics.mulTwoNumbers(8, 7));
		
	}
	@Test
	public void test4() {
		
		Assert.assertEquals(2,Mathematics.divTwoNumbers(10, 5));
		
	}
	@Test
	public void test5() {
		
		Assert.assertEquals(0,Mathematics.modTwoNumbers(10, 5));
		
	}
}
