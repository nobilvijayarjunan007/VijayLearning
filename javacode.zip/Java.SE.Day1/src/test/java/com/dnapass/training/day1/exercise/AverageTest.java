package com.dnapass.training.day1.exercise;

import org.junit.Test;

import junit.framework.Assert;

public class AverageTest {

	@SuppressWarnings("deprecation")
	@Test
	public void test_OfAvg() {

		Assert.assertEquals(15, Average.displayTheAverageOfThreeNumbers(15,15,15), 0.01);// 15,15,15

	}

	@SuppressWarnings("deprecation")
	@Test
	public void test_OfAvg1() {

		Assert.assertEquals(30, Average.displayTheAverageOfThreeNumbers(45,0,45), 0.01);// 45,0,45

	}

	@SuppressWarnings("deprecation")
	@Test
	public void test_OfAvg2() {

		Assert.assertEquals(2, Average.displayTheAverageOfThreeNumbers(3,0,3), 0.01);// 3,0,3

	}

	@SuppressWarnings("deprecation")
	@Test
	public void test_OfAvg3() {

		Assert.assertEquals(10, Average.displayTheAverageOfThreeNumbers(20,5,5), 0.01);// 20,5,5

	}
}
