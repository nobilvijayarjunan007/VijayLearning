package com.dnapass.training.day1.exercise;

import java.util.Scanner;

/*8. Write a program to read a number and calculate the sum of odd digits (values) present in the given number. 

Create a class with a static method checkSum which accepts a positive integer. The return type should be 1 if the sum is odd. In case the sum is even return -1 as output. 

Create a class Main which would get the input as a positive integer and call the static method checkSum present in the UserMainCode. 

Sample Input 1: 

56895 

Sample Output 1: 

Sum of odd digits is odd. 

 Sample Input 2: 

84228 

Sample Output 2: 

Sum of odd digits is even. */
public class Calculator {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		// Calculator c = new Calculator();
		double sum = displaySumOfThreeNumbers(3,4,5);

	}

	public static double displaySumOfThreeNumbers(int a,int b,int c) {
		
		long sum = a + b + c;
		if (sum % 2 == 1)
			System.out.println("Sum of odd digits is odd. >> " + sum);

		else if (sum % 2 == 0)

			System.out.println("Sum of odd digits is even. >> " + sum);
		return sum;

	}
}
