package com.dnapass.training.day1.exercise;

import java.util.Scanner;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ASCII_Value {
	/*
	 * 6. Write a Java program to print the ascii value of a given character.
	 */

	static Logger logger = LoggerFactory.getLogger(ASCII_Value.class);

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int ascii = getASCII_ValueOfGivenCharacter('A');
		logger.info("ASCII VALUE  " + ascii);

	}

	public static int getASCII_ValueOfGivenCharacter(char character) {
		// TODO Auto-generated method stub

		

		int ascii = character;
		System.out.println("Your Entered Character ASCII value is >>>> " + ascii);
		return ascii;
	}

}
