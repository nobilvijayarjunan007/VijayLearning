package com.dnapass.training.day1.exercise;

import java.util.Scanner;

public class NumberUtil {
	/*
	 * DAY 1>>>>1 PROGRAM
	 * 
	 * Write a Java program to print the result of the following operations.
	 * 
	 * Test Data:
	 * 
	 * a. -5 + 8 * 6
	 * 
	 * b. (55+9) % 9
	 * 
	 * c. 20 + -3*5 / 8
	 * 
	 * d. 5 + 15 / 3 * 2 - 8 % 3
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		problemOne();
		problemTwo();
		problemThree();
		problemFour();

	}

	public static long problemOne() {
		Scanner sc = new Scanner(System.in);
		System.out.println("!!We are going to solve the Problems here!!");
		System.out.println(" enter value  a = ");
		int a = sc.nextInt();
		System.out.println(" enter value  b = ");
		int b = sc.nextInt();
		System.out.println(" enter value  c = ");
		int c = sc.nextInt();
		// a. -5 + 8 * 6
		long result_1 = (-a + (b * c));

		System.out.println(" The Final Result Is = " + result_1);

		return result_1;
	}

	public static double problemTwo() {
		Scanner sc = new Scanner(System.in);
		System.out.println("!!We are going to solve the Problems here!!");
		System.out.println(" enter value  a = ");
		int a = sc.nextInt();
		System.out.println(" enter value  b = ");
		int b = sc.nextInt();
		System.out.println(" enter value  c = ");
		double c = sc.nextDouble();
		// (55+9) % 9
		double result_1 = ((a + b) % c);

		System.out.println(" The Final Result Is = " + result_1);

		return result_1;
	}

	public static double problemThree() {
		Scanner sc = new Scanner(System.in);
		System.out.println("!!We are going to solve the Problems here!!");
		System.out.println(" enter value  a = ");
		int a = sc.nextInt();
		System.out.println(" enter value  b = ");
		int b = sc.nextInt();
		System.out.println(" enter value  c = ");
		int c = sc.nextInt();
		System.out.println(" enter value  d = ");
		double d = sc.nextDouble();
		// c. 20 + -3*5 / 8
		double result_1 = a + (-(b) * (c / d));

		System.out.println(" The Final Result Is = " + result_1);
		return result_1;
	}

	public static double problemFour() {
		Scanner sc = new Scanner(System.in);
		System.out.println("!!We are going to solve the Problems here!!");
		System.out.println(" enter value  a = ");
		int a = sc.nextInt();
		System.out.println(" enter value  b = ");
		int b = sc.nextInt();
		System.out.println(" enter value  c = ");
		double c = sc.nextDouble();
		System.out.println(" enter value  d = ");
		double d = sc.nextDouble();
		System.out.println(" enter value  e = ");
		double e = sc.nextDouble();
		System.out.println(" enter value  f = ");
		double f = sc.nextDouble();
		// d. 5 + 15 / 3 * 2 - 8 % 3
		double result_1 = a + ((b / c) * d) - (e % f);

		System.out.println(" The Final Result Is = " + result_1);
		return result_1;
	}
}
