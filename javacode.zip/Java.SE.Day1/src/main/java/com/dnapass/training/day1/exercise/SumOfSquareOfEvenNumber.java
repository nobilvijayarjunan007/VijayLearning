package com.dnapass.training.day1.exercise;

/*9. Write a program to read a number, calculate the sum of squares of even digits (values) present in the given number.  

Create a class UserMainCode with a static method sumOfSquaresOfEvenDigits which accepts a positive integer. The return type (integer) should be the sum of squares of the even digits. 

Create a class Main which would get the input as a positive integer and call the static method sumOfSquaresOfEvenDigits present in the UserMainCode. 

Sample Input 1: 

     56895 

Sample Output 1: 

      100 */
public class SumOfSquareOfEvenNumber {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.out.println("The Sum Of Squares Of EvenDigits " + sumOfSquaresOfEvenDigits(2, 3, 4, 5, 6));
	}

	public static int sumOfSquaresOfEvenDigits(int a, int b, int c, int d, int e) {
		int sum = 0;
		int[] nums = { a, b, c, d, e };
		for (int i = 0; i < nums.length; i++) {

			if (nums[i] % 2 == 0) {
				System.out.println("number >> " + i + ">>" + nums[i]);
				sum += nums[i] * nums[i];
			}
		}
		return sum;
	}

}
