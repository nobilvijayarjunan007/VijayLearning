package com.dnapass.training.day1.exercise;

public class PrimeNumber {

	public static void main(String[] args) {

		findTheNumberIsPrimeOrNot(11);

	}

	public static String findTheNumberIsPrimeOrNot(int input) {
		// TODO Auto-generated method stub
		int i, m = 0, flag = 0;
		String string = null;
		int n = input;// it is the number to be checked
		m = n / 2;
		if (n == 0 || n == 1) {
			string=n+ " not a prime number";
			System.out.println(n + " not a prime number");
		} else {
			for (i = 2; i <= m; i++) {
				if (n % i == 0) {
					string = n + " not a prime number";
					System.out.println(n + " not a prime number");
					flag = 1;
					break;
				}
			}
			if (flag == 0) {
				string =n + " is a prime number";
				System.out.println(n + " is a prime number");
			}
		}
      return string;
	}

}
