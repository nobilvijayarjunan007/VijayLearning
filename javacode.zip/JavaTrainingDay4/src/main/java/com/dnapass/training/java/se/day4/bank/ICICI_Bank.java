package com.dnapass.training.java.se.day4.bank;

public class ICICI_Bank implements Bank {

	@Override
	public   int getInterestRate() {
		// TODO Auto-generated method stub
		return 8;
	}

}
