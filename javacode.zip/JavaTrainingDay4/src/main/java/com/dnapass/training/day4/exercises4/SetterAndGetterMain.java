package com.dnapass.training.day4.exercises4;

public class SetterAndGetterMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		

		        SetterAndGetter sg = new SetterAndGetter(); 

		        System.out.println("before setting"); 
		        System.out.println("a value is  = "+sg.getA() ); 
		        sg.setA(222);
		        System.out.println("after setting"); 
		        System.out.println("a value is  = "+sg.getA() ); 

		       

		    } 

		} 
	