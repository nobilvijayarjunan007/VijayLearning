package com.dnapass.training.day4.exercises1;

public class Rectangle extends Shape{

	
	 private Integer length ;

	 private Integer breadth; 
	 
	 
	


	public Rectangle() {
		super();
	}


	public Rectangle(String name, Integer length, Integer breadth) {
		super(name);
		this.length = length;
		this.breadth = breadth;
	}


	@Override
	Float calculateArea() {
		
		Float areaOfRectancle=(float) (length*breadth);
		return areaOfRectancle;
	}
	public Integer getLength() {
		return length;
	}


	public void setLength(Integer length) {
		this.length = length;
	}


	public Integer getBreadth() {
		return breadth;
	}


	public void setBreadth(Integer breadth) {
		this.breadth = breadth;
	}

}
