package com.dnapass.training.day4.exercises6;

public class GrandFather {

	int c = 100;

	public int getA() {
		return c;

	}

	public void setA(int a) {
		this.c = a;
	}

	public  int display() {

		System.out.println("GrandFather has " + c + " books");
		
		return c;
	}
}