package com.dnapass.training.day4.exercises5;

public class NumberUtil2 {

	double number2 = 123.45;

	public NumberUtil2() {

	}

	public void setNumber2(double value) {

		number2 = value;

	}

	public double getNumber2() {

		return number2;

	}
}
