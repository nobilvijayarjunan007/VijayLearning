package com.dnapass.training.day4.exercises5;

public class NumberUtilMain {

	public static void main(String[] args) {

		NumberUtil num1 = new NumberUtil();

		NumberUtil2 num2 = new NumberUtil2();

		System.out.println("before setter ");

		System.out.println("before setter number1 = " + num1.getNumber1());

		System.out.println("before setter  nuber2 = " + num2.getNumber2());

		num1.setNumber1(222);

		num2.setNumber2(333.33);
		System.out.println("after setter ");

		System.out.println("after setter number1  = " + num1.getNumber1());

		System.out.println("after setter number2  = " + num2.getNumber2());

	}

}
