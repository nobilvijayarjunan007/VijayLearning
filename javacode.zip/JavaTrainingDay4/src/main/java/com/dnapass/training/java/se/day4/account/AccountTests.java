package com.dnapass.training.java.se.day4.account;

public class AccountTests {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		SavingsAccount savingAccts = new SavingsAccount(1,1000,0.5);
		CurrentAccount currentAccts = new CurrentAccount(2,2000);
		
		savingAccts.deposite(10000d);
		
		
		savingAccts.transfer(2000.0, currentAccts);
		currentAccts.withdraw(15000);
		
		currentAccts.withdraw(80);
		
		savingAccts.addInterest();
		currentAccts.deductFees();
		System.out.println("saving account balance "+savingAccts.getAccountBalance());
		System.out.println("saving account balance "+currentAccts.getAccountBalance());
	}

}
