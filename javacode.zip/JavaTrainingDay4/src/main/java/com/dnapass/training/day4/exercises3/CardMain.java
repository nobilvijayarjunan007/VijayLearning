package com.dnapass.training.day4.exercises3;

import java.util.Scanner;

public class CardMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner scan = new Scanner(System.in);
		System.out.println("Select the Card");
		System.out.println("1.Payback Card");
		System.out.println("2.Membership Card");
		int i = scan.nextInt();
		if (i == 1) {
			System.out.println("Enter the Card Details:");
			System.out.println("1.holderName");
			String name = scan.next();

			System.out.println("5.totalAmount");
			Double amount = scan.nextDouble();
			System.out.println("2.cardNumber");
			String cardNo = scan.next();
			System.out.println("3.expiryDate");
			String expDate = scan.next();
			System.out.println("4.pointsEarned");
			Integer point = scan.nextInt();

			Card card1 = new PaybackCard(name, cardNo, expDate, point, amount);
			System.out.println(card1);

		} else if (i == 2) {
			System.out.println("Enter the Card Details:");
			System.out.println("1.holderName");
			String name = scan.next();
			System.out.println("2.cardNumber");
			String cardNo = scan.next();
			System.out.println("3.expiryDate");
			String expDate = scan.next();
			System.out.println("4.rating");
			Integer rating = scan.nextInt();

			Card card2 = new MembershipCard(name,cardNo,expDate,rating);
			System.out.println(card2);

		}
		else {System.out.println("Enter card Number 1 or 2");
		System.out.println("your input is invalid");
		}

	}

}
