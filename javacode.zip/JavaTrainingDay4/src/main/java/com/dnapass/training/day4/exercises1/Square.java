package com.dnapass.training.day4.exercises1;

public class Square extends Shape {

	private Integer side;

	public Square() {
		super();
	}

	public Square(String name, Integer side) {
		super(name);
		this.side = side;
	}

	public Integer getSide() {
		return side;
	}

	public void setSide(Integer side) {
		this.side = side;
	}

	@Override
	Float calculateArea() {
		Float areaOfSquare = (float) Math.pow(side, 2);

		return areaOfSquare;
	}

}
