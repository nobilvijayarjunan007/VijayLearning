package com.dnapass.training.java.se.day4.bank;

public class CentralBank {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Bank bank = new SBI();
		System.out.println(bank);
		bank = new ICICI_Bank();
		System.out.println(bank);
		int sbi=bank.getInterestRate();
		int icici=bank.getInterestRate();
		
		System.out.println(sbi);
		System.out.println(icici);
		
		
	}

}
