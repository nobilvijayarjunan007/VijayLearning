package com.dnapass.training.day4.exercises4;

public class SetterAndGetter {

	 private int a = 100; 

	    public void setA( int value) { 

	        a = value; 

	} 

	    public int getA() { 

	        return a; 

	    } 
	}


