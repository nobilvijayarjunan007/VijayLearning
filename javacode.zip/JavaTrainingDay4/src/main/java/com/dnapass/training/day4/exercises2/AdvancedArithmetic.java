package com.dnapass.training.day4.exercises2;

public interface AdvancedArithmetic  {

	
	int divisor_sum(int n);
}
