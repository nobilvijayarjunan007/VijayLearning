package com.dnapass.training.day4.exercises1;

public class AreaOfShape {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Shape s = new Circle("Circle", 25);
		Float areaOFCircle = s.calculateArea();
		
		
//>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>.
		s = new Rectangle("Rectangle", 5, 5);
		Float areaOFRectangle = s.calculateArea();
		
		
		
		
//>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>.
		s = new Square("Square", 10);
		Float areaOFSquare = s.calculateArea();

		
		System.out.format("areaOFCircle  :"+"%.2f%n",areaOFCircle);
		System.out.format("areaOFRectangle  :"+"%.2f%n",areaOFRectangle);
		System.out.format("areaOFSquare  :"+"%.2f%n",areaOFSquare);
	}

}
