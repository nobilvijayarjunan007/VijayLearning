package com.dnapass.training.day4.exercises4;
import org.junit.Assert;
import org.junit.Test;


public class SetterAndGetterTest {
	 SetterAndGetter sg = new SetterAndGetter();
	@Test
	public void test1() {
		 
		Assert.assertEquals(100, sg.getA(),0.01);
		
	}
	@Test
	public void test2() {
		 sg.setA(5005);
		Assert.assertEquals(5005, sg.getA(),0.01);
		
	}
	@Test
	public void test3() {
		sg.setA(-9999);
		Assert.assertEquals(-9999, sg.getA(),0.01);
		
	}
	
	
	
}

