package com.dnapass.training.day4.exercises1;

import org.junit.Assert;
import org.junit.Test;

public class AreaOfShapeTest {

	@Test
	public void testOfCircle() {
		Shape s = new Circle("Circle", 25);
		Assert.assertEquals(1963.50, s.calculateArea(),0.01);
		
	}
	@Test
	public void testOfCircle1() {
		Shape s = new Circle("Circle", -25);
		Assert.assertEquals(1963.50, s.calculateArea(),0.01);
		
	}
	@Test
	public void testOfCircle2() {
		Shape s = new Circle("Circle", 0);
		Assert.assertEquals(0.0, s.calculateArea(),0.01);
		
	}
	@Test
	public void testOfRectangle() {
		Shape s = new Rectangle("Rectangle", 5, 5);
		Assert.assertEquals(25, s.calculateArea(),0.01);
		
	}
	@Test
	public void testOfRectangle1() {
		Shape s = new Rectangle("Rectangle", -50,- 5);
		Assert.assertEquals(250, s.calculateArea(),0.01);
		
	}
	@Test
	public void testOfSquare() {
		Shape s = new Square("Square", 25);
		Assert.assertEquals(625, s.calculateArea(),0.01);
		
	}
	@Test
	public void testOfSquare1() {
		Shape s = new Square("Square", 10);
		Assert.assertEquals(100, s.calculateArea(),0.01);
		
	}
	
}
