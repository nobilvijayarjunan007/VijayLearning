package com.dnapass.training.day4.exercises;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JavaTrainingDay4ApplicationTests {

	@Test
	void contextLoads() {
	}

}
