package com.dnapass.training.day4.exercises5;
import org.junit.Assert;
import org.junit.Test;
public class NumberUtilTest {

	NumberUtil num1 = new NumberUtil();

	NumberUtil2 num2 = new NumberUtil2();
	
	@Test
	
	public void test1() {
		num1.setNumber1(500);
		Assert.assertEquals(500,num1.getNumber1(),0.0);
		
	}
	
	@Test
	public void test2() {
		
		num1.setNumber1(-100);
		Assert.assertEquals(-100,num1.getNumber1(),0.0);
		
	}
	
	@SuppressWarnings("deprecation")
	@Test
	public void test3() {
		num2.setNumber2(9999);
		Assert.assertEquals(9999,num2.getNumber2(),0.01);
		
	}
	
	@SuppressWarnings("deprecation")
	@Test
	public void test4() {
		num2.setNumber2(-9999);
		Assert.assertEquals(-9999,num2.getNumber2(),0.01);
		
	}
}
