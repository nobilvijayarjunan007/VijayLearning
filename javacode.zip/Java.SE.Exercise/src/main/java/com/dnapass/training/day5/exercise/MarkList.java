package com.dnapass.training.day5.exercise;

import java.util.Optional;

public class MarkList {

	int num;

	public static void graceMarks(MarkList obj4) {
		obj4.num += 10;
	}

	public static void main(String[] args) {

		MarkList obj1 = new MarkList();
		MarkList obj2 = obj1;

		obj1 = null;
		obj2.num = 60;
		graceMarks(obj2);
		System.out.println("nn");
		
		
		Optional<String> fullName = Optional.of("HCL");
		
		fullName = Optional.ofNullable(null);
		
		System.out.println("Full Name : "+fullName.orElseGet(()->"[Tech]"));
	}
}
