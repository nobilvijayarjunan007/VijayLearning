package com.dnapass.training.day5.exercise;

public interface poet {
	default void poet() {
		System.out.println("Poet default method");
	}
}
