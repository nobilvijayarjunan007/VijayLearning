package com.dnapass.training.day5.exercise;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.Arrays;

public class Main2 {
	private static void doperate(int i, Operation o) {
		o.operate(i);
	}

	public static void main(String[] args) {

		

		int b = 90;
		Main2.doperate(b, n -> {
			System.out.println(b + n);
			System.out.println(this);
		});

	}

}
