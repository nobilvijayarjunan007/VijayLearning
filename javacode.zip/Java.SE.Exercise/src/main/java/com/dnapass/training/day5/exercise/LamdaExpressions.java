package com.dnapass.training.day5.exercise;

public class LamdaExpressions {

	public static void main(String a[]) {

		String name = "Java";

		Runnable runnable1 = () -> System.out.print(name);

		String name1 = "Runnable";

		name1 = name.toUpperCase();

		//Runnable runnable2 = () -> System.out.print(name1);
		Runnable runnable2 = () -> System.out.print(name1);
		runnable2.run();
	}
}
