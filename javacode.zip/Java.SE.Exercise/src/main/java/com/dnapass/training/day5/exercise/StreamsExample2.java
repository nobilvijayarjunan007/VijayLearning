package com.dnapass.training.day5.exercise;

import java.util.Arrays;
import java.util.List;

public class StreamsExample2 {

	public static void main(String[] args) {
		List<Person> persons = Arrays.asList(new Person("Bharath", 30), new Person("Vetri", 20),
				new Person("Siva", 40));
		Person result1 = persons.stream().filter(x -> "Bharath".equals(x.getName())).findAny().orElse(null);
		System.out.println(result1);
	}

}
