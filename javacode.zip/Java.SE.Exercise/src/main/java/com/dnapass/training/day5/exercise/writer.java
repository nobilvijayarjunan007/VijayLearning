package com.dnapass.training.day5.exercise;

public interface writer {
	default void write() {
		System.out.println("writer default method");
	}
}
