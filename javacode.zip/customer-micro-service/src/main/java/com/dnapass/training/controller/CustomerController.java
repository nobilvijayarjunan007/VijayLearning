package com.dnapass.training.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.dnapass.training.entities.CustomerEntity;
import com.dnapass.training.entities.PaymentEntity;
import com.dnapass.training.exception.ApplicationException;
import com.dnapass.training.service.CustomerService;
import com.dnapass.training.service.PaymentService;

@RestController
@RequestMapping("/customerapi")
public class CustomerController {

	@Autowired
	private CustomerService custService;
	@Autowired
	private PaymentService payService;

	@RequestMapping(method = RequestMethod.POST, value = "/customers")
	public ResponseEntity<CustomerEntity> addCustomer(@RequestBody CustomerEntity customer)
			throws ApplicationException {

		CustomerEntity newCust = custService.addCustomer(customer);

		HttpHeaders httpHeaders = new HttpHeaders();
		httpHeaders.add("customer", "/customers" + newCust.getCustomerNumber().toString());

		return new ResponseEntity<>(newCust, httpHeaders, HttpStatus.CREATED);
	}

	@RequestMapping(method = RequestMethod.GET, value = "/customers/{custId}")
	public ResponseEntity<CustomerEntity> findCustomer(@PathVariable(name = "custId") Long id) {

		CustomerEntity cust = custService.findCustomerById(id);

		return new ResponseEntity<>(cust, HttpStatus.OK);
	}

	@RequestMapping(method = RequestMethod.GET, value = "/customers/{checkNo}/{custId}")
	public ResponseEntity<PaymentEntity> findPayments(@PathVariable(name = "checkNo") String checkNo,
			@PathVariable(name = "custId") Long custId) {

		PaymentEntity payment = payService.findPayment(checkNo, custId);

		return new ResponseEntity<>(payment, HttpStatus.OK);
	}

	@RequestMapping(method = RequestMethod.GET, value = "/customersList")
	public ResponseEntity<List<CustomerEntity>> findCustomers() {

		List<CustomerEntity> customers = custService.findCustomer();

		return new ResponseEntity<>(customers, HttpStatus.OK);
	}

	@RequestMapping(method = RequestMethod.GET, value = "/paymentsList")
	public ResponseEntity<List<PaymentEntity>> findOffices() {

		List<PaymentEntity> payments = payService.findPayments();

		return new ResponseEntity<>(payments, HttpStatus.OK);
	}

	@RequestMapping(method = RequestMethod.PUT, value = "/customer/{custId}")
	public ResponseEntity<CustomerEntity> addEmployeeOffice(@RequestBody PaymentEntity payment,
			@PathVariable(name = "custId") Long custId) {

		CustomerEntity addCustomerPayment = custService.addCustomerPayment(payment, custId);

		return new ResponseEntity<>(addCustomerPayment, HttpStatus.OK);
	}

}
