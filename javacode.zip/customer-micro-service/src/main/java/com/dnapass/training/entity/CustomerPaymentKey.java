//
//package com.dnapass.training.entity;
//
//import java.io.Serializable;
//import java.util.Objects;
//
//import javax.persistence.Column;
//import javax.persistence.Embeddable;
//import javax.persistence.GeneratedValue;
//import javax.persistence.Id;
//
//@Embeddable
//public class CustomerPaymentKey implements Serializable {
//
//	private static final long serialVersionUID = 1L;
//
//	// @Id
//	private Long customerNumberPk;
//	// @Id
//	// @GeneratedValue
//	private String checkNumber;
//
//	public CustomerPaymentKey() {
//		super();
//	}
//
//	public CustomerPaymentKey(Long customerNumber, String checkNumber) {
//		super();
//		this.customerNumberPk = customerNumber;
//		this.checkNumber = checkNumber;
//	}
//
//	public CustomerPaymentKey(String string) {
//		// TODO Auto-generated constructor stub
//	}
//
//	public Long getCustomerNumber() {
//		return customerNumberPk;
//	}
//
//	public void setCustomerNumber(Long customerNumber) {
//		this.customerNumberPk = customerNumber;
//	}
//
//	public String getCheckNumber() {
//		return checkNumber;
//	}
//
//	public void setCheckNumber(String checkNumber) {
//		this.checkNumber = checkNumber;
//	}
//
//	@Override
//	public int hashCode() {
//		return Objects.hash(checkNumber, customerNumberPk);
//	}
//
//	@Override
//	public boolean equals(Object obj) {
//		if (this == obj)
//			return true;
//		if (obj == null)
//			return false;
//		if (getClass() != obj.getClass())
//			return false;
//		CustomerPaymentKey other = (CustomerPaymentKey) obj;
//		return Objects.equals(checkNumber, other.checkNumber)
//				&& Objects.equals(customerNumberPk, other.customerNumberPk);
//	}
//
//	@Override
//	public String toString() {
//		return "CustomerPaymentKey [customerNumber=" + customerNumberPk + ", checkNumber=" + checkNumber + "]";
//	}
//
//}
