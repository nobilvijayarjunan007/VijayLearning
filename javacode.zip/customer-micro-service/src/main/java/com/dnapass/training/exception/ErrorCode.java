package com.dnapass.training.exception;

public enum ErrorCode {
	APP0001,APP0002 ,APP0003
}
