//package com.dnapass.training.entity;
//
//import java.io.Serializable;
//import java.util.ArrayList;
//import java.util.List;
//import java.util.Objects;
//
//import javax.persistence.CascadeType;
//import javax.persistence.Column;
//import javax.persistence.Entity;
//import javax.persistence.FetchType;
//import javax.persistence.GeneratedValue;
//import javax.persistence.GenerationType;
//import javax.persistence.Id;
//import javax.persistence.JoinColumn;
//import javax.persistence.ManyToOne;
//import javax.persistence.OneToMany;
//import javax.persistence.OneToOne;
//import javax.persistence.Table;
//
//import com.fasterxml.jackson.annotation.JsonBackReference;
//
//@Entity
//@Table(name = "Customers")
//public class CustomerEntity implements Serializable {
//
//	private static final long serialVersionUID = 1L;
//	@Id
//	@GeneratedValue
//	@Column(name = "cust_no")
//	private Long customerNumber;
//	@Column(name = "cust_name")
//	private String customerName;
//	@Column(name = "cont_last_name")
//	private String contactLastName;
//
//	private String contactFirstName;
//	private String phone;
//	private String addressLine1;
//	private String addressLine2;
//	private String city;
//	private String state;
//	private String postalCode;
//	private String country;
//
//	private String creditLimit;
//
////	@ManyToOne(cascade = CascadeType.ALL)
////	@JoinColumn(name = " sales_RepEmployeeNumber")
////	private EmployeeEntity employee;
////
////	@OneToMany(mappedBy = "customer", cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.EAGER)
////	private List<OrderEntity> orders = new ArrayList<>();
//	@JsonBackReference
//	@OneToOne(mappedBy = "customer", cascade = CascadeType.ALL, orphanRemoval = true)
//	private PaymentEntity payments;
//
//	public CustomerEntity() {
//		super();
//	}
//
//	public CustomerEntity(Long customerNumber, String customerName, String contactLastName, String contactFirstName,
//			String phone, String addressLine1, String addressLine2, String city, String state, String postalCode,
//			String country, String creditLimit, PaymentEntity payments) {
//		super();
//		this.customerNumber = customerNumber;
//		this.customerName = customerName;
//		this.contactLastName = contactLastName;
//		this.contactFirstName = contactFirstName;
//		this.phone = phone;
//		this.addressLine1 = addressLine1;
//		this.addressLine2 = addressLine2;
//		this.city = city;
//		this.state = state;
//		this.postalCode = postalCode;
//		this.country = country;
//		this.creditLimit = creditLimit;
//		this.payments = payments;
//	}
//
//	public CustomerEntity(Long customerNumber, String customerName, String contactLastName, String contactFirstName,
//			String phone, String addressLine1, String addressLine2, String city, String state, String postalCode,
//			String country, String creditLimit) {
//		super();
//		this.customerNumber = customerNumber;
//		this.customerName = customerName;
//		this.contactLastName = contactLastName;
//		this.contactFirstName = contactFirstName;
//		this.phone = phone;
//		this.addressLine1 = addressLine1;
//		this.addressLine2 = addressLine2;
//		this.city = city;
//		this.state = state;
//		this.postalCode = postalCode;
//		this.country = country;
//		this.creditLimit = creditLimit;
//	}
//
////	public CustomerEntity(Long customerNumber, String customerName, String contactLastName, String contactFirstName,
////			String phone, String addressLine1, String addressLine2, String city, String state, String postalCode,
////			String country, String creditLimit, EmployeeEntity employee, List<OrderEntity> orders,
////			PaymentEntity payments) {
////		super();
////		this.customerNumber = customerNumber;
////		this.customerName = customerName;
////		this.contactLastName = contactLastName;
////		this.contactFirstName = contactFirstName;
////		this.phone = phone;
////		this.addressLine1 = addressLine1;
////		this.addressLine2 = addressLine2;
////		this.city = city;
////		this.state = state;
////		this.postalCode = postalCode;
////		this.country = country;
////		this.creditLimit = creditLimit;
////		this.employee = employee;
////		this.orders = orders;
////		this.payments = payments;
////	}
//
//	public Long getCustomerNumber() {
//		return customerNumber;
//	}
//
//	public void setCustomerNumber(Long customerNumber) {
//		this.customerNumber = customerNumber;
//	}
//
//	public String getCustomerName() {
//		return customerName;
//	}
//
//	public void setCustomerName(String customerName) {
//		this.customerName = customerName;
//	}
//
//	public String getContactLastName() {
//		return contactLastName;
//	}
//
//	public void setContactLastName(String contactLastName) {
//		this.contactLastName = contactLastName;
//	}
//
//	public String getContactFirstName() {
//		return contactFirstName;
//	}
//
//	public void setContactFirstName(String contactFirstName) {
//		this.contactFirstName = contactFirstName;
//	}
//
//	public String getPhone() {
//		return phone;
//	}
//
//	public void setPhone(String phone) {
//		this.phone = phone;
//	}
//
//	public String getAddressLine1() {
//		return addressLine1;
//	}
//
//	public void setAddressLine1(String addressLine1) {
//		this.addressLine1 = addressLine1;
//	}
//
//	public String getAddressLine2() {
//		return addressLine2;
//	}
//
//	public void setAddressLine2(String addressLine2) {
//		this.addressLine2 = addressLine2;
//	}
//
//	public String getCity() {
//		return city;
//	}
//
//	public void setCity(String city) {
//		this.city = city;
//	}
//
//	public String getState() {
//		return state;
//	}
//
//	public void setState(String state) {
//		this.state = state;
//	}
//
//	public String getPostalCode() {
//		return postalCode;
//	}
//
//	public void setPostalCode(String postalCode) {
//		this.postalCode = postalCode;
//	}
//
//	public String getCountry() {
//		return country;
//	}
//
//	public void setCountry(String country) {
//		this.country = country;
//	}
//
//	public String getCreditLimit() {
//		return creditLimit;
//	}
//
//	public void setCreditLimit(String creditLimit) {
//		this.creditLimit = creditLimit;
//	}
//
////	public EmployeeEntity getEmployee() {
////		return employee;
////	}
////
////	public void setEmployee(EmployeeEntity employee) {
////		this.employee = employee;
////	}
////
////	public List<OrderEntity> getOrders() {
////		return orders;
////	}
////
////	public void setOrders(List<OrderEntity> orders) {
////		this.orders = orders;
////	}
//
//	public PaymentEntity getPayments() {
//		return payments;
//	}
//
//	public void setPayments(PaymentEntity payments) {
//		this.payments = payments;
//	}
//
//	@Override
//	public int hashCode() {
//		final int prime = 31;
//		int result = 1;
//		result = prime * result + ((addressLine1 == null) ? 0 : addressLine1.hashCode());
//		result = prime * result + ((addressLine2 == null) ? 0 : addressLine2.hashCode());
//		result = prime * result + ((city == null) ? 0 : city.hashCode());
//		result = prime * result + ((contactFirstName == null) ? 0 : contactFirstName.hashCode());
//		result = prime * result + ((contactLastName == null) ? 0 : contactLastName.hashCode());
//		result = prime * result + ((country == null) ? 0 : country.hashCode());
//		result = prime * result + ((creditLimit == null) ? 0 : creditLimit.hashCode());
//		result = prime * result + ((customerName == null) ? 0 : customerName.hashCode());
//		result = prime * result + ((customerNumber == null) ? 0 : customerNumber.hashCode());
//		result = prime * result + ((payments == null) ? 0 : payments.hashCode());
//		result = prime * result + ((phone == null) ? 0 : phone.hashCode());
//		result = prime * result + ((postalCode == null) ? 0 : postalCode.hashCode());
//		result = prime * result + ((state == null) ? 0 : state.hashCode());
//		return result;
//	}
//
//	@Override
//	public boolean equals(Object obj) {
//		if (this == obj)
//			return true;
//		if (obj == null)
//			return false;
//		if (getClass() != obj.getClass())
//			return false;
//		CustomerEntity other = (CustomerEntity) obj;
//		if (addressLine1 == null) {
//			if (other.addressLine1 != null)
//				return false;
//		} else if (!addressLine1.equals(other.addressLine1))
//			return false;
//		if (addressLine2 == null) {
//			if (other.addressLine2 != null)
//				return false;
//		} else if (!addressLine2.equals(other.addressLine2))
//			return false;
//		if (city == null) {
//			if (other.city != null)
//				return false;
//		} else if (!city.equals(other.city))
//			return false;
//		if (contactFirstName == null) {
//			if (other.contactFirstName != null)
//				return false;
//		} else if (!contactFirstName.equals(other.contactFirstName))
//			return false;
//		if (contactLastName == null) {
//			if (other.contactLastName != null)
//				return false;
//		} else if (!contactLastName.equals(other.contactLastName))
//			return false;
//		if (country == null) {
//			if (other.country != null)
//				return false;
//		} else if (!country.equals(other.country))
//			return false;
//		if (creditLimit == null) {
//			if (other.creditLimit != null)
//				return false;
//		} else if (!creditLimit.equals(other.creditLimit))
//			return false;
//		if (customerName == null) {
//			if (other.customerName != null)
//				return false;
//		} else if (!customerName.equals(other.customerName))
//			return false;
//		if (customerNumber == null) {
//			if (other.customerNumber != null)
//				return false;
//		} else if (!customerNumber.equals(other.customerNumber))
//			return false;
//		if (payments == null) {
//			if (other.payments != null)
//				return false;
//		} else if (!payments.equals(other.payments))
//			return false;
//		if (phone == null) {
//			if (other.phone != null)
//				return false;
//		} else if (!phone.equals(other.phone))
//			return false;
//		if (postalCode == null) {
//			if (other.postalCode != null)
//				return false;
//		} else if (!postalCode.equals(other.postalCode))
//			return false;
//		if (state == null) {
//			if (other.state != null)
//				return false;
//		} else if (!state.equals(other.state))
//			return false;
//		return true;
//	}
//
//	@Override
//	public String toString() {
//		return "CustomerEntity [customerNumber=" + customerNumber + ", customerName=" + customerName
//				+ ", contactLastName=" + contactLastName + ", contactFirstName=" + contactFirstName + ", phone=" + phone
//				+ ", addressLine1=" + addressLine1 + ", addressLine2=" + addressLine2 + ", city=" + city + ", state="
//				+ state + ", postalCode=" + postalCode + ", country=" + country + ", creditLimit=" + creditLimit
//				+ ", payments=" + payments + "]";
//	}
//
//}
