package com.dnapass.training.entity;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;

@Entity(name = "Employees")
public class EmployeeEntity implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)

	private Long employeeNumber;
	private String lastName;
	private String firstName;
	private String extension;
	private String email;
	@OneToOne(cascade = CascadeType.ALL)

	private EmployeeEntity manager;

	private String jobTitle;
	// @JsonBackReference
	@JsonManagedReference
	@ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	@JoinColumn(name = "office_code")
	private OfficeEntity offices;

//	@OneToMany(mappedBy = "employee", cascade = CascadeType.ALL, orphanRemoval = true) //
//
//	private List<CustomerEntity> customers = new ArrayList<>();

	public EmployeeEntity() {
		super();
	}

//	public EmployeeEntity(Long employeeNumber, String lastName, String firstName, String extension, String email,
//			EmployeeEntity manager, String jobTitle, OfficeEntity offices, List<CustomerEntity> customers) {
//		super();
//		this.employeeNumber = employeeNumber;
//		this.lastName = lastName;
//		this.firstName = firstName;
//		this.extension = extension;
//		this.email = email;
//		this.manager = manager;
//		this.jobTitle = jobTitle;
//		this.offices = offices;
//		this.customers = customers;
//	}

	public Long getEmployeeNumber() {
		return employeeNumber;
	}

	public EmployeeEntity(Long employeeNumber, String lastName, String firstName, String extension, String email,
			EmployeeEntity manager, String jobTitle) {
		super();
		this.employeeNumber = employeeNumber;
		this.lastName = lastName;
		this.firstName = firstName;
		this.extension = extension;
		this.email = email;
		this.manager = manager;
		this.jobTitle = jobTitle;
	}

	public EmployeeEntity(Long employeeNumber, String lastName, String firstName, String extension, String email,
			EmployeeEntity manager, String jobTitle, OfficeEntity offices) {
		super();
		this.employeeNumber = employeeNumber;
		this.lastName = lastName;
		this.firstName = firstName;
		this.extension = extension;
		this.email = email;
		this.manager = manager;
		this.jobTitle = jobTitle;
		this.offices = offices;
	}

	public void setEmployeeNumber(Long employeeNumber) {
		this.employeeNumber = employeeNumber;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getExtension() {
		return extension;
	}

	public void setExtension(String extension) {
		this.extension = extension;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public EmployeeEntity getManager() {
		return manager;
	}

	public void setManager(EmployeeEntity manager) {
		this.manager = manager;
	}

	public String getJobTitle() {
		return jobTitle;
	}

	public void setJobTitle(String jobTitle) {
		this.jobTitle = jobTitle;
	}

	public OfficeEntity getOffices() {
		return offices;
	}

	public void setOffices(OfficeEntity offices) {
		this.offices = offices;
	}
//	public List<CustomerEntity> getCustomers() {
//	return customers;
//}
//
//public void setCustomers(List<CustomerEntity> customers) {
//	this.customers = customers;
//}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((email == null) ? 0 : email.hashCode());
		result = prime * result + ((employeeNumber == null) ? 0 : employeeNumber.hashCode());
		result = prime * result + ((extension == null) ? 0 : extension.hashCode());
		result = prime * result + ((firstName == null) ? 0 : firstName.hashCode());
		result = prime * result + ((jobTitle == null) ? 0 : jobTitle.hashCode());
		result = prime * result + ((lastName == null) ? 0 : lastName.hashCode());
		result = prime * result + ((manager == null) ? 0 : manager.hashCode());
		result = prime * result + ((offices == null) ? 0 : offices.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		EmployeeEntity other = (EmployeeEntity) obj;
		if (email == null) {
			if (other.email != null)
				return false;
		} else if (!email.equals(other.email))
			return false;
		if (employeeNumber == null) {
			if (other.employeeNumber != null)
				return false;
		} else if (!employeeNumber.equals(other.employeeNumber))
			return false;
		if (extension == null) {
			if (other.extension != null)
				return false;
		} else if (!extension.equals(other.extension))
			return false;
		if (firstName == null) {
			if (other.firstName != null)
				return false;
		} else if (!firstName.equals(other.firstName))
			return false;
		if (jobTitle == null) {
			if (other.jobTitle != null)
				return false;
		} else if (!jobTitle.equals(other.jobTitle))
			return false;
		if (lastName == null) {
			if (other.lastName != null)
				return false;
		} else if (!lastName.equals(other.lastName))
			return false;
		if (manager == null) {
			if (other.manager != null)
				return false;
		} else if (!manager.equals(other.manager))
			return false;
		if (offices == null) {
			if (other.offices != null)
				return false;
		} else if (!offices.equals(other.offices))
			return false;
		return true;
	}

//	@Override
//	public String toString() {
//		return "EmployeeEntity [employeeNumber=" + employeeNumber + ", lastName=" + lastName + ", firstName="
//				+ firstName + ", extension=" + extension + ", email=" + email + ", manager=" + manager + ", jobTitle="
//				+ jobTitle + ", offices=" + offices + "]";
//	}

	@Override
	public String toString() {
		return "EmployeeEntity [employeeNumber=" + employeeNumber + ", lastName=" + lastName + ", firstName="
				+ firstName + ", extension=" + extension + ", email=" + email + ", manager=" + manager + ", jobTitle="
				+ jobTitle + ", offices=" + offices + "]";
	}

}
