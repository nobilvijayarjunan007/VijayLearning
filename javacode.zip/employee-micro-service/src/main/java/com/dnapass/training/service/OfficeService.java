package com.dnapass.training.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;

import com.dnapass.training.entity.EmployeeEntity;
import com.dnapass.training.entity.OfficeEntity;
import com.dnapass.training.repo.OfficeRepo;

@Service
public class OfficeService {

	@Autowired
	private OfficeRepo offRepo;

	public OfficeEntity findOffice(String officeName) {
		OfficeEntity office = offRepo.findAll().stream().filter(off -> off.getOfficeCode().equals(officeName)).findAny()
				.get();

		return office;
	}

	public List<OfficeEntity> findOffices() {
		List<OfficeEntity> offices = offRepo.findAll();
		return offices;
	}
	
	

}
