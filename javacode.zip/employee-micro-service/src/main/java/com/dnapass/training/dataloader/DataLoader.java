package com.dnapass.training.dataloader;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.dnapass.training.entity.EmployeeEntity;
import com.dnapass.training.entity.OfficeEntity;

public class DataLoader {

	public static List<OfficeEntity> office() {
		List<OfficeEntity> office = new ArrayList<>();

		OfficeEntity off1 = new OfficeEntity("office1", "San Francisco", "+1 650 219 4782", "100 Market Street",
				"Suite 300", "CA", "USA", "94080", "NA");

		OfficeEntity off2 = new OfficeEntity("office2", "Boston", "+1 215 837 0825", "1550 Court Place", "Suite 102",
				"MA", "USA", "02107", "NA");

		OfficeEntity off3 = new OfficeEntity("office3", "NYC", "+1 212 555 3000", "523 East 53rd Street", "apt. 5A",
				"NY", "USA", "10022", "NA");

/////////////////////////

		EmployeeEntity emp1 = new EmployeeEntity(null, "Murphy", "Diane", "x5800", "dmurphy@classicmodelcars.com", null,
				"President", off1);

		EmployeeEntity emp2 = new EmployeeEntity(null, "Patterson", "Steve", "x4334", "spatterson@classicmodelcars.com",
				null, "Sales Rep", off2);

		EmployeeEntity emp3 = new EmployeeEntity(null, "Tseng", "Foon Yue", "x2248", "ftseng@classicmodelcars.com",
				null, "Sales Rep", off2);

		EmployeeEntity emp4 = new EmployeeEntity(null, "Vanauf", "George", "x4102", "gvanauf@classicmodelcars.com",
				emp1, "Sales Rep", off1);
		EmployeeEntity emp5 = new EmployeeEntity(null, "Foon", "Diane", "x5800", "dmurphy@classicmodelcars.com", null,
				"President", off3);

		EmployeeEntity emp6 = new EmployeeEntity(null, "StevePatterson", "Steve", "x4334",
				"spatterson@classicmodelcars.com", emp1, "Sales Rep", off1);

		EmployeeEntity emp7 = new EmployeeEntity(null, "Tseng", "Foon Foon", "x2248", "ftseng@classicmodelcars.com",
				emp5, "Sales Rep", off3);

		EmployeeEntity emp8 = new EmployeeEntity(null, "FoonVanauf", "George", "x4102", "gvanauf@classicmodelcars.com",
				null, "Sales Rep", off2);

		off1.setEmployees(Arrays.asList(emp1, emp4, emp6));
		off2.setEmployees(Arrays.asList(emp2, emp3, emp8));
		off3.setEmployees(Arrays.asList(emp5, emp7));

		office.add(off1);
		office.add(off3);
		office.add(off2);

		return office;
	}

	//
	public static List<OfficeEntity> officeDetailsLoader() {
		List<OfficeEntity> offices = new ArrayList<>();
		offices.add(new OfficeEntity("office1", "San Francisco", "+1 650 219 4782", "100 Market Street", "Suite 300",
				"CA", "USA", "94080", "NA", null));

		offices.add(new OfficeEntity("office2", "Boston", "+1 215 837 0825", "1550 Court Place", "Suite 102", "MA",
				"USA", "02107", "NA", null));

		offices.add(new OfficeEntity("office3", "NYC", "+1 212 555 3000", "523 East 53rd Street", "apt. 5A", "NY",
				"USA", "10022", "NA", null));

		offices.add(new OfficeEntity("office4", "Paris", "+33 14 723 4404", "43 Rue Jouffroy D\"abbans", null, null,
				"France", "75017", "EMEA", null));

		offices.add(new OfficeEntity("off5", "Tokyo", "+81 33 224 5000", "4-1 Kioicho", null, "Chiyoda-Ku", "Japan",
				"102-8578", "Japan", null));

		offices.add(new OfficeEntity("off6", "Sydney", "+61 2 9264 2451", "5-11 Wentworth Avenue", "Floor #2", null,
				"Australia", "NSW 2010", "APAC", null));

		offices.add(new OfficeEntity("off7", "London", "+44 20 7877 2041", "25 Old Broad Street", "Level 7", null, "UK",
				"EC2N 1HN", "EMEA", null));

		return offices;
	}

	public static List<EmployeeEntity> employeesLoader() {
		List<EmployeeEntity> emps = new ArrayList<>();

		emps.add(new EmployeeEntity(null, "Murphy", "Diane", "x5800", "dmurphy@classicmodelcars.com", null, "President",
				officeDetailsLoader().get(0)));

		emps.add(new EmployeeEntity(null, "Patterson", "Steve", "x4334", "spatterson@classicmodelcars.com", null,
				"Sales Rep", officeDetailsLoader().get(1)));

		emps.add(new EmployeeEntity(null, "Tseng", "Foon Yue", "x2248", "ftseng@classicmodelcars.com", null,
				"Sales Rep", officeDetailsLoader().get(2)));

//		emps.add(new EmployeeEntity(null, "Vanauf", "George", "x4102", "gvanauf@classicmodelcars.com", null,
//				"Sales Rep", null, null));
//
//		emps.add(new EmployeeEntity(null, "Bondur", "Loui", "x6493", "lbondur@classicmodelcars.com", null, "Sales Rep",
//				null, null));
//
//		emps.add(new EmployeeEntity(null, "Hernandez", "Gerard", "x2028", "ghernande@classicmodelcars.com", null,
//				"Sales Rep", null, null));
//
//		emps.add(new EmployeeEntity(null, "Castillo", "Pamela", "x2759", "pcastillo@classicmodelcars.com", null,
//				"Sales Rep", null, null));
//
//		emps.add(new EmployeeEntity(null, "Bott", "Larry", "x2311", "lbott@classicmodelcars.com", null, "Sales Rep",
//				null, null));
//
//		emps.add(new EmployeeEntity(null, "Jones", "Barry", "x102", "bjones@classicmodelcars.com", null, "Sales Rep",
//				null, null));
//
//		emps.add(new EmployeeEntity(null, "Fixter", "Andy", "x101", "afixter@classicmodelcars.com", null, "Sales Rep",
//				null, null));
//
//		emps.add(new EmployeeEntity(null, "Marsh", "Peter", "x102", "pmarsh@classicmodelcars.com", null, "Sales Rep",
//				null, null));
//
//		emps.add(new EmployeeEntity(null, "King", "Tom", "x103", "tking@classicmodelcars.com", null, "Sales Rep", null,
//				null));
//
//		emps.add(new EmployeeEntity(null, "Nishi", "Mami", "x101", "mnishi@classicmodelcars.com", null, "Sales Rep",
//				null, null));
//
//		emps.add(new EmployeeEntity(null, "Kato", "Yoshimi", "x102", "ykato@classicmodelcars.com", null, "Sales Rep",
//				null, null));
//
//		emps.add(new EmployeeEntity(null, "Gerard", "Martin", "x2312", "mgerard@classicmodelcars.com", null,
//				"Sales Rep", null, null));

		return emps;
	}

}
