package com.dnapass.training.day2.exercise;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Application {

	public static void main(String[] args) {
		SpringApplication.run(Application.class, args);

		// stream iterator filter limit forEach
		Stream.iterate(1, e -> e + 1).filter(element -> element % 5 == 0).limit(10).forEach(System.out::println);

		// the same but it is in collection as a list
		// stream iterator filter limit collect
		List<Integer> collect = Stream.iterate(1, element -> element + 1).filter(element -> element % 5 == 0).limit(10)
				.collect(Collectors.toList());
		System.out.println(collect);

		collect.stream().forEach(System.out::println);

		// convert into new list by using map
		// stream filter map
		Stream<Long> map = collect.stream().filter(integer -> integer % 10 == 0).map(integer -> integer.longValue());

		List<Long> list = map.toList();
		System.out.println("+++++++++++long+++++++++++++" + list);
	}

}
