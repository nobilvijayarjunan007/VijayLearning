package com.dnapass.training;

import java.time.Duration;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.gateway.route.RouteLocator;
import org.springframework.cloud.gateway.route.builder.RouteLocatorBuilder;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.context.annotation.Bean;
import org.springframework.core.env.Environment;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import org.springframework.cloud.circuitbreaker.resilience4j.ReactiveResilience4JCircuitBreakerFactory;
import org.springframework.cloud.circuitbreaker.resilience4j.Resilience4JConfigBuilder;
import org.springframework.cloud.client.circuitbreaker.Customizer;
import io.github.resilience4j.circuitbreaker.CircuitBreakerConfig;
import io.github.resilience4j.timelimiter.TimeLimiterConfig;

@SpringBootApplication
//@EnableDiscoveryClient
@EnableEurekaClient
@RestController
public class EmployeeCustomerApiGatewayApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmployeeCustomerApiGatewayApplication.class, args);
	}

	@Autowired
	private Environment environment;

	@GetMapping("/fallback")
	public String getHello() {
		return "Gateway FallBack -> Hi I am FallBack : " + environment.getProperty("local.server.port");
	}

	/*
	 * @Bean public RouteLocator myRoutes(RouteLocatorBuilder builder) { return
	 * builder.routes().route(p ->
	 * p.path("/api/employeesList").uri("lb://employee-micro-service")) .route(p ->
	 * p.path("/customersList").uri("lb://customer-micro-service")).build(); }
	 */

	@Bean
	public Customizer<ReactiveResilience4JCircuitBreakerFactory> defaultCustomiser() {

		return factory -> factory.configureDefault(id -> new Resilience4JConfigBuilder(id)
				.circuitBreakerConfig(CircuitBreakerConfig.ofDefaults())
				.timeLimiterConfig(TimeLimiterConfig.custom().timeoutDuration(Duration.ofMillis(200)).build()).build());
	}

	@Bean
	public Customizer<ReactiveResilience4JCircuitBreakerFactory> defaultCustomiserSliding() {

		return factory -> factory.configureDefault(id -> new Resilience4JConfigBuilder(id)
				.circuitBreakerConfig(CircuitBreakerConfig.custom().slidingWindowSize(10).build())
				.timeLimiterConfig(TimeLimiterConfig.custom().timeoutDuration(Duration.ofMillis(200)).build()).build());
	}

}
