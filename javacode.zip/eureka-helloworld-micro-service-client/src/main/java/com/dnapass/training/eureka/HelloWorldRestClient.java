package com.dnapass.training.eureka;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@RestController
public class HelloWorldRestClient {
	private static final String RESOURCE_PATH = "http://localhost:8080/api/v1/helloworld";

	@Autowired
	private RestTemplate restTemplate;

	@GetMapping("/getMessage")
	// @RequestMapping("/getMessage")
	public String getGreeting() {
		ResponseEntity<String> response = restTemplate.getForEntity(RESOURCE_PATH, String.class);
		return response.getBody();

	}
}
