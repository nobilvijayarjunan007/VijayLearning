package com.dnapass.training.employee;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeeCustomerMicroServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
