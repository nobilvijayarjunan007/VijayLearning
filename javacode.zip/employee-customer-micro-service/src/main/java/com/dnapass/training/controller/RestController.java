//package com.dnapass.training.controller;
//
//import java.util.List;
//import java.util.stream.IntStream;
//
//import javax.swing.Spring;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.http.ResponseEntity;
//import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.client.RestTemplate;
//
//import com.dnapass.training.models.Customer;
//import com.dnapass.training.models.Employee;
//
//@org.springframework.web.bind.annotation.RestController
//
//public class RestController {
//
//	private static final String HTTP_EMPLOYEE_MICRO_SERVICE_API_EMPLOYEES_EMPLOYEES_LIST = "http://employee-micro-service/api/employees/employeesList";
//
//	@Autowired
//	private RestTemplate employeeRestTemplate;
//
////	@Autowired
////	private CustomerClient customerFeignClient;
//
//	@GetMapping("/api/employees/{id}")
//	public String findEmployee() {
//
//		Employee employee = employeeRestTemplate.getForObject(HTTP_EMPLOYEE_MICRO_SERVICE_API_EMPLOYEES_EMPLOYEES_LIST,
//				Employee.class);
//		System.out.println(employee);
//
////		ResponseEntity<List<Customer>> customers = customerFeignClient.getCustomers();
////		System.out.println(customers);
//
//		return "List Created";
//	}
//
//}
