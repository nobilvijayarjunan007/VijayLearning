package com.dnapass.training.java.se.date.day8;

import org.junit.Assert;
import org.junit.Test;

public class ExtractDateAndTimeTest {
	@Test
	public void test1() {
		Assert.assertEquals(2016-07-14,ExtractDateAndTime.extractDateFromString("2016-07-14"));
	
	}
}
