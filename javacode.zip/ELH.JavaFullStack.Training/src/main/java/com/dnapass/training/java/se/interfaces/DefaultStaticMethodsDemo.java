package com.dnapass.training.java.se.interfaces;

public class DefaultStaticMethodsDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Vehicle car = new Car("BMW");
		System.out.println(car.getBrand());
		System.out.println(car.speedup());
		System.out.println(car.slowDown());
		System.out.println(car.turnAlarmOn());
		System.out.println(car.turnAlarmOff());
		System.out.println(Vehicle.getHorsePower(2500, 480));

		Vehicle bike = new Motorbike("ACTIVA 4G");
		System.out.println(bike.getBrand());
		System.out.println(bike.speedup());
		System.out.println(bike.slowDown());
		System.out.println(bike.turnAlarmOn());
		System.out.println(bike.turnAlarmOff());
		System.out.println(Vehicle.getHorsePower(2500, 480));
	}

}
