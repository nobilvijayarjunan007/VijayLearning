package com.dnapass.training.java.se.date.day8;

import java.util.Calendar;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class MaximumDate {

	public static Logger logger = LoggerFactory.getLogger(MaximumDate.class);
	public static void main(String[] args) {
		Calendar cal = Calendar.getInstance();
		System.out.println();

		logger.info("\nCurrent Date and Time: " + cal.getTime());

		int actualMaxYear = cal.getActualMaximum(Calendar.YEAR);
		int actualMaxMonth = cal.getActualMaximum(Calendar.MONTH);
		int actualMaxWeek = cal.getActualMaximum(Calendar.WEEK_OF_YEAR);
		int actualMaxDate = cal.getActualMaximum(Calendar.DATE);

		logger.info(" Maximum Year " + actualMaxYear+"\n");
		logger.info(" Actual Maximum month " + actualMaxMonth+"\n");
		logger.info(" Actual Maximum Week " + actualMaxWeek+"\n");
		logger.info(" Actual Maximum Date " + actualMaxDate + "\n");
		
		
		

	}

}
