package com.dnapass.training.java.se.date.day8;

import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class HashMapDemo {

	public static void main(String[] args) {

		HashMap hm = new HashMap();
		hm.put("Manish", "MGR");
		hm.put("Babu", "CLK");
		hm.put("Rohit", "MGR");
		hm.put("Viru", "PGR");
		Collection values = hm.values();
		Set s = hm.entrySet();
		Iterator i = s.iterator();
		while (i.hasNext()) {

			Map.Entry me = (Map.Entry) i.next();
			if ("MGR".equals(me.getValue())) {

				System.out.println(me.getKey());
			}
		}

	}

}
