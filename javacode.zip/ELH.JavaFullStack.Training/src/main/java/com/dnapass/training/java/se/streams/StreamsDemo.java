package com.dnapass.training.java.se.streams;

import static java.lang.System.out;
import static java.util.Comparator.comparing;
import static java.util.function.Function.identity;
import static java.util.stream.Collectors.averagingDouble;
import static java.util.stream.Collectors.counting;
import static java.util.stream.Collectors.groupingBy;
import static java.util.stream.Collectors.maxBy;
import static java.util.stream.Collectors.partitioningBy;
import static java.util.stream.Collectors.reducing;
import static java.util.stream.Collectors.summingDouble;
import static java.util.stream.Collectors.toCollection;
import static java.util.stream.Collectors.toList;
import static java.util.stream.Collectors.toSet;

import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.TreeSet;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;

import com.dnapass.training.java.se.lambda.DataLoader;
import com.dnapass.training.java.se.lambda.Person;
import com.dnapass.training.java.se.lambda.ProductType;
import com.dnapass.training.java.se.lambda.TransactionsEntity;

public class StreamsDemo {

	public static void main(String[] args) throws IOException {
		StreamsDemo streamsDemo = new StreamsDemo();
		// streamsDemo.demo();
		streamsDemo.demo2();
	}

	private void demo2() {

		List<TransactionsEntity> transactions = DataLoader.newTransaction();
		out.println("Original transaction >> " + transactions);

		// find all transaction of type grocery and return a list of transaction IDS
		// sorted in decreasing
		// order of transaction value. with out streams

		List<Integer> transactionIds = new ArrayList<>();
		out.println("before ids : " + transactionIds);

		List<TransactionsEntity> groceryTransactions = new ArrayList<>();
		out.println("before grocery : " + groceryTransactions);

		for (TransactionsEntity t : transactions) {
			if (t.getType() == ProductType.GROCERY) {
				groceryTransactions.add(t);
			}
		}

		out.println("after grocery : " + groceryTransactions);

		out.println("after grocery by using stream ");
		List<TransactionsEntity> list = transactions.stream().filter(tran -> tran.getAmount() >= 100.00).toList();
		System.out.println(list);

		Long count = transactions.stream().filter(tran -> tran.getAmount() >= 100.00).count();

		System.out.println(count);

		List<TransactionsEntity> list2 = transactions.stream().filter(tran -> tran.getAmount() >= 100.00)
				.dropWhile(tran -> tran.getCity() == "Chennai").toList();
		System.out.println(list2);

		// // Annonymous
		Collections.sort(groceryTransactions, new Comparator<TransactionsEntity>() {

			@Override
			public int compare(TransactionsEntity t1, TransactionsEntity t2) {
				// TODO Auto-generated method stub
				return t2.getAmount().compareTo(t1.getAmount());
			}

		});

		out.println("after grocery >> " + groceryTransactions);

		for (TransactionsEntity t : groceryTransactions) {
			transactionIds.add(t.getId());
		}

		out.println("after ids : " + transactionIds);

		// find all transaction of type grocery and return a list of transaction IDS
		// sorted in decreasing
		// order of transaction value. with streams

		List<Integer> list3 = transactions.stream().filter(tran -> tran.getType() == ProductType.ELECTRIC)
				.sorted(comparing(TransactionsEntity::getId).reversed()).map(t -> t.getId()).toList();
		System.out.println(list3);
		transactionIds = transactions.stream().filter(t -> t.getType() == ProductType.GROCERY)
				.sorted(comparing(TransactionsEntity::getAmount).reversed()).map(TransactionsEntity::getId)
				.collect(Collectors.toList());

		out.println("With Streams >>  " + transactionIds);

		List<Integer> numbers = Arrays.asList(1, 2, 3, 4, 5, 6, 7, 8);
		List<Integer> twoEvenSquares = null;// Arrays.asList(4,16);

		twoEvenSquares = numbers.stream().filter(n -> {
			out.println("filtering " + n);
			return n % 2 == 0;
		}).map(n -> {
			out.println("mapping " + n);
			return n * n;
		}).limit(2).collect(Collectors.toList());// if 3 >> 4 16 36

		out.println(" even Squares >> " + twoEvenSquares);

		// to check that all elements in a stream of transaction have a value higher
		// than 100,

		boolean expensive = transactions.stream().allMatch(t -> t.getAmount() > 10);
		out.println(expensive);

		// to find any grocery transaction

		Optional<TransactionsEntity> gtran = transactions.stream().filter(t -> t.getType() == ProductType.GROCERY)
				.findAny();

		out.println(gtran);

		out.println(gtran.get());

		// return a list of the length of each word from a list
		List<String> words = Arrays.asList("Oracle", "Java", "Magazine");
		out.println(words);
		List<Integer> wordLengths = words.stream().map(String::length).collect(Collectors.toList());
		out.println(wordLengths);

//		// Calculate the sum
		numbers = Arrays.asList(1, 2, 3, 4);
		int sum = numbers.stream().reduce(0, (a, b) -> a + b);
		out.println(sum);

		// calculate the product
		int product = numbers.stream().reduce(1, (a, b) -> a * b);
		out.println(product);

		// calculate the maximum
		int max = numbers.stream().reduce(Integer.MAX_VALUE, Integer::max);
		out.println(max);

		// the read a cost: we perform many boxing operations to repeately add
		// Integer Object together.

		double statementSum = transactions.stream().map(t -> t.getAmount()).reduce(0d, (a, b) -> a + b);
		out.println(statementSum);
		statementSum = transactions.stream().mapToDouble(TransactionsEntity::getAmount).sum(); // works!

		out.println(statementSum);
		// practiced by vijay
		// start
		Double reduce = transactions.stream().filter(t -> t.getType() == ProductType.GROCERY)
				.map(TransactionsEntity::getAmount).reduce(0d, (t1, t2) -> t1 + t2);
		System.out.println(reduce);

		double sum2 = transactions.stream().filter(t -> t.getType() == ProductType.GROCERY)
				.mapToDouble(TransactionsEntity::getAmount).sum();
		System.out.println(sum2);
		// end

		// return a stream of all odd numbers between 10 and 30

		IntStream oddNumbers = IntStream.rangeClosed(10, 31).filter(n -> n % 2 == 1);
		out.println(oddNumbers);
		oddNumbers.forEach(System.out::println);

		// flatMap

		Stream<String> wordsStream = Stream.of("Java", "Magazine", "is", "the", "best", "java");

		Map<String, Long> wordToCount = wordsStream.collect(Collectors.groupingBy(identity(), counting()));

		wordsStream = Stream.of("Java", "Magazine", "is", "the", "best", "java");

		Map<String, Long> letterToCount = wordsStream.map(w -> w.split("")).flatMap(Arrays::stream)
				.collect(groupingBy(identity(), counting()));

		out.println(wordToCount);

		out.println(letterToCount);

		// find all unique words in a array

		String[] arrayyOfWords = { "Java abstraction inheritence encapsulation fuctional", "java Magazine functional" };

		Stream<String> streamOfWords = Arrays.stream(arrayyOfWords);

		streamOfWords.map(line -> line.split("\\s+")) // Stream<String[]>
				.flatMap(Arrays::stream) // Stream<String>
				.distinct() // Stream<String>
				.forEach(out::println);

		// to get a list of the IDs for all the expensive transactions.

		List<Integer> expensiveTransactionsIds = transactions.stream().filter(t -> t.getAmount() > 300)
				.map(TransactionsEntity::getId).collect(toList());
		out.println(expensiveTransactionsIds);

		// generate the set of only the cities that have inexpensive transactions.

		Set<String> cities = transactions.stream().filter(t -> t.getAmount() < 1000).map(TransactionsEntity::getCity)
				.collect(Collectors.toSet());

		out.println(cities);

		// HashSet by passing a consructor reference to it

		cities = transactions.stream().filter(t -> t.getAmount() < 1000).map(TransactionsEntity::getCity)
				.collect(toCollection(TreeSet::new));

		out.println(cities);

		// Summarizing

		long howManyTransactions = transactions.stream().collect(counting());

		out.println(howManyTransactions);

		// calculate the total value of all transactions.

		double totalValue = transactions.stream().collect(summingDouble(TransactionsEntity::getAmount));

		out.println(totalValue);

		// calculate the average value of all transactions.

		double average = transactions.stream().collect(averagingDouble(TransactionsEntity::getAmount));

		out.println(average);

		// highest transaction by using the value of a transaction as a comparison key.

		Optional<TransactionsEntity> highestTransction = transactions.stream()
				.collect(maxBy(comparing(TransactionsEntity::getAmount)));

		highestTransction.ifPresent(out::println);
		// calculate the sum of all transactions using reducing().

		totalValue = transactions.stream().collect(reducing(0.0, TransactionsEntity::getAmount, Double::sum));

		out.println(totalValue);

		// grouping
		// calculate the sum of all transactions by currency.

		Map<String, List<TransactionsEntity>> transactionsByCurrency = transactions.stream()
				.collect(groupingBy(TransactionsEntity::getCurrency));

		out.println(transactionsByCurrency);

		// Partitioning
		// group the transactions into list cheap and expensive

		Map<Boolean, List<TransactionsEntity>> partitionedTransactions = transactions.stream()
				.collect(partitioningBy(t -> t.getAmount() > 200));

		out.println(partitionedTransactions);

		// composing collectors.
		// sum of all transction for each city

		Map<String, Double> cityToSum = transactions.stream()
				.collect(groupingBy(TransactionsEntity::getCity, summingDouble(TransactionsEntity::getAmount)));

		out.println(cityToSum);

		Map<String, Optional<TransactionsEntity>> cityToHighestTransaction = transactions.stream()
				.collect(groupingBy(TransactionsEntity::getCity, maxBy(comparing(TransactionsEntity::getAmount))));

		out.println(cityToHighestTransaction);

		// group the transaction by city , and then we further group the transactions
		// by the cuurency of transaction in each city to get the average transaction
		// value for the cuurency.

		Map<String, Map<String, Double>> cityByCurrencyToAverage = transactions.stream()
				.collect(groupingBy(TransactionsEntity::getCity,
						groupingBy(TransactionsEntity::getCurrency, averagingDouble(TransactionsEntity::getAmount))));
		out.println(cityByCurrencyToAverage);

		// Stream

		// filter
		// Person object that is not at least 21 years of age.
		List<Person> people = DataLoader.newPersons();

		people.stream().filter((p) -> p.getAge() >= 21).forEach(p -> out.println(" " + p.getFirstName()));

		// Predicates

		Predicate<Person> drinkingAge = (p) -> p.getAge() >= 21;

		Predicate<Person> brown = p -> p.getLastName().equals("drunk");

		people.stream().filter(drinkingAge.and(brown)).forEach(p -> out.println(" " + p.getFirstName()));

		// map()

		IntStream ages = people.stream().mapToInt(p -> p.getAge());

		// reduce() SUM(),MAX(),and MIN() COUNT()

		sum = people.stream().mapToInt(Person::getAge).sum();
		out.println(sum);
		// Parallelization

		people.parallelStream().filter(p -> p.getAge() >= 21)
				.forEach(p -> out.println(" " + p.getFirstName() + Thread.currentThread()));

		// sequential() on it.
		List<Integer> listOfNumbers = Arrays.asList(1, 2, 3, 4);

		listOfNumbers.parallelStream().forEach(n -> out.println(n + " " + Thread.currentThread().getName()));

		// number five actually gets added up in every worker thread:
		listOfNumbers = Arrays.asList(1, 2, 3, 4);
		sum = listOfNumbers.parallelStream().reduce(5, Integer::sum);
		// assertThat(sum).isNotEqualTo(15);
		System.out.println(sum);
		listOfNumbers = Arrays.asList(1, 2, 3, 4);
		sum = listOfNumbers.parallelStream().reduce(5, Integer::sum) + 5;
		// assertThat(sum).isEqualTo(15);
		System.out.println(sum);
		IntStream.rangeClosed(1, 100).reduce(0, Integer::sum); // 68,274 A+_
		IntStream.rangeClosed(1, 100).parallel().reduce(0, Integer::sum); // 35476,283 A+_

		ArrayList<Integer> arrayListOfNumbers = new ArrayList<>();

		LinkedList<Integer> linkedListOfNumbers = new LinkedList<>();
		IntStream.rangeClosed(1, 1000000).forEach(i -> {

			arrayListOfNumbers.add(i);

			linkedListOfNumbers.add(i);
		});

		arrayListOfNumbers.stream().reduce(0, Integer::sum); // 5,437,923,224
		arrayListOfNumbers.parallelStream().reduce(0, Integer::sum); // 2,004,849,711
		linkedListOfNumbers.stream().reduce(0, Integer::sum); // 10,664,918,132
		linkedListOfNumbers.parallelStream().reduce(0, Integer::sum); // 13,561,609,611

	}

	private void demo() throws IOException {
		// Building Streams

		Stream<Integer> numbersFromValues = Stream.of(1, 2, 3, 4);
		out.println(numbersFromValues);

		int[] numbersArray = { 1, 2, 3, 4 };
		IntStream numbersFromArray = Arrays.stream(numbersArray);
		// IntStream.range(0,0)

		out.println(numbersFromArray);

		Stream<String> lines = Files.lines(Paths.get("C:\\Users\\vijay_a\\sample1.txt"), Charset.defaultCharset());
		long numberOfsLines = lines.count();
		out.println(numberOfsLines);

		Stream<Integer> intNumbers = Stream.iterate(0, n -> n + 10);
		intNumbers.limit(5).forEach(out::println);// 0,10,20,30,40

		// Referencing a Stream

		Stream<String> stream = Stream.of("a", "b", "c").filter(element -> element.contains("b"));
		out.println(stream);
		Optional<String> anyElement = stream.findAny();

		out.println(anyElement);
		out.println(anyElement.get());

		stream = Stream.of("a", "b", "c").filter(element -> element.contains("b"));

		Optional<String> firstElement = stream.findFirst();

		out.println(firstElement);
		out.println(firstElement.get());

		// an attempt to reuse the same reference after calling the terminals operation
		// will triggered the IllegalStateException

		List<String> elements = Stream.of("abc", "bcd", "c").filter(element -> element.contains("b"))
				.collect(Collectors.toList());
		out.println(elements);

		anyElement = elements.stream().findAny();
		firstElement = elements.stream().findFirst();

		out.println(anyElement);
		out.println(firstElement);

		List<String> list = Arrays.asList("abc1", "abc2", "abc3");

		Stream<String> stream1 = list.stream().filter(element -> {
			out.println("filter() was called");
			return element.contains("2");
		}).map(element -> {
			out.println("map() was called");
			return element.toUpperCase();
		});

		out.println(stream1);

		Optional<String> string = list.stream().filter(element -> {
			out.println("filter() was called");
			return element.contains("3");
		}).map(element -> {
			out.println("map() was called");
			return element.toUpperCase();
		}).findFirst();

		out.println(string);

		long size = list.stream().map(element -> {
			out.println("map was called");
			return element.substring(0, 3);
		}).skip(0).count();

		out.println(size);

		size = list.stream().skip(2).map(element -> {
			out.println("map was called");
			return element.substring(0, 3);
		}).count();

		out.println(size);

	}

	@Override
	public String toString() {
		return " Vijay StreamsDemo [getClass()=" + getClass() + ", hashCode()=" + hashCode() + ", toString()="
				+ super.toString() + "]";
	}

}
