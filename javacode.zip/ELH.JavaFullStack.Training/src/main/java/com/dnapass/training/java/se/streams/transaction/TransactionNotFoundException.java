package com.dnapass.training.java.se.streams.transaction;

public class TransactionNotFoundException extends Exception {

	public TransactionNotFoundException(String string) {
		
	}

	 TransactionNotFoundException() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
