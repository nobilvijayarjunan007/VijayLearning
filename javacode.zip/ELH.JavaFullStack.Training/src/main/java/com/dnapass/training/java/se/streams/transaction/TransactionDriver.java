package com.dnapass.training.java.se.streams.transaction;

import java.util.List;
import java.util.Optional;

import com.dnapass.training.java.se.lambda.ProductType;
import com.dnapass.training.java.se.lambda.TransactionsEntity;

public class TransactionDriver {

	public static void main(String[] args) throws TransactionNotFoundException {

		TransactionsImpl2 tran = new TransactionsImpl2();
		TransactionsEntity tran1 = new TransactionsEntity(10, ProductType.FRUIT, 9999.55, "Mumbai", "INR");

		TransactionsEntity transaction = tran.create(tran1);
		System.out.println(transaction);

		Optional<TransactionsEntity> transactionGetbyId = tran.findById(1);
		System.out.println(transactionGetbyId);

		Optional<List<TransactionsEntity>> findAll = tran.findAll();
		System.out.println(findAll + "\n" + findAll.get());
		TransactionsEntity tran2 = new TransactionsEntity(10, ProductType.ELECTRIC, 8899.55, "Chennai", "INR");
		Optional<TransactionsEntity> update = tran.update(tran2, 10);
		System.out.println(update);
		tran.deleteById(1);
	}

}
