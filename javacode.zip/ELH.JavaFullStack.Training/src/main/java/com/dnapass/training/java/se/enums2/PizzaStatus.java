package com.dnapass.training.java.se.enums2;

public enum PizzaStatus {
	ORDERED, READY, DELIVERED;
}
