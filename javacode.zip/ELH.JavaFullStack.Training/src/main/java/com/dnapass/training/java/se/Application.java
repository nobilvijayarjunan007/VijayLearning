package com.dnapass.training.java.se;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Application {
	private static Logger logger = LoggerFactory.getLogger(Application.class);

	public static void main(String[] args) {
		SpringApplication.run(Application.class, args);

		List<Integer> markList = Dataloaders.markList();
		List<Integer> filterList = Service.filterList(markList, 90);
		List<Integer> filterListBelowGivenValue = Service.filterListBelowGivenValue(markList, 25);

		System.out.println(filterList);
		System.out.println(filterListBelowGivenValue);

	}

}
