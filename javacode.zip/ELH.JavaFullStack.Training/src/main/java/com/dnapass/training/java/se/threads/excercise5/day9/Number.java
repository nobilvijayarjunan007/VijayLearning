package com.dnapass.training.java.se.threads.excercise5.day9;

public class Number implements Runnable {

   int number ;
   public Number(int number) {
	   this.number =number;
	   
   }
	@Override
	public void run() {
		for(int i=1;i<20;i++) {
			
			try {
				Thread.sleep(200);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			if(i%number==0) {System.out.println(Thread.currentThread().getName()+" number"+i);}
			
		}

	}

	public static void main(String[] args) throws InterruptedException {
		
		Number n1 =new Number(2);
		Thread t1 = new Thread(n1);
		Number n2 = new Number(5);
		Thread t2 = new Thread(n2);
		Number n3 = new Number(8);
		Thread t3 = new Thread(n3);
		t1.start();
		t1.join();
		t2.start();
		t3.start();
		System.out.println("All  the threads are started");
	}

}
