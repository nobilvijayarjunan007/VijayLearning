package com.dnapass.training.java.se.threads3.day9;

public class Notifier implements Runnable {
	
	private Message1 msg;
	
	
	
		public Notifier(Message1 msg) {
			// TODO Auto-generated constructor stub
			this.msg =msg;
		}
		
		public void run() {
			
			String name =Thread.currentThread().getName();
			System.out.println(name +"Started");
			 
				try {
					Thread.sleep(1000);
					synchronized (msg) {
					msg.setmsg(name + "Notifier Work Done");
				 msg.notifyAll();
					}
				
						
					
				}
				catch (InterruptedException e){
					e.printStackTrace();
				}	
		
	}

}
