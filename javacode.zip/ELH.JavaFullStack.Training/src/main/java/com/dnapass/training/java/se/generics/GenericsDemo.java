package com.dnapass.training.java.se.generics;

import static java.lang.System.out;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class GenericsDemo {

	public static void main(String[] args) {

		List list = new ArrayList();
		list.add("hello i am with type cast");
		String s = (String) list.get(0); // need cast
		out.println("with type casting >> " + s);

		List<String> list1 = new ArrayList<String>();
		list1.add("hello i am with out type cast");
		String s1 = list1.get(0);
		out.println("without type casting >> " + s1);

		GenericBox<Integer> integerBox;
		integerBox = new GenericBox<Integer>();

		GenericBox<Integer> integerBox1 = new GenericBox();

		Pair<String, Integer> p1 = new OrderedPair<>("Even", 8);
		Pair<String, String> p2 = new OrderedPair<>("hello", "world");

		OrderedPair<String, GenericBox<Integer>> p = new OrderedPair<>("primes", new GenericBox<>());

		GenericBox rawBox = new GenericBox();

		rawBox = integerBox1;
		integerBox1 = rawBox;

		rawBox.setT(8);

		Pair<Integer, String> p3 = new OrderedPair<>(1, "apple");
		Pair<Integer, String> p4 = new OrderedPair<>(2, "pear");
		boolean same = Util.<Integer, String>compare(p3, p4);

		same = Util.compare(p3, p4);

		Pair<String, Integer> p5 = new OrderedPair<>("abc", 1);
		Pair<String, Integer> p6 = new OrderedPair<>("xyz", 2);
		same = Util.<String, Integer>compare(p5, p6);

		same = Util.compare(p5, p6);

		Pair<String, String> p7 = new OrderedPair<>("abc", "1");
		Pair<String, String> p8 = new OrderedPair<>("abc", "2");
		same = Util.<String, String>compare(p7, p8);

		same = Util.compare(p7, p8);

		integerBox = new GenericBox<Integer>();

		integerBox.setT(new Integer(10));
		integerBox.inspect("some text");
		integerBox.inspect(20);
		// integerBox.inspect2("some text");
		integerBox.inspect2(20);
		integerBox.inspect1(20);
		// integerBox.inspect1(""some text); // error : this is still String !

		Integer[] array = { Integer.valueOf(10), new Integer(20) };

		GenericsDemo.<Integer>countGreaterThanBounded(array, new Integer(10));

		Object someObject = new Object();
		Integer someInteger = new Integer(10);

		someObject = someInteger;// ok
		someInteger = (Integer) someObject; // need casting

		GenericBox<Number> box = new GenericBox<Number>();
		box.add(new Integer(10)); // ok
		box.add(new Double(10.1)); // ok

		GenericBox<Number> boxInteger = new GenericBox<Number>();
		boxInteger.boxTest(new GenericBox<Integer>());
		boxInteger.boxTest(new GenericBox<Thread>());

		boxInteger.boxTest1(new GenericBox<Integer>());

		// boxInteger.boxTest1(new GenericBox<Number>());

		java.util.ArrayList<GenericBox<Integer>> listOfIntegerBoxes = new java.util.ArrayList<>();
		GenericsDemo.<Integer>addBox(Integer.valueOf(20), listOfIntegerBoxes);
		addBox(Integer.valueOf(30), listOfIntegerBoxes);
		addBox(Integer.valueOf(40), listOfIntegerBoxes);
		outputBoxes(listOfIntegerBoxes);

		List<Integer> li = Arrays.asList(1, 2, 3);
		out.println("sum = " + sumOfList1(li));

		List<Double> ld = Arrays.asList(1.2, 2.3, 3.5);
		out.println("sum = " + sumOfList(ld));

		List<Integer> li1 = Arrays.asList(1, 2, 3);
		List<String> ls = Arrays.asList("one", "two", "three");
		// GenericsDemo.PrintList(li1);
		// GenericsDemo.PrintList(ls);

		GenericsDemo.PrintList1(li1);
		GenericsDemo.PrintList1(ls);

		List<Integer> intList = new ArrayList<>();
		// List<Number> numList =intList; //compiler error

		List<? extends Integer> intList1 = new ArrayList<>();
		List<? extends Number> numList1 = intList1; // ok List<? extends Integer> is a // subtype of List<? extends
													// Number>

	}

	public static void addNumbers(List<? super Integer> list) {
		for (int i = 1; i <= 10; i++) {
			list.add(i);
		}
	}

	public static void PrintList1(List<?> list) {
		for (Object elem : list) {
			out.println(elem + " ");
			out.println();
		}

	}

	public static void PrintList(List<Object> list) {
		for (Object elem : list) {
			out.println(elem + " ");
			out.println();
		}
	}

	public static String sumOfList1(List<Integer> li) {

		return null;
	}

	public static double sumOfList(List<? extends Number> list) {

		double s = 0.0;
		for (Number n : list)
			s += n.doubleValue();

		return s;
	}

	public static <T> int countGreaterThan(T[] anArray, T elem) {
		int count = 0;
		for (T e : anArray)// compileTime error
			++count;
		return count;
	}

	public static <T extends Comparable<T>> int countGreaterThanBounded(T[] anArray, T elem) {

		int count = 0;
		for (T e : anArray)
			if (e.compareTo(elem) > 0)
				++count;
		return count;

	}

	public static <U> void outputBoxes(java.util.List<GenericBox<U>> boxes) {

		int counter = 0;
		for (GenericBox<U> box : boxes) {
			U boxContents = box.getT();

			out.println("Box #" + counter + " contains [" + boxContents.toString() + "]");
			counter++;
		}

	}

	public static <U> void addBox(U u, java.util.List<GenericBox<U>> boxes) {
		GenericBox<U> box = new GenericBox<>();
		box.setT(u);
		boxes.add(box);
	}

}
