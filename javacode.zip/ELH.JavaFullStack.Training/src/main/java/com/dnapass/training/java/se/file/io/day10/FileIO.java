package com.dnapass.training.java.se.file.io.day10;

import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.io.Serializable;
import java.io.Writer;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class FileIO {

}
class CopyByte {
	public static void copyBytes() throws IOException {
		FileInputStream in = null;
		FileOutputStream out = null;
		try {
			in = new FileInputStream("input.txt");
			out = new FileOutputStream("output.txt");
			int c;
			while ((c = in.read()) != -1) {
				out.write(c);
			}
		} finally {
			if (in != null) {
				in.close();
			}
			if (out != null) {
				out.close();
			}
		}

	}
}
class CopyCharacters {
	public static void copyCharacters() throws IOException {
		FileReader inputStream = null;
		FileWriter outputStream = null;
		try {
			inputStream = new FileReader("xanadu.txt");
			outputStream = new FileWriter("characteroutput.txt");

			int c;
			while ((c = inputStream.read()) != -1) {
				outputStream.write(c);
			}
		} finally {
			if (inputStream != null) {
				inputStream.close();
			}
			if (outputStream != null) {
				outputStream.close();
			}
		}

	}

}

class CopyLine {
	public static void main(String[] args) throws IOException {
		BufferedReader inputStream = null;
		PrintWriter outputStream = null;
		try {
			inputStream = new BufferedReader(new FileReader("xanadu.txt"));
			outputStream = new PrintWriter(new FileWriter("characteroutput.txt"));

			String l;
			while ((l = inputStream.readLine()) != null) {
				outputStream.println(l);
			}
		} finally {
			if (inputStream != null) {
				inputStream.close();
			}
			if (outputStream != null) {
				outputStream.close();
			}
		}

	}

}

class CopyExample {
	private static final String IMAGE_FILE = "exampleimage.jpg";
	private static final String IMAGE_COPY = "exampleimagecopy.jpg";
	private static final String TEXT_FILE = "exampleInput.txt";
	private static final String TEXT_COPY = "exampleInputCopy.txt";

	public void copyBinaryFile() throws IOException {
		System.out.println(String.format("Copying Image file %s to %s", IMAGE_FILE, IMAGE_COPY));

		try (InputStream in = new FileInputStream(IMAGE_FILE); OutputStream out = new FileOutputStream(IMAGE_COPY)) {

			byte[] data = new byte[16];
			while ((in.read(data)) != -1) {
				out.write(data);
			}
			out.flush();

		} catch (FileNotFoundException e) {
			System.err.println(String.format("Unable to find file: %s", e.getMessage()));
		} catch (IOException e) {
			System.err.println(String.format("Exception reading or writing: %s", e.getMessage()));
		}
	}

	public void copyTextFile() throws IOException {

		System.out.println(String.format("Copying Image file %s to %s", TEXT_FILE, TEXT_COPY));

		try (BufferedReader in = new BufferedReader(new FileReader(TEXT_FILE));
				BufferedWriter out = new BufferedWriter(new FileWriter(TEXT_COPY))) {
			String line;

			while ((line = in.readLine()) != null) {
				out.write(line);
				out.newLine();
			}
			out.flush();
		} catch (FileNotFoundException e) {
			System.err.println(String.format("Unable to find file: %s", e.getMessage()));
		} catch (IOException e) {
			System.err.println(String.format("Exception reading or writing: %s", e.getMessage()));
		} finally {

		}
	}

}

class FileObjectExample {
	private static final String FILE_NAME = "exampleInput.txt";

	public void demo() throws IOException {
		File exampleInput = new File(FILE_NAME);
		System.out.println(String.format("Does it exist? %b", exampleInput.exists()));
		System.out.println(String.format("is it a directory? %b", exampleInput.isDirectory()));
		System.out.println(String.format("is it a file? %b", exampleInput.isFile()));
		System.out.println(String.format("can the app read it? %b", exampleInput.canRead()));
		System.out.println(String.format("Absolu5te path: %s", exampleInput.getAbsolutePath()));
		System.out.println(String.format("path: %s", exampleInput.getPath()));

		FileReader reader = null;
		BufferedWriter out = null;

		try {
			reader = new FileReader(exampleInput);
			out = new BufferedWriter(new FileWriter(exampleInput));
		} finally {
			if (reader != null)
				reader.close();
			if (out != null)
				out.close();
		}

	}

}

class InputStreamExample {
	private static final String FILE_NAME = "exampleInput.txt";

	public void useFileInputSteram() throws IOException {

		System.out.println(String.format("Reading File %s using a FileInputStream", FILE_NAME));

		InputStream is = null;
		try {

			is = new FileInputStream(FILE_NAME);
			int input;
			String output = "";
			while ((input = is.read()) != -1) {
				output += (char) input;
			}
			System.out.println();
		} catch (FileNotFoundException e) {
			System.err.println(
					String.format("Exception creating FileInputStream for file %s: %s", FILE_NAME, e.getMessage()));
		} finally {
			if (is != null) {
				is.close();
			}
		}

	}

	public void useFileReader() throws IOException {

		System.err.println(String.format("Reading file %s using a FileReader", FILE_NAME));
		InputStreamReader reader = null;
		try {
			reader = new FileReader(FILE_NAME);
			int input;
			String output = "";
			while ((input = reader.read()) != -1) {
				output += (char) input;
			}
			System.out.println(output);
		} catch (FileNotFoundException e) {
			System.err.println(
					String.format("Exception creating FileInputStream for file %s: %s", FILE_NAME, e.getMessage()));
		} finally {
			if (reader != null) {
				reader.close();
			}
		}

	}

	public void useBufferedReader() throws IOException {
		System.out.println(String.format("Reading file %s using a BufferedReader", FILE_NAME));

		try (BufferedReader reader = new BufferedReader(new FileReader(FILE_NAME))) {

			String line;
			while ((line = reader.readLine()) != null) {
				System.out.println(line);
			}

		} catch (FileNotFoundException e) {
			System.err.println(
					String.format("Exception creating BufferedReader for file %s: %s", FILE_NAME, e.getMessage()));
		}

	}

}

class OutputStreamsExample {
	static Logger LOGGER = LoggerFactory.getLogger(FileOperations.class);
	private static final String STREAM_OUTPUT_FILE = "streamOutput.txt";
	private static final String WRITER_OUTPUT_FILE = "writerOutput.txt";
	private static final String BUFFERED_OUTPUT_FILE = "bufferedOutput.txt";

	private static final String OUTPUT_TEXT = "This is my example text.\nI'ts not terribly long or exciting";

	public void useFileOutputStream() throws IOException {
		System.out.println(String.format("writing file %s using a FileOutputStream", STREAM_OUTPUT_FILE));

		try (FileOutputStream out = new FileOutputStream(STREAM_OUTPUT_FILE);) {
			byte[] data = OUTPUT_TEXT.getBytes();
			out.write(data);
			out.flush();
		} catch (FileNotFoundException e) {
			System.err.println(String.format("Exception  creating FileOutputStream for file %s: %s", STREAM_OUTPUT_FILE,
					e.getMessage()));
		} catch (IOException e) {
			System.err
					.println(String.format(" Exception writing  to file %s :%s, ", STREAM_OUTPUT_FILE, e.getMessage()));

		}

	}

	public void useFileWriter() throws IOException {
		System.out.println(String.format("Writing file %s using a FileWriter", WRITER_OUTPUT_FILE));

		try (FileWriter out = new FileWriter(WRITER_OUTPUT_FILE);) {

			out.write(OUTPUT_TEXT);
			out.flush();
		} catch (FileNotFoundException e) {
			System.err.println(String.format("Exception  creating FileOutputStream for file %s: %s", WRITER_OUTPUT_FILE,
					e.getMessage()));
		} catch (IOException e) {
			System.err
					.println(String.format(" Exception writing  to file %s :%s, ", WRITER_OUTPUT_FILE, e.getMessage()));

		}
	}

	public void useBufferedWriter() throws IOException {
		System.out.println(String.format("writing file %s using a FileWriter", BUFFERED_OUTPUT_FILE));
		BufferedWriter out = null;
		String[] lines = { "This is my first line of text", "This is second line", "And this is third line" };

		try {
			out = new BufferedWriter(new FileWriter(BUFFERED_OUTPUT_FILE));
			for (String line : lines) {
				out.write(line);
				out.newLine();
			}

			out.flush();
		} catch (FileNotFoundException e) {
			System.err.println(String.format("Exception  creating FileOutputStream for file %s: %s",
					BUFFERED_OUTPUT_FILE, e.getMessage()));

		} catch (IOException e) {
			System.err.println(
					String.format(" Exception writing  to file %s :%s, ", BUFFERED_OUTPUT_FILE, e.getMessage()));

		}

		finally {
			if (out != null) {
				out.close();
			}
		}
	}

	public void writeFileWithDataOutputStream() {
		final double[] prices = { 19, 99, 9.99, 15.99, 4.99 };
		final int[] units = { 12, 8, 13, 29, 50 };
		final String[] descs = { "Java T-shirt", "Java Mug", "Duke Juggling dolls", "java Pin", "java Key Chain" };
		try (DataOutputStream out = new DataOutputStream(
				new BufferedOutputStream(new FileOutputStream("C:/Project_Work/workspace/java-io-guide/sample.txt")))) {
			for (int i = 0; i < prices.length; i++) {

				out.writeDouble(prices[i]);
				out.writeInt(units[i]);
				out.writeUTF(descs[i]);

			}
		} catch (IOException e) {
			LOGGER.error(e.getMessage());

		}
	}
}

class FileOperations {

	

	static Logger LOGGER = LoggerFactory.getLogger(FileOperations.class);

	public void createFile() {
		File file = new File("C:/Project_Work/workspace/java-io-guide/sample.txt");

		try {
			if (file.createNewFile()) {
				LOGGER.info("File is Created !!");
			} else {
				LOGGER.info("File is already exist");
			}
		} catch (IOException e) {
			LOGGER.error(e.getMessage());
		}

	}

	public void deleteFile() {
		File file = new File("C:/Project_Work/workspace/java-io-guide/sample.txt");
		if (file.delete()) {
			LOGGER.info(file.getName() + "Created !!");

		} else {
			LOGGER.info("Delete operation failed");
		}
	}

	public void RenameFile() {
		File file = new File("C:/Project_Work/workspace/java-io-guide/sample.txt");

		boolean hasRename = file.renameTo(new File("C:/Project_Work/workspace/java-io-guide/sample2.txt"));

		if (hasRename) {
			LOGGER.info("File Rename successful");

		} else {
			LOGGER.info("File Rename failed");
		}
	}

	public void copyFile() {
		try (InputStream inStream = new FileInputStream("sample2.txt");

				OutputStream outStream = new FileOutputStream("sample1.txt")) {
			byte[] buffer = new byte[1024];
			int length;
			while ((length = inStream.read(buffer)) > 0) {
				outStream.write(buffer, 0, length);

			}
		} catch (IOException e) {
			LOGGER.error(e.getMessage());
		}
	}

	public void moveFile() {
		File file = new File("C:/Project_Work/workspace/java-io-guide/sample.txt");

		boolean hasRename = file.renameTo(new File("C:/Project_Work/workspace/java-io-guide/src/sample.txt"));

		if (hasRename) {
			LOGGER.info("File is moved successful");

		} else {
			LOGGER.info("File is fail failed");
		}
	}

	public void writeFile() {
		try (BufferedWriter bw = new BufferedWriter(
				new FileWriter("C:/Project_Work/workspace/java-io-guide/src/sample.txt"))) {

			String content = " This is the content to write into file\n";

			bw.write(content);
		} catch (IOException e) {
			LOGGER.error(e.getMessage());
		}
	}

	public void appendToExitingFile() {
		try (Writer writer = new FileWriter("C:/Project_Work/workspace/java-io-guide/src/sample.txt", true);
				BufferedWriter bw = new BufferedWriter(writer)) {
			String content = "append something to existing file\n";

			bw.write(content);
		} catch (IOException e) {
			LOGGER.error(e.getMessage());
		}
	}

	public void getFileSize() {
		File file = new File("C:/Project_Work/workspace/java-io-guide/sample.txt");
		if (file.exists()) {
			double bytes = file.length();
			double kilobytes = (bytes / 1024);
			double megabytes = (kilobytes / 1024);
			double gigabytes = (megabytes / 1024);
			double terabytes = (gigabytes / 1024);
			double petabytes = (terabytes / 1024);
			double exabytes = (petabytes / 1024);
			double zettabytes = (exabytes / 1024);
			double yottabytes = (zettabytes / 1024);

			System.out.println("bytes :" + bytes);
			System.out.println("kilobytes :" + kilobytes);
			System.out.println("megabytes :" + megabytes);
			System.out.println("gigabytes :" + gigabytes);
			System.out.println("terabytes :" + terabytes);
			System.out.println("petabytes :" + petabytes);
			System.out.println("exabytes :" + exabytes);
			System.out.println("zettabytes :" + zettabytes);

		} else {
			System.out.println("File does not exists");
		}
	}

	public void getFilePath() {
		File file = new File("C:/Project_Work/workspace/java-io-guide/sample.txt");
		String absolutePath = file.getAbsolutePath();
		String filePath = absolutePath.substring(0, absolutePath.lastIndexOf(File.separator));
		System.out.println(filePath);
	}

}

class ObjectStreamExample {
	public void readObject() {
		try (ObjectInputStream in = new ObjectInputStream(new FileInputStream("employess.txt"))) {
			final Employee employee = (Employee) in.readObject();
			System.out.println("printing employee object details");
			System.out.println(employee.getId() + " " + employee.getName());
			System.out.println("printing address object details");
		} catch (IOException | ClassNotFoundException e) {
			e.printStackTrace();
		}
	}

	public void writeObject() {
		try (ObjectOutputStream in = new ObjectOutputStream(new FileOutputStream("employess.txt"))) {
			final Employee employee = new Employee(1, "name");
			System.out.println("printing employee object details");
			System.out.println(employee.getId() + " " + employee.getName());
			System.out.println("printing address object details");
		} catch (IOException e) {
			e.printStackTrace();
		}

	}
}

class Employee implements Serializable {
	private static final long serialVersionUID = 1L;
	private int id;
	private String name;

	public Employee(int id, String name) {
		super();
		this.id = id;
		this.name = name;
	}

	public Employee() {
		super();
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

}
