package com.dnapass.training.java.se;

import java.util.ArrayList;
import java.util.List;

public class Dataloaders {

	public static List<Integer> markList() {
		List<Integer> markList = new ArrayList();

		markList.add(300);
		markList.add(90);
		markList.add(9);
		markList.add(45);
		markList.add(56);
		markList.add(90);
		markList.add(67);
		markList.add(45);
		markList.add(12);
		markList.add(90);
		markList.add(50);
		markList.add(43);

		return markList;
	}
}
