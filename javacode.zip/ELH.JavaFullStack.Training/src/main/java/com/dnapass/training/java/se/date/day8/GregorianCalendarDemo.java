package com.dnapass.training.java.se.date.day8;

import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.SimpleTimeZone;
import java.util.TimeZone;

public class GregorianCalendarDemo {

	public static void main(String[] args) {
		String [] ids = TimeZone.getAvailableIDs(-8*60*60*1000);

		if (ids.length==0) {
			
			System.exit(0);
		}
		System.out.println("Current Time");
		
		
		SimpleTimeZone pdt=new SimpleTimeZone(-8*60*60*1000,ids[0]);
		
		pdt.setStartRule(Calendar.APRIL,1, Calendar.SUNDAY,2*60*60*60);
		
		pdt.setEndRule(Calendar.OCTOBER,-1, Calendar.SUNDAY,2*60*60*60);
		
		Calendar calendar = new GregorianCalendar(pdt);
		
		Date trialTime = new Date();
		
		calendar.setTime(trialTime);
		
		System.out.println(calendar.get(Calendar.ERA));
		System.out.println(calendar.get(Calendar.YEAR));
		System.out.println((calendar.get(Calendar.MONTH)+1));
		System.out.println(calendar.get(Calendar.WEEK_OF_YEAR));
		System.out.println(calendar.get(Calendar.WEEK_OF_MONTH));
		System.out.println(calendar.get(Calendar.DATE));
		System.out.println(calendar.get(Calendar.DAY_OF_MONTH));
		System.out.println(calendar.get(Calendar.DAY_OF_YEAR));
		System.out.println(calendar.get(Calendar.DAY_OF_WEEK));
		System.out.println(calendar.get(Calendar.DAY_OF_WEEK_IN_MONTH));
		System.out.println(calendar.get(Calendar.AM_PM));
		System.out.println(calendar.get(Calendar.HOUR));
		System.out.println(calendar.get(Calendar.HOUR_OF_DAY));
		System.out.println(calendar.get(Calendar.SECOND));
		System.out.println(calendar.get(Calendar.MILLISECOND));
		System.out.println(calendar.get(Calendar.ZONE_OFFSET/(60*60*1000)));
		System.out.println(calendar.get(Calendar.DST_OFFSET)/(60*60*1000));
		
		
	}

}
