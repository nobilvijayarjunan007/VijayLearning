package com.dnapass.training.java.se.threads2.day9;

public class ThreadSleep {
	public static  void sleep() throws InterruptedException {
		// TODO Auto-generated method stub
		
		long start  = System.currentTimeMillis();
		 Thread.sleep(2000);
		 
		 System.out.println("Sleep time in ms : " +(System.currentTimeMillis() - start) );
			
	}
		
}
