package com.dnapass.training.java.se.lambda.expression;
@FunctionalInterface
public interface CheckPeople {

	boolean test(People p);
}
