package com.dnapass.training.java.se.threads.excercise2.day9;

public class DemoThread1 implements Runnable {

	public static void main(String[] args) {

		Thread thread1 = new Thread(new DemoThread1());
		Thread thread2 = new Thread(new DemoThread1());
		Thread thread3 = new Thread(new DemoThread1());
		thread1.start();
		thread2.start();
		thread3.start();
	}

	@Override
	public void run() {
		int count = 0;
		for (int i = 1; i <= 10; i++) {
			System.out.println("running child Thread in loop : " + i);
			try {
				Thread.sleep(2000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			count++;
		}
		System.out.println(count);
	}

}
