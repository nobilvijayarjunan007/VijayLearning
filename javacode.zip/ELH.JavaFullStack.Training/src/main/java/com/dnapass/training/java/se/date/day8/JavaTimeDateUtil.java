package com.dnapass.training.java.se.date.day8;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.Month;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.time.temporal.TemporalAdjusters;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Set;

public class JavaTimeDateUtil {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Date today = new Date();
		System.out.println("Note the time includes the default timezone - " + today.toString());
		Date twentysevenFeb2017Date = new Date(2017, 1, 27);
		System.out.println("Now  deprecated new Date(day,month,year) - but note month starts at zero,and year 1990 -"
				+ twentysevenFeb2017Date);

		Calendar twentysevenFeb2017Calendar = new GregorianCalendar(2017, 1, 27);
		System.out.println("Calendar - month starts at zero,but year fixed - " + twentysevenFeb2017Calendar.getTime());

		DateFormat ddMMyyyySDF = new SimpleDateFormat("dd/MM/YYYY");
		System.out.println("DateFormat is not ThreadSafe - " + ddMMyyyySDF.format(twentysevenFeb2017Date));

		displayCurrentdate();

		localDateTimesExample();

		formatDateTime();
		timeArithmetic();
		localDateTimeArithmetic();

		 //zonedDateTimeArithmetic();
		// dateArithmetic();
		// displayCurrentdateTime();

		// displayCurrentdateTime();
		//zonedDateTimeArithmetic();

	}

	public static void localDateTimesExample() {
		LocalDate currentLocaldate = LocalDate.now();
		System.out.println("currentLocaldate - yyyy-MM-dd - " + currentLocaldate);

		LocalDate twentysevenFeb2017LocalDate = LocalDate.of(2017, 2, 27);
		System.out.println("twentysevenFeb2017LocalDate - yyyy-MM-dd - " + twentysevenFeb2017LocalDate);

		twentysevenFeb2017LocalDate = twentysevenFeb2017LocalDate.withMonth(12).withYear(2017).withDayOfMonth(25);
		System.out.println("twentysevenFeb2017LocalDate  - with -" + twentysevenFeb2017LocalDate);

		LocalDate parsetwentysevenFeb2017LocalDate = LocalDate.parse("2017-02-27",
				DateTimeFormatter.ofPattern("yyyy-MM-dd"));
		System.out.println(
				"parsetwentysevenFeb2017LocalDate - pattern - yyyy-MM-dd - " + parsetwentysevenFeb2017LocalDate);

		twentysevenFeb2017LocalDate = twentysevenFeb2017LocalDate.plusDays(1);
		System.out.println("twentysevenFeb2017LocalDate - immutable - " + twentysevenFeb2017LocalDate);

		LocalTime CurrentLocalTime = LocalTime.now();
		System.out.println("currentLocalTime -  yyyy-MM-dd - " + CurrentLocalTime);

		LocalTime ParseLocalTime = LocalTime.parse("13:44");
		System.out.println("ParseLocalTime - " + ParseLocalTime);

		ParseLocalTime = LocalTime.parse("13:44:25");
		System.out.println("ParseLocalTime - immutable " + ParseLocalTime);

	}

	public static void displayCurrentdate() {

		LocalTime myObj = LocalTime.now();
		LocalDate.of(2015, 02, 20);

		LocalDate.parse("2015-02-20");
		System.out.println(myObj);

	}

	public static void displayCurrentdateTime() {

		LocalDateTime myObj = LocalDateTime.now();
		System.out.println(myObj);

		LocalDateTime currentLocalDateTime = LocalDateTime.now();
		System.out.println("currentLocalDateTime" + currentLocalDateTime);

		currentLocalDateTime = currentLocalDateTime.parse("2019-06-21 T23:53:00:123");
		System.out.println("currentLocalDateTime - parse -" + currentLocalDateTime);

		currentLocalDateTime = currentLocalDateTime.minusYears(10);
		System.out.println("currentLocalDateTime - minus 10 years -" + currentLocalDateTime);

	}

	public static void formatDateTime() {

		LocalDateTime myDateObj = LocalDateTime.now();
		System.out.println("Before Formatting : " + myDateObj);
		DateTimeFormatter myFormatObj = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss");

		String formattedDate = myDateObj.format(myFormatObj);
		System.out.println("After Formatting : " + formattedDate);
	}

	public static void timeArithmetic() {
		LocalTime now = LocalTime.now();
		LocalTime sixThirty = LocalTime.parse("06:30");
		LocalTime sevenThirty = LocalTime.parse("06:30").plus(1, ChronoUnit.HOURS);

		int six = LocalTime.parse("06:30").getHour();
		boolean isbefore = LocalTime.parse("06:30").isBefore(LocalTime.parse("07:30"));
		LocalTime maxTime = LocalTime.MAX;

	}

	public static void dateArithmetic() {
		LocalDate tomorrow = LocalDate.now().plusDays(1);
		LocalDate previousMonthSameDay = LocalDate.now().minus(1, ChronoUnit.HOURS);
		DayOfWeek sunday = LocalDate.parse("2016-06-12").getDayOfWeek();

		int twelve = LocalDate.parse("2016-06-12").getDayOfMonth();
		boolean leapyear = LocalDate.now().isLeapYear();
		boolean notBefore = LocalDate.parse("2016-06-12").isBefore(LocalDate.parse("2016-06-11"));

		boolean isAfter = LocalDate.parse("2016-06-12").isAfter(LocalDate.parse("2016-06-11"));
		LocalDateTime beginnningOfday = LocalDate.parse("2016-06-12").atStartOfDay();
		LocalDate firstDayOfMonth = LocalDate.parse("2016-06-12").with(TemporalAdjusters.firstDayOfMonth());

	}

	public static void localDateTimeArithmetic() {
		LocalDateTime.now();
		LocalDateTime.of(2015, Month.FEBRUARY, 20, 06, 30);
		LocalDateTime.parse("2015-02-20T06:30:00");
		LocalDateTime.now().plusDays(1);
		LocalDateTime.now().minusHours(2);
		LocalDateTime.now().getMonth();
	}

	public static void zonedDateTimeArithmetic() {
		ZoneId zoneid = ZoneId.of("Europe/Paris");
		Set<String> allZoneIds = ZoneId.getAvailableZoneIds();

		ZonedDateTime zonedDateTime = ZonedDateTime.of(LocalDateTime.now(), zoneid);
		ZonedDateTime.parse("2015 -05-03T10:15:30 +01:00[Europe/Paris]");

		LocalDateTime localDateTime = LocalDateTime.of(2015, Month.FEBRUARY, 20, 06, 30);
		ZoneOffset offset = ZoneOffset.of("Australia/Sydney");

	}

}
