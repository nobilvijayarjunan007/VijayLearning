package com.dnapass.training.java.se.threads2.day9;

 class ApplicationAnonymus {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
     Runner1  runner1 =new Runner1();
     runner1.setName("ZZZ");
     runner1.run ();
     
     Runner1  runner2 =new Runner1();
     runner2.setName("XXX");
     runner2.run ();
     
     Thread  thread1 =new Thread(new  RunnerRunnable(),"AAA");
     thread1.start ();
     Thread  thread2 =new Thread(new  RunnerRunnable(),"BBB");
     thread2.start ();
     
     Thread  thread3 =new Thread(new  Runnable() {
    	 
    
    	 public void run () {
    		 for (int i =0;i<5;i++) {
    			 System.out.println("Hello : "+ i + "Thread : "+ Thread.currentThread().getName());
    		
    		 
    		 try {
    			 Thread.sleep(100);
    			 }
    		catch (InterruptedException ignored){
    			}
    		 }
    	 }
     }
     ,"CCC");
     thread3.start();
	}
 }
 
 
 
    		 
    		 
    		 
    		 
    			 
    		 
    
