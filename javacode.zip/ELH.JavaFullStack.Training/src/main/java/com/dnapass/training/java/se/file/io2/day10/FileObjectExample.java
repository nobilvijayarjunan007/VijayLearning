package com.dnapass.training.java.se.file.io2.day10;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class FileObjectExample {
	private static final String FILE_NAME = "C:\\Users\\vijay_a\\exampleInput.txt";
	public static void main(String[] args) throws IOException {
		new FileObjectExample().demo();
	}
	public void demo() throws IOException {
		File exampleInput = new File(FILE_NAME);
		System.out.println(String.format("Does it exist? %b", exampleInput.exists()));
		System.out.println(String.format("is it a directory? %b", exampleInput.isDirectory()));
		System.out.println(String.format("is it a file? %b", exampleInput.isFile()));
		System.out.println(String.format("can the app read it? %b", exampleInput.canRead()));
		System.out.println(String.format("Absolu5te path: %s", exampleInput.getAbsolutePath()));
		System.out.println(String.format("path: %s", exampleInput.getPath()));

		FileReader reader = null;
		BufferedWriter out = null;

		try {
			reader = new FileReader(exampleInput);
			out = new BufferedWriter(new FileWriter(exampleInput));
		} finally {
			if (reader != null)
				reader.close();
			if (out != null)
				out.close();
		}

	}
}
