package com.dnapass.training.java.se.enums3;

public class PlanetEnumDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		if (args.length != 1) {
			System.err.println("Usage : java planet <earth_weight>");
			System.exit(-1);

		}

		double earthweight = Double.parseDouble(args[0]);
		double mass = earthweight / Planet.EARTH.surfaceGravity();
		for (Planet p : Planet.values())
			System.out.printf("Your weight on %s is %f%n ", p, p.surfaceWeight(mass));

	}

}
