package com.dnapass.training.java.se.file.nio.day11;

import static java.nio.file.StandardCopyOption.REPLACE_EXISTING;
import static java.nio.file.StandardOpenOption.APPEND;
import static java.nio.file.StandardOpenOption.CREATE;
import static java.nio.file.StandardOpenOption.READ;
import static java.nio.file.StandardOpenOption.WRITE;

import java.io.BufferedWriter;
import java.io.File;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.DirectoryNotEmptyException;
import java.nio.file.FileStore;
import java.nio.file.Files;
import java.nio.file.NoSuchFileException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.attribute.BasicFileAttributes;
import java.nio.file.attribute.FileTime;

//import org.junit.platform.commons.logging.LoggerFactory;
import org.slf4j.Logger;

import com.dnapass.training.java.se.date.day8.ApplicationException;

public class NioFiles {

	
	
	public static void main(String[] args) throws ApplicationException, IOException {

		System.out.println(System.getProperty("user.home"));
		
	/*	PathDemo.creatingPath();
		PathDemo.retrievingInformationAboutPath();
		PathDemo.convertingAPath();
		PathDemo.creatingPathBetweenTwoPaths();
		PathDemo.comparingTwoPaths();
		FileDemo.catchingExcetions();
		FileDemo.checkingFileOrDirectory();
		FileDemo.deleteFileOrDirectory();*/
		FileDemo.copyFileOrDirectory();
		
	}
}

class PathDemo {
	
	public static void creatingPath() {

		Path p = Paths.get(System.getProperty("user.home"), "logs", "foo.log");
		System.out.println(p);
		
	}

	public static void retrievingInformationAboutPath() {

		Path path = Paths.get("C:\\home\\joe\\foo");

		System.out.format("toString: %s%n", path.toString());
		System.out.format("getFileName: %s%n", path.getFileName());
		System.out.format("getName(0): %s%n", path.getName(0));
		System.out.format("getNameCount: %s%n", path.getNameCount());
		System.out.format("subPath(0,2): %s%n", path.subpath(0, 2));

		System.out.format("getParent: %s%n", path.getParent());
		System.out.format("getRoot: %s%n", path.getRoot());

		path = Paths.get("sally\\bar");

	}

	public static void convertingAPath() {
		/*
		 * Path p1 = Paths.get("/home/logfile");
		 * 
		 * System.out.format("%s%n",p1.toUri());
		 * 
		 * Path fullPath=p1.toAbsolutePath();
		 * 
		 * Path fp =p1.toRealPathPath();
		 */

		Path p1 = Paths.get("C:\\home\\joe\\foo");
		System.out.format("%s%n", p1.resolve("bar"));
		Paths.get("foo").resolve("/home/joe");
	}

	public static void creatingPathBetweenTwoPaths() {

		Path p1 = Paths.get("joe");
		Path p2 = Paths.get("sally");
		// Result is../sally
		Path p1_to_p2 = p1.relativize(p2);
		System.out.println(p1_to_p2);
		// Result is ../joe
		Path p2_to_p1 = p2.relativize(p1);
		System.out.println(p2_to_p1);
		p1 = Paths.get("home");

		Path p3 = Paths.get("home/sally/bar");

		// Result is sally/bar

		Path p1_to_p3 = p1.relativize(p3);
		Path p3_to_p1 = p3.relativize(p1);
		
		System.out.println(p1_to_p3);
		System.out.println(p3_to_p1);

	}

	public static void comparingTwoPaths() throws ApplicationException {

		Path path = Paths.get("C:\\home\\joe\\foo");
		Path otherPath = Paths.get("C:\\home\\joe\\foo");

		Path begining = Paths.get("/home");

		Path ending = Paths.get("foo");

		if (path.equals(otherPath)) {
			// equality logic here
		} else if (path.startsWith(begining)) {
			// path begims with "/home"
		} else if (path.endsWith(ending)) {
			// path end with "foo"
		}

		path = Paths.get("C:\\home\\joe\\foe");
		for (Path name : path) {
			System.out.println(name);
		}
	}

}

class FileDemo {
	
	public static void catchingExcetions() throws ApplicationException, IOException {

		Charset charset = Charset.forName("US-ASCII");
		String s = "some text";
		try (BufferedWriter writer = Files.newBufferedWriter(Paths.get("C:\\home\\joe\\foo"), charset)) {
			writer.write(s, 0, s.length());

		} catch (IOException x) {
			System.err.format("IOException: %s%n", x);
		}
		BufferedWriter writer = null;
		try {

			writer = Files.newBufferedWriter(Paths.get("C:\\home\\joe\\foo"), charset);
			writer.write(s, 0, s.length());
		} catch (NoSuchFileException x) {
			System.err.format("%s does not exist\n", x.getFile());
			throw new ApplicationException("file should be exist");
		} catch (IOException x) {
			System.err.format("IOException: %s%n", x);
			throw new ApplicationException("file should be exist");
		} finally {
			if (writer != null)
				writer.close();
		}

	}

	public static void checkingFileOrDirectory() throws ApplicationException,IOException {

		Path file = Paths.get("C:\\home\\joe\\foo");

		Files.exists(file);
		Files.notExists(file);

		boolean isRegularExecutableFile = Files.isRegularFile(file) & Files.isReadable(file) & Files.isExecutable(file);

		Path p1 = Paths.get("C:\\home\\joe\\foo");
		Path p2 = Paths.get("C:\\home\\joe\\foo");
		if (Files.isSameFile(p1, p2)) {
			// logic when the paths locate the same file
		}

	}

	public static void deleteFileOrDirectory() throws ApplicationException,IOException {

		Path path = Paths.get("C:\\home\\joe\\foo");
		try {
			Files.delete(path);
		} catch (NoSuchFileException x) {
			System.err.format("%s: no such" + "file or directory%n", path);
		} catch (DirectoryNotEmptyException x) {
			System.err.format("%s not empty%n", path);
		} catch (IOException x) {
			System.err.println(x);
		}

	}

	public static void copyFileOrDirectory() throws ApplicationException,IOException {
		Path source = Paths.get("C:\\home\\joe\\foo");
		Path target = Paths.get("C:\\home\\joe\\foo");
		Files.copy(source, target, REPLACE_EXISTING);
		Files.move(source, target, REPLACE_EXISTING);

	}

	public static void managingMetaData() throws ApplicationException,IOException {
		Path file = Paths.get("C:\\home\\joe\\foo");

		BasicFileAttributes attr = Files.readAttributes(file, BasicFileAttributes.class);
		System.out.println("creationTime: " + attr.creationTime());
		System.out.println("lastAccessTime: " + attr.lastAccessTime());
		System.out.println("lastModifierTime: " + attr.lastModifiedTime());
		System.out.println("isDirectory: " + attr.isDirectory());

		System.out.println("isOthers: " + attr.isOther());
		System.out.println("isRegularFile: " + attr.isRegularFile());
		System.out.println("isSymbolicLink: " + attr.isSymbolicLink());
		System.out.println("size: " + attr.size());

		// Setting Time Stamp

		attr = Files.readAttributes(file, BasicFileAttributes.class);
		long currentTime = System.currentTimeMillis();
		FileTime ft = FileTime.fromMillis(currentTime);
		Files.setLastModifiedTime(file, ft);

	}

	public static void fileStoreAttributes() throws ApplicationException,IOException {

		Path file = Paths.get("C:\\home\\joe\\foo");
		FileStore store = Files.getFileStore(file);

		long total = store.getTotalSpace() / 1024;

		long used = (store.getTotalSpace() - store.getUnallocatedSpace()) / 1024;

		long avail = store.getUnallocatedSpace() / 1024;

	}
	public static void readingWritingBytes() throws IOException{
		
		Path file = Paths.get("C:\\home\\joe\\foo");
		byte[] fileArray;
		fileArray = Files.readAllBytes(file);
		file = Paths.get("C:\\home\\joe\\foo");
		byte[] buf="some text".getBytes();
		Files.write(file, buf);
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
