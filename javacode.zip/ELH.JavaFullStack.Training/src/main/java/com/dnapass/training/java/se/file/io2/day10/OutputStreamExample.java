package com.dnapass.training.java.se.file.io2.day10;

import java.io.BufferedOutputStream;
import java.io.BufferedWriter;
import java.io.DataOutputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;



public class OutputStreamExample {
	static Logger LOGGER = LoggerFactory.getLogger(FileOperations.class);
	private static final String STREAM_OUTPUT_FILE = "C:\\Users\\vijay_a\\streamOutput.txt";
	private static final String WRITER_OUTPUT_FILE = "C:\\Users\\vijay_a\\writerOutput.txt";
	private static final String BUFFERED_OUTPUT_FILE = "C:\\Users\\vijay_a\\bufferedOutput.txt";

	private static final String OUTPUT_TEXT = "This is my example text.\nI'ts not terribly long or exciting";
	public static void main(String[] args) throws IOException {
		/*new OutputStreamExample().useFileOutputStream();
		new OutputStreamExample().useFileWriter();
		new OutputStreamExample().useBufferedWriter();*/
		new OutputStreamExample().writeFileWithDataOutputStream();
	}
	public void useFileOutputStream() throws IOException {
		System.out.println(String.format("writing file %s using a FileOutputStream", STREAM_OUTPUT_FILE));

		try (FileOutputStream out = new FileOutputStream(STREAM_OUTPUT_FILE);) {
			byte[] data = OUTPUT_TEXT.getBytes();
			out.write(data);
			out.flush();
			System.out.println(data);
		} catch (FileNotFoundException e) {
			System.err.println(String.format("Exception  creating FileOutputStream for file %s: %s", STREAM_OUTPUT_FILE,
					e.getMessage()));
		} catch (IOException e) {
			System.err
					.println(String.format(" Exception writing  to file %s :%s, ", STREAM_OUTPUT_FILE, e.getMessage()));

		}

	}

	public void useFileWriter() throws IOException {
		System.out.println(String.format("Writing file %s using a FileWriter", WRITER_OUTPUT_FILE));

		try (FileWriter out = new FileWriter(WRITER_OUTPUT_FILE);) {

			out.write(OUTPUT_TEXT);
			out.flush();
		} catch (FileNotFoundException e) {
			System.err.println(String.format("Exception  creating FileOutputStream for file %s: %s", WRITER_OUTPUT_FILE,
					e.getMessage()));
		} catch (IOException e) {
			System.err
					.println(String.format(" Exception writing  to file %s :%s, ", WRITER_OUTPUT_FILE, e.getMessage()));

		}
	}

	public void useBufferedWriter() throws IOException {
		System.out.println(String.format("writing file %s using a FileWriter", BUFFERED_OUTPUT_FILE));
		BufferedWriter out = null;
		String[] lines = { "This is my first line of text", "This is second line", "And this is third line" };

		try {
			out = new BufferedWriter(new FileWriter(BUFFERED_OUTPUT_FILE));
			for (String line : lines) {
				out.write(line);
				out.newLine();
				System.out.println("vijay"+line);
			}

			out.flush();
		} catch (FileNotFoundException e) {
			System.err.println(String.format("Exception  creating FileOutputStream for file %s: %s",
					BUFFERED_OUTPUT_FILE, e.getMessage()));

		} catch (IOException e) {
			System.err.println(
					String.format(" Exception writing  to file %s :%s, ", BUFFERED_OUTPUT_FILE, e.getMessage()));

		}

		finally {
			if (out != null) {
				out.close();
			}
		}
	}

	public void writeFileWithDataOutputStream() {
		final double[] prices = { 19, 99, 9.99, 15.99, 4.99 };
		final int[] units = { 12, 8, 13, 29, 50 };
		final String[] descs = { "Java T-shirt", "Java Mug", "Duke Juggling dolls", "java Pin", "java Key Chain" };
		try (DataOutputStream out = new DataOutputStream(
				new BufferedOutputStream(new FileOutputStream("C:\\Users\\vijay_a\\sample.txt")))) {
			for (int i = 0; i < prices.length; i++) {

				out.writeDouble(prices[i]);
				out.writeInt(units[i]);
				out.writeUTF(descs[i]);

			}
		} catch (IOException e) {
			LOGGER.error(e.getMessage());

		}
	}
}
