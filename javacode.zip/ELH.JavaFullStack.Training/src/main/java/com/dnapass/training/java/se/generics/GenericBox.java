package com.dnapass.training.java.se.generics;

import static java.lang.System.out;

public class GenericBox<T> {

	// T stands for "Type"

	private T t;

	public T getT() {
		return t;
	}

	public void setT(T t) {
		this.t = t;
	}

	public void add(T t) {

		// this.t+=t;
	}

	public void boxTest(GenericBox<?> n) {

	}

	public void boxTest1(GenericBox<Integer> n) {

	}

	public <U> void inspect(U u) {

		out.println("T: " + t.getClass().getName());
		out.println("U: " + u.getClass().getName());
	}

	public <U extends Number> void inspect1(U u) {

		out.println("T: " + t.getClass().getName());
		out.println("U: " + u.getClass().getName());
	}

	public <U extends Number> void inspect2(U u) {

		out.println("T: " + t.getClass().getName());
		out.println("U: " + u.getClass().getName());
	}

}
