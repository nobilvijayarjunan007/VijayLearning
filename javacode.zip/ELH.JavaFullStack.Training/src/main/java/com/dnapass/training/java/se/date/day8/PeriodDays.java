package com.dnapass.training.java.se.date.day8;
import java.time.LocalDate;
import java.time.Period;

public class PeriodDays {

	public static void main(String[] args) {
		LocalDate localDate1 = LocalDate.parse("2022-03-01");
		LocalDate localDate2 = LocalDate.parse("2022-09-16");

		// calculate difference
		long days = Period.between(localDate1, localDate2).getDays();

		// print days
		System.out.println("Days between " + localDate1 + " and " + localDate2 + ": " + days);


	}

}
