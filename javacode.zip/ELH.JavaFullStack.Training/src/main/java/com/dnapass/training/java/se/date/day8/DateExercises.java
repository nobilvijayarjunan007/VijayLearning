package com.dnapass.training.java.se.date.day8;

import java.text.ParseException;

public class DateExercises {

	public static void main(String[] args) throws ParseException {

		// DateConverter.dateUsingCalanderClass(2016, 0, 1);//year month date
		//
		// DateConverter.CurrentTimeInNewYork("America/New_york");
		//
		// DateConverter.getFullDateAndTime();
		//
		// DateConverter.getDateAfterTwoWeek(14);
		//
		// DateConverter.convertDateToString("2011-12-03");
		//
		// DateConverter.dateStringToDate("2016-07-14 09:00:02");

		// DateConverter.dateStringToDate1("2016-07-14 09:00:02");
		//
		// DateConverter.unixTimeStampToDate();
		//
		// DateConverter.inDayLightTime();
		//
		// DateConverter.observeDaylightTime();
		//
	}

}
