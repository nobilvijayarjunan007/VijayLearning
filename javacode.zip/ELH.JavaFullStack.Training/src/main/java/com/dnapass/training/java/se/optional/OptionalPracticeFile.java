package com.dnapass.training.java.se.optional;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.function.Consumer;

public class OptionalPracticeFile {
	public static void main(String[] args) {

		Optional<Object> empty = Optional.empty();
		System.out.println(empty.isEmpty());
		String name = "baeldung";
		Optional<String> opt = Optional.of(name);
		System.out.println(opt.get());
		String name1 = null;
		String of = Optional.ofNullable(name1).orElse("vijay");

		System.out.println(of);

	}
}
