package com.dnapass.training.java.se.threads4.day9;

public class ThreadJoinDemo {

	public static void main(String[] args) {
		Worker worker = new Worker();
		worker.doWork();
	}

}

class Worker {

	private long count = 0;

	public void increment(String threadName) throws InterruptedException {
		count++;

		System.out.println("Thread in progress: " + threadName + "- and count is: " + count);

	}

	public void doWork() {
		Thread thread1 = new Thread(new Runnable() {
			public void run() {
				for (int i = 0; i < 10; i++) {
					try {
						increment(Thread.currentThread().getName());
						Thread.sleep(10);
					} catch (InterruptedException ex) {

					}
				}

			}
		});
		thread1.start();
		Thread thread2 = new Thread(new Runnable() {
			public void run() {
				for (int i = 0; i < 10; i++) {
					try {
						increment(Thread.currentThread().getName());
						Thread.sleep(10);
					} catch (InterruptedException ex) {

					}
				}

			}
		});
		thread2.start();

		try {
			thread1.join();
			thread2.join();
		}catch(InterruptedException ignored) {
			
		}
		if(count%2==0) {
			System.out.println("worker thread produces even number ");
		}
		System.out.println("Count is: "+count);
	}
}