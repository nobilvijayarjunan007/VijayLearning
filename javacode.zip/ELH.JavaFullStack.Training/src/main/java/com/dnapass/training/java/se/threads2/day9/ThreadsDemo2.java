package com.dnapass.training.java.se.threads2.day9;

public class ThreadsDemo2 {

	public static void main(String[] args) throws InterruptedException {
		ThreadSleep.sleep();

	}

}
