package com.dnapass.training.java.se.threads1.day9;

public class Counter extends Thread {
	
	private static int c=10;
	public  void run (){
		new Counter().increment();
		System.out.println("inc "+c);
		new Counter().decrement();
		System.out.println("dec "+c);
	    
		}
	
	public static void main(String[] args)  {
		
		Counter t1 = new Counter();
		
		t1.start();
		
	}
	
	public void increment () {
		c++;
	}

	public void decrement () {
		c--;
	}

	public int value () {
		 return c;
	}
}


	