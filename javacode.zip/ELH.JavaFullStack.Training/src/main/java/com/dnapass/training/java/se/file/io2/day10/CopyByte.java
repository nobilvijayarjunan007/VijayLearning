package com.dnapass.training.java.se.file.io2.day10;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class CopyByte {
	public static void main(String[] args) throws IOException {
		
		
		
		copyBytes2();
	}
	public static void copyBytes() throws IOException {
		FileInputStream in = null;
		FileOutputStream out = null;
		try {
			in = new FileInputStream("C:\\Users\\vijay_a\\input.txt");
			out = new FileOutputStream("C:\\Users\\vijay_a\\output.txt");
			int c;
			int count=0;
			while ((c = in.read()) != -1) {
				out.write(c);
				char ch=(char)c;
				System.out.print(ch);
				
				count++;
			}
			System.out.println();
			System.out.println(count);
		} finally {
			if (in != null) {
				in.close();
			}
			if (out != null) {
				out.close();
			}
		}

	}
	public static void copyBytes2() throws IOException {
		FileInputStream in = null;
		FileOutputStream out = null;
		try {
			in = new FileInputStream("C:\\Users\\vijay_a\\bank4.dat");
			out = new FileOutputStream("C:\\Users\\vijay_a\\bank4.dat");
			int c;
			int count=0;
			while ((c = in.read()) != -1) {
				out.write(c);
				char ch=(char)c;
				System.out.print(ch);
				
				count++;
			}
			System.out.println();
			System.out.println(count);
		} finally {
			if (in != null) {
				in.close();
			}
			if (out != null) {
				out.close();
			}
		}

	}
}
