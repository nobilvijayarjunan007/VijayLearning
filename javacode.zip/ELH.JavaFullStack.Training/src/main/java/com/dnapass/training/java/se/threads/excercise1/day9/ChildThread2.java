package com.dnapass.training.java.se.threads.excercise1.day9;

import java.util.Calendar;
import java.util.Date;

public class ChildThread2 {
	public void run() throws InterruptedException {

		Thread.sleep(10000);

		Calendar cal = Calendar.getInstance();
		Date date = cal.getTime();
		System.out.println(date);
	}

}
