package com.dnapass.training.java.se.lambda;

public enum ProductType {

	FRUIT,GROCERY,FUEL,ELECTRIC
}
