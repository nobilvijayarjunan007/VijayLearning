package com.dnapass.training.java.se.lambda;

import java.util.ArrayList;
import java.util.List;

public class DataLoader {

	public static List<TransactionsEntity> newTransaction() {

		List<TransactionsEntity> transactions = new ArrayList<TransactionsEntity>();

		transactions.add(new TransactionsEntity(1, ProductType.FRUIT, 45.55, "chennai", "INR"));
		transactions.add(new TransactionsEntity(3, ProductType.GROCERY, 252.22, "london", "GBP"));
		transactions.add(new TransactionsEntity(5, ProductType.ELECTRIC, 20.99, "bangalore", "USD"));
		transactions.add(new TransactionsEntity(2, ProductType.FRUIT, 68.22, "chennai", "INR"));
		transactions.add(new TransactionsEntity(4, ProductType.FUEL, 90.34, "london", "GBP"));
		transactions.add(new TransactionsEntity(7, ProductType.ELECTRIC, 150.56, "bangalore", "USD"));
		transactions.add(new TransactionsEntity(6, ProductType.GROCERY, 456.99, "chennai", "INR"));
		transactions.add(new TransactionsEntity(8, ProductType.FUEL, 451.55, "bangalore", "USD"));
		return transactions;
	}

	public static List<Person> newPersons() {

		List<Person> persons = new ArrayList<>();
		persons.add(new Person("vijay", "kumar", 25));
		persons.add(new Person("kumar", "naveen", 25));
		persons.add(new Person("naveen", "drunk", 25));
		persons.add(new Person("priya", "naveen", 25));
		return persons;
	}

}
