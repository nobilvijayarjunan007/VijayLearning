package com.dnapass.training.java.se.date.day8;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

public class DateConverter {

	public static Date dateUsingCalanderClass(int year, int month, int date) {

		Calendar cal = Calendar.getInstance();
		cal.clear();

		cal.set(Calendar.YEAR, year);
		cal.set(Calendar.MONTH, month);
		cal.set(Calendar.DATE, date);
		System.out.println(cal.getTime());

		return cal.getTime();
	}

	public static String CurrentTimeInNewYork(String string) {
		Calendar calNewYork = Calendar.getInstance();
		calNewYork.setTimeZone(TimeZone.getTimeZone(string));
		String newYorkTime = "" + calNewYork.get(Calendar.HOUR) + ":" + calNewYork.get(Calendar.MINUTE) + ":"
				+ calNewYork.get(Calendar.SECOND);
		System.out.println(newYorkTime);
		return newYorkTime;
	}

	public static String getFullDateAndTime() {
		Calendar now = Calendar.getInstance();

		String currentFullDateAndTime = "Current Full Date and Time is " + (now.get((Calendar.MONTH)) + 1) + "-"
				+ now.get(Calendar.DATE) + "-" + now.get(Calendar.YEAR) + " " + now.get(Calendar.HOUR_OF_DAY) + ":"
				+ now.get(Calendar.MINUTE) + ":" + now.get(Calendar.SECOND);
		System.out.println(currentFullDateAndTime);
		return currentFullDateAndTime;
	}

	public static Date getDateAfterTwoWeek(int noOfDays) {

		Calendar cal = Calendar.getInstance();

		Date cdate = cal.getTime();

		cal.add(Calendar.DAY_OF_YEAR, noOfDays);

		Date date = cal.getTime();
		System.out.println("Current Date  " + cdate);
		System.out.println("Day After Two Weeks" + date);

		return date;

	}

	public static String convertDateToString(String string) {

		/*Patterns are based on a simple sequence of letters and symbols.A pattern is used to create a Formatter using the ofPattern(String) and ofPattern(String, Locale) methods.For example, "d MMM uuuu" will format 2011-12-03 as '3 Dec 2011'.A formatter created from a pattern can be used as many times as necessary,it is immutable and is thread-safe. 
		For example: */

		 // LocalDate date = LocalDate.now();
		LocalDate date =LocalDate.parse(string);
		  System.out.println(date);
		  DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MMMM d, yyyy");
		  String text = date.format(formatter);
		  LocalDate parsedDate = LocalDate.parse(text, formatter);
		  System.out.println(text);
		  System.out.println(parsedDate);
		  return text;
		/*DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MMMM d, yyyy", Locale.ENGLISH);

		LocalDate date = LocalDate.parse(string, formatter);

		System.out.println(date);
		return date;*/
	}

	public static Date dateStringToDate(String string) throws ParseException {

		
			SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			Date date = sdf.parse(string);
			//sdf.format(date);
			System.out.println(date);
		
		return date;

	}

	public static Date dateStringToDate1(String string) throws ParseException {
		
			SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			Date date = sdf.parse(string);
			//sdf.format(date);
			System.out.println(date);
			/*Date date = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(string);
			System.out.println(date);
			String newStr = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(string);
			System.out.println(date);*/
		
		return date;
	}

	public static void unixTimeStampToDate() {
		// Unix seconds

		long unix_Seconds = 1372339860;
		// conver seconds to milliseconds

		Date date = new Date(unix_Seconds * 1000L);
		// format of the Date

		SimpleDateFormat jdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss z");
		TimeZone timeZone = TimeZone.getTimeZone("GMT-4");
		jdf.setTimeZone(timeZone);
		String java_date = jdf.format(date);
		System.out.println(java_date);

	}

	public static void inDayLightTime() {
		// Creating a Time Zone
		TimeZone offTimeZone = TimeZone.getTimeZone("Europe/Rome");
		// Creating Date Object
		Date dt = new Date();
		// Verifying day Lights
		boolean bool_daylights = offTimeZone.inDaylightTime(dt);

		// Checking the value of day light
		System.out.println("It is in day" + " light saving time? " + bool_daylights);

		// Creating a Time Zone
		offTimeZone = TimeZone.getTimeZone("Europe/Rome");
		// Creating Date Object
		dt = new Date();
		// Verifying day Lights
		bool_daylights = offTimeZone.inDaylightTime(dt);

		// Checking the value of day light
		System.out.println("It is in day" + " light saving time? " + bool_daylights);

	}

	public static void observeDaylightTime() {
		// Creating a time zone object
		TimeZone timeObj = TimeZone.getTimeZone("Pacific/Pago_pago");

		// Displaying the time Zone

		System.out.println(timeObj);
		// verifying day light
		boolean bool_daylights = timeObj.observesDaylightTime();
		// Checking the Value of the light
		System.out.println("The result is: " + bool_daylights);
		//

	}

}
