package com.dnapass.training.java.se;

import java.util.HashSet;

import java.util.Set;

public class Employee {

	private int empId;
	private String empName;
	private String dept;
	private String empLocation;

	public static void main(String[] args) {
		Set<Employee> evaluate = evaluate();
		evaluate.stream().forEach(System.out::println);
	}

	public Employee() {
		super();
	}

	public Employee(int empId, String empName, String dept, String empLocation) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.dept = dept;
		this.empLocation = empLocation;
	}

	public static Set<Employee> evaluate() {

		Set<Employee> empList = new HashSet<>();
		for (int i = 1; i <= 1000; i++) {
			String name = "name" + i;
			String dept = "dept" + i;
			String location = "location" + i;

			empList.add(new Employee(i, name, dept, location));
		}

		return empList;
	}

	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empName=" + empName + ", dept=" + dept + ", empLocation=" + empLocation
				+ "]";
	}

}
