package com.dnapass.training.java.se.date.day8;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Date;

public class ExtractDateAndTime {

	public static void main(String[] args) throws ParseException {
		// TODO Auto-generated method stub
		extractDateAndTimeFromString("2016-07-14 09:00:02");
		extractDateFromString("2016-07-14");
		extractTimeFromString("09:00:02");
	}

	public static LocalTime extractTimeFromString(String string) {
		LocalTime time=LocalTime.parse(string);
		System.out.println(time);
		return time;
	}

	public static LocalDate extractDateFromString(String string) {
		
		LocalDate date=LocalDate.parse(string);
		
		System.out.println(date);
		return date;
	}

	public static Date extractDateAndTimeFromString(String string) throws ParseException {

		try {

			Date date = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(string);
			System.out.println(date);
		} catch (ParseException e) {

			e.printStackTrace();

		}

		return new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(string);

	}
}
