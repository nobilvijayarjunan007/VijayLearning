package com.dnapass.training.java.se.threads3.day9;

public class Waiter implements Runnable{
	private Message1 msg;
	
	public Waiter (Message1 m) {
		this.msg =m;
		
	}
public void run() {
	
	String name =Thread.currentThread().getName();
	synchronized (msg) {
		try {
			System.out.println(name +"waiting to get notified at time :"+System.currentTimeMillis());
		 msg.wait();
		
		}
		catch (InterruptedException e){
			e.printStackTrace();
		}	
			
		System.out.println(name +"waiting to get notified at time :"+System.currentTimeMillis());
		System.out.println(name + "processed "+msg.getmsg());
		
	}
}
}
