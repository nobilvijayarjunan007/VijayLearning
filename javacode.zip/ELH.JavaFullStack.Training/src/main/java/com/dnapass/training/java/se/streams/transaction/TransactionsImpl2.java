package com.dnapass.training.java.se.streams.transaction;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import com.dnapass.training.java.se.lambda.DataLoader;
import com.dnapass.training.java.se.lambda.TransactionsEntity;

public class TransactionsImpl2 {
	static List<TransactionsEntity> trans = new ArrayList<>();
	static {
		List<TransactionsEntity> transactions = DataLoader.newTransaction();
		trans.addAll(transactions);
	}

	public Optional<TransactionsEntity> findById(Integer i) throws TransactionNotFoundException {

		Optional<TransactionsEntity> t1 = Optional.ofNullable(trans.stream().filter(t -> t.getId().equals(i) ).findFirst()
				.orElseThrow(() -> new TransactionNotFoundException("Transaction")));

		return t1;
	}

	public Optional<List<TransactionsEntity>> findAll() throws TransactionNotFoundException {

		List<TransactionsEntity> list = trans.stream().collect(Collectors.toList());

		return Optional.of(list);
	}

	public Optional<TransactionsEntity> update(TransactionsEntity tran1, Integer i)
			throws TransactionNotFoundException {

		Optional<TransactionsEntity> t1 = Optional.ofNullable(trans.stream().filter(t -> t.getId().equals(1)).findFirst().orElseThrow(() -> new TransactionNotFoundException("Transaction")));
		t1.get().setCity(tran1.getCity());
		return t1;
	}

	public TransactionsEntity create(TransactionsEntity tran1) throws TransactionNotFoundException {

		trans.add(tran1);
		int indexOf = trans.indexOf(tran1);

		return trans.get(indexOf);

		/*
		 * Stream<TransactionsEntity> transaction = Stream.of(tran1);
		 * List<TransactionsEntity> newTransaction =
		 * transaction.collect(Collectors.toList()); trans.addAll(newTransaction);
		 */

		// System.out.println("Transaction added successfully" + newTransaction);

	}

	public void deleteById(Integer i) throws TransactionNotFoundException {
		Optional<TransactionsEntity> findFirst = trans.stream().filter(t -> t.getId() == i).findFirst();
		if (findFirst.isPresent()) {
			trans.remove(i);
			System.out.println("delete is done");
		} else {
			throw new TransactionNotFoundException("Transaction id is not presented here" + i);
		}

	}

}
