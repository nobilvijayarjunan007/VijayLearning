package com.dnapass.training.java.se.interfaces;

public class Car implements Vehicle {

	private final String brand;

	public Car(String brand) {
		this.brand = brand;
	}

	@Override
	public String getBrand() {
		// TODO Auto-generated method stub
		return brand;
	}

	@Override
	public String speedup() {
		// TODO Auto-generated method stub
		return "The car is speeding up.";
	}

	@Override
	public String slowDown() {
		// TODO Auto-generated method stub
		return "The car is slowing up.";
	}

}

class Motorbike implements Vehicle {

	private final String brand;

	public Motorbike(String brand) {
		this.brand = brand;
	}

	@Override
	public String getBrand() {
		// TODO Auto-generated method stub
		return brand;
	}

	@Override
	public String speedup() {
		// TODO Auto-generated method stub
		return "The Motorbike is speeding up.";
	}

	@Override
	public String slowDown() {
		// TODO Auto-generated method stub
		return "The Motorbike is slowing up.";
	}

}
