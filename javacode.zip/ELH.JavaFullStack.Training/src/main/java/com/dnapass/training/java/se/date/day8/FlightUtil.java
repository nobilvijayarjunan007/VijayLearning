package com.dnapass.training.java.se.date.day8;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.Month;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;

public class FlightUtil {

	public static void main(String[] args) throws ParseException {

		LocalDateTime local = LocalDateTime.of(2013, 7, 20, 19, 30);
		arrivalTimeInTokyo(local, 650);
		arrivalTimeInDelhi(local, 1250);

		/* getTimeAfterSet(); */
		/*
		 * SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss Z"); Date
		 * date = sdf.parse("09-02-2022 19:30:00 -0800"); getTimeAsPerGivenFormat(date,
		 * sdf);
		 */

	}

	public static ZonedDateTime arrivalTimeInDelhi(LocalDateTime local, int i) {

		LocalDateTime arrivalTimeInDelhi = local.plusMinutes(i);

		ZonedDateTime zdt1 = local.atZone(ZoneId.of("America/Los_Angeles"));
		System.out.println("Leaving  Time In San Francisco " + zdt1);
		System.out.println();
		ZonedDateTime zdt2 = arrivalTimeInDelhi.atZone(ZoneId.of("Asia/Kolkata"));
		System.out.println(zdt2.toString());
		System.out.println();
		System.out.println("Arrival Time In Tokyo " + zdt2);
		System.out.println();
		return zdt2;
	}

	public static ZonedDateTime arrivalTimeInTokyo(LocalDateTime local, int i) {
		LocalDateTime arrivalTimeInTokyo = local.plusMinutes(i);

		ZonedDateTime zdt1 = local.atZone(ZoneId.of("America/Los_Angeles"));
		System.out.println("Leaving  Time In San Francisco " + zdt1);
		System.out.println();
		ZonedDateTime zdt2 = arrivalTimeInTokyo.atZone(ZoneId.of("Asia/Tokyo"));
		System.out.println(zdt2.toString());
		System.out.println();
		System.out.println("Arrival Time In Tokyo " + zdt2);

		System.out.println();
		return zdt2;
	}

	// >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

	private static void getTimeAsPerGivenFormat(Date date, SimpleDateFormat sdf) {
		TimeZone timeZone = TimeZone.getTimeZone("America/Los_Angeles");
		sdf.setTimeZone(timeZone);
		System.out.println("timeZone >> " + timeZone);
		System.out.println("Parse date >> " + date);
		String dateAfterFormat = sdf.format(date);

		System.out.println(dateAfterFormat + " " + timeZone.toZoneId());
	}

	private static void getTimeAfterSet() {
		Calendar cal = Calendar.getInstance();
		System.out.println(
				" " + cal.get(Calendar.DATE) + "/" + (cal.get(Calendar.MONTH) + 1) + "/" + cal.get(Calendar.YEAR));
		cal.clear();
		cal.set(Calendar.DATE, 20);
		cal.set(Calendar.MONTH, 7 - 1);
		cal.set(Calendar.YEAR, 2013);
		cal.set(Calendar.HOUR, 19);
		cal.set(Calendar.MINUTE, 30);
		cal.setTimeZone(TimeZone.getTimeZone("America/Los_angeles"));
		System.out.println(" " + cal.get(Calendar.DATE) + "/" + (cal.get(Calendar.MONTH) + 1) + "/"
				+ cal.get(Calendar.YEAR) + " " + cal.get(Calendar.HOUR) + ":" + cal.get(Calendar.MINUTE) + " "
				+ cal.get(Calendar.ZONE_OFFSET));
	}

}
