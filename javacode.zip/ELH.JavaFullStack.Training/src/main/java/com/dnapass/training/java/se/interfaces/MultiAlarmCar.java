package com.dnapass.training.java.se.interfaces;

public class MultiAlarmCar implements Vehicle, Alarm {

	private final String brand;

	public MultiAlarmCar(String brand) {
		this.brand = brand;
	}

	@Override
	public String getBrand() {
		// TODO Auto-generated method stub
		return brand;
	}

	@Override
	public String speedup() {
		// TODO Auto-generated method stub
		return "The MultiAlarmCar is speeding up.";
	}

	@Override
	public String slowDown() {
		// TODO Auto-generated method stub
		return "The MultiAlarmCar is slowing up.";
	}

	@Override
	public String turnAlarmOff() {
		// TODO Auto-generated method stub
		return Alarm.super.turnAlarmOff();
	}

	@Override
	public String turnAlarmOn() {
		// TODO Auto-generated method stub
		return Alarm.super.turnAlarmOn();
	}

}
