package com.dnapass.training.java.se.threads7.day9;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class SynchronizeDemo {

	public static void main(String[] args) {
		System.out.println("Synchronized objects");
		Worker1 worker = new Worker1();
		worker.main();
		System.out.println("Synchronized methods");
		WorkerMethodsSynchronized Worker2 = new WorkerMethodsSynchronized();
		Worker2.main();

	}

}

class Worker1 {

	private Random random = new Random();
	private final Object lock1 = new Object();
	private final Object lock2 = new Object();

	private List<Integer> list1 = new ArrayList<Integer>();
	private List<Integer> list2 = new ArrayList<Integer>();

	public void stageOne() {

		synchronized (lock1) {
			try {
				Thread.sleep(1);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			list1.add(random.nextInt(100));
		}
	}

	public void stageTwo1() {

		synchronized (lock2) {
			try {
				Thread.sleep(1);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			list1.add(random.nextInt(100));
		}
	}

	public void process() {
		for (int i = 0; i < 1000; i++) {
			stageOne();
			stageTwo1();
		}

	}

	private void stageTwo() {
		// TODO Auto-generated method stub

	}

	public void main() {
		System.out.println("starting......");
		long start = System.currentTimeMillis();
		Thread t1 = new Thread(new Runnable() {
			public void run() {
				process();
			}
		});

		Thread t2 = new Thread(new Runnable() {
			public void run() {
				process();
			}
		});

		t1.start();
		t2.start();
		try {
			t1.join();
			t2.join();
		}

		catch (InterruptedException e) {
			e.printStackTrace();
		}

		long end = System.currentTimeMillis();

		System.out.println("Time taken : " + (end - start));
		System.out.println(" List 1 : " + list1.size() + " ;  list2 : " + list2.size());
	}
}

class WorkerMethodsSynchronized {

	private Random random = new Random();

	private List<Integer> list1 = new ArrayList<Integer>();
	private List<Integer> list2 = new ArrayList<Integer>();

	public synchronized void stageOne() {
		try {
			Thread.sleep(1);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		list1.add(random.nextInt(100));

	}

	public synchronized void stageTwo() {
		try {
			Thread.sleep(1);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		list1.add(random.nextInt(100));

	}

	public void process() {
		for (int i = 0; i < 1000; i++) {
			stageOne();
			stageTwo();
		}

	}

	public void main() {
		System.out.println("starting......");
		long start = System.currentTimeMillis();
		Thread t1 = new Thread(new Runnable() {
			public void run() {
				process();
			}
		});

		Thread t2 = new Thread(new Runnable() {
			public void run() {
				process();
			}
		});

		t1.start();
		t2.start();
		try {
			t1.join();
			t2.join();
		}

		catch (InterruptedException ignored) {

		}

		long end = System.currentTimeMillis();

		System.out.println("Time taken : " + (end - start));
		System.out.println(" List 1 : " + list1.size() + " ;  list2 : " + list2.size());

	}

}