package com.dnapass.training.java.se.threads9.day9;

import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.logging.Logger;

import org.springframework.scheduling.config.Task;
public class FactorialTaskDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
ExecutorService executorService =Executors.newSingleThreadExecutor();
FactorialTask  task =new FactorialTask(5);
System.out.println(task.call());

	}

}
class  FactorialTask implements Callable <Integer>{
	int number;
	
	
	public FactorialTask (int number) {
		super();
		this.number =number;
		
	}


public Integer call() {
	int fact = 1;
	
	for (int count = number; count >1 ; count --) {
		fact = fact * count;
		
	}
		
	return fact;
}

}

class EventLoggingTask implements Runnable {

	static final Logger LOGGER = Logger.getLogger(EventLoggingTask.class.getName());
	@Override
	public void run() {
		// TODO Auto-generated method stub
		LOGGER.info("Message");
	}
	
}