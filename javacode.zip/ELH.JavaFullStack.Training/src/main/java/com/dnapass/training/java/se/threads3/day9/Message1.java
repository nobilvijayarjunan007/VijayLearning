package com.dnapass.training.java.se.threads3.day9;

public class Message1 {
	private String msg ;
	
	public Message1 (String str) {
		this. msg = str ;
	}
	public String getmsg () {
		return msg;
	}
	public void  setmsg (String str) {
		this. msg = str ;
}
}