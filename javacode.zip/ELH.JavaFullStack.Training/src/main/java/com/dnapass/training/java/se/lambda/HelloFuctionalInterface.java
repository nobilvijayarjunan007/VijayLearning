package com.dnapass.training.java.se.lambda;
@FunctionalInterface
public interface HelloFuctionalInterface {

	public String sayHello();
	
	//public String sayWorld();
	
	//boolean equals(Object obj);
	
}
