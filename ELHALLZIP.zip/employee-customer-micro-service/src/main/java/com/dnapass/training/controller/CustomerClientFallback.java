package com.dnapass.training.controller;

public class CustomerClientFallback {

}
