package com.dnapass.training.day6.transaction.service;

import java.util.List;

import com.dnapass.training.day6.transaction.ProductType;
import com.dnapass.training.day6.transaction.TransactionsEntity;

public interface ITransactionRepo {
	boolean createTransaction(TransactionsEntity transaction) throws ApplicationException;
    boolean update(TransactionsEntity transaction) throws ApplicationException;
	boolean delete(TransactionsEntity transaction) throws ApplicationException;

	TransactionsEntity findById(Integer id) throws ApplicationException;

	boolean find(TransactionsEntity transaction) throws ApplicationException;

	List<TransactionsEntity> findByIdAndProductType(Integer id, ProductType prod) throws ApplicationException;

	List<TransactionsEntity> findByIdAndProductTypeAndCity(Integer id, ProductType prod, String city)
			throws ApplicationException;

}