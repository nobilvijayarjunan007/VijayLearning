package com.dnapass.training.day6.collection.sample;

import java.util.HashSet;
import java.util.Iterator;

public class HashSetDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		HashSet<String> colors = new HashSet<String>();
		colors.add("Red");
		colors.add("Green");
		colors.add("Black");
		colors.add("white");
		colors.add("Pink");
		colors.add("Yellow");

		System.out.println("The Hash Set : " + colors);

		Iterator<String> colorsITrp = colors.iterator();

		while (colorsITrp.hasNext()) {
			System.out.println(colorsITrp.next());
		}
		System.out.println("size of the Hash set : " + colors.size());

		System.out.println("checking the above array list is empty or not! " + colors.isEmpty());

		HashSet<String> new_h_set = new HashSet<String>();
		HashSet<String> new_h_set_clone = (HashSet) colors.clone();
		new_h_set = (HashSet) colors;
		new_h_set.add("new color");

		System.out.println("cloned Hash Set :" + new_h_set);

		String[] new_array = new String[colors.size()];
		System.out.println("1" + colors);
		colors.toArray();
		System.out.println("2" + new_array);

		System.out.println("Array element");
		for (String element : new_array) {
			System.out.println(element);
		}

	}

}
