package com.dnapass.training.day6.collection;

import java.util.HashSet;

public class CollectionsUtil {

	public static void main(String[] args) {
		/*
		HashSet<String> list = new HashSet<String>();
		
		list.add("Apple");
		list.*/
	}
}
