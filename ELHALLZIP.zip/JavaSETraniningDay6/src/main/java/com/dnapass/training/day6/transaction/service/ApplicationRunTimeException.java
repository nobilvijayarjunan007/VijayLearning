package com.dnapass.training.day6.transaction.service;

public class ApplicationRunTimeException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String wrongCalling;
	private String message;
	

   public ApplicationRunTimeException( String message,int i) {
		
		this.message = message;
	}
	public ApplicationRunTimeException( String wrongCalling) {
		
		this.wrongCalling = wrongCalling;
	}

	public String getWrongCalling() {
		return wrongCalling;
	}

	public void setWrongCalling(String wrongCalling) {
		this.wrongCalling = wrongCalling;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}
	
	
	
}
