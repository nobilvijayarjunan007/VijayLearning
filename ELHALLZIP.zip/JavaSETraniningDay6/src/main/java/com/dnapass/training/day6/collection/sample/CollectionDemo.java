package com.dnapass.training.day6.collection.sample;

import java.util.*;

import com.dnapass.training.day6.transaction.ProductType;
import com.dnapass.training.day6.transaction.TransactionDataLoader;
import com.dnapass.training.day6.transaction.TransactionsEntity;


public class CollectionDemo {

	public static void main(String[] args) {
		CollectionDemo collectionDemo = new CollectionDemo();
		System.out.println(-Integer.MIN_VALUE == Integer.MAX_VALUE);
	}

	private void demo() {
		List<TransactionsEntity> transactions = TransactionDataLoader.newTransaction();
		System.out.println("Original List " + transactions);

		Collections.sort(transactions);
		System.out.println("Sorted alphabetically list" + transactions);

		Collections.reverse(transactions);
		System.out.println("Reverse List " + transactions);

		Collections.shuffle(transactions);
		System.out.println("Shuffle list " + transactions);

		System.out.println("Checking occurance of GROCERIES :" + Collections.frequency(transactions,
				new TransactionsEntity(124, ProductType.GROCERY, 120.0, "london", "GBP")));

		List<TransactionsEntity> tranactionscopy = new ArrayList<TransactionsEntity>(transactions.size());
		Collections.copy(tranactionscopy, transactions);
		System.out.println("tranactionscopy " + tranactionscopy);

	}
}
