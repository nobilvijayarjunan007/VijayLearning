package com.dnapass.training.day6.collection.sample;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.PriorityQueue;

public class PriorityQueueDemo {

	public static void main(String args[]) {

		PriorityQueue<String> queue = new PriorityQueue<String>();
		queue.add("Red");
		queue.add("Green");
		queue.add("Orange");
		queue.add("White");
		queue.add("Black");
		System.out.println("Element of Proiority Queue ");
		System.out.println(queue);

		for (String element : queue) {
			System.out.println(element);
		}

		PriorityQueue<String> queue2 = new PriorityQueue<String>();
		queue2.add("pink");
		queue2.add("white");
		queue2.add("Black");
		System.out.println("Priority Queue2 " + queue2);

		queue.addAll(queue2);
		System.out.println("New Priority Queue1 " + queue);
		queue.offer("Blue");

		System.out.println("The New Priority queue " + queue);
		queue.clear();

		System.out.println("The New Priority Queue " + queue);

		System.out.println("Size  of the Priority Queue : " + queue.size());

		System.out.println("The first element of the Queue : " + queue.peek());

		System.out.println("Remove the first element : " + queue.poll());
		System.out.println("Priority Queue after removing first element : " + queue);

		List<String> array_list = new ArrayList<String>();
		System.out.println("Array Containing all of the element in the queue " + array_list);

		PriorityQueue<Integer> pq1 = new PriorityQueue<Integer>(10, Collections.reverseOrder());
		pq1.add(10);
		pq1.add(22);
		pq1.add(36);
		pq1.add(14);
		pq1.add(88);
		pq1.add(95);
		System.out.println("\n Original Priorty Queue " + pq1);

		System.out.println("\n Maxiumm Priorty Queue " + pq1);
		Integer val = null;
		while ((val = pq1.poll()) != null) {
			System.out.println(val);
		}
		System.out.println("\n");
	}
}
