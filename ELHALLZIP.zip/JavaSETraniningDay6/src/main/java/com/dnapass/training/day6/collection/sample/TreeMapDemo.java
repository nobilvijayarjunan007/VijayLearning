package com.dnapass.training.day6.collection.sample;

import java.util.Comparator;
import java.util.Map.Entry;
import java.util.Set;
import java.util.SortedMap;
import java.util.TreeMap;

public class TreeMapDemo {

	public static void main(String args[]) {

		TreeMap<Integer, String> tree_map = new TreeMap<Integer, String>();

		tree_map.put(1, "Red");
		tree_map.put(2, "Green");
		tree_map.put(3, "black");
		tree_map.put(4, "Yellow");
		tree_map.put(5, "Blue");

		for (Entry<Integer, String> entry : tree_map.entrySet()) {
			System.out.println(entry.getKey() + " =>" + entry.getValue());
		}

		TreeMap<String, String> tree_map1 = new TreeMap<String, String>();
		tree_map1.put("c1", "Black");
		tree_map1.put("c2", "blue");
		tree_map1.put("c3", "white");
		tree_map1.put("c4", "yellow");
		tree_map1.put("c5", "pink");
		System.out.println("Tree Map 1: " + tree_map1);

		TreeMap<String, String> tree_map2 = new TreeMap<String, String>();
		tree_map2.put("a1", "Black");
		tree_map2.put("a2", "Black");
		System.out.println("Tree Map 2 : " + tree_map2);

		tree_map1.putAll(tree_map2);
		System.out.println("After coping map2 to map1 " + tree_map1);
		System.out.println(tree_map1);

		if (tree_map1.containsKey("c1")) {
			System.out.println("The Tree Map contain key c1");
		} else {
			System.out.println("The Tree Map Not contain key c1");
		}

		if (tree_map1.containsKey("c5"))
			System.out.println("The Tree Map contain key c5");
		else
			System.out.println("The Tree Map not contain key ");

		if (tree_map1.containsValue("Green"))
			System.out.println("The Tree Map contain key Value");
		else
			System.out.println("The Tree Map Not contain Value ");

		if (tree_map1.containsValue("Pink"))
			System.out.println("The Tree Map contain key Value");
		else
			System.out.println("The Tree Map Not contain Value ");

		Set<String> keys = tree_map1.keySet();
		for (String key : keys)
			System.out.println(key);

		tree_map1.clear();
		System.out.println("The New Map :" + tree_map1);

		TreeMap<String, String> sort_tree_map1 = new TreeMap<String, String>(new SortKey());
		sort_tree_map1.put("c2", "Red");
		sort_tree_map1.put("c3", "Green");
		sort_tree_map1.put("c4", "Black");
		sort_tree_map1.put("c5", "Whitw");
		System.out.println(sort_tree_map1);

		System.out.println("Grestest Key :" + tree_map1.firstKey());
		System.out.println("Least Key : " + tree_map1.lastEntry());

		System.out.println("Reverse order view of the keys :" + tree_map1.descendingKeySet());
		TreeMap<Integer, String> tree_map_int = new TreeMap<Integer, String>();

		tree_map_int.put(10, "Red");
		tree_map_int.put(20, "Green");
		tree_map_int.put(30, "Black");
		tree_map_int.put(40, "Blue");
		tree_map_int.put(50, "White");

		System.out.println("Checking the entry for 10");
		System.out.println("value is : " + tree_map_int.floorEntry(10));
		System.out.println("Checking the entry for 20");
		System.out.println("value is : " + tree_map_int.floorEntry(20));
		System.out.println("Checking the entry for 10");
		System.out.println("value is : " + tree_map_int.floorEntry(30));

		System.out.println("checking the key for 10");
		System.out.println("Key is " + tree_map_int.floorKey(10));
		System.out.println("checking the key for 20");
		System.out.println("Key is " + tree_map_int.floorKey(20));
		System.out.println("checking the key for 30");
		System.out.println("Key is " + tree_map_int.floorKey(30));

		System.out.println("checking the entry for 10");
		System.out.println("Key is " + tree_map_int.headMap(10));
		System.out.println("checking the entry for 20");
		System.out.println("Key is " + tree_map_int.headMap(20));
		System.out.println("checking the entry for 30");
		System.out.println("Key is " + tree_map_int.headMap(30));

		System.out.println("Checking the entry for 10 ");
		System.out.println("key(s) " + tree_map_int.headMap(10, true));
		System.out.println("Checking the entry for 20 ");
		System.out.println("key(s) " + tree_map_int.headMap(20, true));
		System.out.println("Checking the entry for 30 ");
		System.out.println("key(s) " + tree_map_int.headMap(30, true));

		System.out.println("Checking the entry for 10 ");
		System.out.println("key(s) " + tree_map_int.higherEntry(10));
		System.out.println("Checking the entry for 20 ");
		System.out.println("key(s) " + tree_map_int.higherEntry(20));
		System.out.println("Checking the entry for 30 ");
		System.out.println("key(s) " + tree_map_int.higherEntry(30));

		System.out.println("Checking the entry for 10");
		System.out.println();

		System.out.println("Checking the entry for 10 ");
		System.out.println("key(s) " + tree_map_int.lowerKey(10));
		System.out.println("Checking the entry for 20 ");
		System.out.println("key(s) " + tree_map_int.lowerKey(20));
		System.out.println("Checking the entry for 30 ");
		System.out.println("key(s) " + tree_map_int.lowerKey(30));

		System.out.println("Orginal TreeMap Content : " + tree_map1.navigableKeySet());

		System.out.println("value returned " + tree_map.pollFirstEntry());
		System.out.println("value returned " + tree_map.pollLastEntry());
		System.out.println("value after poll : " + tree_map);

		SortedMap<Integer, String> sub_tree_map = new TreeMap<Integer, String>();
		sub_tree_map = tree_map.subMap(20, 40);
		System.out.println("Sub map key-value :" + sub_tree_map);

		sub_tree_map = tree_map.subMap(20, true, 40, true);
		System.out.println("sub map key-values :" + sub_tree_map);

		System.out.println("keys are greater than or equal to 20 " + tree_map.tailMap(20));
		System.out.println("keys are greater than or equal to 20 " + tree_map.tailMap(20, false));

		System.out.println("keys greater than or equal to 20 " + tree_map.ceilingEntry(20));
		System.out.println("keys greater than or equal to 40 " + tree_map.ceilingEntry(40));
		System.out.println("keys greater than or equal to 50 " + tree_map.ceilingEntry(50));

		System.out.println("keys greater than or equal to 20 " + tree_map.ceilingKey(10));
		System.out.println("keys greater than or equal to 40 " + tree_map.ceilingKey(40));
		System.out.println("keys greater than or equal to 50 " + tree_map.ceilingKey(50));
	}
}

class SortKey implements Comparator<String> {
	public int compare(String str1, String str2) {
		return str1.substring(5).compareTo(str2.substring(5));
	}
}
