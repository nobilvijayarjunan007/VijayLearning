package com.dnapass.training.day6.transaction;

import java.util.ArrayList;
import java.util.List;

public class TransactionDataLoader {

	public static List<TransactionsEntity> newTransaction() {

		List<TransactionsEntity> transactions = new ArrayList<TransactionsEntity>();

		transactions.add(new TransactionsEntity(100, ProductType.FRUIT, 45.55, "Chennai", "INR"));
		transactions.add(new TransactionsEntity(101, ProductType.GROCERY, 252.22, "london", "GBP"));
		transactions.add(new TransactionsEntity(102, ProductType.ELECTRIC, 20.99, "bangalore", "USD"));
		transactions.add(new TransactionsEntity(103, ProductType.FRUIT, 68.22, "Chennai", "INR"));
		transactions.add(new TransactionsEntity(104, ProductType.FUEL, 90.34, "london", "GBP"));
		transactions.add(new TransactionsEntity(105, ProductType.ELECTRIC, 150.56, "bangalore", "USD"));
		transactions.add(new TransactionsEntity(106, ProductType.GROCERY, 456.99, "Chennai", "INR"));
		transactions.add(new TransactionsEntity(107, ProductType.FUEL, 451.55, "bangalore", "USD"));
		return transactions;
	}

	public static List<TransactionsEntity> updateTransaction() {
		List<TransactionsEntity> transactions2 = new ArrayList<TransactionsEntity>();

		transactions2.add(new TransactionsEntity(100, ProductType.FRUIT, 45.55, "Chennai", "INR"));
		transactions2.add(new TransactionsEntity(102, ProductType.GROCERY, 252.22, "londan", "GBP"));
		transactions2.add(new TransactionsEntity(106, ProductType.ELECTRIC, 20.99, "bangalore", "USD"));
		transactions2.add(new TransactionsEntity(105, ProductType.FRUIT, 68.22, "Chennai", "INR"));
		transactions2.add(new TransactionsEntity(101, ProductType.FUEL, 90.34, "london", "GBP"));
		java.util.List<TransactionsEntity> list = TransactionDataLoader.newTransaction();
		list.addAll(transactions2);
		return list;
	}
}
