package com.dnapass.training.day6.transaction.service;

import java.util.ArrayList;
import java.util.ConcurrentModificationException;
import java.util.List;

import org.junit.Assert;
import org.junit.Test;

import com.dnapass.training.day6.transaction.ProductType;
import com.dnapass.training.day6.transaction.TransactionDataLoader;
import com.dnapass.training.day6.transaction.TransactionsEntity;

public class TransactionInMemoryRepoTest {

	public static List<TransactionsEntity> transactionDatabase = new ArrayList<TransactionsEntity>();

	static {
		transactionDatabase = TransactionDataLoader.newTransaction();
	}
	

	@Test
	public void addTransactionTest() throws ApplicationException {
		TransactionsEntity transaction1 = new TransactionsEntity(108, ProductType.FRUIT, 4555.55, "Chennai", "INR");
		Assert.assertTrue(new TransactionInMemoryRepo().createTransaction(transaction1));
		
	}
	@Test
	public void getSizeOfTransactionListAfterAddTransaction() throws ApplicationException {

		TransactionsEntity transaction1 = new TransactionsEntity(1020, ProductType.FRUIT, 45.55, "Chennai", "INR");
		
		transactionDatabase.add(transaction1);
		
		Assert.assertEquals(9,transactionDatabase.size());
		
	}
	
	@Test
	public void findTransationByIdTypeCity() throws ApplicationException {

		List<TransactionsEntity> list = new TransactionInMemoryRepo().findByIdAndProductTypeAndCity(100, ProductType.FRUIT,
				"Chennai");

		Assert.assertEquals(list,new TransactionInMemoryRepo().findByIdAndProductTypeAndCity(100, ProductType.FRUIT,
				"Chennai"));

	}
	
	@Test
	public void updateTransactionTest() throws ApplicationException,ConcurrentModificationException {
		TransactionsEntity transaction1 = new TransactionsEntity(100, ProductType.FRUIT, 8888.55, "Chennai", "INR");
	
		
		Assert.assertTrue(new TransactionInMemoryRepo().update(transaction1));
		
		
	}
	
	@Test
	public void deleteTransactionTest() throws ApplicationException {
		TransactionsEntity transaction = new TransactionsEntity(100, ProductType.FRUIT, 45.55, "Chennai", "INR");
		Assert.assertTrue(new TransactionInMemoryRepo().delete(transaction));
		
	}
}
