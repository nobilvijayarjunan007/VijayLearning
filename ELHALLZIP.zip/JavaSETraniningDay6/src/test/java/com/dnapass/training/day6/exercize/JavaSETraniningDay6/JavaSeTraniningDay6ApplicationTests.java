package com.dnapass.training.day6.exercize.JavaSETraniningDay6;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JavaSeTraniningDay6ApplicationTests {

	@Test
	void contextLoads() {
	}

}
