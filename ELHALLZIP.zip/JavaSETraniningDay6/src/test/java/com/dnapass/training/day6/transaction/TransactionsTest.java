package com.dnapass.training.day6.transaction;

import java.awt.List;

import org.junit.Assert;
import org.junit.Test;

public class TransactionsTest {
	@Test
	public void test1GetIdAfterTransaction() {

		//java.util.List<TransactionsEntity> list = TransactionDataLoader.newTransaction();

		TransactionsEntity tran1 = new TransactionsEntity(1020, ProductType.FRUIT, 45.55, "Chennai", "INR");

		Assert.assertEquals(1020, tran1.getId(), 0.01);

	}

	@Test
	public void test2displaySizeOfTheListBeforeAddingNewTransaction() {

		java.util.List<TransactionsEntity> list = TransactionDataLoader.newTransaction();

		Assert.assertEquals(8, list.size(), 0.01);

	}

	@Test
	public void test3displaySizeOfTheListAfterAddingNewTransaction() {

		java.util.List<TransactionsEntity> list = TransactionDataLoader.newTransaction();
		// list.add(index, element);

		TransactionsEntity tran1 = new TransactionsEntity(1020, ProductType.FRUIT, 455.55, "Chennai", "INR");
		list.add(tran1);
		Assert.assertEquals(9, list.size(), 0.01);

	}

	@Test
	public void test4SizeOfTheListAfterRemovingTransaction() {

		java.util.List<TransactionsEntity> list = TransactionDataLoader.newTransaction();
		list.remove(1);

		list.remove(2);

		Assert.assertEquals(6, list.size(), 0.01);

	}

	@Test
	public void test5SizeOfTheListAfterAddingAndRemovingTransaction() {

		java.util.List<TransactionsEntity> list = TransactionDataLoader.newTransaction();
		list.remove(1);
		TransactionsEntity tran1 = new TransactionsEntity(1020, ProductType.FRUIT, 455.55, "Chennai", "INR");
		list.add(tran1);
		list.remove(tran1);

		Assert.assertEquals(7, list.size(), 0.01);

	}

	@Test
	public void test6SizeOfTheListAfterAddingNewTransaction() {

		java.util.List<TransactionsEntity> list = TransactionDataLoader.updateTransaction();

		Assert.assertEquals(13, list.size(), 0.01);

	}

}