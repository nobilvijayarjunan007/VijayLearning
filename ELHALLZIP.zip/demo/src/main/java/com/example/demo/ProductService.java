package com.example.demo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ProductService {

	@Autowired
	private ProductLineRepo productLineRepo;
	@Autowired
	private ProductRepo productRepo;

	public List<ProductEntity> findProducts() {

		List<ProductEntity> orderDetailsList = productRepo.findAll();
		return orderDetailsList;
	}

	public ProductEntity findProduct(String productLineId, String productId) {

		ProductEntity ProductEntity = productRepo.findAll().stream()
				.filter(prod -> prod.getProductCode().equals(productId)
						&& prod.getProductLines().getProductLine().equals(productLineId))
				.findAny().get();
		return ProductEntity;
	}
}
