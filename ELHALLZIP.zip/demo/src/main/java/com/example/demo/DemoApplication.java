package com.example.demo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.web.bind.annotation.RestController;

@SpringBootApplication
@RestController
public class DemoApplication {

	@Autowired
	private ProductLineRepo productLineRepo;
	@Autowired
	private ProductRepo productRepo;

	public static void main(String[] args) {
		SpringApplication.run(DemoApplication.class, args);
	}

	// @Bean
	public CommandLineRunner productLineService1() {

		System.out.println("+++++++++++++++++++++++++++++++++++++++++++++++++++");
		return args -> {
			System.out.println("++++++++++++++++++++Order Details here!!!+++++++++++++++++++++++++++");
			List<ProductLineEntity> productsLinesData = Dataloader.productsLinesData();

			productLineRepo.saveAll(productsLinesData);

		};

	}

	@Bean

	public CommandLineRunner productService1() {

		System.out.println("+++++++++++++++++++++++++++++++++++++++++++++++++++");
		return args -> {
			System.out.println("++++++++++++++++++++Order Details here!!!+++++++++++++++++++++++++++");
			List<ProductEntity> productsData = Dataloader.loadProducts();

			productRepo.saveAll(productsData);

		};

	}

}
