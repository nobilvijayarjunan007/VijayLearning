package com.dnapass.training.dataloader;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.dnapass.training.entities.CustomerEntity;
import com.dnapass.training.entities.PaymentEntity;

public class DataLoader1 {

	public static List<CustomerEntity> customersLoader() {

		List<CustomerEntity> customers = new ArrayList<>();

		CustomerEntity cust1 = new CustomerEntity(null, "Atelier graphique", "Schmitt", "Carine ", "40.32.2555",
				"54, rue Royale", null, "Nantes", null, "44000", "France", "21000.00", 1l);

		CustomerEntity cust2 = new CustomerEntity(null, "Signal Gift Stores", "King", "Jean", "7025551838",
				"8489 Strong St.", null, "Las Vegas", "NV", "83030", "USA", "71800.00", 2l);

		CustomerEntity cust3 = new CustomerEntity(null, "Australian Collectors, Co.", "Ferguson", "Peter",
				"03 9520 4555", "636 St Kilda Road", "Level 3", "Melbourne", "Victoria", "3004", "Australia",
				"117300.00", 3l);

		PaymentEntity pay1 = new PaymentEntity("HQ336336", "2004-10-19", 6066, cust1);

		PaymentEntity pay2 = new PaymentEntity("OM314933", "2003-06-05", 14571, cust1);

		PaymentEntity pay3 = new PaymentEntity("BO864823", "2004-12-18", 1676, cust2);

		cust1.setPayments(Arrays.asList(pay1, pay2));
		cust2.setPayments(Arrays.asList(pay3));

		customers.add(cust1);
		customers.add(cust2);

		return customers;
	}
//		

//	public static List<PaymentEntity> paymentLoader() {
//
//		List<PaymentEntity> payments = new ArrayList<>();
//		payments.add(new PaymentEntity(null, "HQ336336", "2004-10-19", 6066, null));
//		payments.add(new PaymentEntity(null, "OM314933", "2003-06-05", 14571, null));
//		payments.add(new PaymentEntity(null, null, "2004-12-18", 1676, null));
//		payments.add(new PaymentEntity(null, null, "2004-12-17", 14191, null));
//		payments.add(new PaymentEntity(null, null, "2003-06-06", 32641, null));
//		payments.add(new PaymentEntity(null, null, "2004-08-20", 33347, null));
//		payments.add(new PaymentEntity(null, null, "2003-05-20", 45864, null));
//		payments.add(new PaymentEntity(null, null, "2004-12-15", 82261, null));
//		payments.add(new PaymentEntity(null, null, "2003-05-31", 7565, null));
//		payments.add(new PaymentEntity(null, null, "2004-03-10", 44894, null));
//		payments.add(new PaymentEntity(null, null, "2004-12-31", 52166, null));
//
//		return payments;
//
//	}

//	public static List<CustomerEntity> loadCustomers()
//	{
//	List<CustomerEntity> custList=new ArrayList<>();
//	CustomerEntity cust=new CustomerEntity(null,"Atelier graphique","Schmitt","Carine","40.32.2555",
//	"54, rue Royale",null,"Nantes",null,"44000","France",21000.00);
//	CustomerEntity cust1=new CustomerEntity(null,"Signal Gift Stores","King","Jean","7025551838",
//	"8489 Strong St.",null,"Las Vegas","NV","83030","USA",71800.00);
//
//
//	PaymentEntity pay1=new PaymentEntity(null,"HQ336336",cust,"24-02-2000",6066.78);
//	// PaymentEntity pay2=new PaymentEntity(cust,"JM555205",LocalDate.of(2003,06,05),14571.44);
//	// PaymentEntity pay3=new PaymentEntity(cust,"OM314933",LocalDate.of(2004,12,18),1676.14);
//	PaymentEntity pay4=new PaymentEntity(null,"BO864823",cust1,LocalDate.of(2004,12,7),14191.12);
//	// PaymentEntity pay5=new PaymentEntity(cust1,"HQ55022",LocalDate.of(2003,06,06),32641.98);
//	// PaymentEntity pay6=new PaymentEntity(cust1,"ND748579",LocalDate.of(2004,10,20),33347.88);
//	cust.setPayment(pay1);
//	cust1.setPayment(pay4);
//	custList.add(cust);
//	custList.add(cust1);
//	return custList;
//	}
//	

}
