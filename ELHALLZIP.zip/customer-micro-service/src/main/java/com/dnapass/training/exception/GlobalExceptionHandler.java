package com.dnapass.training.exception;

import java.util.ArrayList;
import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

@ControllerAdvice
public class GlobalExceptionHandler extends ResponseEntityExceptionHandler {

	@ExceptionHandler(ApplicationException.class)
	ResponseEntity<ErrorResponse> applicationExceptionHandler(ApplicationException ex) {
		System.out.println("++++++++++++ApplicationException Called++++++++++++");
		List<String> details = new ArrayList<>();
		details.add(ex.getMessage());
		details.add(ex.toString());
		ErrorResponse error = new ErrorResponse(ex.getMessage(), details, ErrorCode.APP0001);
		return new ResponseEntity<>(error, HttpStatus.CONFLICT);
	}

	@ExceptionHandler(NullPointerException.class)
	ResponseEntity<ErrorResponse> nullPointerHandler(NullPointerException ex) {
		System.out.println("++++++++++++NullPointerException Called++++++++++++");
		List<String> details = new ArrayList<>();
		details.add(ex.getMessage());
		details.add(ex.toString());
		ErrorResponse error = new ErrorResponse(ex.getMessage(), details, ErrorCode.APP0002);
		return new ResponseEntity<>(error, HttpStatus.INTERNAL_SERVER_ERROR);
	}

	@ExceptionHandler(Exception.class)
	ResponseEntity<ErrorResponse> ExceptionHandler(Exception ex) {
		System.out.println("++++++++++++Exception Called++++++++++++");

		List<String> details = new ArrayList<>();
		details.add(ex.getMessage());
		details.add(ex.toString());
		ErrorResponse error = new ErrorResponse(ex.getMessage(), details, ErrorCode.APP0003);
		return new ResponseEntity<>(error, HttpStatus.INTERNAL_SERVER_ERROR);
	}
}
