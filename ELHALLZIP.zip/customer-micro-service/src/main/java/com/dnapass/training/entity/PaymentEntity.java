//package com.dnapass.training.entity;
//
//import java.io.Serializable;
//import java.util.Objects;
//
//import javax.persistence.CascadeType;
//import javax.persistence.Column;
//import javax.persistence.EmbeddedId;
//import javax.persistence.Entity;
//import javax.persistence.FetchType;
//import javax.persistence.GeneratedValue;
//import javax.persistence.Id;
//import javax.persistence.IdClass;
//import javax.persistence.JoinColumn;
//import javax.persistence.MapsId;
//import javax.persistence.OneToOne;
//
//import com.fasterxml.jackson.annotation.JsonManagedReference;
//
//@Entity(name = "Payments")
////@IdClass(CustomerPaymentKey.class)
//public class PaymentEntity implements Serializable {
//
//	private static final long serialVersionUID = 1L;
//	@EmbeddedId
//	private CustomerPaymentKey customerPaymentKey;
//	// @Id
//	// @GeneratedValue
//	// private CustomerEntity customerNumber;
//	// @Id
//	// @GeneratedValue
//	// @Column(name = "check_number")
//	// private Long checkNumber;
//	private String paymentDate;
//	private Integer amount;
//	@JsonManagedReference
//	@OneToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
//	@MapsId("customerNumberPk")
//	@JoinColumn(name = "customer_Number")
//	private CustomerEntity customer;
//
//	public PaymentEntity() {
//		super();
//	}
//
//	public PaymentEntity(CustomerPaymentKey customerPaymentKey, String paymentDate, Integer amount,
//			CustomerEntity customer) {
//		super();
//		this.customerPaymentKey = customerPaymentKey;
//		this.paymentDate = paymentDate;
//		this.amount = amount;
//		this.customer = customer;
//	}
//
//	public PaymentEntity(String paymentDate, Integer amount) {
//		super();
//		this.paymentDate = paymentDate;
//		this.amount = amount;
//	}
//
//	public PaymentEntity(String paymentDate, Integer amount, CustomerEntity customer) {
//		super();
//		this.paymentDate = paymentDate;
//		this.amount = amount;
//		this.customer = customer;
//	}
//
//	public PaymentEntity(CustomerPaymentKey customerPaymentKey, String paymentDate, Integer amount) {
//		super();
//		this.customerPaymentKey = customerPaymentKey;
//		this.paymentDate = paymentDate;
//		this.amount = amount;
//	}
//
//	public CustomerPaymentKey getCustomerPaymentKey() {
//		return customerPaymentKey;
//	}
//
//	public void setCustomerPaymentKey(CustomerPaymentKey customerPaymentKey) {
//		this.customerPaymentKey = customerPaymentKey;
//	}
//
//	public String getPaymentDate() {
//		return paymentDate;
//	}
//
//	public void setPaymentDate(String paymentDate) {
//		this.paymentDate = paymentDate;
//	}
//
//	public Integer getAmount() {
//		return amount;
//	}
//
//	public void setAmount(Integer amount) {
//		this.amount = amount;
//	}
//
//	public CustomerEntity getCustomer() {
//		return customer;
//	}
//
//	public void setCustomer(CustomerEntity customer) {
//		this.customer = customer;
//	}
//
//	@Override
//	public int hashCode() {
//		final int prime = 31;
//		int result = 1;
//		result = prime * result + ((amount == null) ? 0 : amount.hashCode());
//		result = prime * result + ((customer == null) ? 0 : customer.hashCode());
//		result = prime * result + ((customerPaymentKey == null) ? 0 : customerPaymentKey.hashCode());
//		result = prime * result + ((paymentDate == null) ? 0 : paymentDate.hashCode());
//		return result;
//	}
//
//	@Override
//	public boolean equals(Object obj) {
//		if (this == obj)
//			return true;
//		if (obj == null)
//			return false;
//		if (getClass() != obj.getClass())
//			return false;
//		PaymentEntity other = (PaymentEntity) obj;
//		if (amount == null) {
//			if (other.amount != null)
//				return false;
//		} else if (!amount.equals(other.amount))
//			return false;
//		if (customer == null) {
//			if (other.customer != null)
//				return false;
//		} else if (!customer.equals(other.customer))
//			return false;
//		if (customerPaymentKey == null) {
//			if (other.customerPaymentKey != null)
//				return false;
//		} else if (!customerPaymentKey.equals(other.customerPaymentKey))
//			return false;
//		if (paymentDate == null) {
//			if (other.paymentDate != null)
//				return false;
//		} else if (!paymentDate.equals(other.paymentDate))
//			return false;
//		return true;
//	}
//
//	@Override
//	public String toString() {
//		return "PaymentEntity [customerPaymentKey=" + customerPaymentKey + ", paymentDate=" + paymentDate + ", amount="
//				+ amount + ", customer=" + customer + "]";
//	}
//
//}
