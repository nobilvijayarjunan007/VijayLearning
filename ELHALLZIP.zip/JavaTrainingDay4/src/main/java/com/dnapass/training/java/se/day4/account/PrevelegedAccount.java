package com.dnapass.training.java.se.day4.account;

public class PrevelegedAccount  extends Account {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public void withdraw(double amount) {
		super.setAccountBalance(super.getAccountBalance()-amount);
	}
}
