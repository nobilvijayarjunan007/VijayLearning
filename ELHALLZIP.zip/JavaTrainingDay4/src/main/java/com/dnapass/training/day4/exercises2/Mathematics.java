package com.dnapass.training.day4.exercises2;

public class Mathematics {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		AdvancedArithmetic adv = new MyCalculator();
		int sumOfDivisor=adv.divisor_sum(5);
		System.out.println(sumOfDivisor);
	}

}
