package com.dnapass.training.day4.exercises1;

public class Circle extends Shape {

	private Integer radius;
	

	public Circle() {
		super();
	}

	public Circle(String name, Integer radius) {
		super(name);

		this.radius=radius;
	}

	@Override
	Float calculateArea() {

		Float areaOfCircle=(float) ((Math.PI)*Math.pow(radius, 2));
		return areaOfCircle ;
	}

	public Integer getRadius() {
		return radius;
	}

	public void setRadius(Integer radius) {
		this.radius = radius;
	}
}
