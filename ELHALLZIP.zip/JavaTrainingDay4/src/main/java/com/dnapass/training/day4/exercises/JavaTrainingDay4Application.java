package com.dnapass.training.day4.exercises;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JavaTrainingDay4Application {

	public static void main(String[] args) {
		SpringApplication.run(JavaTrainingDay4Application.class, args);
	}

}
