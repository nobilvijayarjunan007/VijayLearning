package com.dnapass.training.day4.exercises6;

public class Father extends GrandFather {

	 int b = 75;

	public int getB() {
		return b;
	}

	public void setB(int b) {
		this.b = b;
	}

	public  int display() {

		System.out.println("Father has " + b + " books");
		return b;
	}
}