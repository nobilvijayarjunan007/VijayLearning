package com.dnapass.training.day4.exercises6;

public class Child extends Father {

     int c = 15;

	public int getC() {
		return c;
	}

	public void setC(int c) {
		this.c = c;
	}

	public  int display() {

		System.out.println("chil has " + c + " books");
		
		return c;
	}
}