package com.dnapass.training.java.se.day4.bank;

public class SBI implements Bank {

	@Override
	public int getInterestRate() {
		// TODO Auto-generated method stub
		return 6;
		
	}

	
}
