package com.dnapass.training.day4.exercises5;

public class NumberUtil {

	int number1 = 100;

	public NumberUtil() {

	}

	public void setNumber1(int value) {

		number1 = value;

	}

	public int getNumber1() {

		return number1;

	}
}