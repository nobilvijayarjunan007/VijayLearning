package com.dnapass.training.java.se.day4.bank;

public interface Bank {

	public int minimumBalance=1000;
	
    int getInterestRate();
}
