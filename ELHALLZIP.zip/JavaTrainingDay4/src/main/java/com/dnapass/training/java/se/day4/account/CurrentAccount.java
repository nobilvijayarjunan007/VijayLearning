package com.dnapass.training.java.se.day4.account;

import java.util.Objects;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;



public class CurrentAccount extends Account{
	static Logger logger = LoggerFactory.getLogger(CurrentAccount.class); 
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private static final int FREE_TRANSACTION=3;
	private static final double TRANSACTION_FEE=2.0;
	private double transactionCount;
	
	public CurrentAccount(int accountNumber,double initialBalance) {
		
		super(accountNumber,initialBalance);
		
		transactionCount = 0;
		
	}
	public void deposite(Double amount) {
		
		System.out.println("account deposite called");
		transactionCount++;
		super.deposite(amount);
		
	}
	public void withdraw(double amount) {
		transactionCount++;
		//System.out.println("transactionCount >>"+transactionCount);
		if(transactionCount>3){
			this.deductFees();}
		super.withdraw(amount);
	}
	
	public void deductFees() {
		if(transactionCount> FREE_TRANSACTION) {
			double fees = TRANSACTION_FEE*(transactionCount-FREE_TRANSACTION);
			System.out.println("fees"+fees);
			super.withdraw(fees);
		}
		transactionCount=transactionCount-1;
		
		
		
	}
	
	
}
