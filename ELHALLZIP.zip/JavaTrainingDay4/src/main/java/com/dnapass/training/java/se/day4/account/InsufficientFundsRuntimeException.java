package com.dnapass.training.java.se.day4.account;

import java.util.Arrays;

import com.dnapass.training.java.se.day4.account.Errorcode;

public class InsufficientFundsRuntimeException extends RuntimeException {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	//private String message ;
	private double accountBalance;
	Errorcode errcode;
	public InsufficientFundsRuntimeException(String string, double accountBalance, Errorcode err0001) {
		super(string);
		
		this.accountBalance=accountBalance;
		this.errcode=err0001;
	}
	
	/*public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}*/

	public double getAccountBalance() {
		return accountBalance;
	}

	public void setAccountBalance(double accountBalance) {
		this.accountBalance = accountBalance;
	}

	public Errorcode getErrcode() {
		return errcode;
	}

	public void setErrcode(Errorcode errcode) {
		this.errcode = errcode;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	

	@Override
	public String toString() {
		final int maxLen = 10;
		return "InsufficientFundsRuntimeException [accountBalance=" + accountBalance + ", "
				+ (errcode != null ? "errcode=" + errcode + ", " : "") + "getAccountBalance()=" + getAccountBalance()
				+ ", " + (getErrcode() != null ? "getErrcode()=" + getErrcode() + ", " : "")
				+ (getMessage() != null ? "getMessage()=" + getMessage() + ", " : "")
				+ (getLocalizedMessage() != null ? "getLocalizedMessage()=" + getLocalizedMessage() + ", " : "")
				+ (getCause() != null ? "getCause()=" + getCause() + ", " : "")
				+ (super.toString() != null ? "toString()=" + super.toString() + ", " : "")
				+ (fillInStackTrace() != null ? "fillInStackTrace()=" + fillInStackTrace() + ", " : "")
				+ (getStackTrace() != null ? "getStackTrace()="
						+ Arrays.asList(getStackTrace()).subList(0, Math.min(getStackTrace().length, maxLen)) + ", "
						: "")
				
				+ (getSuppressed() != null ? "getSuppressed()="
						+ Arrays.asList(getSuppressed()).subList(0, Math.min(getSuppressed().length, maxLen)) + ", "
						: "")
				+ (getClass() != null ? "getClass()=" + getClass() + ", " : "") + "hashCode()=" + hashCode() + "]";
	}

	

}
