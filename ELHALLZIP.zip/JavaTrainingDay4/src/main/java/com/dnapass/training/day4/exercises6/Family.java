package com.dnapass.training.day4.exercises6;

public class Family {

	static int a = 555;

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		GrandFather objA = new GrandFather();

		Father objB1 = new Father();

		GrandFather objB2 = new Father();

		Child objC1 = new Child();

		Father objC2 = new Child();

		GrandFather objC3 = new Child();

		objA.display();

		objB1.display();

		objB2.display();

		objC1.display();

		objC2.display();

		objC3.display();
	}

}
