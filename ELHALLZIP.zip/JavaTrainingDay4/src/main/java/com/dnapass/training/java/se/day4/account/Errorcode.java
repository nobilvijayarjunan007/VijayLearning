package com.dnapass.training.java.se.day4.account;

public enum Errorcode {
	err0001,err0002
}
