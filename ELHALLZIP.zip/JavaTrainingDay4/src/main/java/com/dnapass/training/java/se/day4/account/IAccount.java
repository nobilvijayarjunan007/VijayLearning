package com.dnapass.training.java.se.day4.account;

public interface IAccount {

	void showData();

	void deposite(Double depositeAmount);

	void withdraw(double withdrawalAmount);

	void transfer(double amount, IAccount other);

}