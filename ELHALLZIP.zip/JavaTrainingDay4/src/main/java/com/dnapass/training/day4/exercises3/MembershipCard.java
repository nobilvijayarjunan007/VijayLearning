package com.dnapass.training.day4.exercises3;

public class MembershipCard extends Card {

	private Integer rating;
	
	

	public MembershipCard() {
		super();
	}

	public MembershipCard(String holderName, String cardNumber, String expiryDate, Integer rating) {
		super(holderName, cardNumber, expiryDate);
		this.rating = rating;
	}

	public Integer getRating() {
		return rating;
	}

	public void setRating(Integer rating) {
		this.rating = rating;
	}

	@Override
	public String toString() {
		return "MembershipCard [" + (rating != null ? "rating=" + rating + ", " : "")
				+ (holderName != null ? "holderName=" + holderName + ", " : "")
				+ (cardNumber != null ? "cardNumber=" + cardNumber + ", " : "")
				+ (expiryDate != null ? "expiryDate=" + expiryDate : "") + "]";
	}
	
	
}
