package com.dnapass.training.java.se.day4.bank;

import org.junit.Test;

import junit.framework.Assert;

public class SBI_And_ICICI_Test {

	SBI bank = new SBI();
	ICICI_Bank bank1 = new ICICI_Bank();
	@Test
	public void testMinimumBalanceOfSBI() {
		
		Assert.assertEquals(1000, bank.minimumBalance);
		
	}
	@Test
	public void testSBI_InterestRate() {
		
		Assert.assertEquals(6, bank.getInterestRate());
		
	}
	@Test
	public void testMinimumBalanceOfICICI() {
		
		Assert.assertEquals(1000, bank1.minimumBalance);
		
	}
	@Test
	public void testICICI_InterestRate() {
		
		Assert.assertEquals(8, bank1.getInterestRate());
		
	}
}
