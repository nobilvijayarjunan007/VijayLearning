package com.dnapass.training.day4.exercises6;

import org.junit.Assert;
import org.junit.Test;

public class FamilyTest {

	GrandFather objA = new GrandFather();
	@Test
	public void test1() {
		
		Assert.assertEquals(100,objA.display());
		
	}
}
