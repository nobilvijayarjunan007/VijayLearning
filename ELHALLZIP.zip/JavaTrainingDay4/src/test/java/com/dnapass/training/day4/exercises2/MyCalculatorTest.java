package com.dnapass.training.day4.exercises2;

import org.junit.Assert;
import org.junit.Test;

public class MyCalculatorTest {

	MyCalculator myCisco = new MyCalculator();	
	@Test
	public void test1() {
		
		Assert.assertEquals(7,myCisco.divisor_sum(4));
		
		
	}
	@Test
	public void test2() {
		
		Assert.assertEquals(28,myCisco.divisor_sum(12));
		
		
	}
	@Test
	public void test3() {
		
		Assert.assertEquals(6,myCisco.divisor_sum(5));
		
		
	}
	@Test
	public void test4() {
		
		Assert.assertEquals(18,myCisco.divisor_sum(10));
		
		
	}
}
