package com.dnapass.training.java.se.test.suite.day4;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

import com.dnapass.training.day4.exercises1.AreaOfShapeTest;
import com.dnapass.training.day4.exercises2.MyCalculatorTest;
import com.dnapass.training.day4.exercises4.SetterAndGetterTest;
import com.dnapass.training.day4.exercises5.NumberUtilTest;
import com.dnapass.training.day4.exercises6.FamilyTest;
import com.dnapass.training.java.se.day4.account.AccountTest;
import com.dnapass.training.java.se.day4.bank.SBI_And_ICICI_Test;

@RunWith(Suite.class)
@Suite.SuiteClasses({AreaOfShapeTest.class,MyCalculatorTest.class,SetterAndGetterTest.class,NumberUtilTest.class,FamilyTest.class,AccountTest.class,SBI_And_ICICI_Test.class})
public class TestSuiteDay4 {

}
