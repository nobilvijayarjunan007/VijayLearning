package com.dnapass.training.java.se.day4.account;

import org.junit.Test;

import com.dnapass.training.java.se.day4.account.CurrentAccount;
import com.dnapass.training.java.se.day4.account.PrevelegedAccount;
import com.dnapass.training.java.se.day4.account.SavingsAccount;

import junit.framework.Assert;

public class AccountTest {

	SavingsAccount savingAccts = new SavingsAccount(1,10000,0.5);
	CurrentAccount currentAccts = new CurrentAccount(2,2000);
	
	@Test
	public void test1CheckSavingsAccountBalance() {
		
		Assert.assertEquals(10000,savingAccts.getAccountBalance(),0.0 );
		
	}
	
	@SuppressWarnings("deprecation")
	@Test
	public void test2DepositSavingsAccountAfterDeposit() {
		savingAccts.deposite(25000d);
		Assert.assertEquals(35000,savingAccts.getAccountBalance() , 0.0);
		
	}
	@Test
	public void test3CheckSavingsAccountBalanceAfterWithdrawal() {
		savingAccts.withdraw(1500);
		Assert.assertEquals(8500,savingAccts.getAccountBalance(),0.0 );
		
		
	}
	@Test
	public void test4CheckCuuretAccountBalanceAfterWithdrawal() {
		currentAccts.withdraw(1500);
		
		Assert.assertEquals(500,currentAccts.getAccountBalance(),0.0 );
		
		
	}
	@Test
	public void test5CheckCuuretAccountBalanceAfterWithdrawal() {
		currentAccts.deposite(12500d);;
		Assert.assertEquals(14500,currentAccts.getAccountBalance(),0.0 );
		
		
	}
	@Test
	public void test6CheckCuuretAccountBalanceAfterWithdrawal() {
		
		currentAccts.withdraw(1000);
		currentAccts.withdraw(100);
		currentAccts.withdraw(100);
		currentAccts.withdraw(100);
		currentAccts.withdraw(100);
		currentAccts.withdraw(100);
		Assert.assertEquals(494,currentAccts.getAccountBalance(),0.0 );
		
		
	}
	@Test
	public void test7CheckPrevelegedAccountBalanceAfterWithdrawal() {
		PrevelegedAccount prevAcc= new PrevelegedAccount();
		prevAcc.deposite(5500d);
		prevAcc.withdraw(6000);
		Assert.assertEquals(-500,prevAcc.getAccountBalance(),0.0 );
		
		
	}
}
