package com.dnapass.training;

import java.util.Arrays;
import java.util.List;
import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.ServiceInstance;
import org.springframework.cloud.client.discovery.DiscoveryClient;
import org.springframework.core.env.Environment;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

//import com.netflix.discovery.DiscoveryClient;

@RestController
public class ServiceInstanceRestController {

	@Autowired
	private Environment environment;

	@Autowired
	private DiscoveryClient discoveryClient;

	@RequestMapping("/service-instances/{applicationName}")
	public List<ServiceInstance> serviceInstanceByApplicationName(@PathVariable String applicationName) {

		return this.discoveryClient.getInstances(applicationName);

	}

	@RequestMapping("/hello")
	public String home() {
		EurekaClientDemoApplication.log.info("Access / hello");

		List<String> greetings = Arrays.asList("Hi there", "Greetings", "Salutation");
		Random random = new Random();
		int randumNum = random.nextInt(greetings.size());

		return greetings.get(randumNum) + ":" + environment.getProperty("local.server.port");

	}
}
