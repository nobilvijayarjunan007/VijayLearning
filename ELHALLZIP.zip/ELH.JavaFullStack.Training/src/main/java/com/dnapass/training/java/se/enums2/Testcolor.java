package com.dnapass.training.java.se.enums2;

public enum Testcolor {
	GREEN
}
