package com.dnapass.training.java.se.lambda;

public interface Something {

	public String doit(Integer i);
}
