package com.dnapass.training.java.se.generics;

public interface Pair<K,V> {
	
	K getKey();
	V getValue();

}
