package com.dnapass.training.java.se.file.nio.day11;

import java.util.Objects;



public class Account {

	
	private static final long serialVersionUID = 1L;

	private static int LAST_ASSIGNED_NUMBER = 0;

	private int accountNumber;
	private double accountBalance;


	public Account() {
		super();
		LAST_ASSIGNED_NUMBER++;
		accountNumber = LAST_ASSIGNED_NUMBER;

	}

	public Account(int accountNumber, double accountBalance) {
		super();
		this.accountNumber = accountNumber;
		this.accountBalance = accountBalance;

	}
	public Account(double accountBalance) {
		super();
		LAST_ASSIGNED_NUMBER++;
		accountNumber = LAST_ASSIGNED_NUMBER;

		this.accountBalance = accountBalance;
	}

	public void showData() {
		System.out.println("Account Number : " + accountNumber);
		System.out.println("Account Balance : " + accountBalance);
	}

	public void deposite(Double depositeAmount) {
		Objects.requireNonNull(depositeAmount, " Requried field missing");
		System.out.println("Account deposit called :");

		if (depositeAmount < 0) {

		} else {
			accountBalance = accountBalance + depositeAmount;

		}
	}

	public void transfer(double amount, Account other) {
		withdraw(amount);
		other.deposite(amount);

	}

	public void withdraw(double withdrawlAmount) {
		// TODO Auto-generated method stub
		if (accountBalance < withdrawlAmount) {

		} else {
			accountBalance -= withdrawlAmount;

		}
	}

	public int getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(int accountNumber) {
		this.accountNumber = accountNumber;
	}

	public double getAccountBalance() {
		return accountBalance;
	}

	public void setAccountBalance(double accountBalance) {
		this.accountBalance = accountBalance;
	}

	@Override
	public String toString() {
		return "Account [accountNumber=" + accountNumber + ", accountBalance=" + accountBalance + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		long temp;
		temp = Double.doubleToLongBits(accountBalance);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		result = prime * result + accountNumber;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Account other = (Account) obj;
		if (Double.doubleToLongBits(accountBalance) != Double.doubleToLongBits(other.accountBalance))
			return false;
		if (accountNumber != other.accountNumber)
			return false;
		return true;
	}

	

}
