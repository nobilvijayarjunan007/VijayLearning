package com.dnapass.training.java.se.streams;

public class StreamPractice {
	public enum Day {
		Sun, Mon, Tue, Wed, Thu, Fri, Sat
	};

	public static void main(String[] args) {

		Day[] days = Day.values();

		for (Day day : days)
			switch (day) {
			case Sun:
				System.out.println("Sunday");

				break;
			case Mon:
				System.out.println("Monady");

				break;
			case Tue:
				System.out.println("Tuesday");

				break;
			case Wed:
				System.out.println("Wednesday");

				break;
			case Thu:
				System.out.println("Thursdayy");

				break;
			case Fri:
				System.out.println("Friday");

				break;
			case Sat:
				System.out.println("Saturday");

				break;

			default:
				System.out.println("Invalid day");
				break;
			}
	}
}
