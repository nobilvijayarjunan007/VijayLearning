package com.dnapass.training.java.se.enums2;

public class Pizza2 {

	private PizzaStatus status = PizzaStatus.DELIVERED;

	public enum PizzaStatus {
		ORDERED(5) {

			public boolean isOrdered() {
				return true;
			}
		},

		READY(2) {

			public boolean isReady() {
				return true;
			}
		},

		DELIVERED(0) {
			public boolean isDelivered1() {
				return true;
			}
		};

		private int timeToDelivery;

		public boolean isOrdered() {
			return false;
		}

		public boolean isReady() {
			return false;
		}

		public boolean isDelivered() {
			return false;
		}

		public int getTimeToDelivery() {

			return timeToDelivery;
		}

		PizzaStatus(int timeDelivery) {
			this.timeToDelivery = timeToDelivery;
		}

	}

	public boolean isDeiverable() {

		return this.status.isReady();
	}

	public void setStatus(PizzaStatus ready) {

	}

	public PizzaStatus getStatus() {

		return status;

	}

	public void printTimeToDeliver() {
		System.out.println("Time to delivery is " + this.getStatus().getTimeToDelivery());
	}

	// method that set and get the status variable

}
