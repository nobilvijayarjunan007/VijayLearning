package com.dnapass.training.java.se.threads1.day9;

public class ThreadDemo {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub

		HelloRunnable helloRunnable =new HelloRunnable();
		Thread thread =new Thread(helloRunnable);
		thread.start();
		
		Hellothread  hellothread =new  Hellothread();
		hellothread.start();
		
		String importantInfo[] ={"mares eats oats", "Does  eat oats","little lamps ivy",
	"A kid will eat ivy too"	};
	
		
		for (int i=0;i< importantInfo.length ;i++) {
			Thread.sleep(4000);
			System.out.println(importantInfo[i]);
		}
		
		for (int i=0;i< importantInfo.length ;i++) {
			try {
				Thread.sleep(4000);
			}
			catch (InterruptedException e) {
				return;
			
			}
			System.out.println(importantInfo[i]);
		}
		for (int i=0;i< importantInfo.length ;i++) {
			heavycrunch(importantInfo[i]);
			
			if (Thread.interrupted()){
				
				return ;
				
		}
			if (Thread.interrupted()){
				throw new InterruptedException ();
				
			}
		}
		

		
	
	}

	private static void heavycrunch( String string) {
		
		
	}


}
