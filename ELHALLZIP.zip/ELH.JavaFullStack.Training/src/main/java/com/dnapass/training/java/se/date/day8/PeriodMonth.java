package com.dnapass.training.java.se.date.day8;

import java.time.LocalDate;
import java.time.Period;


public class PeriodMonth {

	public static void main(String[] args) {
		
		LocalDate localDate1 = LocalDate.parse("2022-03-01");
		LocalDate localDate2 = LocalDate.parse("2022-09-16");

		// calculate difference
		long month = Period.between(localDate1, localDate2).getMonths();

		// print days
		System.out.println("Months between " + localDate1 + " and " + localDate2 + ": " + month);

		
	}

}
