package com.dnapass.training.java.se.threads.excercise1.day9;

import java.util.Calendar;
import java.util.Date;

public class ChildThread extends Thread{

	public void run() {
		
		
		try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		Calendar cal=Calendar.getInstance();
		Date date=cal.getTime();
		System.out.println(date);
	}
}
