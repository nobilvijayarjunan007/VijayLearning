package com.dnapass.training.java.se.date.day8;

public class IPAddress {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String str = "132.145.184.210";
		String[] str1 = str.split("[.]");
		int count=0;
		for (int i=0;i<str1.length;i++) {
			int j = Integer.parseInt(str1[i]);
			
			if (j >= 0 && j <= 255) {
					count++;
			}

		}
		if(count==4) {System.out.println("valid");}
		else {System.out.println("InValid");}
		
	}

}
