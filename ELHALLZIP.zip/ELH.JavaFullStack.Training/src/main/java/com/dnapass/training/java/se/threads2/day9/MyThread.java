package com.dnapass.training.java.se.threads2.day9;

public class MyThread  extends Thread{
	public  MyThread (String name) {
		super(name);
	}
	public void run () {
		 System.out.println("My Thread  - START" +Thread.currentThread().getName());
	
		 try {
			 Thread.sleep(1000);
			
		 doDBProcessing ();
		 }
		catch (InterruptedException e){
			e.printStackTrace();
		}	
		 System.out.println("My Thread  - END" +Thread.currentThread().getName());
			
}
	private void doDBProcessing() throws InterruptedException {
		// TODO Auto-generated method stub
		 Thread.sleep(1000);
	}
}