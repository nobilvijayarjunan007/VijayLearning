package com.dnapass.training.java.se.date.day8;

import java.util.ArrayList;

import java.util.Collections;
import java.util.List;

public class SubArrayList {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int[] num = { 1, 3, 4, 2, 5, 7, 6, 8, 10, 9 };

		List list = getSubArrayList(num);
		System.out.println(list);
	}

	private static List getSubArrayList(int[] num) {
		ArrayList al = new ArrayList();
		for (int n : num) {

			al.add(n);

		}

		System.out.println(al);
		Collections.sort(al);

		Object[] ob = al.toArray();
		ArrayList subList = new ArrayList();
		for (int i = 0; i < ob.length; i++) {
			if (i == 2 || i == 6 || i == 8) {

				subList.add(ob[i]);
			}

		}

		
		return subList;
	}

}
