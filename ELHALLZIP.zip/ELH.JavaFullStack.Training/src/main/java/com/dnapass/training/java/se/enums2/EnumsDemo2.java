package com.dnapass.training.java.se.enums2;

import java.util.ArrayList;
import java.util.EnumMap;
import java.util.EnumSet;
import java.util.List;
import java.util.stream.Collectors;

public class EnumsDemo2 {

	public static void main(String[] args) {

		Pizza testPz = new Pizza();

		// at run time safety
		if (testPz.getStatus().equals(Pizza.PizzaStatus.DELIVERED))
			;

		if (testPz.getStatus() == (Pizza.PizzaStatus.DELIVERED))
			;

		// COMPILE TIME SAFETY
		if (testPz.getStatus().equals(Testcolor.GREEN))
			;

		// if (testPz.getStatus() == TestColor.GREEN);

		Pizza2 testPz2 = new Pizza2();
		testPz2.setStatus(Pizza2.PizzaStatus.READY);
		System.out.println(testPz.isDeliverable());

		EnumSet<PizzaStatus> undeliveredPizzaStatuses = EnumSet.of(PizzaStatus.ORDERED, PizzaStatus.READY);
		List<Pizza> pzList = new ArrayList<>();
		Pizza pz1 = new Pizza();
		pz1.setStatus(Pizza.PizzaStatus.DELIVERED);

		Pizza pz2 = new Pizza();
		pz2.setStatus(Pizza.PizzaStatus.ORDERED);

		Pizza pz3 = new Pizza();
		pz3.setStatus(Pizza.PizzaStatus.ORDERED);

		Pizza pz4 = new Pizza();
		pz4.setStatus(Pizza.PizzaStatus.READY);

		pzList.add(pz1);
		pzList.add(pz2);
		pzList.add(pz3);
		pzList.add(pz4);

		List<Pizza> list = pzList.stream().filter((s) -> undeliveredPizzaStatuses.contains(s.getStatus()))
				.collect(Collectors.toList());

		EnumMap<Pizza.PizzaStatus, List<Pizza>> map = groupPizzaByStatus(pzList);
		System.out.println(map.get(Pizza.PizzaStatus.DELIVERED).size());
		System.out.println(map.get(Pizza.PizzaStatus.ORDERED).size());

		System.out.println(map.get(Pizza.PizzaStatus.READY).size());

	}

	public static EnumMap<Pizza.PizzaStatus, List<Pizza>> groupPizzaByStatus(List<Pizza> pizzaList) {

		EnumMap<Pizza.PizzaStatus, List<Pizza>> pzByStatus = new EnumMap<>(Pizza.PizzaStatus.class);

		for (Pizza pz : pizzaList) {

			Pizza.PizzaStatus status = pz.getStatus();
			if (pzByStatus.containsKey(status)) {
				pzByStatus.get(status).add(pz);
			} else {
				List<Pizza> newPzList = new ArrayList<Pizza>();
				newPzList.add(pz);
				pzByStatus.put(status, newPzList);
			}
		}

		return pzByStatus;

	}

	public static EnumMap<Pizza.PizzaStatus, List<Pizza>> groupPizzaByStatusJavaB(List<Pizza> pzList) {
		return pzList.stream().collect(Collectors.groupingBy(Pizza::getStatus,
				() -> new EnumMap<>(Pizza.PizzaStatus.class), Collectors.toList()));

	}
}
