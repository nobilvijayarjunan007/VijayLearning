package com.dnapass.training.java.se.threads9.day9;

import java.util.Random;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class DeadlockDemo {

	public static void main(String[] args) {
		new SimpleDeadLock().run();
		
	}

}

class SimpleDeadLock {

	public static final Object lock1 = new Object();
	public static final Object lock2 = new Object();
	private int index;

	public static void run() {

		Thread t1 = new Thread1();
		Thread t2 = new Thread2();
		t1.start();
		t2.start();
	}

	private static class Thread1 extends Thread {

		public void run() {
			synchronized (lock1) {
				System.out.println("Thread 1: Holding lock 1....");
				try {
					Thread.sleep(10);
				} catch (InterruptedException ignored) {
					System.out.println("Thraed 1: Holding lock  2...");
					synchronized (lock2) {
						System.out.println("Thread 2: Holding lock 1 & 2....");
					}
				}
			}
		}
	}

	private static class Thread2 extends Thread {

		public void run() {
			synchronized (lock2) {
				System.out.println("Thread 2: Holding lock 2....");
				try {
					Thread.sleep(10);
				} catch (InterruptedException ignored) {
					System.out.println("Thraed 2: Holding lock 1...");
					synchronized (lock1) {
						System.out.println("Thread 2: Holding lock 2 & 1....");
					}
				}
			}
		}
	}

}

class Account {

	private int balance = 10000;

	public void deposit(int amount) {

		balance += amount;
	}

	public void withdraw(int amount) {
		balance -= amount;
	}

	public int getBalance() {
		return balance;
	}

	public static void transfer(Account acc1, Account acc2, int amount) {
		acc1.withdraw(amount);
		acc2.deposit(amount);
	}

}

class AccountRunner {

	private Account acc1 = new Account();
	private Account acc2 = new Account();
	private Lock lock1 = new ReentrantLock();
	private Lock lock2 = new ReentrantLock();

	private void acquireLocks(Lock firstLock, Lock secondLock) throws InterruptedException {

		while (true) {
			boolean gotFirstLock = false;
			boolean gotSecondLock = false;
			try {
				gotFirstLock = firstLock.tryLock();
				gotSecondLock = secondLock.tryLock();

			} finally {
				if (gotFirstLock && gotSecondLock)
					return;
				else if (gotFirstLock)
					firstLock.unlock();
				else if (gotSecondLock)
					secondLock.unlock();
			}

			Thread.sleep(1);
		}
	}

	public void firstTread() throws InterruptedException {
		Random random = new Random();
		for (int i = 0; i < 10000; i++) {
			acquireLocks(lock1, lock2);
			try {
				Account.transfer(acc1, acc2, random.nextInt(100));
			} finally {
				lock1.unlock();
				lock2.unlock();
			}
		}

	}

	public void secondTread() throws InterruptedException {
		Random random = new Random();
		for (int i = 0; i < 10000; i++) {
			acquireLocks(lock2, lock1);
			try {
				Account.transfer(acc2, acc1, random.nextInt(100));
			} finally {
				lock1.unlock();
				lock2.unlock();
			}
		}

	}

	public void finished() {
		System.out.println("Account 1 balance: " + acc1.getBalance());
		System.out.println("Account 1 balance: " + acc2.getBalance());
		System.out.println("Account 1 balance: " + (acc1.getBalance() + acc2.getBalance()));

	}

	public static void run() throws InterruptedException {

		final AccountRunner runner = new AccountRunner();

		Thread t1 = new Thread(new Runnable() {
			public void run() {
				try {
					runner.firstTread();
				} catch (InterruptedException ignored) {

				}
			}
		});
		Thread t2 = new Thread(new Runnable() {
			public void run() {
				try {
					runner.secondTread();
				} catch (InterruptedException ignored) {

				}
			}
		});

		t1.start();
		t2.start();

		t1.join();
		t2.join();
		runner.finished();

	}

}
