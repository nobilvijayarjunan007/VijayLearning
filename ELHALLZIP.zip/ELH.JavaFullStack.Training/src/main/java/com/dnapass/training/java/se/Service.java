package com.dnapass.training.java.se;

import java.util.List;

public class Service {

	public static List<Integer> filterListBelowGivenValue(List<Integer> markList, int i) {
		List<Integer> list = markList.stream().filter(num -> num <= i).toList();
		return list;
	}

	public static List<Integer> filterList(List<Integer> markList, int i) {
		List<Integer> list = markList.stream().filter(num -> num >= i).toList();
		return list;
	}
}
