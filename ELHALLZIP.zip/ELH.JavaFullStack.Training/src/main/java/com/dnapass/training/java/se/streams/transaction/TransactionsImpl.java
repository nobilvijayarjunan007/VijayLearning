package com.dnapass.training.java.se.streams.transaction;

import java.util.List;
import java.util.stream.Collectors;

import com.dnapass.training.java.se.lambda.DataLoader;
import com.dnapass.training.java.se.lambda.ProductType;
import com.dnapass.training.java.se.lambda.TransactionsEntity;

public class TransactionsImpl {

	public static void main(String[] args) {

		List<TransactionsEntity> transactions = DataLoader.newTransaction();

		create(transactions);
		addNew(transactions);
		delete(transactions);

	}

	private static void create(List<TransactionsEntity> transactions) {

		List<TransactionsEntity> transactionsList = transactions.stream().collect(Collectors.toList());
		System.out.println(transactionsList);
		transactions.stream().collect(Collectors.toList()).forEach(System.out::println);
	}

	private static void addNew(List<TransactionsEntity> transactions) {
		TransactionsEntity tranNew = new TransactionsEntity(9, ProductType.FRUIT, 4555.55, "ChennaiSholinganallu",
				"INR");
		transactions.add(tranNew);
		
		List<TransactionsEntity> transactionsList = transactions.stream().collect(Collectors.toList());
		System.out.println(transactionsList);
		transactions.stream().collect(Collectors.toList()).forEach(System.out::println);
	}

	private static void delete(List<TransactionsEntity> transactions) {

		transactions.stream().filter(t -> t.getCity() == "Chennai").collect(Collectors.toList())
				.forEach(System.out::println);
		List<TransactionsEntity> filterList = transactions.stream().filter(t -> t.getCity() == "Chennai")
				.collect(Collectors.toList());

		transactions.removeAll(filterList);
		System.out.println("after deletion of list");
		System.out.println(transactions);
		transactions.stream().collect(Collectors.toList()).forEach(System.out::println);

	}
}
