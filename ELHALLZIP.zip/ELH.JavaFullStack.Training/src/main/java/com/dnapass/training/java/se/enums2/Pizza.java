package com.dnapass.training.java.se.enums2;

public class Pizza {

	private PizzaStatus status;

	public enum PizzaStatus {

		ORDERED, READY, DELIVERED;
	}

	public boolean isDeliverable() {

		if (getStatus() == PizzaStatus.READY) {
			return true;
		}
		return false;

	}

	public PizzaStatus getStatus() {

		return PizzaStatus.DELIVERED;
	}

	public int getDeliveryTimeInDays() {

		switch (status) {
		case ORDERED:

			return 5;

		case READY:

			return 2;

		case DELIVERED:
			return 0;

		}
		return 0;

		// method that set and get the status variable.

	}

	public void setStatus(PizzaStatus delivered) {
		// TODO Auto-generated method stub

	}

}
