package com.dnapass.training.java.se.date.day8;

public class DateFormat {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String date ="04/03/1997";
		
		String date2=date.replace('/', '-');
		
		System.out.println(date2);
	}

}
