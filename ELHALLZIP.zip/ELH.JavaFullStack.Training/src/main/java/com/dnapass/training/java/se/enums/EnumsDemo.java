package com.dnapass.training.java.se.enums;

public class EnumsDemo {

	Day day = Day.FRIDAY;

	public static void main(String[] args) {
		EnumsDemo firstDay = new EnumsDemo(Day.MONDAY);
		firstDay.tellItLikeItIs();

		EnumsDemo thirdDay = new EnumsDemo(Day.WEDNESDAY);
		thirdDay.tellItLikeItIs();

		EnumsDemo fifthDay = new EnumsDemo(Day.FRIDAY);
		fifthDay.tellItLikeItIs();

		EnumsDemo sixthDay = new EnumsDemo(Day.SATURDAY);
		sixthDay.tellItLikeItIs();

		EnumsDemo seventhDay = new EnumsDemo(Day.SUNDAY);
		seventhDay.tellItLikeItIs();

	}

	public EnumsDemo(Day day) {
		this.day = day;
	}

	public void tellItLikeItIs() {
		switch (day) {
		case MONDAY:
			System.out.println(" Mondays are bad .");
			break;

		case FRIDAY:
			System.out.println(" Fridays are better .");
			break;

		case SATURDAY:
		case SUNDAY:
			System.out.println("Weekends are best.");

			break;

		default:
			System.out.println("Midweek days are so-so.");

			break;

		}
	}

}
