package com.dnapass.training.java.se.lambda;

import static java.lang.System.out;
import static java.util.Comparator.comparing;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.function.Consumer;

public class LambdaDemo {

	public static void main(String[] args) {

		int i = 0;
		out.println(i);
		i++;

		HelloFuctionalInterface msg = () -> {
			return "Hello";
		};

		out.println(msg.sayHello() + " World !!!");

		LambdaDemo lambdaDemo = new LambdaDemo();
		lambdaDemo.demo();
	}

	private void demo() {
		// anonymous inner class syntex and clearly suffers from vertical problem

		Runnable r = new Runnable() {

			public void run() {
				out.println("Howdy, world!");

			}

		};
		r.run();

		// more than just an anonymous class instance.

		Runnable r2 = () -> out.println("Howdy, world!");
		r2.run();

		List<Integer> numbers = new ArrayList<Integer>();

		numbers.add(5);
		numbers.add(9);
		numbers.add(8);
		numbers.add(1);

		numbers.forEach(n -> {
			out.println(n);
		});

		Consumer<Integer> method = n -> {
			out.println(n);
		};

		numbers.forEach(method);

		// one liner with implicit return

		Comparator<String> c = (String lhs, String rhs) -> lhs.compareTo(rhs);
		int result = c.compare("Hello", "World");

		out.println(result);

		// with return statement
		Comparator<String> c1 = (String lhs, String rhs) -> {

			out.println("I am Comparing " + lhs + " to " + rhs);
			return lhs.compareTo(rhs);
		};
		result = c1.compare("Vijay", "Arjunan");

		out.println(result);

		// Type inference

		Comparator<String> c2 = (lhs, rhs) -> {
			out.println("I am Comparing " + lhs + " to " + rhs);
			return lhs.compareTo(rhs);
		};

		result = c2.compare("Vijay", "Arjunan");

		out.println(result);
		out.println();

		LambdaDemo lambdaDemo = new LambdaDemo();

		List<TransactionsEntity> transactions = DataLoader.newTransaction();

		// anonymous inner class

		Comparator<TransactionsEntity> c3 = new Comparator<TransactionsEntity>() {

			@Override
			public int compare(TransactionsEntity h1, TransactionsEntity h2) {

				return h1.getId().compareTo(h2.getId());
			}
		};
		out.println("before sort by id");
		transactions.forEach(m -> {
			out.println(m);
		});
		Collections.sort(transactions, c3);
		out.println("after sort by id");
		transactions.forEach(m -> {
			out.println(m);
		});
		out.println();

		Comparator<TransactionsEntity> c4 = new Comparator<TransactionsEntity>() {

			@Override
			public int compare(TransactionsEntity h1, TransactionsEntity h2) {

				return h1.getAmount().compareTo(h2.getAmount());
			}
		};

		Collections.sort(transactions, c4);
		out.println("after sort by amount");
		transactions.forEach(m -> {
			out.println(m);
		});
		out.println();

		Comparator<TransactionsEntity> c5 = new Comparator<TransactionsEntity>() {

			@Override
			public int compare(TransactionsEntity h1, TransactionsEntity h2) {

				return h1.getType().compareTo(h2.getType());
			}
		};

		Collections.sort(transactions, c5);
		out.println("after sort by type");
		transactions.forEach(m -> {
			out.println(m);

		});
		out.println();

		// lambda

		Comparator<? super TransactionsEntity> c6 = (lhs, rhs) -> lhs.getId().compareTo(rhs.getId());

		Collections.sort(transactions, c6);

		out.println(" Lambda model : after sort by id");
		transactions.forEach(m -> {
			out.println(m);

		});

		out.println();
		// Collector comparing , method reference

		Collections.sort(transactions, comparing(TransactionsEntity::getId));
		out.println("Method reference : sort by id " + transactions);
		Collections.sort(transactions, comparing(TransactionsEntity::getType));
		out.println("Method reference : sort by type " + transactions);
		Collections.sort(transactions, comparing(TransactionsEntity::getAmount));
		out.println("Method reference : sort by amount " + transactions);

		
	/*	// Methodreferance 

		//1.static methods


		transactions.stream().map(t-> t.getAmount()).forEach(amt ->System.out.println(String.valueof(amt)));
		transactions.stream().map(t-> t.getAmount()).forEach(String::valueof);


		//2.Instance methods of particular objects

		transactions.stream().sorted(a,b) -> c3.compare(a,b);
		transactions.stream().sorted(c3::compare);


		//3.Instance methods of an arbitary  object of a particular type

		transactions.stream().map(t-> t.getAmount()).sorted(a,b) -> a.compareTo(b);
		transactions.stream().map(t-> t.getAmount()).sorted(Double::compareTo);

		//4.constructor

		Supplier<TransactionsEntity>t1 = Transaction ::new;
		System.out.println(t1.get);*/


		List<Person> people = Arrays.asList(new Person("Ted", "Neward",42), new Person ("Charlotte" ,"Neward", 39),
		                                new Person("Michel", "Neward",19),  new Person("Matthew", "Neward",13),
		                                new Person("Neal", "Ford",45),  new Person("Candy", "Ford",39),
		                                new Person("Jeff", "Brown",43), new Person("Besty", "Brown",39));

		//annonymus inner class

		Collections.sort(people, new Comparator<Person> () {
			public int compare(Person lhs ,Person rhs) {
				if(lhs.getLastName().equals (rhs.getLastName())) {
					
					return lhs.getAge() -rhs.getAge();
				}
				else
					return lhs.getLastName().compareTo (rhs.getLastName());
					
				
			}
		});
		System.out.println(people);


		//Lamda

		Collections.sort(people,(lhs ,rhs)-> {
			if(lhs.getLastName().equals (rhs.getLastName()))
				
				return lhs.getAge() -rhs.getAge();
			else
				return lhs.getLastName().compareTo (rhs.getLastName());
				
			
		});

		System.out.println(people);
		people.forEach((it) -> System.out.println("person:   "+ it));


		//Lamda examples


		final Comparator<Person> BY_FIRST =(lhs,rhs) -> lhs.getFirstName().compareTo (rhs.getFirstName());
		final Comparator<Person> BY_LAST =(lhs,rhs) -> lhs.getLastName().compareTo (rhs.getLastName());
		final Comparator<Person> BY_AGE =(lhs,rhs) -> lhs.getAge().compareTo (rhs.getAge());

		//method referance examples

		final Comparator<Person> BY_FIRST1 = comparing(Person::getFirstName);
		final Comparator<Person> BY_LAST1 = comparing(Person::getLastName);
		final Comparator<Person> BY_AGE1 = comparing(Person::getAge);



			Collections.sort(people,BY_LAST);	
			Collections.sort(people,BY_LAST1);	
			
			
			// composition
			
			Collections.sort(people,BY_LAST.thenComparing(BY_AGE));
			Collections.sort(people,BY_LAST.thenComparing(BY_AGE1));
		


		


		
	}

}
