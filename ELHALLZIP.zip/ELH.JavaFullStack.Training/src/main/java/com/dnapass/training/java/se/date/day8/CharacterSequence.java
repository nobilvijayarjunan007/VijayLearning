package com.dnapass.training.java.se.date.day8;

public class CharacterSequence {

	public static void main(String[] args) {
		String string = "the picture was grea";
		int i= checkCharater(string);
		System.out.println(i);
	}

	public static int checkCharater(String string) {
		
		char[] ch=string.toCharArray();
		
		for(char c:ch) {
			if(ch[0]==ch[ch.length-1]) {
				System.out.println("valid");
				return 1;
			}
			else if(ch[0]!=ch[ch.length-1]) {
				System.out.println("Invalid");
				return -1;
			}
			
			
		}
		return 0;
		
		
		
	}

}
