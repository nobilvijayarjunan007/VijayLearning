package com.dnapass.training.java.se.file.nio.day11;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.Scanner;

import ch.qos.logback.core.net.SyslogOutputStream;

public class RandomAccessFileDemo {

	public static void main(String[] args) throws IOException {
		
		
		Scanner in = new Scanner (System.in);
		
		BankData data = new BankData();
		
		try {
			File file = new File("C:\\Users\\vijay_a\\bank3.dat");
			RandomAccessFile raFile=new RandomAccessFile(file,"rw");
			BankData data1 = new BankData(raFile);
			Account ac= new Account(111,15000);
			//data1.find(100);
			data1.write(3, ac);
			try {
				if (file.createNewFile()) {
					System.out.println("File is Created !!");
				} else {
					System.out.println("File is already exist");
				}
			} catch (IOException e) {
				System.err.println(e.getMessage());
			}
			data.open(file);
			
			boolean done = false;
			while(!done) {
				System.out.println("Enter the Account number");
				int accountNumber=in.nextInt();
				System.out.println("Enter Amount to deposit: ");
				double amount=in.nextDouble();
				int position = data.find(accountNumber);
				Account account;
				if(position>=0) {
					account=data.read(position);
					account.deposite(amount);
					System.out.println("new balance="+account.getAccountBalance());
				}else //Add  new account
				{
					account = new Account(accountNumber,amount);
					position=data.size();
					System.out.println("Adding new Account");
				}
					data.write(position,account);
					System.out.println("Done?(Y/N");
					String input=in.next();
					if(input.equalsIgnoreCase("Y")) 
					done=true;	
					
					
				
			}
		}finally {
			data.close();
		}

	}

}
