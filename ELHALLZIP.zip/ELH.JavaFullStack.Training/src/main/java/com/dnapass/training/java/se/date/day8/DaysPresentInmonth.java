package com.dnapass.training.java.se.date.day8;

import java.time.YearMonth;

public class DaysPresentInmonth {

	public static void main(String[] args) {

		getNumberOfDays(2024, 1);//if index of month from zero
		getNumberOfDays2(2023, 2);//if index of month from one 
	}

	public static int getNumberOfDays2(int year, int month) {

		YearMonth yearMonthObj = YearMonth.of(year, month);

		int daysInMonth = yearMonthObj.lengthOfMonth();
		System.out.println(daysInMonth+" Days is present at "+month+" month in "+year+" year");

		return daysInMonth;

	}

	public static int getNumberOfDays(int year, int month) {

		YearMonth yearMonthObj = YearMonth.of(year, month+1);

		int daysInMonth = yearMonthObj.lengthOfMonth();
		System.out.println(daysInMonth+" Days is present at "+month+" month in "+year+" year");

		return daysInMonth;

	}

}
