package com.dnapass.training.java.se.threads1.day9;

 public class MsLunch {
	 private int c1 =0;
	 private int c2 =0;
	 private Object lock1 =new Object();
	 private Object lock2 =new Object();
	 
	 public  void c1(){
		 synchronized(lock1) {
			 c1++;
		 }
		 
	 }
	 public  void c2(){
		 synchronized(lock2) {
			 c2++;
		 }
		 
	 }


}
