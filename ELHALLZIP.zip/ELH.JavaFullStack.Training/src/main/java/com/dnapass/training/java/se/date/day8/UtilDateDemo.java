package com.dnapass.training.java.se.date.day8;

import java.text.DateFormatSymbols;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Locale;
import java.util.SimpleTimeZone;
import java.util.TimeZone;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class UtilDateDemo {

	public static Logger logger = LoggerFactory.getLogger(UtilDateDemo.class);
	public static final String MM_DD_YYYY_H_MM_SS = "MM/dd/yyyy, H:mm:ss";

	@SuppressWarnings("unused")
	public static void main(String[] args) throws ApplicationException {
		int year = 2022;
		int month = 0;
		int date = 1;

		Calendar cal = Calendar.getInstance();
		System.out.println();
		logger.info("Year : " + cal.get(Calendar.YEAR));
		logger.info("Month : " + cal.get(Calendar.MONTH));
		logger.info("Date : " + cal.get(Calendar.DATE));
		logger.info("Hour : " + cal.get(Calendar.HOUR));
		logger.info("Minute : " + cal.get(Calendar.MINUTE));

		System.out.println();

		cal.clear();
		System.out.println();
		cal.set(Calendar.YEAR, year);
		cal.set(Calendar.MONTH, month);
		cal.set(Calendar.DATE, date + 20);
		System.out.println();
		logger.info("" + cal.getTime());

		cal = Calendar.getInstance();
		System.out.println();

		logger.info("\nCurrent Date and Time: " + cal.getTime());

		int actualMaxYear = cal.getActualMaximum(Calendar.YEAR);
		int actualMaxMonth = cal.getActualMaximum(Calendar.MONTH);
		int actualMaxWeek = cal.getActualMaximum(Calendar.WEEK_OF_YEAR);
		int actualMaxDate = cal.getActualMaximum(Calendar.DATE);

		logger.info("\n Actual Maximum Year " + actualMaxYear);
		logger.info("\n Actual Maximum month " + actualMaxMonth);
		logger.info("\n Actual Maximum Week " + actualMaxWeek);
		logger.info("\n Actual Maximum Date " + actualMaxDate + "\n");
		System.out.println();

		logger.info("\nCurrent Date and Time: " + cal.getTime());

		int actualMinYear = cal.getActualMinimum(Calendar.YEAR);
		int actualMinMonth = cal.getActualMinimum(Calendar.MONTH);
		int actualMinWeek = cal.getActualMinimum(Calendar.WEEK_OF_YEAR);
		int actualMinDate = cal.getActualMinimum(Calendar.DATE);

		logger.info("\n Actual Minimum Year " + actualMinYear);
		logger.info("\n Actual Minimum month " + actualMinMonth);
		logger.info("\n Actual Minimum Week " + actualMinWeek);
		logger.info("\n Actual Minimum Date " + actualMinDate + "\n");

		System.out.println();

		Calendar calNewYork = Calendar.getInstance();
		calNewYork.setTimeZone(TimeZone.getTimeZone("America/New_York"));
		System.out.println();

		logger.info("Time in New York " + calNewYork + "\n");

		logger.info("Time in New York " + calNewYork.get(Calendar.HOUR_OF_DAY) + ":" + calNewYork.get(Calendar.MINUTE)
				+ ":" + calNewYork.get(Calendar.SECOND) + "\n");

		Calendar now = Calendar.getInstance();

		logger.info("Current Full Date and Time is " + (now.get((Calendar.MONTH)) + 1) + "-" + now.get(Calendar.DATE)
				+ "-" + now.get(Calendar.YEAR) + " " + now.get(Calendar.HOUR_OF_DAY) + ":" + now.get(Calendar.MINUTE)
				+ ":" + now.get(Calendar.SECOND));
		System.out.println();

		Calendar calendar = Calendar.getInstance();
		System.out.println();

		logger.info("" + calendar.getActualMaximum(Calendar.DAY_OF_MONTH));

		System.out.println();

		cal = Calendar.getInstance();
		System.out.println();

		cal.set(Calendar.DAY_OF_MONTH, cal.getActualMaximum(Calendar.DAY_OF_MONTH));

		logger.info("" + cal.getTime());

		System.out.println();

		cal = calendar.getInstance();

		int days = cal.getActualMaximum(Calendar.DAY_OF_MONTH);

		logger.info("Number of days of current month  " + days);

		DateFormatSymbols symbols = new DateFormatSymbols(new Locale("de"));

		String[] dayNames = symbols.getWeekdays();

		for (String s : dayNames) {

			System.out.println(s + "\n");
			// logger.info("\n"+s);

		}

		int noOfDays = 14;
		cal = calendar.getInstance();

		Date cdate = cal.getTime();

		cal.add(Calendar.DAY_OF_YEAR, noOfDays);

		Date cdate1 = cal.getTime();
		logger.info("\n" + cdate);
		logger.info("\n" + cdate1);

		cal = calendar.getInstance();
		cdate = cal.getTime();
		cal.add(Calendar.YEAR, 1);
		Date ndate = cal.getTime();

		cal.add(Calendar.YEAR, -2);
		Date pdate = cal.getTime();
		logger.info("\n" + cdate);
		logger.info("\n" + ndate);
		logger.info("\n" + pdate);

		// year to leap year or not

		year = 2016;
		System.out.println();
		if (year % 400 == 0 || year % 4 == 0 && year % 100 != 0) {
			System.out.println("year " + year + " is a leep year");
		} else {
			System.out.println("year " + year + " is not a leep year");
		}

		cal = new GregorianCalendar();
		
		cal.set(Calendar.HOUR_OF_DAY, 0);
		cal.set(Calendar.MINUTE, 0);
		cal.set(Calendar.SECOND, 0);
		
		System.out.println("\n"+cal.getTime()+"\n");
		
		try {
			String originalString = "2016-07-14 09:00:02";
			if(originalString==null) {
				throw new ParseException(originalString,1);
			}
			
			
		}
		catch (ParseException e) {
			
			//e.printStackTrace();
			throw new ApplicationException("input can't be null",e);
		}
		
		//Unix seconds
		
		long unix_seconds = 1372339860;
		//conver seconds to milliseconds
		
		Date date12 = new Date(unix_seconds*1000L);
		//format of the Date
		
		SimpleDateFormat jdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss z");
		TimeZone timeZone = TimeZone.getTimeZone("GMT-4");
		
		// TimeZone timeZone = new SimpleTimeZone(rawOffset,Id);
		
		String [] id = TimeZone.getAvailableIDs();
		System.out.println("In timeZone class available Ids are :");
		for(int i=0;i<id.length;i++) {
			
			System.out.println(id[i]);
		}
	
		String id1 = TimeZone.getTimeZone("Asia/Kolkata").getID();
		int offset = TimeZone.getTimeZone("Asia/Kolkata").getRawOffset();
		
		SimpleTimeZone obj = new SimpleTimeZone(offset,id1);
		
		jdf.setTimeZone(timeZone);
		String java_date = jdf.format(date12);
		System.out.println("\n"+java_date+"\n");
		
	}

}
