package com.dnapass.training.java.se.file.io2.day10;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class CopyCharacters {
public static void main(String[] args) throws IOException {
		
		
		
	copyCharacters();
	}
	public static void copyCharacters() throws IOException {
		FileReader inputStream = null;
		FileWriter outputStream = null;
		try {
			inputStream = new FileReader("C:\\Users\\vijay_a\\xanadu.txt");
			outputStream = new FileWriter("C:\\Users\\vijay_a\\characteroutput.txt");

			int c;
			int count=0;
			while ((c = inputStream.read()) != -1) {
				outputStream.write(c);
				char ch=(char)c;
				System.out.print(ch);
				
				count++;
			}
			System.out.println();
			System.out.println();
			System.out.println("count Of character   "+count);
		} finally {
			if (inputStream != null) {
				inputStream.close();
			}
			if (outputStream != null) {
				outputStream.close();
			}
		}

	}

}
