package com.dnapass.training.java.se.date.day8;

import java.util.Calendar;
import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class CurrentDate {

	public static Logger logger = LoggerFactory.getLogger(CurrentDate.class);

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		displayTheCurrentTimeAndDate();
		displayTheCurrentTimeAndDate2();

	}

	public static String displayTheCurrentTimeAndDate2() {
		Calendar cal = Calendar.getInstance();

		String dateAndTime = cal.get(Calendar.YEAR) + "/" + (cal.get(Calendar.MONTH)+1) + "/" + cal.get(Calendar.DATE);
				

		System.out.println(dateAndTime);
		return dateAndTime;
	}

	public static Date displayTheCurrentTimeAndDate() {
		Calendar cal = Calendar.getInstance();

		Date currentDateAndTime = cal.getTime();

		logger.info("Current Date And Time : " + currentDateAndTime);

		return currentDateAndTime;

	}

}
