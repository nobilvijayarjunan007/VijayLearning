package com.dnapass.training.java.se.lambda.expression;

import java.util.List;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;

public class LambdaExpressionsDemo {

	/*
	 * @FunctionalInterface interface CheckPeople {
	 * 
	 * boolean test(People p); }
	 */
	// Approach 1: Create Methods that Search for Peoples that Match One
	// Characteristic
	public static void printPeoplesOlderThan(List<People> roster, int age) {
		for (People p : roster) {
			if (p.getAge() >= age) {
				p.printPeople();
			}
		}
	}

	// Approach 2: Create More Generalized Search Methods
	public static void printPeoplesWithinAgeRange(List<People> roster, int low, int high) {
		for (People p : roster) {
			if (low <= p.getAge() && p.getAge() < high) {
				p.printPeople();
			}
		}
	}

	// Approach 3: Specify Speech Criteria code in a local class
	// Approach 4: Specify Speech Criteria code in an Anonymus class
	// Approach 5: Specify Speech Criteria code in a Lamda Expression

	public static void printPeoples(List<People> roster, CheckPeople tester) {
		for (People p : roster) {
			if (tester.test(p)) {
				p.printPeople();
			}
		}
	}

	// Approach 6: Use Standard Functional InterfaceJ:with Lambda Expressions

	public static void printPeoplesWithPredicate(List<People> roster, Predicate<People> tester) {
		for (People p : roster) {
			if (tester.test(p)) {
				p.printPeople();
			}
		}
	}

	// Approach 7: Use Lambda Expressions Throughout Your Application
	public static void processPeoples(List<People> roster, Predicate<People> tester, Consumer<People> block) {
		for (People p : roster) {
			if (tester.test(p)) {
				block.accept(p);
			}
		}
	}

	// Approach 7, second example

	public static void processPeoplesWithFunction(List<People> roster, Predicate<People> tester,
			Function<People, String> mapper, Consumer<String> block) {
		for (People p : roster) {
			if (tester.test(p)) {
				String data = mapper.apply(p);
				block.accept(data);
			}
		}
	}

	// Approach 8: Use Generics More Extensively
	public static <X, Y> void processElements(Iterable<X> source, Predicate<X> tester, Function<X, Y> mapper,
			Consumer<Y> block) {
		for (X p : source)
			if (tester.test(p)) {
				Y data = mapper.apply(p);
				block.accept(data);
			}
	}

	public static void main(String... args) {
		List<People> roster = People.createRoster();
		for (People p : roster) {
			p.printPeople();
		}

		// Approach 1: Create Methods that Search for Peoples that Match One
		// Characteristic
		System.out.println("Peoples older than 20:");
		printPeoplesOlderThan(roster, 20);
		System.out.println();

		// Approach 2: Create More Generalized Search Methods

		System.out.println("peoples between the ages of 14 and 30:");
		printPeoplesWithinAgeRange(roster, 14, 30);
		System.out.println();

		// Approach 3: Specify Search Criteria Code in a Local Class
		System.out.println("Peoples who are eligible for Selective Service:");
		class CheckPeopleOlderThane implements CheckPeople {
			public boolean test(People p) {
				return p.getAge() >= 20;
			} 
		}

		class CheckPeoplePeoplesWithinAgeRange implements CheckPeople {
			public boolean test(People p) {
				return 14 <= p.getAge() && p.getAge() < 30;
			}
		}
		printPeoples(roster, new CheckPeopleOlderThane());
		printPeoples(roster, new CheckPeoplePeoplesWithinAgeRange());

		class CheckPeopleEligibleForSelectiveService implements CheckPeople {
			public boolean test(People p) {
				return p.getGender() == People.Sex.MALE && p.getAge() >= 18 && p.getAge() <= 30;
			}
		}

		class CheckPeopleEligibleForSelectiveServicel implements CheckPeople {
			public boolean test(People p) {
				return p.getGender() == People.Sex.MALE && p.getAge() >= 18 && p.getAge() <= 35;
			}
		}

		printPeoples(roster, new CheckPeopleEligibleForSelectiveServicel());

		System.out.println();

		// Approach 4: Specify Search Criteria Code in an Anonymous Class
		System.out.println("Peoples who are eligible for Selective Service " + "(anonymous class):");

		printPeoples(roster, new CheckPeople() {
			public boolean test(People p) {
				return p.getGender() == People.Sex.MALE && p.getAge() >= 18 && p.getAge() <= 25;
			}
		});

		printPeoples(roster, new CheckPeople() {
			public boolean test(People p) {
				return p.getGender() == People.Sex.MALE && p.getAge() >= 18 && p.getAge() <= 30;
			}
		});

		System.out.println();

		// Approach 5: Specify Search Criteria Code with a Lambda Expression

		System.out.println("Peoples who are eligible for Selective Service " + "(lambda expression):");

		CheckPeople tester = (People p) -> p.getGender() == People.Sex.MALE && p.getAge() >= 18 && p.getAge() <= 25;

		printPeoples(roster, tester);

		printPeoples(roster, (People p) -> p.getGender() == People.Sex.MALE && p.getAge() >= 18 && p.getAge() <= 25);
		printPeoples(roster, (People p) -> p.getGender() == People.Sex.MALE && p.getAge() >= 18 && p.getAge() <= 30);

		System.out.println();

		// Approach 6: use Standard Functional Interfaces with Lamda
		// Expressions

		System.out.println("Peoples who are eligible for Selective Service " + "(with Predicate parameter ):");
		Predicate<People> tester2 = p -> p.getGender() == People.Sex.MALE && p.getAge() >= 18 && p.getAge() <= 25;
		printPeoplesWithPredicate(roster, tester2);

		System.out.println();

		// Approach 7: Use Lamda Expressions Through Your Application

		System.out.println(
				"Peoples who are eligible for Selective Service " + "(with Predicate and Consumer parameters ):");

		Consumer<People> block = p -> p.printPeople();
		Predicate<People> tester3 = p -> p.getGender() == People.Sex.MALE && p.getAge() >= 18 && p.getAge() <= 25;

		processPeoples(roster, tester3, block);
		Consumer<People> blockl = p -> {// peopleRepo .save(people )
		};

		processPeoples(roster, tester3, blockl);
		System.out.println();
		// Approach 7, second example

		System.out.println("Peoples who are eligible for Selective Service "
				+ "(with Predicate, Function, and Consumer parameters):");

		Function<People, String> mapper = p -> p.getEmailAddress();
		Consumer<String> block2 = email -> System.out.println(email);
		processPeoplesWithFunction(roster,
				p -> p.getGender() == People.Sex.MALE && p.getAge() >= 18 && p.getAge() <= 25, mapper, block2);

		System.out.println();

		// Approach 8: Use Generics More Extensively
		System.out.println("Peoples who are eligible for Selective Service " + "(generic version):");

		processElements(roster, p -> p.getGender() == People.Sex.MALE && p.getAge() >= 18 && p.getAge() <= 25,
				p -> p.getEmailAddress(), email -> System.out.println(email));

		processElements(roster, p -> p.getGender() == People.Sex.MALE && p.getAge() >= 18 && p.getAge() <= 25,
				p -> p.getName(), c123 -> System.out.println(c123));

		/*
		 * processElement s(rosterEmployee , e -> e.getGenderl()== People .Sex.MALE &&
		 * p.getAge()>= 18 && p.getAge()<= 25, p -> p.getEmailAddress(), empRepo ->
		 * empRepo .save());
		 *
		 * processElement s(rosterEmployee , e -> e.getGenderl()== People .Sex.MALE &&
		 * p.getAge()>= 18 && p.getAge()<= 25, p -> p.getEmailAddress(), empRepo ->
		 * empRepo .save());
		 *
		 */

		System.out.println();

		// Approach 9: Use Bulk Data Operations That Accept Lambda Expressions
		// as Parameters
		System.out.println("Peoples who are eligible for Selective Service " + "(with bulk data operations):");
		roster.stream().filter(p -> p.getGender() == People.Sex.MALE && p.getAge() >= 18 && p.getAge() <= 25)
				.map(p -> p.getEmailAddress()).forEach(email -> System.out.println(email));
	}
}