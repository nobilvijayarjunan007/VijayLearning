package com.dnapass.training.java.se.threads5.day9;

public class ThreadIsAliveDemo extends Thread {
	public static int amount = 0;

	public static void main(String[] args) {

		ThreadIsAliveDemo thread = new ThreadIsAliveDemo();

		thread.start();

		while (thread.isAlive()) {
			System.out.println("Waiting...");
		}

		System.out.println("Main: " + amount);

		amount++;
		System.out.println("Main: " + amount);

	}

	public void run() {
		amount++;
	}
}
