package com.dnapass.training.java.se.threads1.day9;

public class HelloRunnable implements Runnable {

	public  void run (){
		// TODO Auto-generated method stub
System.out.println( "Hello from a Thread!");
	}

}
