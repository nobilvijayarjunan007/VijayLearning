package com.dnapass.training.java.se.interfaces;

public interface Vehicle {

	String getBrand();

	String speedup();

	String slowDown();

	default String turnAlarmOn() {
		log();
		return "Turning the vehicle alarm On.";

	}

	default String turnAlarmOff() {
		log();
		return "Turning the vehicle alarm Off.";

	}

	static int getHorsePower(int rpm, int torque) {
		logs();
		return (rpm * torque) / 5252;

	}

	static void logs() {
		// TODO Auto-generated method stub
		System.out.println("method call logged");

	}

	static void log() {
		System.out.println("method call logged");
	}
}
