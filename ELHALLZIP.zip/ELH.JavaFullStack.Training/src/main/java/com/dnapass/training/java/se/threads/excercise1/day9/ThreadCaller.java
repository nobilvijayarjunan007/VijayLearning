package com.dnapass.training.java.se.threads.excercise1.day9;

public class ThreadCaller  {

	public static void main(String[] args) {
		
		ChildThread t1 = new ChildThread();
		System.out.println("Tread Started ::: "+t1.getName());
		t1.start();
		
		t1.setName("MyThread");
		System.out.println("Tread new ::: "+t1.getName());
	}

}
