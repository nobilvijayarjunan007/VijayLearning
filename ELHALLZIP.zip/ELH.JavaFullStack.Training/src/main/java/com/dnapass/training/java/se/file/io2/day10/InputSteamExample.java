package com.dnapass.training.java.se.file.io2.day10;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

public class InputSteamExample {
	private static final String FILE_NAME = "C:\\Users\\vijay_a\\exampleInput.txt";
	public static void main(String[] args) throws IOException {
		new InputSteamExample().useFileInputSteram();
		new InputSteamExample().useFileReader();
		new InputSteamExample().useBufferedReader();
	}
	public void useFileInputSteram() throws IOException {

		System.out.println(String.format("Reading File %s using a FileInputStream", FILE_NAME));

		InputStream is = null;
		try {

			is = new FileInputStream(FILE_NAME);
			int input;
			String output = "";
			while ((input = is.read()) != -1) {
				output += (char) input;
				
			}
			System.out.println();
			System.out.println(output);
		} catch (FileNotFoundException e) {
			System.err.println(
					String.format("Exception creating FileInputStream for file %s: %s", FILE_NAME, e.getMessage()));
		} finally {
			if (is != null) {
				is.close();
			}
		}

	}

	public void useFileReader() throws IOException {

		System.err.println(String.format("Reading file %s using a FileReader", FILE_NAME));
		InputStreamReader reader = null;
		try {
			reader = new FileReader(FILE_NAME);
			int input;
			String output = "";
			while ((input = reader.read()) != -1) {
				output += (char) input;
			}
			System.out.println(output);
		} catch (FileNotFoundException e) {
			System.err.println(
					String.format("Exception creating FileInputStream for file %s: %s", FILE_NAME, e.getMessage()));
		} finally {
			if (reader != null) {
				reader.close();
			}
		}

	}

	public void useBufferedReader() throws IOException {
		System.out.println(String.format("Reading file %s using a BufferedReader", FILE_NAME));

		try (BufferedReader reader = new BufferedReader(new FileReader(FILE_NAME))) {

			String line;
			while ((line = reader.readLine()) != null) {
				System.out.println(line);
			}

		} catch (FileNotFoundException e) {
			System.err.println(
					String.format("Exception creating BufferedReader for file %s: %s", FILE_NAME, e.getMessage()));
		}

	}

}
