package com.dnapass.training.java.se.date.day8;

import java.util.Calendar;

public class DefaultCalendar {

	public static void main(String[] args) {
		
		Calendar cal=Calendar.getInstance();
		
		System.out.println("Year :"+cal.get(Calendar.YEAR));

		System.out.println("month :"+cal.get(Calendar.MONTH));
		System.out.println("date :"+cal.get(Calendar.DATE));
		System.out.println("hours :"+cal.get(Calendar.HOUR));
		System.out.println("minutes :"+cal.get(Calendar.MINUTE));
		
	}

}
