package com.dnapass.training.java.se.file.io2.day10;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.Writer;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;



public class FileOperations {
	static Logger LOGGER = LoggerFactory.getLogger(FileOperations.class);
	public static void main(String[] args) throws IOException {
		//new FileOperations().createFile();
		//new FileOperations().deleteFile();
		//new FileOperations().RenameFile();
		//new FileOperations().copyFile();
		//new FileOperations().writeFile();
		new FileOperations().appendToExitingFile();
		new FileOperations().getFileSize();
		new FileOperations().getFilePath();
	}
	public void createFile() {
		File file = new File("C:\\Users\\vijay_a\\sample1.txt");

		try {
			if (file.createNewFile()) {
				LOGGER.info("File is Created !!");
			} else {
				LOGGER.info("File is already exist");
			}
		} catch (IOException e) {
			LOGGER.error(e.getMessage());
		}

	}

	public void deleteFile() {
		File file = new File("C:\\Users\\vijay_a\\sample1.txt");
		if (file.delete()) {
			LOGGER.info(file.getName() + "Deleted !!");

		} else {
			LOGGER.info("Delete operation failed");
		}
	}

	public void RenameFile() {
		File file = new File("C:\\Users\\vijay_a\\sample1.txt");

		boolean hasRename = file.renameTo(new File("C:\\Users\\vijay_a\\sample2.txt"));

		if (hasRename) {
			LOGGER.info("File Rename successful");

		} else {
			LOGGER.info("File Rename failed");
		}
	}

	public void copyFile() {
		try (InputStream inStream = new FileInputStream("C:\\Users\\vijay_a\\sample2.txt");

				OutputStream outStream = new FileOutputStream("C:\\Users\\vijay_a\\sample1.txt")) {
			byte[] buffer = new byte[1024];
			int length;
			while ((length = inStream.read(buffer)) > 0) {
				outStream.write(buffer, 0, length);

			}
		} catch (IOException e) {
			LOGGER.error(e.getMessage());
		}
	}

	public void moveFile() {
		File file = new File("C:\\Users\\vijay_a\\sample2.txt");

		boolean hasRename = file.renameTo(new File("C:\\Users\\vijay_a\\move\\sample2.txt"));

		if (hasRename) {
			LOGGER.info("File is moved successful");

		} else {
			LOGGER.info("File is fail failed");
		}
	}

	public void writeFile() {
		try (BufferedWriter bw = new BufferedWriter(
				new FileWriter("C:\\Users\\vijay_a\\sampleWriteFile.txt"))) {

			String content = " This is the content to write into file\n";

			bw.write(content);
		} catch (IOException e) {
			LOGGER.error(e.getMessage());
		}
	}

	public void appendToExitingFile() {
		try (Writer writer = new FileWriter("C:\\Users\\vijay_a\\sampleWriteFile.txt", true);
				BufferedWriter bw = new BufferedWriter(writer)) {
			String content = "append something to existing file\n";

			bw.write(content);
		} catch (IOException e) {
			LOGGER.error(e.getMessage());
		}
	}

	public void getFileSize() {
		File file = new File("C:\\Users\\vijay_a\\sampleWriteFile.txt");
		if (file.exists()) {
			double bytes = file.length();
			double kilobytes = (bytes / 1024);
			double megabytes = (kilobytes / 1024);
			double gigabytes = (megabytes / 1024);
			double terabytes = (gigabytes / 1024);
			double petabytes = (terabytes / 1024);
			double exabytes = (petabytes / 1024);
			double zettabytes = (exabytes / 1024);
			double yottabytes = (zettabytes / 1024);

			System.out.println("bytes :" + bytes);
			System.out.println("kilobytes :" + kilobytes);
			System.out.println("megabytes :" + megabytes);
			System.out.println("gigabytes :" + gigabytes);
			System.out.println("terabytes :" + terabytes);
			System.out.println("petabytes :" + petabytes);
			System.out.println("exabytes :" + exabytes);
			System.out.println("zettabytes :" + zettabytes);

		} else {
			System.out.println("File does not exists");
		}
	}

	public void getFilePath() {
		File file = new File("C:\\Users\\vijay_a\\sampleWriteFile.txt");
		String absolutePath = file.getAbsolutePath();
		String filePath = absolutePath.substring(0, absolutePath.lastIndexOf(File.separator));
		System.out.println(filePath);
	}
}
