package com.dnapass.training.java.se.file.io2.day10;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;



public class ObjectStreamExample implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public static void main(String [] args) {
		
		//new ObjectStreamExample().readObject();
		
		
		
		new ObjectStreamExample().writeObject();
	}
	public void readObject() {
		try (ObjectInputStream in = new ObjectInputStream(new FileInputStream("C:\\Users\\vijay_a\\employees.txt"))) {
			final Employee employee = (Employee) in.readObject();
			
			System.out.println("printing employee object details");
			System.out.println(employee.getId() + " " + employee.getName());
			System.out.println("printing address object details");
		} catch (IOException | ClassNotFoundException e) {
			e.printStackTrace();
		}
	}

	public void writeObject() {
		try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream("C:\\Users\\vijay_a\\employees.txt"))) {
			final Employee employee = new Employee(1000, "vijay");
			System.out.println("printing employee object details");
			System.out.println(employee.getId() + " " + employee.getName());
			System.out.println("printing address object details");
			//out.writeObject(employee);
		} catch (IOException e) {
			e.printStackTrace();
		}

	}
}
