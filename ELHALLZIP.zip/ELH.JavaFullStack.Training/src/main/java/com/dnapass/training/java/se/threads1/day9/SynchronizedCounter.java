package com.dnapass.training.java.se.threads1.day9;

import java.util.ArrayList;
import java.util.List;

public class SynchronizedCounter extends Thread {
 private int c=0;
 static  private int s=0;
 
 private String lastName;
 private List<String> namelist =new ArrayList<String>();
 public static void main(String[] args) throws InterruptedException {
	 
	 SynchronizedCounter t1= new SynchronizedCounter();
	 
	 SynchronizedCounter t2= new SynchronizedCounter();
	 SynchronizedCounter t3= new SynchronizedCounter();
	 
	 t1.start();
	 t1.setName("AAA");
	 t2.start();
	 t2.setName("BBB");
 }
 
 public  void run (){
	 SynchronizedCounter th= new SynchronizedCounter();
   
		th.increment();
	
     int v1=th.value();
     System.out.println(v1);
    
		th.decrement();
	
     v1=th.value();
     System.out.println(v1);
	}
 
 public  synchronized void increment ()  {
	 
	 for(int i=1;i<=10;i++) {
		 System.out.println(Thread.currentThread().getName()+" "+c);
		c++;}
	}

	public  synchronized void decrement ()  {
		
		 for(int i=10;i>=0;i--) {
			 System.out.println(Thread.currentThread().getName()+" "+c);
				c--;}
		
	}
	public  synchronized int value () {
		 return c;
	}
}
