package com.dnapass.training.java.se.threads1.day9;

public class Hellothread extends Thread{
	public  void run (){
		
    System.out.println( "Hello from a Thread!");
	}

}
