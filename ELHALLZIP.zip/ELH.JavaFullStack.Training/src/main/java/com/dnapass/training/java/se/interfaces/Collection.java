package com.dnapass.training.java.se.interfaces;

import java.util.stream.IntStream;
import java.util.stream.Stream;

public interface Collection {

	default Stream stream() {
		return Stream.empty();

	}

	public default IntStream chars() {
		return IntStream.empty();

	}
}
