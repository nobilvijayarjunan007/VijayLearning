package com.dnapass.training.java.se.file.nio.day11;


import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;

public class BankData {
	private static final long DOUBLE_SIZE = 8;
	private static final long INT_SIZE = 4;
	private static final long RECORD_SIZE =INT_SIZE+DOUBLE_SIZE ;
	private RandomAccessFile file;

	public BankData() {
		this.file = null;
	}

	public BankData(RandomAccessFile file2) {
		this.file = file2;
	}

	public void open(File fileName) throws IOException {
		if (file != null)
			file.close();
		file = new RandomAccessFile(fileName, "rw");
	}

	public int size() throws IOException {

		return (int) (file.length() / RECORD_SIZE);
	}

	public void close() throws IOException {
		if (file != null)
			file.close();
		file=null;
	}
	public Account read(int n) throws IOException {

		file.seek(n*RECORD_SIZE);
		int accountNumber=file.readInt();
		double balance = file.readDouble();
		
		return new Account(accountNumber,balance);
	}

	public int find(int accountNumber) throws IOException {
for(int i=0;i<size();i++) {
	file.seek(i*RECORD_SIZE);
	int a= file.readInt();
	if(a==accountNumber)
		System.out.println(accountNumber);
		return i;
}
		return -1 ;
	}

	

	public void write(int n, Account account) throws IOException {

		file.seek(n*RECORD_SIZE);
		System.out.println(account.getAccountNumber());
		System.out.println(account.getAccountBalance());
		System.out.println(account);
		file.writeInt(account.getAccountNumber());
		file.writeDouble(account.getAccountBalance());
	}

}
