package com.dnapass.training.java.se.generics;

public class NaturalNumberUtil<T extends Number> {

	private T n;

	public NaturalNumberUtil(T n) {
		super();
		this.n = n;
	}

	public boolean isEven() {
		return n.intValue() % 2 == 0;
	}

}
