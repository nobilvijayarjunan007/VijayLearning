package com.dnapass.training.java.se.optional;

import java.util.Optional;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.function.Supplier;

public class OptionalDemo {

	@SuppressWarnings("unchecked")
	public static void main(String[] args) {

		Optional<String> empty = Optional.empty();
		String name = "baeldung";
		Optional<String> opt = Optional.of(name);

		if (name != null) {
			System.out.println(name);
		}

		if (opt.isPresent()) {
			System.out.println(opt);
			System.out.println(opt.get());
			// System.out.println(empty .get());
		}

		// expected = NullPointerException.class
		name = null;
		/*Optional.of(name);*/
		name = "baeldung";
		opt = Optional.ofNullable(name);

		name = null;
		opt = Optional.ofNullable(name);
		if (opt.isPresent()) {
			System.out.println(opt);
			System.out.println(opt.get().length());
		}
		if (name != null) {
			System.out.println(name.length());
		}
		opt = Optional.of("baeldung");
		opt.ifPresent(n -> System.out.println(n.length()));

		// Default Value With orElse()
		String nullName = null;
		name = Optional.ofNullable(nullName).orElse("john");
		System.out.println(name);

		// Default Value With orElseGet();
		nullName = null;
		name = Optional.ofNullable(nullName).orElseGet(() -> "john");
		System.out.println(name);

		@SuppressWarnings("rawtypes")
		OptionalDemo optionalDemo = new OptionalDemo();
		String text = "text";

		String defaultText = Optional.ofNullable(text).orElseGet(optionalDemo::getMyDefault);
		System.out.println(defaultText);
		nullName = null;
		name = Optional.of(nullName).orElseThrow(IllegalArgumentException::new);
		opt = Optional.of("baeldung");
		name = opt.get();
		opt = Optional.ofNullable(null);
		name = opt.get();
		optionalDemo.demo();
		name.chars();
		@SuppressWarnings("rawtypes")
		Optional emptyOptional = Optional.empty();
		Optional<String> nomEmptyOptional = Optional.of("xyz");

		@SuppressWarnings("rawtypes")
		Optional nonEmptyOrEmptyOptional1 = Optional.ofNullable("xyz");
		@SuppressWarnings("rawtypes")
		Optional nonEmptyOrEmptyOptional2 = Optional.ofNullable(null);

		System.out.println(emptyOptional);
		System.out.println(nomEmptyOptional);
		System.out.println(nonEmptyOrEmptyOptional1);
		System.out.println(nonEmptyOrEmptyOptional2);

		// of () - returns a non-empty Optional with value

		/* ---------------------------------- */

		nomEmptyOptional = Optional.of("abc");
		System.out.println(nomEmptyOptional); // Optional[abc]
		System.out.println(nomEmptyOptional.get()); // abc
		System.out.println(Optional.of(null)); // NPE

		nomEmptyOptional = Optional.of("abc");
		emptyOptional = Optional.empty();

		System.out.println(emptyOptional.isPresent()); // false
		System.out.println(nomEmptyOptional.isPresent());// true
		nomEmptyOptional = Optional.of("abc");
		emptyOptional = Optional.empty();

		// ifPresent ()- if value present invoke specified Consumer
		/*-------------------------------------- */

		Consumer<String> consumer = s -> System.out.println(s);
		nomEmptyOptional.ifPresent(consumer); // abc
		emptyOptional.ifPresent(consumer); // never invoke consumer

		/*
		 * filter()- If a value is present, and value matches the given predicate ,
		 * return an Optional otherwise return an empty Optional.
		 */
		/*----- ---- ------------------------------------- ------------�*/
		Predicate<String> predicate = s -> s.contains("a");
		System.out.println(nomEmptyOptional.filter(predicate));// Optional[abc]
		System.out.println(nomEmptyOptional.filter(s -> s.equals("Peter")));// Optional .empty
		System.out.println(emptyOptional.filter(predicate));// Optional.empty
		System.out.println(nomEmptyOptional.filter(s -> s.startsWith("a")));// Optional(abc]

		/*
		 * map() - if a value is present ,apply the provided mapping function to it, and
		 * if the result is not-null, return an optional describing the result.
		 * otherwise return an empty optional.
		 */

		Function<String, String> function = s -> s.substring(0, 0).length() == 0 ? null : s;

		Optional<String> nonEmptyOptional = null;
		System.out.println(nonEmptyOptional.map(function));// Optional.empty
		System.out.println(nonEmptyOptional.map(String::toLowerCase));// Optional[abc]
		System.out.println(emptyOptional.map(function));// Optional.empty

		/*
		 * flatMap() - This method is similar to map(Function), but the provided mapper
		 * is one whose result is already an Optional, and if Invoked, flatMap does not
		 * wrap it with an additional Optional.
		 */
		/* _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ __ _ _ _ _ _ _ _ _ _ _ _ _ _ */

		@SuppressWarnings("rawtypes")
		Optional<Optional> optionalContainer = Optional.of(Optional.of("abc "));
		@SuppressWarnings("rawtypes")
		Optional<Optional> emptyOptionalContainer = Optional.of(Optional.of("abc "));

		function = s -> s.substring(0, 0).length() == 0 ? null : s;
		Function<String, String> function2 = s -> s.substring(0, 5);

		System.out.println(optionalContainer.map(optional -> optional.map(function2)));// Optional[Optional[abc]]
		System.out.println(optionalContainer.flatMap(optional -> optional.map(function2)));// Optional[abc]
		// System.out.println(emptyOptionalContainer.flatmap(optional ->
		// optional.map(function2)));//Optional.empty

		// orElse() - Return the value if present, otherwise return other,
		/* _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ __ _ _ _ _ _ _ _ _ _ _ _ _ _ */
		System.out.println(nonEmptyOptional.orElse("def"));// abc
		System.out.println(emptyOptional.orElse("def"));// def

		/*
		 * orElseGet - Return the value if present, otherwise invoke other and return
		 * the result of that invocation.
		 */
		/* _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ __ _ _ _ _ _ _ _ _ _ _ _ _ _ */
		Supplier<String> supplier = () -> "def";
		System.out.println(nonEmptyOptional.orElse("def"));// abc
		System.out.println(emptyOptional.orElse("def"));// def

		// orElseThrow() - Return the contained Value, if present, otherwise
		// throw an exception to be created by the provided supplier.
		/* _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ __ _ _ _ _ _ _ _ _ _ _ _ _ _ */
		System.out.println(nonEmptyOptional.orElseThrow(NullPointerException::new));// abc
		try {
			System.out.println(emptyOptional.orElseThrow(NullPointerException::new));
		} catch (Throwable e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} // NullPointerException

		// 1000 lines
	}

	public String getMyDefault() {
		System.out.println("Getting Default Value");
		return "Default Value";

	}

	private void demo() {
		Computer computer = newComputer();

		String version = millionBug(computer);
		System.out.println(version);

		// String version = computer?.getSoundcard()?.getUSB()?.getVersion();
		// String version = computer?.getSoundcard()?.getUSB()?.getVersion() ?;
		// "UNKNOWN";

		version = traditionalNullPointerHandling1(computer);
		System.out.println(version);
		// Optional<Computer> mayBeComputer = Optional.empty();

		Optional<Computer> mayBeComputer = mayBeComputer();
		version = optionalDemo1(mayBeComputer);
		System.out.println(version);
	}

	/*
	 * private static String optionalDemo(Optional<Computer> mayBeComputer) { //
	 * TODO Auto-generated method stub return null; }
	 * 
	 * 
	 * 
	 * private Optional<OptionalDemo<With>.Computer> newmayBeComputer() { // TODO
	 * Auto-generated method stub return null; }
	 * 
	 * 
	 * 
	 * private String traditionalNullPointerHandling(OptionalDemo<With>.Computer
	 * computer2) { // TODO Auto-generated method stub return null; }
	 * 
	 * 
	 * 
	 * private String millionDollarBug(OptionalDemo<With>.Computer computer2) { //
	 * TODO Auto-generated method stub return null; }
	 * 
	 */

	private String optionalDemo1(Optional<Computer> mayBeComputer) {
		return mayBeComputer.flatMap(Computer::getMayBeSoundCard).flatMap(SoundCard::getMayBeUsb).map(USB::getVersion)
				.orElse("UNKNOWN");

	}

	private String traditionalNullPointerHandling1(Computer computer) {
		String version = "UNKNOWN";
		if (computer != null) {
			SoundCard soundcard = computer.getSoundCard();
			if (soundcard != null) {
				USB usb = soundcard.getUSB();
				if (usb != null) {
					version = usb.getVersion();
				}
			}
		}
		return version;

	}

	private String millionBug(Computer computer) {
		return computer.getSoundCard().getUSB().getVersion();
	}

	private Optional<Computer> mayBeComputer() {

		Computer computer = new Computer();
		SoundCard soundCard = new SoundCard();
		USB usb = new USB();
		usb.setVersion("1.0");
		soundCard.setUsb(usb);
		computer.setSoundCard(soundCard);

		Optional<Computer> optionalComputer = Optional.of(computer);
		Optional<SoundCard> mayBeSoundCard = Optional.of(soundCard);
		Optional<USB> mayBeUsb = Optional.of(usb);

		soundCard.setMayBeUsb(mayBeUsb);
		{
			computer.setMayBeSoundCard(mayBeSoundCard);
			return optionalComputer;
		}

	}

	public Computer newComputer() {
		Computer computer = new Computer();
		SoundCard soundCard = new SoundCard();
		USB usb = new USB();
		usb.setVersion("1.0");
		soundCard.setUsb(usb);
		computer.setSoundCard(soundCard);
		return computer;

	}

	public class USB {
		String Version = "1.0";

		public void setVersion(String version) {
			this.Version = version;
		}

		public String getVersion() {
			// TODO Auto-generated method stub
			return Version;
		}
	}

	public class SoundCard {
		USB usb = null;
		Optional<USB> mayBeUsb = null;

		public USB getUSB() {
			// TODO Auto-generated method stub
			return usb;

		}

		public USB getUsb() {
			return usb;
		}

		public void setUsb(USB usb) {
			this.usb = usb;
		}

		public Optional<USB> getMayBeUsb() {
			return mayBeUsb;

		}

		public void setMayBeUsb(Optional<USB> getMayBeUsb) {
			this.mayBeUsb = mayBeUsb;
		}
	}

	public class Computer {
		SoundCard soundCard = null;
		Optional<SoundCard> mayBeSoundCard = null;

		public void setSoundCard(SoundCard soundCard) {
			this.soundCard = soundCard;
		}

		public SoundCard getSoundCard() {
			// TODO Auto-generated method stub
			return soundCard;

		}

		public Optional<SoundCard> getMayBeSoundCard() {
			return mayBeSoundCard;
		}

		public void setMayBeSoundCard(Optional<SoundCard> mayBeSoundCard) {
			this.mayBeSoundCard = mayBeSoundCard;
		}
	}
}
