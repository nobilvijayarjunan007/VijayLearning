package com.dnapass.training.java.se.date.day8;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.OffsetTime;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;

public class DateFormatDemo {

	public static void main(String[] args) {

		formatDate1();
		formatDate2();
		formatDate3();
		formatDate4();
		formatDate5();
	}

	// yyyy-MM-dd
	public static String formatDate1() {

		String result;
		LocalDate localDate = LocalDate.now();
		System.out.println(localDate);
		DateTimeFormatter formatterLocalDate = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		result = formatterLocalDate.format(localDate);
		System.out.println(result);
		return result;
	}

	// HH:mm:ss
	public static String formatDate2() {

		String result;
		LocalTime localTime = LocalTime.now();
		System.out.println(localTime);
		DateTimeFormatter formatterLocalDate = DateTimeFormatter.ofPattern("HH:mm:ss");
		result = formatterLocalDate.format(localTime);
		System.out.println(result);
		return result;
	}
	// yyyy-MM-dd HH:mm:ss
	
		public static String formatDate3() {

			String result;
			LocalDateTime localDateTime = LocalDateTime.now();
			System.out.println(localDateTime);
			DateTimeFormatter formatterLocalDateTime = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
			result = formatterLocalDateTime.format(localDateTime);
			System.out.println(result);
			return result;
		}
		
		//E MMM yyyy HH:mm:ss.SSSZ
		public static String formatDate4() {

			String result;
			ZonedDateTime zonedDateTime = ZonedDateTime.now();
			System.out.println(zonedDateTime);
			DateTimeFormatter formatterZonedDate = DateTimeFormatter.ofPattern("E MMM yyyy HH:mm:ss.SSSZ");
			result = formatterZonedDate.format(zonedDateTime);
			System.out.println(result);
			return result;
		}
		
		//HH:mm:ss,Z
		public static String formatDate5() {
			String result;
		
			OffsetTime offsetTime = OffsetTime.now();
			System.out.println(offsetTime);
			DateTimeFormatter formatterOffsetTime = DateTimeFormatter.ofPattern("HH:mm:ss,Z");
			
			result = formatterOffsetTime.format(offsetTime);
			System.out.println(result);
			return result;
			
			
			
			
		}
}
