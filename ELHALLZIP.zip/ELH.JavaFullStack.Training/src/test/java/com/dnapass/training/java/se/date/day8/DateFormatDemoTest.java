package com.dnapass.training.java.se.date.day8;



import org.junit.Assert;
import org.junit.Test;

public class DateFormatDemoTest {

	
	@Test
	public void test1() {
		
		Assert.assertEquals("2022-02-10",DateFormatDemo.formatDate1());
	
	}
	@Test
	public void test2() {
		
		Assert.assertEquals("11:40",DateFormatDemo.formatDate2());
	
	}
	
	@Test
	public void test3() {
		
		Assert.assertEquals("2022-02-10 11:40",DateFormatDemo.formatDate3());
	
	}
	
	
	
}
