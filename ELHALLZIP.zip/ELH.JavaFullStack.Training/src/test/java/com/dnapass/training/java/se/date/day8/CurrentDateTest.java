package com.dnapass.training.java.se.date.day8;

import java.util.Calendar;
import java.util.Date;

import org.junit.Assert;
import org.junit.Test;

public class CurrentDateTest {

	@Test
	public void test1() {
		Assert.assertEquals("2022/2/14", CurrentDate.displayTheCurrentTimeAndDate2());

	}

	/*@Test
	public void test2() {
		Calendar cal = Calendar.getInstance();

		Date currentDateAndTime = cal.getTime();
		Assert.assertEquals(currentDateAndTime, CurrentDate.displayTheCurrentTimeAndDate());

	}*/
}
