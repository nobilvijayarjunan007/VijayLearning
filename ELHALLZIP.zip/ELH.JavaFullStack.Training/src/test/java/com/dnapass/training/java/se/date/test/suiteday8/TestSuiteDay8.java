package com.dnapass.training.java.se.date.test.suiteday8;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

import com.dnapass.training.java.se.date.day8.CurrentDateTest;
import com.dnapass.training.java.se.date.day8.DateConverterTest;
import com.dnapass.training.java.se.date.day8.FlightUtilTest;


@RunWith(Suite.class)
@Suite.SuiteClasses({CurrentDateTest.class,DateConverterTest.class,FlightUtilTest.class})
public class TestSuiteDay8 {

}
