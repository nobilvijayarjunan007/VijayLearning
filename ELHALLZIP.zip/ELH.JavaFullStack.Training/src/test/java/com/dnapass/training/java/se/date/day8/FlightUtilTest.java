package com.dnapass.training.java.se.date.day8;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;

import org.junit.Assert;
import org.junit.Test;

public class FlightUtilTest {

	@Test
	public void test1ArrivalTimeInDelhi() {
		LocalDateTime local = LocalDateTime.of(2013, 7, 20, 19, 30);
		LocalDateTime arrivalTimeInDelhi = local.plusMinutes(1250);
		ZonedDateTime zdt2 = arrivalTimeInDelhi.atZone(ZoneId.of("Asia/Kolkata"));
		
		Assert.assertEquals(zdt2,FlightUtil.arrivalTimeInDelhi(local, 1250));
	
	}
	
	@Test
	public void test1ArrivalTimeInTokyo() {
		LocalDateTime local = LocalDateTime.of(2013, 7, 20, 19, 30);
		LocalDateTime arrivalTimeInDelhi = local.plusMinutes(650);
		ZonedDateTime zdt2 = arrivalTimeInDelhi.atZone(ZoneId.of("Asia/Tokyo"));
		
		Assert.assertEquals(zdt2,FlightUtil.arrivalTimeInTokyo(local, 650));
	
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
}
