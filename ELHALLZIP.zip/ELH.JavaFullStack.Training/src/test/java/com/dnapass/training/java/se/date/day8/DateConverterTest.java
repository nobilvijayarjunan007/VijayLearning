package com.dnapass.training.java.se.date.day8;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.junit.Assert;
import org.junit.Test;


public class DateConverterTest {

	@Test
	public void test1ConvertDateToString() {
		Assert.assertEquals("December 3, 2011",DateConverter.convertDateToString("2011-12-03"));
	
	}
	@Test
	public void test2ConvertDateToString() {
		Assert.assertEquals("March 4, 1997",DateConverter.convertDateToString("1997-03-04"));
	
	}
	
	
	
	@Test
	public void test3ConvertStringToDate() throws ParseException {
		SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = sdf.parse("2022-02-10 06:00:04");
		Assert.assertEquals(date,DateConverter.dateStringToDate1("2022-02-10 06:00:04"));
	
	}
	
	@Test
	public void test4ConvertStringToDate() throws ParseException {
		SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = sdf.parse("2016-07-14 09:00:02");
		Assert.assertEquals(date,DateConverter.dateStringToDate("2016-07-14 09:00:02"));
	
	}
	
	
	
	
	
}
