package java.stream8.feature.samples;

import java.util.stream.*;

public class StreamIteratorDemo {

	public static void main(String[] args) {

		/*
		 * Stream.iterate(1, e -> e + 1).filter(e -> e % 5 ==
		 * 0).limit(10).forEach(System.out::println);
		 */
		
		String s1 = "abc";
		String s2 = "dfe";
		String s3 = s1.concat(s2.toUpperCase());
		System.out.println(s1+s2+s3);
		

	}
}
