package com.dnapass.training.JPAQuery;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JpaQueryApplicationTests {

	@Test
	void contextLoads() {
	}

}
