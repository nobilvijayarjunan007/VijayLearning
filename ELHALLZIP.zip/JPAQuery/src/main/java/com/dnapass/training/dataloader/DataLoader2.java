package com.dnapass.training.dataloader;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.dnapass.training.entity.LeagueEntity;
import com.dnapass.training.entity.PlayerEntity;
import com.dnapass.training.entity.TeamEntity;

public class DataLoader2 {

	public static List<TeamEntity> newTeam() {

		List<TeamEntity> List = new ArrayList<>();

		TeamEntity team1 = new TeamEntity(null, "Chennai", "CSK", null, null);
		TeamEntity team2 = new TeamEntity(null, "Mumbai", "MI", null, null);

		TeamEntity team5 = new TeamEntity(null, "Kolkatta", "KNR", null, null);
		TeamEntity team6 = new TeamEntity(null, "Delhi", "DL", null, null);

		TeamEntity team3 = new TeamEntity(null, "Bears", "American", null, null);
		TeamEntity team4 = new TeamEntity(null, "villa", "Indian", null, null);

		List.add(team1);
		List.add(team2);
		List.add(team3);
		List.add(team4);
		List.add(team5);
		List.add(team6);

		return List;

	}

	public static List<LeagueEntity> newLeague() {

		LeagueEntity leagueEntity1 = new LeagueEntity(null, " IPL Final", "ICC Match", "Cricket",
				Arrays.asList(newTeam().get(0), newTeam().get(1)));

		LeagueEntity leagueEntity4 = new LeagueEntity(null, " ODI Final", "ICC Match", "Cricket",
				Arrays.asList(newTeam().get(2), newTeam().get(3)));

		LeagueEntity leagueEntity2 = new LeagueEntity(null, " FIFA Final", "FootBall Match", "FoodBall",
				Arrays.asList(newTeam().get(4), newTeam().get(5)));

		LeagueEntity leagueEntity3 = new LeagueEntity(null, " F1Race Final", "Race game", "Car Race", null);

		return Arrays.asList(leagueEntity1, leagueEntity2, leagueEntity3, leagueEntity4);
	}

	public static List<PlayerEntity> newPlayers1() {

		PlayerEntity player1 = new PlayerEntity(null, "Dhoni", "Captain", 9870000.0, null);
		PlayerEntity player2 = new PlayerEntity(null, "Virat", "Wise-Captain", 15500000.0, null);

		PlayerEntity player3 = new PlayerEntity(null, "KL Rahul", "player3", 6700000.0, null);
		PlayerEntity player4 = new PlayerEntity(null, "Rohit", "player4", 15500000.0, null);

		PlayerEntity player5 = new PlayerEntity(null, "Bumrah", "player5", 28900000.0, null);
		PlayerEntity player6 = new PlayerEntity(null, "R Pant", "player6", 15500000.0, null);

		return Arrays.asList(player1, player2, player3, player4, player5, player6);

	}

	public static List<PlayerEntity> newPlayers2() {

		PlayerEntity player1 = new PlayerEntity(null, "Raina", "Captain", 233300.0, null);
		PlayerEntity player2 = new PlayerEntity(null, "Jedeja", "Wise-Captain", 1430000.0, null);

		PlayerEntity player3 = new PlayerEntity(null, "Pandiya", "player3", 6700000.0, null);
		PlayerEntity player4 = new PlayerEntity(null, "Dhawan", "player4", 15500000.0, null);

		PlayerEntity player5 = new PlayerEntity(null, "Hooda", "player5", 28900000.0, null);
		PlayerEntity player6 = new PlayerEntity(null, "Chahal", "player6", 15500000.0, null);

		return Arrays.asList(player1, player2, player3, player4, player5, player6);

	}

}
