
package com.dnapass.training.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Path;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dnapass.training.entity.UserEntity;

@Service
public class UserService {

	@Autowired
	private EntityManager entityManager;

	public List<UserEntity> findUsersbyNames(List<String> names) {

		CriteriaBuilder cb = entityManager.getCriteriaBuilder();

		CriteriaQuery<UserEntity> query = cb.createQuery(UserEntity.class);

		Root<UserEntity> userRoot = query.from(UserEntity.class);

		Path<String> namePath = userRoot.get("name");

		List<Predicate> predicates = new ArrayList<>();
		for (String name : names) {

			predicates.add((Predicate) cb.like(namePath, name));

		}

		Predicate[] array = (Predicate[]) predicates.toArray(new Predicate[predicates.size()]);

		query.select(userRoot).where(cb.or(array));

		return entityManager.createQuery(query).getResultList();

	}
}
