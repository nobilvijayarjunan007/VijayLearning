package com.dnapass.training.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.dnapass.training.entity.ItemsEntity;


@Repository
public interface ItemsRepo extends JpaRepository<ItemsEntity,Long>{

}
