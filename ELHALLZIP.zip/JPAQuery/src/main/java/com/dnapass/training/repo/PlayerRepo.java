package com.dnapass.training.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.dnapass.training.entity.PlayerEntity;

@Repository
public interface PlayerRepo extends JpaRepository<PlayerEntity, Long> {

	@Query("select p from Player p")
	public List<PlayerEntity> getAllPlayer();

	@Query("SELECT DISTINCT p FROM Player p WHERE p.position =:position AND p.name=:name")
	public PlayerEntity findPlayerByNameAndPositionJPQL(@Param(value = "name") String name,
			@Param(value = "position") String position);

	@Query("SELECT p FROM Player p WHERE p.name=:name")
	public PlayerEntity findPlayerByNameJPQL(@Param(value = "name") String name);

	@Query("SELECT p FROM Player p WHERE p.position =:position")
	public List<PlayerEntity> findPlayersByPositionJPQL(@Param(value ="position") String position);

	@Query("SELECT p FROM Player p WHERE p.salary>=:salary")
	public List<PlayerEntity> findPlayersBySalaryJPQL(@Param(value ="salary") Double salary);

	// >> default Automatic query

	public PlayerEntity findPlayerByNameAndPosition(@Param(value ="name") String name,
			@Param(value = "position") String position);

	public PlayerEntity findPlayerByName(String name);

	public List<PlayerEntity> findPlayersByPosition(String position);

	public List<PlayerEntity> findPlayersBySalary(Double salary);

}
