package com.dnapass.training.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.dnapass.training.entity.UserEntity;

@Repository
public interface UserRepo extends JpaRepository<UserEntity,Long> {

	@Query(value = "select * from Users",nativeQuery = true)
	List<UserEntity> findAllUsers();
	
	@Query(value = "select * from Users u where u.age>=20",nativeQuery = true)
    List<UserEntity> findUsersByAge();
	
	@Query(value = "select count(*) from Users u where u.active=true",nativeQuery = true)
	Long countNumberOfUserActive();
	
	/*
	 * @Query(value =
	 * "select * from Users u where u.name in(user1,user3)",nativeQuery = true)
	 * List<UserEntity> findUsersInName();
	 */
	
	
	
	
}
