package com.dnapass.training.entity;

import java.io.Serializable;
import java.util.List;
import java.util.Objects;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToMany;

@Entity(name = "Player")
public class PlayerEntity implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue
	private Long id;
	private String name;
	private String position;
	private Double salary;
	@ManyToMany(mappedBy = "player", cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	private List<TeamEntity> team;

	public PlayerEntity(Long id, String name, String position, Double salary, List<TeamEntity> team) {
		super();
		this.id = id;
		this.name = name;
		this.position = position;
		this.salary = salary;
		this.team = team;
	}

	public PlayerEntity() {
		super();
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPosition() {
		return position;
	}

	public void setPosition(String position) {
		this.position = position;
	}

	public Double getSalary() {
		return salary;
	}

	public void setSalary(Double salary) {
		this.salary = salary;
	}

	public List<TeamEntity> getTeam() {
		return team;
	}

	public void setTeam(List<TeamEntity> team) {
		this.team = team;
	}

	@Override
	public int hashCode() {
		return Objects.hash(id, name, position, salary, team);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		PlayerEntity other = (PlayerEntity) obj;
		return Objects.equals(id, other.id) && Objects.equals(name, other.name)
				&& Objects.equals(position, other.position) && Objects.equals(salary, other.salary)
				&& Objects.equals(team, other.team);
	}

	/*
	 * @Override public String toString() { return "PlayerEntity [id=" + id +
	 * ", name=" + name + ", position=" + position + ", salary=" + salary +
	 * ", team=" + team + "]"; }
	 */

	@Override
	public String toString() {
		return "PlayerEntity [id=" + id + ", name=" + name + ", position=" + position + ", salary=" + salary+"]";
	}

}
