package com.dnapass.training.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dnapass.training.entity.LeagueEntity;
import com.dnapass.training.repo.LeagueRepo;

@Service
public class LeagueService {

	@Autowired
	private LeagueRepo leaguerepo;

	public List<LeagueEntity> getByName(String name) {

		return leaguerepo.getByName(name);

	}

	public List<LeagueEntity> getByDType(String dType) {

		return leaguerepo.getBydType(dType);

	}

	public List<LeagueEntity> getBySport(String sport) {

		return leaguerepo.getBySport(sport);

	}

}
