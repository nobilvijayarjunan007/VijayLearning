package com.dnapass.training.dataloader;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import com.dnapass.training.entity.CartEntity;
import com.dnapass.training.entity.ItemsEntity;
import com.dnapass.training.entity.LeagueEntity;
import com.dnapass.training.entity.PlayerEntity;
import com.dnapass.training.entity.TeamEntity;

public class DataLoader {

	public static List<CartEntity> newCartEntities() {
		List<CartEntity> cartList = new ArrayList<>();
		Set<ItemsEntity> items = new HashSet<ItemsEntity>();
		items.add(new ItemsEntity(null, "itemname1", 10, 100d));
		items.add(new ItemsEntity(null, "itemname2", 20, 200d));
		items.add(new ItemsEntity(null, "itemname3", 30, 300d));
		cartList.add(new CartEntity(null, items));
		Set<ItemsEntity> items2 = new HashSet<>();
		items2.add(new ItemsEntity(null, "itemname4", 40, 400d));
		items2.add(new ItemsEntity(null, "itemname5", 30, 20d));
		cartList.add(new CartEntity(null, items2));
		return cartList;
	}

	public static List<TeamEntity> newTeam() {

		List<TeamEntity> List = new ArrayList<>();

		TeamEntity team1 = new TeamEntity(null, "Chennai", "CSK", cricketIPLLeague(), cskPlayers());
		TeamEntity team2 = new TeamEntity(null, "Mumbai", "MI", cricketIPLLeague(), miPlayers());

		// team1.setLeague(newLeague());
		// team1.setPlayer(newPlayer());

		TeamEntity team5 = new TeamEntity(null, "Kolkatta", "KKR", cricketODILeague(), null);
		TeamEntity team6 = new TeamEntity(null, "Delhi", "DC", cricketODILeague(), null);

		TeamEntity team3 = new TeamEntity(null, "Bears", "American", null, null);
		TeamEntity team4 = new TeamEntity(null, "villa", "Indian", null, null);

		return Arrays.asList(team1, team2, team3, team4, team5, team6);

	}

	private static LeagueEntity cricketIPLLeague() {

		LeagueEntity leagueEntity = new LeagueEntity(null, " IPL Final", "ICC Match", "Cricket", null);
		return leagueEntity;
	}

	public static LeagueEntity cricketODILeague() {

		LeagueEntity leagueEntity = new LeagueEntity(null, " ICC ODI Final", "ICC Match", "Cricket", null);
		return leagueEntity;
	}

	public static List<PlayerEntity> cskPlayers() {

		PlayerEntity player1 = new PlayerEntity(null, "Dhoni", "Captain", 1000.0, null);
		PlayerEntity player2 = new PlayerEntity(null, "Ruturaj", "Wise-Captain", 750.0, null);

		PlayerEntity player3 = new PlayerEntity(null, "Uthapa", "FirstOffplayer", 500.0, null);
		PlayerEntity player4 = new PlayerEntity(null, "Mooen Ali", "FirstOffplayer", 450.0, null);

		PlayerEntity player5 = new PlayerEntity(null, "Shivam Dube", "SecondOffplayer", 400.0, null);
		PlayerEntity player6 = new PlayerEntity(null, "Thakur", "SecondOffplayer", 400.0, null);

		PlayerEntity player7 = new PlayerEntity(null, "Jedeja", "Spin-Bowler", 450.0, null);
		PlayerEntity player8 = new PlayerEntity(null, "Deepak Chahar", "Fast-Bowler", 500.0, null);

		return Arrays.asList(player1, player2, player3, player4, player5, player6, player7, player8);

	}

	public static List<PlayerEntity> miPlayers() {

		PlayerEntity player1 = new PlayerEntity(null, "Rohit", "Captain", 900.0, null);
		PlayerEntity player2 = new PlayerEntity(null, "Pollard", "Wise-Captain", 700.0, null);

		PlayerEntity player3 = new PlayerEntity(null, "Pandiya", "FirstOffplayer", 670.0, null);
		PlayerEntity player4 = new PlayerEntity(null, "Suryakumar Yadhav", "FirstOffplayer", 155.0, null);

		PlayerEntity player5 = new PlayerEntity(null, "Rahul", "SecondOffplayer", 250.0, null);
		PlayerEntity player6 = new PlayerEntity(null, "Arjun", "SecondOffplayer", 150.0, null);

		PlayerEntity player7 = new PlayerEntity(null, "Tymal", "Spin-Bowler", 500.0, null);
		PlayerEntity player8 = new PlayerEntity(null, "Bumrah", "Fast-Bowler", 700.0, null);

		return Arrays.asList(player1, player2, player3, player4, player5, player6, player7, player8);

	}

}
