package com.dnapass.training.java.se.entity;

import java.util.ArrayList;
import java.sql.Date;
import java.util.List;
import java.text.DateFormat;
import com.dnapass.training.java.se.model.Employee;

public class EmployeeDataLoader {

	
	public static List<EmployeeEntity>  newEmployeeEntityLoader() {
		//EmployeeEntity(Long empId, String empName, String empDept, String empLocation)
		List<EmployeeEntity> empEntity = new ArrayList<EmployeeEntity>();
		
		empEntity.add(new EmployeeEntity(101L,"Vijay Arjunan","Software Engineer","Chennai"));
		empEntity.add(new EmployeeEntity(102L,"Naveen Kumar","Mechanical Engineer","Mumbai"));
		empEntity.add(new EmployeeEntity(103L,"Priya Sundari","Test Engineer","Pune"));
		empEntity.add(new EmployeeEntity(104L,"Kamal Hasan","IT Supporter","Mumbai"));
		return empEntity;
	}
	//Employee(Integer empId, String empName, String empDept, String empLocation, Date empHireDate,
			//Double salary) ;
	public static List<Employee>  newEmployeeModelLoader() {
		
		List<Employee> emp = new ArrayList<Employee>();
		emp.add(new Employee(201,"Emp1","Dept1","Location1",Date.valueOf("04-03-1997"),30000d));
		emp.add(new Employee(202,"Emp2","Dept2","Location2",Date.valueOf("01-09-1998"),35000d));
		emp.add(new Employee(203,"Emp3","Dept3","Location1",Date.valueOf("04-03-1991"),40000d));
		emp.add(new Employee(204,"Emp4","Dept4","Location2",Date.valueOf("04-03-2001"),50000d));
		
		return emp;
	}
	
	
	
}
