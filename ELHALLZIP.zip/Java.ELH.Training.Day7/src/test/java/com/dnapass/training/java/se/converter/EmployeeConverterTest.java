package com.dnapass.training.java.se.converter;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;

import com.dnapass.training.java.se.entity.EmployeeDataLoader;
import com.dnapass.training.java.se.entity.EmployeeEntity;
import com.dnapass.training.java.se.model.Employee;

public class EmployeeConverterTest {

	//EmployeeDataLoader.com.dnapass.training.java.se.entity;
	@Test
	public void test1() {
		 
		List<EmployeeEntity> empEntity=EmployeeDataLoader.newEmployeeEntityLoader();
		
		/*
		 * EmployeeEntity empEntity1=new
		 * EmployeeEntity(101L,"Vijay Arjunan","Software Engineer","Chennai");
		 * EmployeeEntity empEntity2=new
		 * EmployeeEntity(102L,"Naveen Kumar","Mechanical Engineer","Mumbai");
		 * EmployeeEntity empEntity3=new
		 * EmployeeEntity(103L,"Priya Sundari","Test Engineer","Pune"); EmployeeEntity
		 * empEntity4=new EmployeeEntity(104L,"Kamal Hasan","IT Supporter","Mumbai");
		 * 
		 * List<EmployeeEntity> empEntity = new ArrayList<EmployeeEntity>();
		 * empEntity.add(empEntity1); empEntity.add(empEntity2);
		 * empEntity.add(empEntity3); empEntity.add(empEntity4);
		 */
		
		assertEquals(4,EmployeeConverter.convert(empEntity).size());
	
	}
	
	@Test
	public void test2() {
		 
		List<EmployeeEntity> empEntity=EmployeeDataLoader.newEmployeeEntityLoader();
		
		assertEquals(103,EmployeeConverter.convert(new EmployeeEntity(103L,"Priya Sundari","Test Engineer","Pune") ).getEmpId() );
		
	
	}
	
	@Test
	public void test3() {
		 
		List<EmployeeEntity> empEntity=EmployeeDataLoader.newEmployeeEntityLoader();
		
		EmployeeEntity emp1 = new EmployeeEntity(103L,"Priya Sundari","Test Engineer","Pune");
		emp1.setEmpDept("Testing ENGG");
		
		assertEquals("Testing ENGG",emp1.getEmpDept());
	
	}
	
	@Test
	public void test4() {
		 
		List<EmployeeEntity> empEntity=EmployeeDataLoader.newEmployeeEntityLoader();
		
		EmployeeEntity emp1 = new EmployeeEntity(109L,"New Employee","New Engineer","Chennai");
		empEntity.add(emp1);
		
		assertEquals(5,EmployeeConverter.convert(empEntity).size());
	}
	
	//........................................................................................................................................................
	/*
	 * @Test public void test5() { List<EmployeeEntity>
	 * empEntity=EmployeeDataLoader.newEmployeeEntityLoader(); List<Employee>
	 * emp=EmployeeDataLoader.newEmployeeModelLoader();
	 * 
	 * Object[] o1=emp.toArray();
	 * 
	 * assertArrayEquals(o1, EmployeeConverter.convert(empEntity).toArray());
	 * 
	 * }
	 */
	@Test
	public void test6() {
		List<EmployeeEntity> empEntity=EmployeeDataLoader.newEmployeeEntityLoader();
		List<Employee> emp=EmployeeDataLoader.newEmployeeModelLoader();
		
		
		
		assertEquals(4, EmployeeConverter.convertToEntity(emp).size());
		
	}
	
	
	}
