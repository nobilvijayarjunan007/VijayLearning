package com.dnapass.training.day5.exercise;

interface MathOperation{
	int calculate (int var1,int var2);
	
}
public int calculateBinary(int var1,int var2,MathOperation math) {
	return math.calculate(var1, var2);
}

public static void main (String[] args) {
	
	StreamDemo sd = new StreamDemo();
	
	MathOperation add = (var1,var2) -> var1+var2;
	MathOperation sub = (var1,var2) -> var1-var2;
}