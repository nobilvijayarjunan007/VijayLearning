package com.dnapass.training.day5.exercise;

import java.util.stream.Stream;

public class StreamDemo {
	public static void main(String[] args) {
		Stream.of("a6", "a5", "a7").map(s -> s.substring(1)).mapToInt(Integer::parseInt).max()
				.ifPresent(System.out::println);
	}
}
