package com.dnapass.training.day5.exercise;

public class LamdaExpression {
	public static void main(String a[]) {
		String name ="Java";
	}
}
