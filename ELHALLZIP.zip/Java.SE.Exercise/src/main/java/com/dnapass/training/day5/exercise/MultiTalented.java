package com.dnapass.training.day5.exercise;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;

public class MultiTalented implements poet, writer {

	public static void main(String[] args) {

		MultiTalented jhon = new MultiTalented();
		jhon.write();

		String[] stringArray = { "Vivek", "Sheela", "Venu" };
		List<String> stringList = Arrays.asList(stringArray);
		Collections.sort(stringList, (a, b) -> a.compareTo(b));
		System.out.println(stringList);
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

		Stream<String> stream = Stream.of("apple", "orange", "banana", "papaya", "cucumber")
				.filter(str -> str.startsWith("a"));

		stream.anyMatch(str -> true);

		stream.noneMatch(str -> true);

		System.out.println(str);

		// +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//		IntStream.range(1, 4).mapToObj(i -> "x" + i + "").forEach(System.out::println);

		// ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//		Stream<Integer> intSream = Stream.of(1, 2, 3, 4);
//		List<Integer> intList = intSream.collect(Collectors.toList());
//		System.out.println(intList);
//
//		Map<Integer, Integer> intMap = intSream.collect(Collectors.toMap(i -> i, i -> i + 10));
//		System.out.println(intMap);
//		++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

	}
}
