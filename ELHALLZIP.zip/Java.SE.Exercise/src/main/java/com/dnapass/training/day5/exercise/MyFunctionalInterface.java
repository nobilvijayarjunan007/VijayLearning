package com.dnapass.training.day5.exercise;

public interface MyFunctionalInterface {

	public String sayHi();
}
