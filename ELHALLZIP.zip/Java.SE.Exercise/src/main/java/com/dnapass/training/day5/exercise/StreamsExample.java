package com.dnapass.training.day5.exercise;

import java.util.stream.Stream;

public class StreamsExample {
	public static void main(String[] args) {
		Stream.iterate(2, (Integer data) -> data * data).limit(5).forEach(System.out::println);
	}
}
