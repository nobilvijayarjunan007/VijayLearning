package com.dnapass.training.day5.exercise;

public class Main {
	private static int a;

	public static int getId();

	public static void main(String[] args) {
		System.out.println(getId());
	}
}
