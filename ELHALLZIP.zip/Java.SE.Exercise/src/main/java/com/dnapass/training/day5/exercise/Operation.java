package com.dnapass.training.day5.exercise;

public interface Operation {
 void operate(int n);
 boolean equals(Object o);
}
