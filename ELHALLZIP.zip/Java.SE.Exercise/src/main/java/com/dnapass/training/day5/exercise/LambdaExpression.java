package com.dnapass.training.day5.exercise;

public class LambdaExpression {

	public static void main(String[] args) {
		MyFunctionalInterface msg = () -> {

			return "Junit";

		};
		System.out.println(msg.sayHi());
	}

}
