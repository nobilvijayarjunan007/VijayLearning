package com.dnapass.training.day5.exercise;

import java.time.Duration;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.Month;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.stream.Stream;

public class App {

	public static void main(String[] args) {

		/*
		 * String s ="Java"; String n = "SE"; BiFunction sf=(s,n) -> s.concat(n);
		 * 
		 * System.out.println(sf.apply(s,n));
		 */

		List<Integer> listNum = Arrays.asList(1, 2, 3, 4, 5, 6);
		int output = listNum.stream().reduce(0, (total, elet) -> total + elet);
		// +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
		System.out.println(output);
		HashMap<Integer, String> hm = new HashMap<>();
		hm.put(20, "Author-A");
		hm.put(10, "Author-B");
		hm.put(30, "Author-C");

		String b3 = hm.replace(20, "Author-X");
		System.out.println(b3);
		// ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

		// compilation erro
		// Arrays.stream(new int[] { 1, 2, 3 }).map(n -> 2 * n +
		// 1).average().ifPresent(System.out.println(n));

		Arrays.asList("Arvind", "Vaishak", "Sheela").stream().peek(System.out::println)
				.allMatch(s -> s.startsWith("A"));

		final LocalDateTime from = LocalDateTime.of(2020, Month.APRIL, 16, 0, 0, 0);
		final LocalDateTime to = LocalDateTime.of(2019, Month.APRIL, 16, 23, 59, 59);

		final Duration between = Duration.between(from, to);

		System.out.println("DurDay" + between.toDays());
		System.out.println("Durhr" + between.toHours());

//		Stream.of(1.0,2.0,3.0)
//		.mapToInt(Double::IntValue)
//		.mapToObj(i -> "a"+i+"")
//		.forEach(System.out::println);

		LocalTime time1 = LocalTime.of(9, 42, 11);
		LocalTime time2 = time1.minusHours(2);
		LocalTime time3 = time2.minusMinutes(34);
		System.out.println(time1);
		System.out.println(time2);
		System.out.println(time3);
	}

}
