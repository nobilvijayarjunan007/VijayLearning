
  package com.dnapass.training.day5.exercise;
  
  public abstract class Example { private int example ;
  
  public Example(int example) { this.example=example; }
  
  public void example() {
  
  } private void exampleZa() {
  
  }
  
  }
 