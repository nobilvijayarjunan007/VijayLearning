package com.dnapass.training.day1.exercise;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)
@Suite.SuiteClasses({ASCCI_ValueTest.class,AverageTest.class,CalculatorTest.class,FizzBuzzTest.class,
	LargestWordTest.class,MathematicsTest.class,NumberUtilTest.class,PrimeNumberTest.class,SumOfSquareOfEvenNumberTest.class,SwappingTest.class})

public class TestSuiteDay1 {

	
}
