package com.dnapass.training.day1.exercise;

import org.junit.Assert;
import org.junit.Test;

public class SumOfSquareOfEvenNumberTest {

	
	@Test
	public void test1() {
		
		Assert.assertEquals(20,SumOfSquareOfEvenNumber.sumOfSquaresOfEvenDigits(1, 2, 3, 4, 5));
		
	}
	@Test
	public void test2() {
		
		Assert.assertEquals(56,SumOfSquareOfEvenNumber.sumOfSquaresOfEvenDigits(1, 2, 3, 4, 6));
		
	}
}
