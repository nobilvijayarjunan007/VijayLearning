package com.dnapass.training.day1.exercise;

import org.junit.Test;

import junit.framework.Assert;

public class NumberUtilTest {

	@SuppressWarnings("deprecation")
	@Test
	public void test_OfSum1() {

		Assert.assertEquals(43, NumberUtil.problemOne(), 0.01);// -5 + 8 * 6

	}

	@SuppressWarnings("deprecation")
	@Test
	public void test_OfSum2() {

		Assert.assertEquals(1, NumberUtil.problemTwo(), 0.01);// (55+9) % 9

	}

	@SuppressWarnings("deprecation")
	@Test
	public void test_OfSum3() {

		Assert.assertEquals(18.125, NumberUtil.problemThree(), 0.01);// 20 + -3*5 / 8

	}

	@SuppressWarnings("deprecation")
	@Test
	public void test_OfSum4() {

		Assert.assertEquals(13, NumberUtil.problemFour(), 0.01);// 5 + 15 / 3 * 2 - 8 % 3

	}
}
