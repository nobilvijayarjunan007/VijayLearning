package com.dnapass.training.day1.exercise;

import org.junit.Assert;
import org.junit.Test;

public class LargestWordTest {

	@Test
	public void test1() {
		
		Assert.assertEquals("Arjunan",LargestWord.getLargestWord("Vijay Arjunan is working in HCL"));
		
	}
	@Test
	public void test2() {
		
		Assert.assertEquals("VijayArjunan",LargestWord.getLargestWord(" VijayArjunan is working in HCL"));
		
	}
	
}
