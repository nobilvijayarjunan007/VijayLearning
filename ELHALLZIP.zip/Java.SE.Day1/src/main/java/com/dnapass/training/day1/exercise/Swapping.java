package com.dnapass.training.day1.exercise;

/*4. Write a Java program to swap two variables. */
public class Swapping {
	static {
		System.out.println("<<<<  Sorting BY Using Swapping >>>>");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		swap(50, 100);
		swap1(50, 100);
		int[] num = { 2, 55, 23, 8, 11, 999 };
		sort(num);

	}

	public static void swap(int i, int j) {

		int a, b, c;

		c = i;
		a = j;
		b = c;

	}
	public static boolean swap1(int i, int j) {

		boolean bb =false;
		int a,b, c;

		c = i;
		a = j;
		b = c;
		if(a==j||b==c) {
			
			bb=true;
		}
return bb;
	}

	private static void sort(int[] num) {
		System.out.println("Before Sorting");
		for (int number : num) {
			System.out.println(number);
		}
		System.out.println("After Sorting");

		int temp;
		for (int i = 0; i < num.length; i++) {
			for (int j = i; j < num.length; j++) {
				if (num[i] > num[j]) {
					temp = num[i];
					num[i] = num[j];
					num[j] = temp;

				}

			}
			System.out.println(num[i]);

		}

	}

}
