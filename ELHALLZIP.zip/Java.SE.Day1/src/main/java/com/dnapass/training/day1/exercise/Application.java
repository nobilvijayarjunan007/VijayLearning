package com.dnapass.training.day1.exercise;

import java.util.stream.Stream;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Application {

	public static void main(String[] args) {
		SpringApplication.run(Application.class, args);

		String s1 = "abc";
		String s2 = "dfe";
		String s3 = s1.concat(s2.toUpperCase());
		System.out.println(s1 + s2 + s3);

	}

}
