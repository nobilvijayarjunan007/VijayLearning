package com.dnapass.training.day1.exercise;

import java.util.Scanner;

public class Mathematics {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc = new Scanner(System.in);
	       System.out.println("!!We are going to solve the Problems here!!");	
	        System.out.println("Input first number  = ");
			 int a = sc.nextInt();
			System.out.println(" Input Second number = ");
			int b = sc.nextInt();
			
			
			
			 System.out.println("Addition of two numbers >> "+addTwoNumbers(a,b));	
			 System.out.println("Sub of two numbers >> "+subTwoNumbers(a,b) );	
			 System.out.println("MUL of two numbers >> "+mulTwoNumbers(a,b));	
			 System.out.println("DIV of two numbers >> "+divTwoNumbers(a,b));	
			 System.out.println("Modulus of two numbers >> "+modTwoNumbers(a,b));
	}
	public static int modTwoNumbers(int a, int b) {
		return a%b;
		// TODO Auto-generated method stub
		
	}

	public static int divTwoNumbers(int a, int b) {
		return a/b;
		// TODO Auto-generated method stub
		
	}

	public static int mulTwoNumbers(int a, int b) {
		return a*b;
		// TODO Auto-generated method stub
		
	}

	public static int subTwoNumbers(int a, int b) {
		return a-b;
		// TODO Auto-generated method stub
		
	}

	public static int addTwoNumbers(int a, int b) {
		return a+b;
		// TODO Auto-generated method stub
		
	}
}
