package com.dnapass.training.day1.exercise;

import java.util.Scanner;

import org.springframework.util.SystemPropertyUtils;

public class Average {

	/*
	 * 3. Write a Java program that takes three numbers as input to calculate and
	 * print the average of the numbers.
	 */

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.out.println(displayTheAverageOfThreeNumbers(15,15,15));

	}

	public static double displayTheAverageOfThreeNumbers(int a,int b,int c) {
		// TODO Auto-generated method stub
		
		double d = 3;
		Double average = ((a + b + c) / d);

		System.out.println(" Average  = " + average);
		return average;
	}

}
