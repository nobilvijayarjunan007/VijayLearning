package com.dnapass.training.day1.exercise;
import java.util.Arrays;
import java.util.Scanner;
import java.util.Comparator;
public class LargestWord {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
	       
	        System.out.println("Enter the sentence here >> ");
			String sentence = sc.nextLine();
			System.out.println("Enter the sentence here >> ");
			String sentence2 = sc.nextLine();
		String largeWord = getLargestWord(sentence);
		String largestWord = getLargestWord2(sentence2);
		System.out.println(sentence);
		System.out.println("Largest Word is  "+largeWord);
		System.out.println(sentence2);
		System.out.println("Largest Word is  "+largestWord);
	}

	public static  String getLargestWord2(String string) {
		// TODO Auto-generated method stub
				String[] words =string.split(" ");
				ComparatorDemo comp = new ComparatorDemo();
				Arrays.sort(words,comp);
				for(int i=0;i<words.length;i++) { 
					
					
					}
				//System.out.println(words[0]);
				return words[0];
	}

	public static String getLargestWord(String string) {
		// TODO Auto-generated method stub
		String[] words =string.split(" ");
		ComparatorDemo comp = new ComparatorDemo();
		Arrays.sort(words,comp);
		for(int i=0;i<words.length;i++) { 
			
			
			}
		//System.out.println(words[0]);
		return words[0];
	}
	
	
	

}
class ComparatorDemo  implements Comparator{

	public int compare(Object o1, Object o2) {
		// TODO Auto-generated method stub
		
		String s1 =(String)o1;
		String s2 =(String)o2;
		if(s1.length()>s2.length())
			return -1;
		else if(s1.length()<s2.length())
			return 1;
		else
		return 0;
	}

}
