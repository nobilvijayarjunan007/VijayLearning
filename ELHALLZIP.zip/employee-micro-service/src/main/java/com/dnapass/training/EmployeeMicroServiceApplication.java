package com.dnapass.training;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.context.annotation.Bean;

import com.dnapass.training.dataloader.DataLoader;
import com.dnapass.training.entity.EmployeeEntity;
import com.dnapass.training.entity.OfficeEntity;
import com.dnapass.training.repo.EmployeeRepo;
import com.dnapass.training.repo.OfficeRepo;
import com.dnapass.training.service.EmployeeService;

@EnableEurekaClient
@SpringBootApplication
public class EmployeeMicroServiceApplication {

	@Autowired
	private EmployeeService empService;

	@Autowired
	private EmployeeRepo employeeRepo;

	@Autowired
	private OfficeRepo offRepo;

	public static void main(String[] args) {
		SpringApplication.run(EmployeeMicroServiceApplication.class, args);
	}

	// @Bean
	public CommandLineRunner customerRepo2() {

		System.out.println("+++++++++++++++++++++++++++++++++++++++++++++++++++");
		return args -> {
			System.out.println("++++++++++++++++++++Emp Details here!!!+++++++++++++++++++++++++++");
			List<EmployeeEntity> employeesLoader = DataLoader.employeesLoader();
			employeeRepo.saveAll(employeesLoader);

			EmployeeEntity employeeEntity = new EmployeeEntity(null, "Vijay", "Diane", "x5800",
					"dmurphy@classicmodelcars.com", null, "President");
			EmployeeEntity addEmployee = empService.addEmployee(employeeEntity);

			System.out.println("++++++++++++++addEmployee+++++++++++++++" + addEmployee);

		};

	}

	@Bean
	public CommandLineRunner officeRepo2() {

		System.out.println("+++++++++++++++++++++++++++++++++++++++++++++++++++");
		return args -> {
			System.out.println("++++++++++++++++++++Emp Details here!!!+++++++++++++++++++++++++++");
			List<OfficeEntity> offices = DataLoader.office();
			offRepo.saveAll(offices);

			System.out.println("+++++++++++++++++++++++++++++++++++++++++++++++++++");
			OfficeEntity office = new OfficeEntity("off3", "Tokyo", "+81 33 224 5000", "4-1 Kioicho", null,
					"Chiyoda-Ku", "Japan", "102-8578", "Japan");

			empService.addEmployeeOffice(office, 8l);
			System.out.println("+++++++++++++++++++++completed++++++++++++++++++++++++++++++");

		};

	}

}
