package com.dnapass.training.controller;

import static org.assertj.core.api.Assertions.assertThat;

import java.io.IOException;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import org.junit.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.dnapass.training.entity.EmployeeEntity;

import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@RunWith(SpringRunner.class)
@SpringBootTest
@AutoConfigureMockMvc
@Rollback(false)
//@TestInstance(Lifecycle.PER_CLASS)
public class EmployeeControllerIntegrationsTest {
	@Autowired
	private MockMvc mvc;

	@Test
	public void contextLoads() throws Exception {

		assertThat(mvc).isNotNull();
	}

	@Test
	public void getEmployeeList() throws Exception {
		String uri = "/api/employeesList";
		MvcResult mvcResult = mvc.perform(MockMvcRequestBuilders.get(uri).accept(MediaType.APPLICATION_JSON_VALUE))
				.andReturn();

		int status = mvcResult.getResponse().getStatus();
		assertEquals(200, status);
		String content = mvcResult.getResponse().getContentAsString();
		System.out.println("content :: " + content);
		List<EmployeeEntity> empList = mapFromJson(content, new TypeReference<List<EmployeeEntity>>() {
		});
		// assertTrue(empList.size() == 4);

		assertEquals(empList.size(), 1);

	}

	@Test
	public void getOfficeList() throws Exception {
		String uri = "/api/officesList";
		MvcResult mvcResult = mvc.perform(MockMvcRequestBuilders.get(uri).accept(MediaType.APPLICATION_JSON_VALUE))
				.andReturn();

		int status = mvcResult.getResponse().getStatus();
		assertEquals(200, status);
		String content = mvcResult.getResponse().getContentAsString();
		System.out.println("content :: " + content);

	}

	@Test
	public void saveEmployyee() throws Exception {
		String uri = "/api/employees";
		EmployeeEntity employeeEntity = new EmployeeEntity(10l, "Nishi", "Mami", "x101", "mnishi@classicmodelcars.com",
				null, "Sales Rep");
		String inputJson = mapToJson(employeeEntity);
		MvcResult mvcResult = mvc.perform(
				MockMvcRequestBuilders.post(uri).contentType(MediaType.APPLICATION_JSON_VALUE).content(inputJson))
				.andReturn();
		System.out.println("mvcResult>>>>>>>>>>>>>>>>>>>>>>>>>" + mvcResult.getResponse().getStatus());
		int status = mvcResult.getResponse().getStatus();
		System.out.println(">>>>>>>>>>>>>>>>>>>>>>>>>" + status);
		assertEquals(201, status);
		String content = mvcResult.getResponse().getContentAsString();
		System.out.println("content ::>>>>>>>>>>>>>>>>>>>>>>>> " + content);
		EmployeeEntity emp = mapFromJson(content, EmployeeEntity.class);
		assertNotNull(emp);

		System.out.println("employee created :: >>>>>>>>>>>>>>>>>>>>> " + emp);

	}

	@Test
	public void getEmployeeById() throws Exception {
		String uri = "/api/employees/1";
		MvcResult mvcResult = mvc.perform(MockMvcRequestBuilders.get(uri).accept(MediaType.APPLICATION_JSON_VALUE))
				.andReturn();

		int status = mvcResult.getResponse().getStatus();
		System.out.println(status);
		assertEquals(200, status);
		String content = mvcResult.getResponse().getContentAsString();
		System.out.println("content :: >>>>>>>>>>>>getEmployee>>>>>>>>>>>>>>" + content);
		EmployeeEntity employee = mapFromJson2(content, new TypeReference<EmployeeEntity>() {
		});

		System.out.println("getEmp () :: " + employee);
	}

	@Test
	public void getOfficeByName() throws Exception {
		String uri = "/api/employeesOffice/office1";
		MvcResult mvcResult = mvc.perform(MockMvcRequestBuilders.get(uri).accept(MediaType.APPLICATION_JSON_VALUE))
				.andReturn();

		int status = mvcResult.getResponse().getStatus();
		System.out.println(status);
		assertEquals(200, status);
		String content = mvcResult.getResponse().getContentAsString();
		System.out.println("content :: >>>>>>>>>>>>GET Office>>>>>>>>>>>>>>" + content);

	}

	private EmployeeEntity mapFromJson2(String content, TypeReference<EmployeeEntity> typeReference)
			throws JsonMappingException, JsonProcessingException {
		ObjectMapper objectMapper = new ObjectMapper();
		objectMapper.setSerializationInclusion(Include.NON_NULL);
		return objectMapper.readValue(content, typeReference);
	}

	protected String mapToJson(Object obj) throws JsonProcessingException {
		ObjectMapper objectMapper = new ObjectMapper();
		objectMapper.setSerializationInclusion(Include.NON_NULL);
		return objectMapper.writeValueAsString(obj);
	}

	protected <T> T mapFromJson(String Json, Class<T> clazz)
			throws JsonParseException, JsonMappingException, IOException {
		ObjectMapper objectMapper = new ObjectMapper();
		objectMapper.setSerializationInclusion(Include.NON_NULL);
		return objectMapper.readValue(Json, clazz);
	}

	private List<EmployeeEntity> mapFromJson(String content, TypeReference<List<EmployeeEntity>> typeReference)
			throws JsonMappingException, JsonProcessingException {

		ObjectMapper objectMapper = new ObjectMapper();
		objectMapper.setSerializationInclusion(Include.NON_NULL);
		return objectMapper.readValue(content, typeReference);
	}
}
