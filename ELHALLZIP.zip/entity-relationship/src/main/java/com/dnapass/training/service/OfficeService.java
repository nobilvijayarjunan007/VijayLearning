package com.dnapass.training.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dnapass.training.entities.OfficeEntity;
import com.dnapass.training.repo.OfficeRepo;

@Service
public class OfficeService {

	@Autowired
	private OfficeRepo officeRepo;

	public OfficeService(OfficeRepo officeRepo) {
		super();
		this.officeRepo = officeRepo;
	}

	public OfficeService() {
		super();

	}
	public void createAll(List<OfficeEntity> offices) {

		officeRepo.saveAll(offices);

	}

	public void create(OfficeEntity office) {

		officeRepo.save(office);

	}

	public void find(OfficeEntity office) {

		officeRepo.findById(office.getOfficeCode());

	}

	public void delete(OfficeEntity office) {

		officeRepo.delete(office);

	}

	public OfficeEntity update(OfficeEntity office, Long id) {

		Optional<OfficeEntity> office1 = officeRepo.findAll().stream()
				.filter(off -> off.getOfficeCode() == office.getOfficeCode() && off.getCity() == office.getCity())
				.findAny();
		office1.get().setCity("Chennai");

		return office1.get();

	}

}
