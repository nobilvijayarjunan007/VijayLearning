package com.dnapass.training.entities;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "ProductLines")
public class ProductLineEntity implements Serializable {

	private static final long serialVersionUID = 1L;
	@Id
	private String productLine;
	private String textDescription;
	private String htmlDescription;
	private String image;
	@OneToMany(mappedBy = "productLines", cascade = CascadeType.ALL, orphanRemoval = true)
	private List<ProductEntity> Products = new ArrayList<>();

	public ProductLineEntity() {
		super();
	}

	public ProductLineEntity(String productLine, String textDescription, String htmlDescription, String image,
			List<ProductEntity> products) {
		super();
		this.productLine = productLine;
		this.textDescription = textDescription;
		this.htmlDescription = htmlDescription;
		this.image = image;
		Products = products;
	}

	public String getProductLine() {
		return productLine;
	}

	public void setProductLine(String productLine) {
		this.productLine = productLine;
	}

	public String getTextDescription() {
		return textDescription;
	}

	public void setTextDescription(String textDescription) {
		this.textDescription = textDescription;
	}

	public String getHtmlDescription() {
		return htmlDescription;
	}

	public void setHtmlDescription(String htmlDescription) {
		this.htmlDescription = htmlDescription;
	}

	public String getImage() {
		return image;
	}

	public void setImage(String image) {
		this.image = image;
	}

	public List<ProductEntity> getProducts() {
		return Products;
	}

	public void setProducts(List<ProductEntity> products) {
		Products = products;
	}

	@Override
	public int hashCode() {
		return Objects.hash(Products, htmlDescription, image, productLine, textDescription);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ProductLineEntity other = (ProductLineEntity) obj;
		return Objects.equals(Products, other.Products) && Objects.equals(htmlDescription, other.htmlDescription)
				&& Objects.equals(image, other.image) && Objects.equals(productLine, other.productLine)
				&& Objects.equals(textDescription, other.textDescription);
	}

	@Override
	public String toString() {
		return "\nProductLineEntity [" + (productLine != null ? "productLine=" + productLine + ", " : "")
				+ (textDescription != null ? "textDescription=" + textDescription + ", " : "")
				+ (htmlDescription != null ? "htmlDescription=" + htmlDescription + ", " : "")
				+ (image != null ? "image=" + image + ", " : "") + (Products != null ? "Products=" + Products : "")
				+ "]";
	}

}
