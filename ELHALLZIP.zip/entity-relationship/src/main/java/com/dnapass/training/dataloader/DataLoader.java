package com.dnapass.training.dataloader;

import java.util.ArrayList;
import java.util.List;

import com.dnapass.training.models.Customer;
import com.dnapass.training.models.Employee;
import com.dnapass.training.models.Office;
import com.dnapass.training.models.OrderDetails;
import com.dnapass.training.models.Orders;
import com.dnapass.training.models.Payment;
import com.dnapass.training.models.ProductLine;
import com.dnapass.training.models.Products;

public class DataLoader {

	public static void main(String[] args) {

		employeesLoader();
		officeDetailsLoader();
		customersLoader();
		ordersLoader();
		paymentLoader();
		orderDetailsLoader();
		productsLoader();
		productsLinesLoader();

	}

	private static List<ProductLine> productsLinesLoader() {
		List<ProductLine> productLines = new ArrayList<>();
		productLines.add(new ProductLine("Classic Cars",
				"Attention car enthusiasts: Make your wildest car ownership dreams come true. Whether you are looking for classic muscle cars, dream sports cars or movie-inspired miniatures, you will find great choices in this category. These replicas feature superb attention to detail and craftsmanship and offer features such as working steering system, opening forward compartment, opening rear trunk with removable spare wheel, 4-wheel independent spring suspension, and so on. The models range in size from 1:10 to 1:24 scale and include numerous limited edition and several out-of-production vehicles. All models include a certificate of authenticity from their manufacturers and come fully assembled and ready for display in the home or office.",
				null, null));

		productLines.add(new ProductLine("Motorcycles",
				"Our motorcycles are state of the art replicas of classic as well as contemporary motorcycle legends such as Harley Davidson, Ducati and Vespa. Models contain stunning details such as official logos, rotating wheels, working kickstand, front suspension, gear-shift lever, footbrake lever, and drive chain. Materials used include diecast and plastic. The models range in size from 1:10 to 1:50 scale and include numerous limited edition and several out-of-production vehicles. All models come fully assembled and ready for display in the home or office. Most include a certificate of authenticity.",
				null, null));

		productLines.add(new ProductLine("Planes",
				"Unique, diecast airplane and helicopter replicas suitable for collections, as well as home, office or classroom decorations. Models contain stunning details such as official logos and insignias, rotating jet engines and propellers, retractable wheels, and so on. Most come fully assembled and with a certificate of authenticity from their manufacturers.",
				null, null));

		productLines.add(new ProductLine("Ships",
				"The perfect holiday or anniversary gift for executives, clients, friends, and family. These handcrafted model ships are unique, stunning works of art that will be treasured for generations! They come fully assembled and ready for display in the home or office. We guarantee the highest quality, and best value.",
				null, null));

		productLines.add(new ProductLine("Trains",
				"Model trains are a rewarding hobby for enthusiasts of all ages. Whether you\"re looking for collectible wooden trains, electric streetcars or locomotives, you\"ll find a number of great choices for any budget within this category. The interactive aspect of trains makes toy trains perfect for young children. The wooden train sets are ideal for children under the age of 5.",
				null, null));

		productLines.add(new ProductLine("Trucks and Buses",
				"The Truck and Bus models are realistic replicas of buses and specialized trucks produced from the early 1920s to present. The models range in size from 1:12 to 1:50 scale and include numerous limited edition and several out-of-production vehicles. Materials used include tin, diecast and plastic. All models include a certificate of authenticity from their manufacturers and are a perfect ornament for the home and office.",
				null, null));

		productLines.add(new ProductLine("Vintage Cars",
				"Our Vintage Car models realistically portray automobiles produced from the early 1900s through the 1940s. Materials used include Bakelite, diecast, plastic and wood. Most of the replicas are in the 1:18 and 1:24 scale sizes, which provide the optimum in detail and accuracy. Prices range from $30.00 up to $180.00 for some special limited edition replicas. All models include a certificate of authenticity from their manufacturers and come fully assembled and ready for display in the home or office.",
				null, null));
		return productLines;

	}

	private static List<Products> productsLoader() {
		List<Products> products = new ArrayList<>();
		products.add(new Products("S10_1678", "1969 Harley Davidson Ultimate Chopper", "Motorcycles", "1:10",
				"Min Lin Diecast",
				"This replica features working kickstand, front suspension, gear-shift lever, footbrake lever, drive chain, wheels and steering. All parts are particularly delicate due to their precise scale and require special care and attention.",
				"7933", 48.81, 95.70));

		products.add(new Products("S10_1949", "1952 Alpine Renault 1300", "Classic Cars", "1:10",
				"Classic Metal Creations",
				"Turnable front wheels; steering function; detailed interior; detailed engine; opening hood; opening trunk; opening doors; and detailed chassis.",
				"7305", 98.58, 214.30));

		products.add(new Products("S10_2016", "1996 Moto Guzzi 1100i", "Motorcycles", "1:10",
				"Highway 66 Mini Classics",
				"Official Moto Guzzi logos and insignias, saddle bags located on side of motorcycle, detailed engine, working steering, working suspension, two leather seats, luggage rack, dual exhaust pipes, small saddle bag located on handle bars, two-tone paint with chrome accents, superior die-cast detail , rotating wheels , working kick stand, diecast metal with plastic parts and baked enamel finish.",
				"6625", 68.99, 118.94));

		products.add(new Products("S10_4698", "2003 Harley-Davidson Eagle Drag Bike", "Motorcycles", "1:10",
				"Red Start Diecast",
				"Model features, official Harley Davidson logos and insignias, detachable rear wheelie bar, heavy diecast metal with resin parts, authentic multi-color tampo-printed graphics, separate engine drive belts, free-turning front fork, rotating tires and rear racing slick, certificate of authenticity, detailed engine, display stand\r\n, precision diecast replica, baked enamel finish, 1:10 scale model, removable fender, seat and tank cover piece for displaying the superior detail of the v-twin engine",
				"5582", 91.02, 193.66));

		products.add(new Products("S10_4757", "1972 Alfa Romeo GTA", "Classic Cars", "1:10", "Motor City Art Classics",
				"Features include: Turnable front wheels; steering function; detailed interior; detailed engine; opening hood; opening trunk; opening doors; and detailed chassis.",
				"3252", 85.68, 136.00));

		products.add(new Products("S10_4962", "1962 LanciaA Delta 16V", "Classic Cars", "1:10", "Second Gear Diecast",
				"Features include: Turnable front wheels; steering function; detailed interior; detailed engine; opening hood; opening trunk; opening doors; and detailed chassis.",
				"6791", 103.42, 147.74));

		products.add(new Products("S12_1099", "1968 Ford Mustang", "Classic Cars", "1:12", "Autoart Studio Design",
				"Hood, doors and trunk all open to reveal highly detailed interior features. Steering wheel actually turns the front wheels. Color dark green.",
				"68", 95.34, 194.57));

		products.add(new Products("S12_1108", "2001 Ferrari Enzo", "Classic Cars", "1:12", "Second Gear Diecast",
				"Turnable front wheels; steering function; detailed interior; detailed engine; opening hood; opening trunk; opening doors; and detailed chassis.",
				"3619", 95.59, 207.80));

		products.add(new Products("S72_3212", "Pont Yacht", "Ships", "1:72", "Unimax Art Galleries",
				"Measures 38 inches Long x 33 3/4 inches High. Includes a stand.\r\nMany extras including rigging, long boats, pilot house, anchors, etc. Comes with 2 masts, all square-rigged",
				"414", 33.30, 54.60));
		return products;

	}

	private static List<OrderDetails> orderDetailsLoader() {
		List<OrderDetails> orderDetails = new ArrayList<>();

		orderDetails.add(new OrderDetails(10100, "S18_1749", 30, 136.00, 3));

		orderDetails.add(new OrderDetails(10100, "S18_2248", 50, 55.09, 2));

		orderDetails.add(new OrderDetails(10100, "S18_4409", 22, 75.46, 4));

		orderDetails.add(new OrderDetails(10100, "S24_3969", 49, 35.29, 1));

		orderDetails.add(new OrderDetails(10101, "S18_2325", 25, 108.06, 4));

		orderDetails.add(new OrderDetails(10101, "S18_2795", 26, 167.06, 1));

		orderDetails.add(new OrderDetails(10101, "S24_1937", 45, 32.53, 3));

		orderDetails.add(new OrderDetails(10101, "S24_2022", 46, 44.35, 2));

		orderDetails.add(new OrderDetails(10102, "S18_1342", 39, 95.55, 2));

		orderDetails.add(new OrderDetails(10425, "S50_1392", 18, 94.92, 2));

		return orderDetails;

	}

	private static List<Payment> paymentLoader() {

		List<Payment> payments = new ArrayList<>();
		payments.add(new Payment(103, "HQ336336", "2004-10-19", 6066));
		payments.add(new Payment(103, "JM555205", "2003-06-05", 14571));
		payments.add(new Payment(103, "OM314933", "2004-12-18", 1676));
		payments.add(new Payment(112, "BO864823", "2004-12-17", 14191));
		payments.add(new Payment(112, "HQ55022", "2003-06-06", 32641));
		payments.add(new Payment(112, "ND748579", "2004-08-20", 33347));
		payments.add(new Payment(114, "GG31455", "2003-05-20", 45864));
		payments.add(new Payment(114, "MA765515", "2004-12-15", 82261));
		payments.add(new Payment(114, "NP603840", "2003-05-31", 7565));
		payments.add(new Payment(114, "NR27552", "2004-03-10", 44894));
		payments.add(new Payment(496, "MN89921", "2004-12-31", 52166));

		return payments;

	}

	private static List<Orders> ordersLoader() {

		List<Orders> orders = new ArrayList<>();
		orders.add(new Orders(10100, "2003-01-06", "2003-01-13", "2003-01-10", "Shipped", null, 363));

		orders.add(
				new Orders(10101, "2003-01-09", "2003-01-18", "2003-01-11", "Shipped", "Check on availability.", 128));

		orders.add(new Orders(10102, "2003-01-10", "2003-01-18", "2003-01-14", "Shipped", null, 181));

		orders.add(new Orders(10103, "2003-01-29", "2003-02-07", "2003-02-02", "Shipped", null, 121));
		orders.add(new Orders(10104, "2003-01-31", "2003-02-09", "2003-02-01", "Shipped", null, 141));

		orders.add(new Orders(10105, "2003-02-11", "2003-02-21", "2003-02-12", "Shipped", null, 145));

		orders.add(new Orders(10106, "2003-02-17", "2003-02-24", "2003-02-21", "Shipped", null, 278));

		orders.add(new Orders(10107, "2003-02-24", "2003-03-03", "2003-02-26", "Shipped",
				"Difficult to negotiate with customer. We need more marketing materials", 131));

		orders.add(new Orders(10108, "2003-03-03", "2003-03-12", "2003-03-08", "Shipped", null, 385));

		return orders;
	}

	private static List<Customer> customersLoader() {
		List<Customer> customers = new ArrayList<>();

		customers.add(new Customer(103, "Atelier graphique", "Schmitt", "Carine ", "40.32.2555", "54, rue Royale", null,
				"Nantes", null, "44000", "France", 1370, "21000.00"));
		customers.add(new Customer(103, "Atelier graphique", "Schmitt", "Carine ", "40.32.2555", "54, rue Royale", null,
				"Nantes", null, "44000", "France", 1370, "21000.00"));

		customers.add(new Customer(112, "Signal Gift Stores", "King", "Jean", "7025551838", "8489 Strong St.", null,
				"Las Vegas", "NV", "83030", "USA", 1166, "71800.00"));

		customers.add(new Customer(114, "Australian Collectors, Co.", "Ferguson", "Peter", "03 9520 4555",
				"636 St Kilda Road", "Level 3", "Melbourne", "Victoria", "3004", "Australia", 1611, "117300.00"));

		customers.add(new Customer(119, "La Rochelle Gifts", "Labrune", "Janine ", "40.67.8555",
				"67, rue des Cinquante Otages", null, "Nantes", null, "44000", "France", 1370, "118200.00"));

		customers.add(new Customer(496, "Kelly\"s Gift Shop", "Snowden", "Tony", "+64 9 5555500",
				"Arenales 1938 3\"A\"", null, "Auckland  ", null, null, "New Zealand", 1612, "110000.00"));
		return customers;
	}

	public static List<Office> officeDetailsLoader() {
		List<Office> offices = new ArrayList<>();
		offices.add(new Office("1", "San Francisco", "+1 650 219 4782", "100 Market Street", "Suite 300", "CA", "USA",
				"94080", "NA"));

		offices.add(new Office("2", "Boston", "+1 215 837 0825", "1550 Court Place", "Suite 102", "MA", "USA", "02107",
				"NA"));

		offices.add(new Office("3", "NYC", "+1 212 555 3000", "523 East 53rd Street", "apt. 5A", "NY", "USA", "10022",
				"NA"));

		offices.add(new Office("4", "Paris", "+33 14 723 4404", "43 Rue Jouffroy D\"abbans", null, null, "France",
				"75017", "EMEA"));

		offices.add(new Office("5", "Tokyo", "+81 33 224 5000", "4-1 Kioicho", null, "Chiyoda-Ku", "Japan", "102-8578",
				"Japan"));

		offices.add(new Office("6", "Sydney", "+61 2 9264 2451", "5-11 Wentworth Avenue", "Floor #2", null, "Australia",
				"NSW 2010", "APAC"));

		offices.add(new Office("7", "London", "+44 20 7877 2041", "25 Old Broad Street", "Level 7", null, "UK",
				"EC2N 1HN", "EMEA"));

		return offices;
	}

	public static List<Employee> employeesLoader() {

		List<Employee> emps = new ArrayList<>();
		emps.add(new Employee(1002, "Murphy", "Diane", "x5800", "dmurphy@classicmodelcars.com", "1", 0, "President"));

		emps.add(new Employee(1056, "Patterson", "Mary", "x4611", "mpatterso@classicmodelcars.com", "1", 1002,
				"VP Sales"));

		emps.add(new Employee(1076, "Firrelli", "Jeff", "x9273", "jfirrelli@classicmodelcars.com", "1", 1002,
				"VP Marketing"));

		emps.add(new Employee(1088, "Patterson", "William", "x4871", "wpatterson@classicmodelcars.com", "6", 1056,
				"Sales Manager (APAC)"));

		emps.add(new Employee(1102, "Bondur", "Gerard", "x5408", "gbondur@classicmodelcars.com", "4", 1056,
				"Sale Manager (EMEA)"));

		emps.add(new Employee(1143, "Bow", "Anthony", "x5428", "abow@classicmodelcars.com", "1", 1056,
				"Sales Manager (NA)"));

		emps.add(new Employee(1165, "Jennings", "Leslie", "x3291", "ljennings@classicmodelcars.com", "1", 1143,
				"Sales Rep"));

		emps.add(new Employee(1166, "Thompson", "Leslie", "x4065", "lthompson@classicmodelcars.com", "1", 1143,
				"Sales Rep"));

		emps.add(new Employee(1188, "Firrelli", "Julie", "x2173", "jfirrelli@classicmodelcars.com", "2", 1143,
				"Sales Rep"));

		emps.add(new Employee(1216, "Patterson", "Steve", "x4334", "spatterson@classicmodelcars.com", "2", 1143,
				"Sales Rep"));

		emps.add(new Employee(1286, "Tseng", "Foon Yue", "x2248", "ftseng@classicmodelcars.com", "3", 1143,
				"Sales Rep"));

		emps.add(new Employee(1323, "Vanauf", "George", "x4102", "gvanauf@classicmodelcars.com", "3", 1143,
				"Sales Rep"));

		emps.add(new Employee(1337, "Bondur", "Loui", "x6493", "lbondur@classicmodelcars.com", "4", 1102, "Sales Rep"));

		emps.add(new Employee(1370, "Hernandez", "Gerard", "x2028", "ghernande@classicmodelcars.com", "4", 1102,
				"Sales Rep"));

		emps.add(new Employee(1401, "Castillo", "Pamela", "x2759", "pcastillo@classicmodelcars.com", "4", 1102,
				"Sales Rep"));

		emps.add(new Employee(1501, "Bott", "Larry", "x2311", "lbott@classicmodelcars.com", "7", 1102, "Sales Rep"));

		emps.add(new Employee(1504, "Jones", "Barry", "x102", "bjones@classicmodelcars.com", "7", 1102, "Sales Rep"));

		emps.add(new Employee(1611, "Fixter", "Andy", "x101", "afixter@classicmodelcars.com", "6", 1088, "Sales Rep"));

		emps.add(new Employee(1612, "Marsh", "Peter", "x102", "pmarsh@classicmodelcars.com", "6", 1088, "Sales Rep"));

		emps.add(new Employee(1619, "King", "Tom", "x103", "tking@classicmodelcars.com", "6", 1088, "Sales Rep"));

		emps.add(new Employee(1621, "Nishi", "Mami", "x101", "mnishi@classicmodelcars.com", "5", 1056, "Sales Rep"));

		emps.add(new Employee(1625, "Kato", "Yoshimi", "x102", "ykato@classicmodelcars.com", "5", 1621, "Sales Rep"));

		emps.add(new Employee(1702, "Gerard", "Martin", "x2312", "mgerard@classicmodelcars.com", "4", 1102,
				"Sales Rep"));

		return emps;

	}

}
