package com.dnapass.training.entities;

import java.io.Serializable;
import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.JoinColumn;
import javax.persistence.MapsId;
import javax.persistence.OneToOne;

@Entity(name="Payments")
@IdClass(CustomerPaymentKey.class)
public class PaymentEntity implements Serializable {

	private static final long serialVersionUID = 1L;
	// @EmbeddedId
	// private CustomerPaymentKey customerPaymentKey;
	@Id
	@GeneratedValue
	private Integer customerNumber;
	@Id
	@GeneratedValue
	@Column(name = "check_number")
	private Long checkNumber;
	private String paymentDate;
	private Integer amount;
	@OneToOne
	// @MapsId("customerNumberPk")
	//@JoinColumn(name = "customer_Number")
	private CustomerEntity customer;

	public PaymentEntity() {
		super();
	}

	public PaymentEntity(Integer customerNumber, Long checkNumber, String paymentDate, Integer amount,
			CustomerEntity customer) {
		super();
		this.customerNumber = customerNumber;
		this.checkNumber = checkNumber;
		this.paymentDate = paymentDate;
		this.amount = amount;
		this.customer = customer;
	}

	public Integer getCustomerNumber() {
		return customerNumber;
	}

	public void setCustomerNumber(Integer customerNumber) {
		this.customerNumber = customerNumber;
	}

	public Long getCheckNumber() {
		return checkNumber;
	}

	public void setCheckNumber(Long checkNumber) {
		this.checkNumber = checkNumber;
	}

	public String getPaymentDate() {
		return paymentDate;
	}

	public void setPaymentDate(String paymentDate) {
		this.paymentDate = paymentDate;
	}

	public Integer getAmount() {
		return amount;
	}

	public void setAmount(Integer amount) {
		this.amount = amount;
	}

	public CustomerEntity getCustomer() {
		return customer;
	}

	public void setCustomer(CustomerEntity customer) {
		this.customer = customer;
	}

	@Override
	public int hashCode() {
		return Objects.hash(amount, checkNumber, customer, customerNumber, paymentDate);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		PaymentEntity other = (PaymentEntity) obj;
		return Objects.equals(amount, other.amount) && Objects.equals(checkNumber, other.checkNumber)
				&& Objects.equals(customer, other.customer) && Objects.equals(customerNumber, other.customerNumber)
				&& Objects.equals(paymentDate, other.paymentDate);
	}

	@Override
	public String toString() {
		return "\nPaymentEntity [" + (customerNumber != null ? "customerNumber=" + customerNumber + ", " : "")
				+ (checkNumber != null ? "checkNumber=" + checkNumber + ", " : "")
				+ (paymentDate != null ? "paymentDate=" + paymentDate + ", " : "")
				+ (amount != null ? "amount=" + amount + ", " : "") + (customer != null ? "customer=" + customer : "")
				+ "]";
	}

	

}
