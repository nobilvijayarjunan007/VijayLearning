package com.dnapass.training.entities;

import java.io.Serializable;
import java.util.Objects;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.MapsId;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "Orders")
public class OrderEntity implements Serializable{

	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer orderNumber;
	private String orderDate;
	private String requiredDate;
	private String shippedDate;
	private String status;
	private String comments;
	
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "customer_Number")
	private CustomerEntity customer;
	
	@OneToOne(mappedBy = "orders",cascade = CascadeType.ALL,orphanRemoval = true)
	private OrderDetailEntity orderDetails;

	

	public OrderEntity() {
		super();
	}

	public OrderEntity(Integer orderNumber, String orderDate, String requiredDate, String shippedDate, String status,
			String comments, CustomerEntity customer, OrderDetailEntity orderDetails) {
		super();
		this.orderNumber = orderNumber;
		this.orderDate = orderDate;
		this.requiredDate = requiredDate;
		this.shippedDate = shippedDate;
		this.status = status;
		this.comments = comments;
		this.customer = customer;
		this.orderDetails = orderDetails;
	}

	public Integer getOrderNumber() {
		return orderNumber;
	}

	public void setOrderNumber(Integer orderNumber) {
		this.orderNumber = orderNumber;
	}

	public String getOrderDate() {
		return orderDate;
	}

	public void setOrderDate(String orderDate) {
		this.orderDate = orderDate;
	}

	public String getRequiredDate() {
		return requiredDate;
	}

	public void setRequiredDate(String requiredDate) {
		this.requiredDate = requiredDate;
	}

	public String getShippedDate() {
		return shippedDate;
	}

	public void setShippedDate(String shippedDate) {
		this.shippedDate = shippedDate;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public CustomerEntity getCustomer() {
		return customer;
	}

	public void setCustomer(CustomerEntity customer) {
		this.customer = customer;
	}

	public OrderDetailEntity getOrderDetails() {
		return orderDetails;
	}

	public void setOrderDetails(OrderDetailEntity orderDetails) {
		this.orderDetails = orderDetails;
	}

	@Override
	public int hashCode() {
		return Objects.hash(comments, customer, orderDate, orderDetails, orderNumber, requiredDate, shippedDate,
				status);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		OrderEntity other = (OrderEntity) obj;
		return Objects.equals(comments, other.comments) && Objects.equals(customer, other.customer)
				&& Objects.equals(orderDate, other.orderDate) && Objects.equals(orderDetails, other.orderDetails)
				&& Objects.equals(orderNumber, other.orderNumber) && Objects.equals(requiredDate, other.requiredDate)
				&& Objects.equals(shippedDate, other.shippedDate) && Objects.equals(status, other.status);
	}

	@Override
	public String toString() {
		return "\nOrderEntity [orderNumber=" + orderNumber + ", orderDate=" + orderDate + ", requiredDate=" + requiredDate
				+ ", shippedDate=" + shippedDate + ", status=" + status + ", comments=" + comments + ", customer="
				+ customer + ", orderDetails=" + orderDetails + "]";
	}

	

}
