package com.dnapass.training.day5.user;

import org.junit.Assert;
import org.junit.Test;

import com.dnapass.training.day5.contacts.ContactValidator;

public class UserValidator1Test2 {
	@Test
	public void validateName() throws ApplicationException {

		Assert.assertEquals("VijayArjunan", UserValidator1.validateName("VijayArjunan"));

	}

	@Test
	public void validateAge() throws ApplicationException {

		Assert.assertEquals(24, UserValidator1.validateAge(24), 0.0);

	}

	@Test
	public void validateEmailId() throws ApplicationException {

		Assert.assertEquals("vijay_a@hcl.com is valid email id", UserValidator1.validateEmailId("vijay_a@hcl.com"));

	}

	@Test
	public void validateCity() throws ApplicationException {

		Assert.assertEquals("Chennai", UserValidator1.validateCity("Chennai"));

	}

	@Test
	public void validateWork() throws ApplicationException {

		Assert.assertEquals("Engineer", UserValidator1.validateWork("Engineer"));

	}

	@Test
	public void validateAboutMe() throws ApplicationException {
		String aboutMe="Search Console tools and reports help you measure your site's Search traffic and performance, "
				+ "fix issues, and make your site shine in Google Search results Start now Optimize your content with...";
		
		Assert.assertEquals(aboutMe,UserValidator1.validateAboutMe(aboutMe));
		
		
	}
}
