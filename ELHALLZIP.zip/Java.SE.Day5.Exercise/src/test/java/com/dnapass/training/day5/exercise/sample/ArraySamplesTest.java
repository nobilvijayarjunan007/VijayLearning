package com.dnapass.training.day5.exercise.sample;

import org.junit.Test;

import com.dnapass.training.day5.exercise.arraysample.ArraySamples;

import junit.framework.Assert;

public class ArraySamplesTest {

	int[] arr = { 1,2,3,4,5,6,7,8,9,10 };

	@Test
	public void test1() {

		Assert.assertTrue("invalid ", ArraySamples.contains(arr, 6));

	}
	@Test
	public void test2() {

		Assert.assertFalse("invalid ", ArraySamples.contains(arr, -6));

	}
	
	@Test
	public void test3() {

		Assert.assertEquals(5, ArraySamples.average(arr),0.0);

	}

	@Test
	public void test4() {

		int[] num = {20,30,10};
		Assert.assertEquals(20, ArraySamples.average(num),0.0);

	}

}
