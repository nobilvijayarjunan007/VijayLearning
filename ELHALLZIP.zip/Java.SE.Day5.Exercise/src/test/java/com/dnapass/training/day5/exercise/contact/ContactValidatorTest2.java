package com.dnapass.training.day5.exercise.contact;

import org.junit.Assert;
import org.junit.Test;

import com.dnapass.training.day5.contacts.ContactValidator;

import com.dnapass.training.day5.user.ApplicationException;

public class ContactValidatorTest2 {

	@Test
	public void validateName() throws ApplicationException {
		
		Assert.assertEquals("VijayArjunan",ContactValidator.validateName("VijayArjunan"));
		
		
	}
	@Test
	public void validateId() throws ApplicationException {
		
		Assert.assertEquals(123,ContactValidator.validateId(123l),0.0);
		
		
	}
	@Test
	public void validateEmailId() throws ApplicationException {
		
		Assert.assertEquals("vijay_a@hcl.com is valid email id",ContactValidator.validateEmailId("vijay_a@hcl.com"));
		
		
	}
	@Test
	public void validateMobileNumber() throws ApplicationException {
		
		Assert.assertEquals("919003951289 is valid mobile number",ContactValidator.validatePhoneNumber("919003951289"));
		
		
	}
	@Test
	public void validateHomeNumber() throws ApplicationException {
		
		Assert.assertEquals("04449734444 is valid landline number",ContactValidator.validateHomePhoneNumber("04449734444"));
		
		
	}
}
