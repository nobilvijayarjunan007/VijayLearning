package com.dnapass.training.day5.exercise.contact;

import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;

import com.dnapass.training.day5.contacts.ContactValidator;
import com.dnapass.training.day5.user.ApplicationException;


public class ContactValidatorTest {

	@SuppressWarnings("deprecation")
	@Rule
	public ExpectedException exceptionRule = ExpectedException.none();

	@Test
	public void ifNameIsNullNameValidationFail() throws ApplicationException {

		exceptionRule.expectMessage("Name can't be null");
		exceptionRule.expect(ApplicationException.class);

		
		ContactValidator.validateName(null);
	}

	// >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>..


	@Test
	public void ifIdIsNullIdValidationFail() throws ApplicationException {

		exceptionRule.expectMessage("your can't be null");
		exceptionRule.expect(ApplicationException.class);

		ContactValidator.validateId(null);
	}
	//>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>.
	
	
	
	@Test
	public void ifMobileNumberNotMatchPatternMobileNumberValidationFail()  throws ApplicationException{
		
		exceptionRule.expectMessage("your number should be Match to the Mobile number pattern");
		exceptionRule.expect(ApplicationException.class);
		
		ContactValidator.validatePhoneNumber("900395128");
	}
	
	@Test
	public void ifHomePhoneNumberNotMatchPatternMobileNumberValidationFail()  throws ApplicationException{
		
		exceptionRule.expectMessage("your number should be Match to the landline number pattern");
		exceptionRule.expect(ApplicationException.class);
		
		ContactValidator.validatePhoneNumber("044 78787");
	}
	
	
	@Test
	public void ifEmailIdIsNotMatchPatternValidationFail()  throws ApplicationException{
		
		exceptionRule.expectMessage("your email id should be Match to the mail id pattern");
		exceptionRule.expect(ApplicationException.class);
		
		ContactValidator.validatePhoneNumber("900395$128.com");
	}
}
