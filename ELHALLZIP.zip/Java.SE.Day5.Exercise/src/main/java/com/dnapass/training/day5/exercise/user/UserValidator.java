package com.dnapass.training.day5.exercise.user;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


public class UserValidator {
	static Logger logger = LoggerFactory.getLogger(UserValidator.class);
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		UserEntity userEntity = EntityDataLoader.newUserEntity();
		
		logger.info("User Details"+"\n"+userEntity);
		
	}

}
