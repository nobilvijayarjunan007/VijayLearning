package com.dnapass.training.day5.exercise.arraysample;

import java.util.Scanner;

public class NumberArrayUtil {

	public static void main(String[] args) {

		int[] anArray;

		anArray = new int[10];

		System.out.println(anArray.length);

		anArray[0] = 1;
		anArray[1] = 2;
		anArray[2] = 3;

		int i1 = anArray[0];
		System.out.println(i1);

		System.out.println(anArray[1]);
		System.out.println(anArray[2]);
		System.out.println(anArray[3]);
		System.out.println(anArray[3]);
		System.out.println(anArray[4]);
		System.out.println(anArray[5]);

		System.out.println(anArray[6]);
		System.out.println(anArray[7]);
		System.out.println(anArray[8]);
		System.out.println(anArray[9]);

		// >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>.

		int[] anArray1 = { 10, 20, 30, 40, 50, 60, 70, 80, 90, 100 };

		System.out.println(anArray1.length);
		for(int i=0;i<anArray.length;i++) {
		System.out.println(anArray[i]);
		}
		// >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>.

		int n;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the number of Elements yyou want to store:");
		n = sc.nextInt();
		int[] array = new int[n];
		System.out.println("Enter the element of the array");
		for (int i = 0; i <= n - 1; i++) {
			System.out.println("Enter the element : " + i);
			array[i] = sc.nextInt();

		}

		System.out.println("Array Elements are");
		for (int i = 0; i < n; i++) {

			System.out.println(array[i]);
		}
		
		//>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>.
		
		
		

	}

}
