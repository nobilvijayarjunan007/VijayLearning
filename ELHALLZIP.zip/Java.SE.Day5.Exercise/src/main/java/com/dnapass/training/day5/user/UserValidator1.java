package com.dnapass.training.day5.user;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class UserValidator1 {

	static Logger logger = LoggerFactory.getLogger(UserValidator1.class);

	public static String validateName(String name) throws ApplicationException {

		String str = name;
		str = str.trim();
		boolean b = str.isEmpty();
		if (name == null || b || name == "") {

			throw new ApplicationException("Name is should not be null");

		}

		System.out.println(name);
		return name;
	}

	public static int validateAge(int age) throws ApplicationException {

		if (age <= 18 || age >= 150) {

			throw new ApplicationException(

					"age is should not be greater than 150  " + "age should not be less than 18");

		}

		System.out.println(age);

		return age;
	}

	public static String validateEmailId(String email) throws ApplicationException {

		Pattern p = Pattern.compile("^[a-zA-Z0-9+_.-]+@[a-zA-Z0-9.-]+$");
		String result = null;
		Matcher m = p.matcher(email);
		if (m.find()) {
			result = m.group() + " is valid email id";
			System.out.println(result);

		} else {
			throw new ApplicationException("your email id should be Match to the mail id pattern");
		}

		return result;
	}

	public static String validateCity(String city) throws ApplicationException {

		String str = city;
		str = str.trim();
		boolean b = str.isEmpty();
		if (city == null || b || city == "") {

			throw new ApplicationException("city is should not be null");

		}

		System.out.println(city);
		return city;
	}
	public static String validateWork(String work) throws ApplicationException {

		String str = work;
		str = str.trim();
		boolean b = str.isEmpty();
		if (work == null || b || work == "") {

			throw new ApplicationException("work is should not be null");

		}

		System.out.println(work);
		return work;
	}
	public static String validateAboutMe(String aboutMe) throws ApplicationException {

		String str = aboutMe;
		str = str.trim();
		boolean b = str.isEmpty();
		if (aboutMe.length()<=20||aboutMe == null || b || aboutMe == "") {

			throw new ApplicationException("aboutMe is should not be null");

		}

		System.out.println(aboutMe);
		return aboutMe;
	}
}
