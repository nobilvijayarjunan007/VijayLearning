package com.dnapass.training.day5.exercise5;

import java.io.IOException;
import java.util.Scanner;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.dnapass.training.day5.exercise3.MyCalculator;

public class CustomerException{

	static Logger logger = LoggerFactory.getLogger(MyCalculator.class);
	
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub

		Scanner age = new Scanner (System.in);
	      logger.info("Enter your age");
	      int a = age.nextInt();
	      logger.info("Enter you name");
	      String b = age.next();

	  try{  
	     if(a<=19){         
	        throw new InvalidAgeRangeException(a,b);
	     }          
	    }
	    catch(InvalidAgeRangeException ex){
	   
	    
	    logger.info("Your age is " + ex.getAge()+"\n"+ex);
        logger.info("Your name is " + ex.getName());
        logger.info("CustomException: InvalidAgeRangeException  " +"\n"+ex.getStackTrace()+"\n"+ex.getClass());  
	    }
	    finally{
	      System.in.close();  
		
	}

}
}