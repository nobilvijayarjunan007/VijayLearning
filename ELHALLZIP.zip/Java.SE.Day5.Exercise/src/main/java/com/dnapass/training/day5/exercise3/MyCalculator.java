package com.dnapass.training.day5.exercise3;

import java.io.IOException;
import java.util.Scanner;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.dnapass.training.day5.exercise1.FileExceptionHandlings;

public class MyCalculator {

	static Logger logger = LoggerFactory.getLogger(MyCalculator.class);

	public static void main(String[] args) throws Exception {

		try {
			Scanner scan = new Scanner(System.in);
			System.out.println("Enter first number");
			int a = scan.nextInt();
			System.out.println("Enter second number");

			int b = scan.nextInt();
			int result = power(a, b);

			logger.info("result is >> " + result);
		}

		catch (InvaliNumberExcetion ie) {

			logger.info(" "+ie.getMessage());
		} finally {
			System.in.close();
		}

	}

	private static int power(int i, int j) throws Exception {
		if (i >= 1 && j >= 1) {
			int num = (int) Math.pow(i, j);
			return num;
		} else

			throw new InvaliNumberExcetion(i,j);

	}
}
